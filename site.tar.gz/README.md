# 悟理智课 · 中学物理智能备课平台

> 基于 [THU-MAIC/OpenMAIC](https://github.com/THU-MAIC/OpenMAIC) 的场景化课堂范式所做的**中学物理垂直二次开发**：
> 教材知识库 → 教案（生成 / 优化）→ 课件（生成 / 优化）→ 可交互课堂，并把**交互仿真、VR 实验场景、数字人讲解、立体课本**直接生成进课件。

![tech](https://img.shields.io/badge/Python-3.12-3776AB) ![tech](https://img.shields.io/badge/前端-原生%20JS%20%2B%20Canvas-38bdf8) ![tech](https://img.shields.io/badge/依赖-零外部框架-34d399) ![license](https://img.shields.io/badge/license-MIT-green)

---

## 一、这个平台解决什么问题

中学物理教师备一节课，通常要重复四件事：翻教材找重难点、写教案、做 PPT、找实验视频或仿真。平台把这条链路收拢成一个工作台：

| 你的输入 | 平台输出 |
|---|---|
| 选一个教材知识点 + 学情 | 结构化教案（目标 / 重难点 / 六环节过程 / 板书 / 分层作业 / 评价 / 数字人讲稿） |
| 上传一份旧教案 | 8 维度诊断 + 逐项改动说明 + 优化版教案（DOCX） |
| 上传一份教案（DOCX / PDF / TXT / MD） | 解析重难点与学情 → 12~14 页课件（PPTX + 单文件交互 HTML） |
| 上传一份原版 PPT（PPTX） | 认知负荷 / 字号 / 结构 / 闭环诊断 → 重构后的优化版课件 + 诊断报告（DOCX） |
| 上传扫描版 / 纯图 PDF | 本机中文 OCR → 可编辑 DOCX + 可复制文字的 PDF（含一键生成课件） |

生成或优化的课件中，按知识点自动嵌入五类互动场景：

- **交互仿真**：9 个真实物理引擎（抛体、斜面摩擦、滑轮组、凸透镜光路、串并联电路、浮力浮沉、机械波、力的合成、分子热运动）。仿真页带**实验工具条**：记录数据（自动抓取实时读数）、数据表、CSV 导出、重置实验、全屏；任务单可逐条勾选。
- **VR 实验场景**：4 个 360° 环视实验室（力学 / 电学 / 光学 / 磁场），可拖拽视角、准星选中热点、热点朗读
- **物理闯关**：3 个知识游戏（抛体投篮、调焦成像、浮沉判断），把规律变成可通关的操作目标
- **数字人教师**：SVG 数字人（形象重绘：眼镜、教鞭、手势、呼吸/眨眼/口型），浏览器语音合成（zh-CN），支持**音色选择、语速与音调调节**并记忆到本地，字幕随朗读逐字高亮
- **立体课本**：CSS 3D 翻页课本，概念卡 / 公式卡 / 实验卡 / 易错卡

---

## 二、快速开始

```bash
# 环境：Python 3.10+（已在 3.12 验证），无需 Node、无需数据库、无需 API Key
cd physics-studio
python run.py                 # 默认监听 0.0.0.0:8770，启动后会打印局域网地址
# 只允许本机访问：
python run.py --host 127.0.0.1
```

打开浏览器访问 **http://127.0.0.1:8770**，从「课件工坊 → 载入示例教案 → 生成课件」开始体验。

### 让同事/其他设备访问

1. 启动后控制台会打印 `局域网访问：http://<你的IP>:8770`，手机/同事电脑连同一 Wi-Fi 即可打开。
2. 若提示“拒绝了连接请求”：多为 **Windows 防火墙** 拦截。首次启动允许“专用网络”访问，或以管理员身份执行：
   ```powershell
   netsh advfirewall firewall add rule name="PhysCraft 8770" dir=in action=allow protocol=TCP localport=8770
   ```
3. 也请确认路由器未开启“AP 隔离/客户端隔离”。
4. 服务默认无登录认证，请只在可信局域网内开放；公网部署请自行加反向代理与访问控制。

### 给不在同一网络的人访问（公网链接）

双击 **`公网访问.bat`**：脚本会自动准备 `cloudflared` 并创建临时公网链接（`https://xxx.trycloudflare.com`），链接会自动复制到剪贴板。电脑需保持开机，链接在重启后会变化。

需要**固定子域名**但不想买域名？双击 **`固定公网链接(ngrok).bat`**：用免费 ngrok 账号领取一个 `xxx.ngrok-free.app` 固定地址（电脑需开机）。想要 24 小时在线，用项目自带的 `Dockerfile` / `render.yaml` 部署到 Render 免费版，见 [docs/DEPLOY.md](docs/DEPLOY.md)。设置环境变量 `PHYSCRAFT_CODE` 可给公网实例加访问码。

> 本执行环境的 shell 出站网络被禁用，无法代跑隧道；因此公网进程需要在你本机普通窗口里启动。

> 整个平台离线可用：知识库、生成规则、仿真引擎全部内置，不依赖任何云服务与大模型。

---

## 三、界面与流程

### 1. 教材知识库
按 `学段 → 教材 → 章节` 浏览，共 **178 个知识点 / 49 章 / 9 册教材**（人教版初中 8 上、8 下、9 全；高中必修一、二、三与选择性必修一、二、三）。每个知识点包含：

- 重要度 / 难度、核心结论、教学重点、教学难点
- 常见误区（用于自动生成辨析题与数字人讲稿）
- 公式、实验建议、仿真 / VR / 游戏映射
- 一键「用此知识点生成教案」「直接生成课件」

### 2. 教案工坊
- **生成**：选知识点 → 设班级层次（薄弱 / 中等 / 优秀）、前测均分、课时、课型 → 生成六环节教案。
  学情画像会实际改变输出：薄弱班给"降低起点 + 小步子 + 支架"策略与额外基础任务；优秀班压缩讲授、增加开放任务与多解法比较。
- **优化**：上传 `.docx/.txt/.md` → 识别目标、重难点、学情、过程、板书、作业 → 输出诊断分（前 / 后）、问题清单与改动对照。
  已有目标与重难点会被**保留并条目化**，不会覆盖教师原始判断。

### 3. 课件工坊
- **生成 PPT**：上传教案 → 解析出教学重难点与学情 → 匹配教材知识点 → 生成 12~14 页课件（按知识点是否含仿真 / VR / 闯关而定）。
  页面序列：封面 → 学习目标 → 情境导入 → 核心概念 → 规律公式 → 交互仿真 → VR 实验 → 物理闯关 → 数字人难点 → 立体课本 → 例题精讲 → 随堂检测 → 课堂小结 → 分层作业。
- **优化 PPT**：上传 `.pptx` → 逐页解析字数、字号、图片、备注 → 诊断（文字过载 / 字号过小 / 缺可视化 / 缺探究 / 结构缺失 / 比例不符）→ 按教学结构重构，原课件要点迁移进概念页。

### 4. 课堂
播放器逐页运行：数字人朗读讲稿、仿真可操作、VR 可环视、立体课本可翻页、检测题可作答并即时反馈。支持 `← →` 切页、空格重读、全屏。
VR 场景支持**滚轮 / ± 按钮缩放**（FOV 32–92）、**双击或“靠近”飞向最近热点**；物理闯关支持**拖拽瞄准发射、拖动蜡烛/光屏、拖材料入液**，并带连击、星级、最佳参数与偏差提示。

### 4.1 实验库、题库与电子教材（新增）
- **实验库**：人教版初中/高中 66 个测量、探究、演示实验，含器材、步骤、记录表、注意事项、常见错误，可按学段/类型检索，一键生成实验课课件。
- **题库**：140 道题（初中 80 / 高中 60），覆盖选择/填空/计算/实验探究/简答；可按学段、题型、难度检索，查看解析与解题步骤、加入错题本、举一反三（同型题/变式）、数字人讲解，并导出 DOCX/PDF 练习卷。生成课件时，例题与随堂检测优先取自题库。
- **电子教材**：
  - **官方教材**：导入你合法持有的教材 PDF，平台本地保存、逐页渲染，支持在线翻页阅读、原版下载，并在右侧叠加本章重难点与关键知识点（不内置、不分发教材原文）。
  - **知识读本**：按教材目录与课标要点编排的读本，分学段按章节在线阅读，支持下载 DOCX 与可复制文字的 PDF。
- **PDF 工具**（课件工坊第三个标签页）：自动识别文字版/扫描版；扫描版调用 Windows 中文 OCR 转成 DOCX 与可复制 PDF，并可直接生成课件。

### 5. 导出
| 导出物 | 说明 |
|---|---|
| `.pptx` | 可编辑，含矢量图示、教学提示与**每页讲稿备注**；互动页为入口页 |
| `-交互版.html` | **单文件**，内联 CSS / 播放器 / 全部控件，双击即可离线演示 |
| `.docx` | 教案（含师生活动表、板书、分层作业、评价量规） |
| `诊断报告.docx` | 课件诊断分数、问题清单、优化后结构 |

---

## 四、项目结构

```
physics-studio/
├── run.py                      # 启动入口
├── core/
│   ├── kb_junior.json          # 初中教材知识库（人教版 8 上 / 8 下 / 9）
│   ├── kb_senior.json          # 高中教材知识库（必修一/二/三、选必一）
│   ├── kb.py                   # 知识库加载、检索、文本→知识点匹配
│   ├── textparse.py            # DOCX / PPTX / PDF / TXT 解析，教案结构化
│   ├── pdf_extract.py          # 纯标准库 PDF 文本提取（CID / ToUnicode 中文还原）
│   ├── pdf_writer.py           # 纯标准库 PDF 生成（CJK 预定义字体，文字可复制）
│   ├── ocr.py                  # 扫描版 PDF → Windows OCR → DOCX / 可复制 PDF
│   ├── labs.py                 # 实验库加载与检索
│   ├── textbook.py             # 电子教材编排与 DOCX / PDF 导出
│   ├── lessonplan.py           # 教案生成 + 8 维诊断 + 优化（保留原判断）
│   ├── physics_problems.py     # 例题 / 检测题模板（数值可验证）
│   ├── generation.py           # 教案 → 场景 DSL；PPT 诊断与优化
│   ├── pptx_export.py          # PPTX 版式系统、矢量图示、讲稿备注
│   ├── docx_export.py          # 教案 DOCX / 诊断报告 DOCX
│   ├── html_export.py          # 单文件交互课件导出
│   ├── samples_build.py        # 示例教案 / 示例原版 PPT
│   └── server.py               # 标准库 HTTP 服务与 API
├── web/
│   ├── index.html              # 工作台 SPA
│   ├── play.html               # 课堂播放页
│   ├── css/app.css             # 设计系统
│   └── js/
│       ├── app.js / api.js / ui.js
│       ├── player.js           # 场景播放器（应用内 + 离线导出共用）
│       ├── views/              # home / kb / lesson / deck / library / about
│       └── widgets/            # sims-core / sims-extra / vr / game / book3d / avatar
├── docs/                       # 契约、架构、知识库说明
├── samples/                    # 示例教案与原版 PPT
├── tests/                      # 冒烟测试、PPTX 版式自检
└── data/                       # 运行时：data/out/<id>/（课件、教案、导出物）
```

---

## 五、与 OpenMAIC 的对应关系

| OpenMAIC 概念 | 本平台实现 |
|---|---|
| 两阶段生成（Outline → Scenes） | `core/generation.py`：教案解析 → 13 类教学场景序列 |
| 场景 DSL（`@openmaic/dsl`） | 轻量 JSON 场景契约（`cover/objectives/hook/concept/formula/simulation/vr/avatar/book3d/example/quiz/summary/homework/report`） |
| Interactive scene（3D / 仿真 / 游戏） | `PSWidgets` 注册制控件，Canvas 2D 伪 3D 与真实物理引擎 |
| 多智能体教师 / TTS | 数字人控件 + `speechSynthesis` + 逐字讲稿 |
| PPTX / HTML 导出 | `pptx_export.py`（可编辑 + 备注）/ `html_export.py`（单文件离线） |
| 知识库 | 中学物理教材知识库 + 知识点检索 |
| PPTX 导入 | `textparse.py` 逐页解析，用于诊断与结构重排 |

**关于"基于"的说明**：本机 shell 对 GitHub 的直连被 TLS 拦截，无法 `git clone` 上游仓库，因此这里按上游公开的架构文档与源码结构做**独立实现**，没有拷贝上游代码；`docs/CONTRACT.md` 中的控件契约、`core/generation.py` 中的场景 DSL 都按同一范式设计。若要接入上游部署，可在 `core/` 增加一个 OpenMAIC API 适配器（生成接口返回的 scenes 可直接映射到本平台场景类型）。

---

## 六、数据契约（摘要）

```jsonc
// data/out/D.../deck.json
{
  "id": "D...", "kind": "deck",
  "meta": { "title", "pointId", "textbook", "chapter", "duration", "classLevel", "source" },
  "analysis": { "keyPoints": [], "hardPoints": [], "student": {}, "misconceptions": [] },
  "scenes": [
    { "id": "s01", "type": "simulation", "title": "...", "widget": "lens",
      "params": { "f": 10, "u": 30 }, "tasks": ["..."], "narration": "..." }
  ],
  "interactive": { "sim": "lens", "vr": "optics", "avatar": true, "book3d": true }
}
```

API：

```
GET  /api/kb                       知识库树 + 统计
GET  /api/kb/point/:id             知识点详情（含相关知识点）
GET  /api/kb/search?q=             检索
POST /api/lesson/generate          生成教案
POST /api/lesson/optimize          上传教案 → 诊断 + 优化
POST /api/deck/generate            上传教案 → 生成课件
POST /api/deck/from-point          按知识点直接生成
POST /api/deck/from-lesson         由已生成教案生成课件
POST /api/deck/optimize            上传 PPTX → 诊断 + 优化
GET  /api/deck/:id/pptx|html|report
GET  /api/lesson/:id/docx
GET  /api/library
```

上传使用 `application/octet-stream` + `X-Filename` 头（不依赖 multipart），上限 60 MB。

---

## 七、设计取舍

1. **离线优先、可复现**：生成由知识库规则驱动，不接 LLM，保证同一输入同一输出，便于教研组复核。需要润色时可在 `core/llm.py` 接入 OpenAI 兼容模型。
2. **PPT 是可编辑的"骨架"，互动在 HTML**：PowerPoint 无法运行 Canvas/VR，因此 PPT 里互动页做成带任务单的入口页，真正的交互在配套单文件 HTML 与平台课堂里。
3. **数值例题模板化**：例题取自可验证的模板（如 `F浮=ρ液gV排`、`1/f=1/u+1/v`），避免生成"看起来对但算不出"的题目。
4. **优化不覆盖教师判断**：已有目标、重难点保留并条目化，缺失处才按知识库补齐，所有改动逐条列出理由。

## 八、已知限制

- 知识库已覆盖人教版初中与高中主干章节（178 个知识点），按 `kb_*.json` 结构可继续扩充。
- 教案支持 `.docx` / `.pdf` / `.txt` / `.md`。PDF 需为**可复制文字**的版本（Word / PowerPoint / WPS 导出的 PDF 均可）；扫描版或纯图片 PDF 请用「PDF 转 DOCX」工具，走本机 Windows 中文 OCR。
- 内置 OCR 依赖 Windows 10/11 中文 OCR 组件，清晰端正的扫描件识别较好；低分辨率、倾斜、手写批注会有错字，转出的 DOCX 可直接校对修改。
- 不支持 `.doc` / `.ppt` 旧格式，请先另存为 `.docx` / `.pptx`。
- 语音使用操作系统 TTS 音色，不同机器音色不同；无 TTS 时数字人按文本节奏驱动口型。
- 优化 PPT 时保留文字要点与结构，不迁移原文件中的位图素材（诊断中会统计图片数量并给出补图建议）。

## 九、性能说明

- 静态资源启用 **gzip** 与 **ETag/304**，重复打开不再重复下载；CSS/JS 传输体积约为原始的 1/5。
- 移除了卡片与顶栏的大面积 `backdrop-filter`（毛玻璃），只保留抽屉、数据表、声音面板等小面积浮层，滚动与切页更稳。
- 播放器切页时销毁上一个控件（取消 rAF、监听、ResizeObserver），仿真/VR 不会在后台空转。
- 数字人只在需要时朗读；语音列表在打开面板时才枚举。
- 支持 `prefers-reduced-motion`，低性能设备可自动关闭动效。

## 十、测试

```bash
python tests/smoke.py        # 端到端：教案 / 课件 / PPTX / HTML / DOCX / 优化
python tests/test_pdf.py     # PDF 教案：提取、匹配知识点、生成与优化
python tests/test_new_features.py  # OCR 转换 / 电子教材 / 实验库
python tests/test_experiments.py   # 实验库 66 条校验
python tests/test_questions.py     # 题库 140 条校验
python tests/test_kb_full.py       # 初中知识库 80 点校验
python tests/test_kb_senior.py     # 高中知识库 98 点校验
python tests/test_textbook_lib.py  # 官方教材导入与页图渲染
python tests/qa_pptx.py data/test/deck.pptx data/test/deck3.pptx   # 版式自检：越界 / 溢出 / 重叠
```

## 十一、许可

MIT。上游 OpenMAIC 亦为 MIT，架构与交互范式致谢清华大学 MAIC 团队。