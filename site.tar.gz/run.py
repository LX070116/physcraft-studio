#!/usr/bin/env python
"""启动入口：python run.py [--port 8770] [--host 127.0.0.1]"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from core.server import serve  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description="悟理智课 · 中学物理智能备课平台")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8770)
    args = ap.parse_args()
    serve(args.host, args.port)


if __name__ == "__main__":
    main()