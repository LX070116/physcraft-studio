# 部署与公网访问

## 先说明

本平台的服务器运行在**你这台电脑**上。我们所在的执行环境（沙箱）**出站网络被封**（DNS 能解析，但 TCP/TLS 连接会被重置），所以无法从这里直接运行 Cloudflare Tunnel / ngrok 之类的穿透进程。外网隧道必须在**你本机的普通窗口**里运行——下面的一次性脚本就是为此准备的。

## 没有 VPS、没有域名？两条路

固定公网地址一定要落在“某个外部服务”上，完全零账号只能拿到临时链接。没有 VPS/域名时，推荐：

### 路线 1：ngrok 免费固定子域名（最快，电脑保持开机）

固定地址形如 `https://你的名字.ngrok-free.app`，不需要买域名。

1. 注册免费 ngrok 账号（可用邮箱或 GitHub）：<https://dashboard.ngrok.com/signup>
2. 复制 Authtoken：<https://dashboard.ngrok.com/get-started/your-authtoken>
3. 领取一个免费 Static Domain：<https://dashboard.ngrok.com/domains>
4. 双击 **`固定公网链接(ngrok).bat`**，粘贴 Authtoken 和 Static Domain。
5. 成功后会显示并复制固定链接，发给别人即可。

说明：电脑需保持开机、窗口保持运行；免费版带宽有限，适合班级/教研演示。重启电脑后重新双击即可，**域名不变**。

### 路线 2：Render 免费版（24 小时在线，需要 GitHub 账号）

固定地址形如 `https://xxx.onrender.com`，不需要你开机，免费实例会休眠（首次访问慢 30 秒左右）。

1. 注册 GitHub 与 Render（都免费）。
2. 新建一个 GitHub 仓库，把 `physics-studio` 整个文件夹拖进网页上传（保留目录结构）。
3. Render → New → Blueprint → 选择该仓库，会自动读取仓库里的 `render.yaml` 与 `Dockerfile`。
4. 部署完成后得到固定 `https://xxx.onrender.com`。

不需要自定义域名；免费实例磁盘是临时的，重启后生成的课件会丢，但知识库/实验库/题库是内置文件，不受影响。

### 路线 0：零账号

只能用 **`公网访问.bat`** 的临时 `trycloudflare.com` 链接，每次重启会变。

## 方案 A：临时公网链接（最快，1 分钟）

适用：把链接发给同事/朋友临时看，电脑保持开机。

1. 先启动平台：双击 **`启动平台.bat`**（或 `python run.py`）。
2. 双击 **`公网访问.bat`**。
   - 首次会自动安装/下载 `cloudflared`（优先 winget，其次国内镜像），约 1~2 分钟。
   - 成功后窗口会显示：
     ```
     公网地址：https://xxxx-xxxx.trycloudflare.com
     ```
   - 链接会自动复制到剪贴板，并打开浏览器验证。
3. 把链接发给别人，对方直接点开即可。

注意：
- 这是**临时地址**，关闭窗口/重启电脑后会变化；需要重新运行脚本拿新链接。
- 电脑必须保持开机、平台窗口保持运行。
- 免费隧道速度一般，适合演示与试看；正式使用建议方案 B/C。

## 方案 B：永久部署到云平台（需要你的账号）

项目已带 `Dockerfile` 与 `render.yaml`，可一键部署到 Render / Railway / Fly.io 等支持 Docker 的平台。

以 **Render** 为例：

1. 把 `physics-studio/` 推到你的 GitHub 仓库（`Dockerfile`、`render.yaml` 一起提交）。
2. 打开 <https://render.com> → New → Blueprint → 选择该仓库。
3. Render 会读取 `render.yaml`，创建一个 Docker Web Service。
4. 在环境变量里设置访问码（可选但强烈建议）：
   ```
   PHYSCRAFT_CODE=你自己的一串随机字符
   ```
5. 部署完成后会得到 `https://xxx.onrender.com` 这样的固定链接，别人点开即可。

其他平台同理：构建镜像 → 暴露 8770 → 健康检查 `/api/health`。

> 免费实例会休眠、磁盘是临时的：生成的课件/教案在重启后会丢失（知识库、实验库、题库是内置文件，不受影响）。需要长期保存请挂载持久磁盘或改用 VPS。

## 方案 C：自己的服务器 / VPS（推荐长期使用）

```bash
# 服务器上
git clone <你的仓库> physics-studio && cd physics-studio
docker build -t physcraft .
docker run -d --name physcraft -p 8770:8770 \
  -e PHYSCRAFT_CODE='你的访问码' \
  -v $(pwd)/data:/app/data \
  --restart unless-stopped physcraft
```

然后：
- 有域名：用 Nginx/Caddy 反代到 `127.0.0.1:8770` 并配 HTTPS；
- 没有公网 IP：在服务器上跑 `cloudflared tunnel --url http://127.0.0.1:8770`，或用命名隧道绑定域名。

## 安全建议

- 公网暴露前，**务必设置 `PHYSCRAFT_CODE`**。设置后首次访问需要输入访问码，之后 30 天免输。
  - Windows 本机临时验证：`set PHYSCRAFT_CODE=你的码 && python run.py`
  - Docker：`-e PHYSCRAFT_CODE=...`
- 不要在公网暴露且不加访问码的实例：平台没有用户体系，任何拿到链接的人都能生成/删除本机数据。
- 若只是给同一间办公室用，优先用局域网地址，不必上公网。

## 我能帮你做到哪一步

- 已经完成：公网访问脚本、Dockerfile、render.yaml、访问码门禁、健康检查、部署文档。
- 需要你参与的：在本机双击 `公网访问.bat`（因为沙箱不能出站），或把仓库推到你的 GitHub/Render 账号。
- 如果你提供 **VPS 的 SSH 地址与账号**，或 **Cloudflare 账号的 Tunnel Token + 域名**，我可以直接在这台机器上把永久部署也配好（需要你确认授权）。