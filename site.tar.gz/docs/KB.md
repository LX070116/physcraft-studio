# 教材知识库说明

## 1. 文件

| 文件 | 学段 | 覆盖 |
|---|---|---|
| `core/kb_junior.json` | 初中 | 人教版八年级上册（6 章）、八年级下册（6 章）、九年级全一册（5 章） |
| `core/kb_senior.json` | 高中 | 人教版 2019 必修第一册、第二册、第三册、选择性必修第一册 |

当前共 **178 个知识点 / 49 章 / 9 册教材**（初中 80 点 / 22 章；高中 98 点 / 27 章），按人教版目录逐节编排。

## 2. 结构

```jsonc
{
  "stage": "初中",
  "textbooks": [{ "id": "rj-8a", "name": "人教版·八年级上册", "grade": "八年级", "term": "上册" }],
  "chapters":  [{ "id": "c-j8a-5", "textbook": "rj-8a", "no": 5, "title": "第五章 透镜及其应用", "theme": "光学仪器" }],
  "points": [{
    "id": "p-j8a-10",                 // 全局唯一，p- 前缀
    "chapter": "c-j8a-5",
    "title": "凸透镜成像的规律",
    "importance": 3,                  // 1~3，3 为中考高频
    "difficulty": 3,                  // 1~3，3 为教学难点
    "summary": "一句话概括",
    "core": ["核心结论 1", "核心结论 2"],       // 用于概念页与讲稿
    "key": ["教学重点"],                        // 用于重点标注
    "hard": ["教学难点"],                       // 用于难点页
    "misconceptions": ["常见误区"],             // 用于判断题与数字人讲稿
    "formulas": ["1/f = 1/u + 1/v"],            // 用于公式页（符号会自动释义）
    "experiments": ["探究凸透镜成像的规律"],      // 用于探究环节与立体课本
    "sim": "lens",                              // 交互仿真 key，可空
    "vr": "optics",                             // VR 场景 key，可空
    "game": "lens-focus",                       // 知识游戏 key，可空
    "tags": ["凸透镜", "成像规律"]
  }]
}
```

## 3. 字段如何被使用

| 字段 | 用在哪 |
|---|---|
| `title` / `summary` | 教案标题、PPT 封面、课堂讲稿 |
| `core` | 概念页要点、数字人讲稿、立体课本概念卡 |
| `key` / `hard` | 教案重点难点、PPT 标签、数字人难点页 |
| `misconceptions` | 随堂检测判断题（自动生成）、讲稿辨析段、易错卡 |
| `formulas` | 公式页；`generation.SYMBOLS` 会解析符号并给出释义 |
| `experiments` | 探究环节活动、立体课本实验卡、作业拓展 |
| `sim` / `vr` / `game` | 决定课件里挂载哪个交互控件 |
| `tags` | 教案板书与作业的措辞 |

## 4. 新增知识点

1. 在对应 `kb_*.json` 的 `chapters` 里找到章节 id；
2. 往 `points` 里追加一条，`id` 用 `p-<教材>-<序号>`，确保唯一；
3. `sim` / `vr` 只能用已注册的控件 key：

   - 仿真：`projectile` `incline` `pulley` `lens` `circuit` `buoyancy` `wave` `vector` `thermal`
   - VR：`mechanics` `circuit` `optics` `field`
   - 游戏：`projectile-hoop` `lens-focus` `float-sink`

4. 重启服务；`/api/kb` 会自动统计新知识点。

## 5. 新增教材版本

在 `kb_*.json` 的 `textbooks` 里加一册（新的 `id`），再挂章节即可；学段由文件的 `stage` 决定。
如果新增一个学段（如"中职"），把文件加入 `core/kb.py` 的加载列表，并在 `web/js/views/kb.js` 的阶段切换里无需改动（按数据驱动渲染）。

## 6. 匹配规则

上传教案/PPT 时，`kb.pick_for_text()` 按以下权重匹配知识点：

- 标题完整出现：+12
- 章节名出现：+4
- 核心结论 / 重点 / 难点 / 标签中的 4 字以上片段出现：+2
- 公式左端出现：+3

匹配失败时回退到"标题包含"与关键词检索；再失败则提示用户写明课题。

## 7. 质量约定

- 结论必须与现行人教版教材一致；有争议的表述写进 `misconceptions` 而不是 `core`；
- `hard` 写"学生真正卡住的地方"（如"动态变化中像与像距的联动"），不要写"理解某某"这类空话；
- 例题模板在 `core/physics_problems.py`，数值必须能用公式复算（测试脚本会打印答案）。