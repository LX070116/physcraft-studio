# 架构说明

## 1. 总体分层

```
浏览器 SPA（web/）
   │  fetch JSON / 上传二进制
   ▼
HTTP 服务（core/server.py，标准库 ThreadingHTTPServer）
   │
   ├─ 知识库（core/kb_*.json + kb.py）
   ├─ 教案（lessonplan.py → docx_export.py）
   ├─ 课件（generation.py → pptx_export.py / html_export.py）
   ├─ 解析（textparse.py：docx / pptx / txt）
   └─ 存储（data/out/<id>/）
```

没有数据库：一个生成物 = 一个目录，`deck.json` / `plan.json` / `meta.json` + 导出文件。
这样做的好处是备份、迁移、审阅都只是"拷文件夹"，也便于教研组做版本留档。

## 2. 场景 DSL

`generation.build_deck()` 输出：

```jsonc
{
  "id": "D...",
  "meta": { "title", "pointId", "textbook", "chapter", "duration", "classLevel", "source" },
  "analysis": { "keyPoints", "hardPoints", "student", "misconceptions", "formulas", "experiments" },
  "scenes": [ { "id", "type", "title", "kicker", "narration", ... } ],
  "interactive": { "sim", "vr", "game", "avatar", "book3d" }
}
```

`type` 共 14 种，播放器与 PPT 导出各自实现一份渲染：

| type | 播放器 | PPTX |
|---|---|---|
| cover | 大标题 + 轨道装饰 | 标题 + 矢量轨道 |
| objectives | 编号卡片 | 四行目标卡 |
| hook | 情境卡 + 问题卡 | 左情境 / 右问题 |
| concept | 要点 + 公式卡 | 左要点 / 右公式 |
| formula | 公式卡组 | 公式条 + 说明 |
| simulation | 挂载 `PSWidgets[widget]` | 设备框 + 矢量图示 + 任务单 |
| game | 挂载 `game` 控件 | 靶心 + 课堂组织 |
| vr | 挂载 `vr` 控件 | 360 圆环 + 热点示意 |
| avatar | 挂载数字人 + 难点 | 数字人插画 + 难点卡 |
| book3d | 挂载立体课本 | 四张纸卡扇形排布 |
| example | 逐步揭示 | 题目 + 步骤 + 答案框 |
| quiz | 可作答 + 反馈 | 题卡 + 答案写进备注 |
| summary | 三栏 + 出门条 | 三栏 + 出门条 |
| homework | 三层 | 三栏 |
| report | 分数对比 + 问题 | 分数对比 + 清单 |

## 3. 生成链路

### 3.1 教案 → 课件

1. `textparse.parse_bytes()` 抽取全文；
2. `normalize_plan()` 按小标题切段（目标 / 重难点 / 学情 / 过程 / 板书 / 作业）；
3. `plan_signals()` 计算时长、行为动词数、是否分层等信号；
4. `kb.pick_for_text()` 以标题、核心结论、公式左端、章节名做加权匹配；
5. `lessonplan.generate()` 用匹配到的知识点生成完整教案（教师原文目标/重难点覆盖默认值）；
6. `generation.build_deck()` 生成场景序列，互动控件按知识点的 `sim` / `vr` 字段挂载。

### 3.2 课件优化

1. `textparse._pptx_parse()` 逐页取文字、最小字号、图片数、备注；
2. `generation.diagnose_pptx()` 计算 8 项指标 → 分数 + 问题清单；
3. 仍走 `build_deck()`，再把原课件要点池 `_pool_bullets()` 填入概念页；
4. 追加一页 `report` 场景（前后分数、改动清单），并按诊断结果写 `diagnosis`。

### 3.3 教案优化

`optimize_plan()` 不是"重写"，而是**合并**：先诊断，再生成基线，最后用教师原文覆盖目标与重难点，并输出 `diffs`（字段 / 原值 / 新值 / 理由）。

## 4. 前端控件契约

`docs/CONTRACT.md`。要点：零依赖、`PSWidgets[key] = { mount(root, params, ctx) }`、
自带样式（`psw-` 前缀）、`ResizeObserver` + DPR、`destroy()` 清理、深色舞台配色。

播放器通过 `mountWidget()` 挂载；离线导出时同一套 `player.js` + 控件脚本被内联进单文件 HTML。

## 5. PPT 版式系统

- 16:9（13.333 × 7.5 in），深色底 + 两个低对比装饰圆；
- 统一页眉：kicker（11 pt 强调色）/ 标题（32 pt 白）/ 强调短线 / 右侧标签；
- 统一页脚：平台名 + 页码（`01 / 13`）；
- 矢量图示 `motif()`：用 `freeform` 画轨迹、斜面、滑轮、光路、电路、波、矢量、分子；
- 讲稿写入 `notes_slide`，可直接作提词或配音文本。

版式自检 `tests/qa_pptx.py` 会估算每个文本框所需高度，检查溢出、越界与文本框重叠，
CI 中可当作 PPT 的"单元测试"。

## 6. 安全与边界

- 上传走原始字节 + `X-Filename`，服务端做文件名清洗与路径校验；
- 静态文件限制在 `web/` 目录内（`relative_to` 校验，拒绝路径穿越）；
- PPTX/DOCX 解析不执行宏，不落盘临时解压；
- 无外网请求（除可选的 `llm.py`，需显式配置 Key）。