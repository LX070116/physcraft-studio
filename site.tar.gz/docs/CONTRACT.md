# 悟理智课 · 前端控件契约（v1）

所有交互控件都是**零依赖的浏览器脚本**（ES5/ES2017 语法即可，不用 import/export，不用打包器）。
脚本加载后向全局注册：

```js
window.PSWidgets = window.PSWidgets || {};
PSWidgets["projectile"] = {
  title: "斜抛运动",
  defaults: { v0: 20, angle: 45 },
  mount(root, params, ctx) {
    // root: 一个已定位、宽高 100% 的容器 div（position:relative）
    // params: 参数对象（已与 defaults 合并）
    // ctx: { speak(text), motion:boolean, theme:{accent,bg,fg,muted,grid} }
    // 返回 { destroy(), resize(w,h), setParams(p) } 均可选
    return { destroy() {} };
  }
};
```

## 硬性要求

1. **自适应**：容器可能从 320×200 到 1600×900 变化；监听 `ResizeObserver` 或 `window.resize` 重绘。
   用 `devicePixelRatio` 让 canvas 高清（`canvas.width = cssW * dpr`）。
2. **自带样式**：用 `<style>` 注入一次（`data-psw-style="<name>"` 去重），类名统一 `psw-` 前缀，避免污染宿主。
3. **配色**：深色舞台 `#0b1220`，强调色用 `ctx.theme.accent`（默认 `#38bdf8`），文字 `#e2e8f0`，弱化 `#94a3b8`。
   不要使用外部图片、字体、CDN；全部 Canvas/SVG/CSS 绘制。
4. **真实物理**：数值要用真实公式（重力加速度 g=9.8，像素换算写清楚），单位标注在界面上。
5. **可交互**：至少一个滑块/按钮/拖拽，实时反馈；给出读数（示波/表格/数值面板）。
6. **健壮**：`destroy()` 后解绑所有监听与 `requestAnimationFrame`；参数缺失时用 defaults；除零/极端值不得崩溃。
7. **无障碍**：交互元素用 `<button>`/`<input type=range>`，带 `aria-label`；键盘可操作。
8. 不写 `console.log` 噪音；不用 `alert`。

## 控件清单与文件归属

| 文件 | 控件 key | 内容 |
|---|---|---|
| `web/js/widgets/sims-core.js` | `projectile` `incline` `pulley` `lens` `circuit` | 抛体运动、斜面摩擦、滑轮组、凸透镜成像（光路）、串并联电路（欧姆定律） |
| `web/js/widgets/sims-extra.js` | `buoyancy` `wave` `vector` `thermal` | 浮力浮沉、机械波/声波、力的合成、分子热运动 |
| `web/js/widgets/game.js` | `game` | 物理闯关（抛体投篮 / 调焦成像 / 浮沉判断） |
| `web/js/widgets/vr.js` | `vr` | 360° 环视实验室（拖拽视角 + 热点） |
| `web/js/widgets/book3d.js` | `book3d` | 立体课本（CSS 3D 翻页） |
| `web/js/widgets/avatar.js` | `avatar` | 数字人教师（SVG + 口型/眨眼/手势 + TTS 联动） |

## 各控件细节

### sims-core.js
- `projectile`：参数 v0(m/s)、angle(°)、g、可选目标点。绘制轨迹、速度矢量分解、射程/最高点/飞行时间读数；"发射"按钮 + 清空。
- `incline`：倾角 θ、摩擦系数 μ、质量 m；计算 a = g(sinθ − μcosθ)；小车沿斜面运动，显示受力分解（重力/支持力/摩擦力矢量）；μ 超过 tanθ 时静止并提示。
- `pulley`：定/动滑轮组（n=1..3 段绳），物重 G、拉力 F、机械效率 η；动画提升，显示省力倍数与做功。
- `lens`：焦距 f、物距 u、物高 h；三条特殊光线作图，像距 v 由 1/f=1/u+1/v 计算，实像/虚像/放大率标注；u<f 时虚像用虚线。
- `circuit`：电源电压 U、R1、R2、串/并联切换；电流表/电压表示数，每只电阻的功率；导线高亮电流方向（动画小点）。

### sims-extra.js
- `buoyancy`：物体密度 ρ物、液体密度 ρ液、体积 V；浮沉判定与受力（G 与 F浮），液面随排水体积上升；显示浸入比例。
- `wave`：横波 y=A sin(2π(ft − x/λ))，频率 f、振幅 A、波速 v；质点振动与波形传播，可暂停/单步；显示 λ = v/f。
- `vector`：两个力 F1、F2 与夹角 θ，平行四边形/三角形合成，显示合力大小方向与余弦定理计算值。
- `thermal`：容器内分子（N≈120）随温度变化速度分布，碰撞容器壁，温度升高速度增大；显示平均速率。

### vr.js
- 场景用 Canvas 伪 3D 全景：yaw/pitch 拖拽（鼠标 + 触摸 + 方向键），fov 75°，地平线 + 地面网格 + 远处物体。
- `params.scene` 预设：`mechanics`（操场/斜面）、`circuit`（实验室台面）、`optics`（暗室光具座）、`field`（磁场空间）。
- `params.objects`: `[{yaw, pitch, label, desc, kind}]`，在对应方位投影绘制图标+标签；准星对准 ≤6° 时高亮，点击/回车弹出说明卡。
- 顶部指南针（N/E/S/W）与"重置视角"按钮；右下角小地图。
- 暴露 `ctx.speak` 用于热点朗读。

### book3d.js
- 一本可翻的 3D 书：封面 + 内页（右翻），`rotateY` 过渡。左右两侧点击/拖拽翻页，页码指示，键盘 ←→。
- `params.book = {title, subtitle, pages:[{title, blocks:[{type:"p"|"formula"|"list"|"note", text|items}]}]}`；缺省用内置示例。
- 页面纸张质感用 CSS 渐变与阴影，不用图片。

### avatar.js
- SVG 教师形象（半身，含头/眼/眉/嘴/身体/手臂），`say(text)` 时：嘴部按字符节奏开合、轻点头、手势；空闲时眨眼与呼吸。
- 支持 `params:{name, role, lines:[...], voice:{name,rate,pitch,volume}}`；`mount` 返回 `{say, stop, setMood("neutral"|"happy"|"thinking"), setVoice(v), setParams, resize, destroy}`。
- 语音：优先 `window.speechSynthesis`（自动挑中文女声），按句切分以保证韵律；`onboundary` 驱动口型与字幕；通过 `ctx.onProgress(index)` 向宿主回报进度；无语音时按 165ms/字 定时驱动。
- 不使用外部头像图片。

## 测试

用 Node 做语法检查（无 DOM，只查语法）：
`& "C:\Users\LX\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe" --check <file>`

并提供一个 `web/js/widgets/demo.html`（自检页，列出所有控件可切换）——仅由 sims-core 负责人创建一次，其他人不要改。