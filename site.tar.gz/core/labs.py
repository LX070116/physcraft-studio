"""中学物理实验库：加载、筛选、检索。"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from .util import read_json

HERE = Path(__file__).resolve().parent


@lru_cache(maxsize=1)
def _items() -> tuple[dict, ...]:
    data = read_json(HERE / "experiments.json") or {}
    return tuple(data.get("items", []))


def all_items() -> list[dict]:
    return list(_items())


def stats() -> dict:
    items = _items()
    by_stage: dict[str, int] = {}
    by_type: dict[str, int] = {}
    for it in items:
        by_stage[it.get("stage", "其他")] = by_stage.get(it.get("stage", "其他"), 0) + 1
        by_type[it.get("type", "其他")] = by_type.get(it.get("type", "其他"), 0) + 1
    return {"total": len(items), "byStage": by_stage, "byType": by_type}


def query(stage: str = "", typ: str = "", q: str = "") -> list[dict]:
    q = (q or "").strip().lower()
    out = []
    for it in _items():
        if stage and it.get("stage") != stage:
            continue
        if typ and it.get("type") != typ:
            continue
        if q:
            hay = " ".join(
                [
                    it.get("title", ""),
                    it.get("chapter", ""),
                    it.get("purpose", ""),
                    " ".join(it.get("tags", [])),
                    " ".join(it.get("apparatus", [])),
                ]
            ).lower()
            if q not in hay:
                continue
        out.append(it)
    return out


def get(eid: str) -> dict | None:
    for it in _items():
        if it.get("id") == eid:
            return it
    return None


def by_point(pid: str) -> list[dict]:
    return [it for it in _items() if pid in (it.get("points") or [])]