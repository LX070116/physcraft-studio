"""中学物理教材知识库：加载、检索、聚合。"""
from __future__ import annotations

import re
from pathlib import Path

from .util import read_json

HERE = Path(__file__).resolve().parent


class KB:
    def __init__(self) -> None:
        self.textbooks: dict[str, dict] = {}
        self.chapters: dict[str, dict] = {}
        self.points: dict[str, dict] = {}
        self.stages: list[str] = []
        for fn in ("kb_junior.json", "kb_senior.json"):
            data = read_json(HERE / fn) or {}
            stage = data.get("stage", "")
            if stage and stage not in self.stages:
                self.stages.append(stage)
            for tb in data.get("textbooks", []):
                tb["stage"] = stage
                self.textbooks[tb["id"]] = tb
            for ch in data.get("chapters", []):
                ch["stage"] = stage
                ch["textbookId"] = ch.get("textbook")
                self.chapters[ch["id"]] = ch
            for p in data.get("points", []):
                p["stage"] = stage
                point = dict(p)
                ch = self.chapters.get(point.get("chapter", ""), {})
                tb = self.textbooks.get(ch.get("textbook", ""), {})
                point["chapterTitle"] = ch.get("title", "")
                point["textbookName"] = tb.get("name", "")
                point["grade"] = tb.get("grade", "")
                point["theme"] = ch.get("theme", "")
                point.setdefault("core", [])
                point.setdefault("key", [])
                point.setdefault("hard", [])
                point.setdefault("misconceptions", [])
                point.setdefault("formulas", [])
                point.setdefault("experiments", [])
                point.setdefault("tags", [])
                self.points[point["id"]] = point

    # ---------- 查询 ----------
    def point(self, pid: str) -> dict | None:
        return self.points.get(pid)

    def chapters_of(self, textbook_id: str) -> list[dict]:
        chs = [c for c in self.chapters.values() if c.get("textbook") == textbook_id]
        return sorted(chs, key=lambda c: c.get("no", 0))

    def points_of_chapter(self, chapter_id: str) -> list[dict]:
        return [p for p in self.points.values() if p.get("chapter") == chapter_id]

    def tree(self) -> list[dict]:
        out = []
        for stage in self.stages:
            tbs = []
            for tb in self.textbooks.values():
                if tb.get("stage") != stage:
                    continue
                chs = []
                for ch in self.chapters_of(tb["id"]):
                    pts = self.points_of_chapter(ch["id"])
                    chs.append(
                        {
                            "id": ch["id"],
                            "no": ch.get("no"),
                            "title": ch.get("title"),
                            "theme": ch.get("theme"),
                            "points": [
                                {
                                    "id": p["id"],
                                    "title": p["title"],
                                    "importance": p.get("importance", 2),
                                    "difficulty": p.get("difficulty", 2),
                                    "summary": p.get("summary", ""),
                                    "sim": p.get("sim", ""),
                                    "vr": p.get("vr", ""),
                                    "game": p.get("game", ""),
                                }
                                for p in sorted(pts, key=lambda x: x["id"])
                            ],
                        }
                    )
                tbs.append({"id": tb["id"], "name": tb["name"], "grade": tb.get("grade"), "chapters": chs})
            out.append({"stage": stage, "textbooks": tbs})
        return out

    def search(self, q: str, limit: int = 20) -> list[dict]:
        q = (q or "").strip()
        if not q:
            return []
        tokens = [t for t in re.split(r"[\s,，、]+", q) if t]

        def score(p: dict) -> int:
            hay = " ".join(
                [
                    p.get("title", ""),
                    p.get("summary", ""),
                    p.get("chapterTitle", ""),
                    " ".join(p.get("key", [])),
                    " ".join(p.get("hard", [])),
                    " ".join(p.get("tags", [])),
                ]
            )
            s = 0
            for t in tokens:
                if t in p.get("title", ""):
                    s += 10
                if t in hay:
                    s += 3
                    s += hay.count(t)
            return s

        ranked = sorted(self.points.values(), key=lambda p: -score(p))
        return [p for p in ranked if score(p) > 0][:limit]

    def pick_for_text(self, text: str, limit: int = 3) -> list[dict]:
        """根据教案/课件文本匹配最相关的知识点。"""
        text = text or ""
        best: list[tuple[int, dict]] = []
        for p in self.points.values():
            s = 0
            title = p.get("title", "")
            # 去掉“第X章”等修饰后匹配
            core_title = re.sub(r"^.*?[\s　]", "", title)
            for frag in {title, core_title, core_title.replace("的", "")}:
                if frag and frag in text:
                    s += 12
            for kw in p.get("core", []) + p.get("key", []) + p.get("hard", []) + p.get("tags", []):
                for piece in re.split(r"[，。；、（）()：:—\s]+", kw):
                    if len(piece) >= 4 and piece in text:
                        s += 2
            for f in p.get("formulas", []):
                lhs = f.split("=")[0].strip()
                if len(lhs) >= 2 and lhs in text:
                    s += 3
            if p.get("chapterTitle") and p["chapterTitle"] in text:
                s += 4
            if s:
                best.append((s, p))
        best.sort(key=lambda x: (-x[0], x[1]["id"]))
        return [p for _, p in best[:limit]]

    def related(self, pid: str, limit: int = 4) -> list[dict]:
        p = self.points.get(pid)
        if not p:
            return []
        out = []
        for other in self.points.values():
            if other["id"] == pid:
                continue
            s = 0
            if other.get("chapter") == p.get("chapter"):
                s += 5
            s += 2 * len(set(p.get("tags", [])) & set(other.get("tags", [])))
            if s:
                out.append((s, other))
        out.sort(key=lambda x: (-x[0], x[1]["id"]))
        return [o for _, o in out[:limit]]

    def stats(self) -> dict:
        return {
            "points": len(self.points),
            "chapters": len(self.chapters),
            "textbooks": len(self.textbooks),
            "stages": self.stages,
            "simPoints": sum(1 for p in self.points.values() if p.get("sim")),
            "vrPoints": sum(1 for p in self.points.values() if p.get("vr")),
        }


_kb: KB | None = None


def get_kb() -> KB:
    global _kb
    if _kb is None:
        _kb = KB()
    return _kb