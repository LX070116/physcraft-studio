"""悟理智课 · HTTP 服务（标准库实现，无外部依赖）。"""
from __future__ import annotations

import gzip
import hashlib
import json
import mimetypes
import os
import re
import sys
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import docx_export, generation, html_export, labs, lessonplan, netinfo, ocr, pptx_export, questionbank, textparse, textbook, textbook_lib
from .kb import get_kb
from .util import OUT, UPLOADS, new_id, read_json, safe_filename, write_json

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "web"
SAMPLES = ROOT / "samples"
MAX_UPLOAD = 60 * 1024 * 1024
ACCESS_CODE = (os.environ.get("PHYSCRAFT_CODE") or "").strip()


# ---------------------------------------------------------------- 存储
def deck_dir(did: str) -> Path:
    return OUT / did


def save_deck(deck: dict) -> Path:
    d = deck_dir(deck["id"])
    write_json(d / "deck.json", deck)
    inter = deck.get("interactive", {})
    tags = []
    if inter.get("sim"):
        tags.append("交互仿真")
    if inter.get("vr"):
        tags.append("VR 场景")
    if inter.get("game"):
        tags.append("物理闯关")
    if inter.get("avatar") or inter.get("book3d"):
        tags.append("数字人/立体课本")
    meta = {
        "id": deck["id"],
        "kind": "deck",
        "kindLabel": "课件",
        "title": deck["meta"].get("title", ""),
        "subtitle": " · ".join(
            x for x in [deck["meta"].get("textbook", ""), deck["meta"].get("chapter", ""), f"{len(deck.get('scenes', []))} 页"] if x
        ),
        "created": deck["meta"].get("date", ""),
        "tags": tags[:3],
    }
    write_json(d / "meta.json", meta)
    return d


def save_plan(plan: dict) -> Path:
    d = OUT / plan["id"]
    write_json(d / "plan.json", plan)
    write_json(
        d / "meta.json",
        {
            "id": plan["id"],
            "kind": "lesson",
            "kindLabel": "教案",
            "title": plan.get("title", ""),
            "subtitle": " · ".join(x for x in [plan.get("meta", {}).get("textbook", ""), plan.get("meta", {}).get("chapter", ""), f"{plan.get('meta', {}).get('duration', 45)} 分钟"] if x),
            "created": plan.get("meta", {}).get("date", ""),
            "tags": [plan.get("meta", {}).get("style", ""), f"{len(plan.get('objectives', []))} 条目标"],
        },
    )
    return d


def load_any(item_id: str):
    d = OUT / item_id
    if (d / "deck.json").exists():
        return "deck", read_json(d / "deck.json")
    if (d / "plan.json").exists():
        return "lesson", read_json(d / "plan.json")
    return None, None


def library() -> dict:
    decks, lessons = [], []
    for d in OUT.iterdir() if OUT.exists() else []:
        if not d.is_dir():
            continue
        meta = read_json(d / "meta.json")
        if not meta or meta.get("kind") not in ("deck", "lesson"):
            continue
        (decks if meta.get("kind") == "deck" else lessons).append(meta)
    key = lambda m: (m.get("created", ""), m.get("id", ""))
    decks.sort(key=key, reverse=True)
    lessons.sort(key=key, reverse=True)
    return {"decks": decks[:60], "lessons": lessons[:60]}


# ---------------------------------------------------------------- 导出（懒生成 + 缓存）
def ensure_pptx(deck: dict) -> Path:
    p = deck_dir(deck["id"]) / "deck.pptx"
    if not p.exists():
        pptx_export.export_pptx(deck, p)
    return p


def ensure_html(deck: dict) -> Path:
    p = deck_dir(deck["id"]) / "deck.html"
    if not p.exists():
        html_export.export_html(deck, p)
    return p


def ensure_docx(plan: dict) -> Path:
    p = OUT / plan["id"] / "lesson.docx"
    if not p.exists():
        docx_export.export_plan_docx(plan, p)
    return p


# ---------------------------------------------------------------- 处理
class Handler(BaseHTTPRequestHandler):
    server_version = "PhysCraft/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        sys.stderr.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))

    def handle_one_request(self):
        try:
            super().handle_one_request()
        except (ConnectionResetError, BrokenPipeError):
            self.close_connection = True

    # ---------- 基础 ----------
    def _send(self, body: bytes, status=200, ctype="application/octet-stream", extra=None):
        compressible = any(
            k in ctype
            for k in ("text/", "javascript", "json", "svg", "xml")
        ) and len(body) > 1200
        use_gzip = compressible and "gzip" in (self.headers.get("Accept-Encoding") or "")
        if use_gzip:
            body = gzip.compress(body, 5)
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        if use_gzip:
            self.send_header("Content-Encoding", "gzip")
            self.send_header("Vary", "Accept-Encoding")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, status=200):
        self._send(json.dumps(obj, ensure_ascii=False).encode("utf-8"), status, "application/json; charset=utf-8")

    def _err(self, msg, status=400):
        self._json({"error": str(msg)}, status)

    def _file(self, path: Path, download_name: str | None = None, inline=False):
        if not path.exists():
            return self._err("文件不存在", 404)
        ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        data = path.read_bytes()
        etag = hashlib.md5(data).hexdigest()
        cache = "no-cache" if inline or ctype.startswith("text/") else "private, max-age=300"
        if self.headers.get("If-None-Match") == etag:
            self.send_response(304)
            self.send_header("ETag", etag)
            self.send_header("Cache-Control", cache)
            self.end_headers()
            return
        extra = {"ETag": etag, "Cache-Control": cache}
        if download_name:
            disp = "inline" if inline else "attachment"
            extra["Content-Disposition"] = f"{disp}; filename*=UTF-8''{urllib.parse.quote(download_name)}"
        self._send(data, 200, ctype, extra)

    def _body(self) -> bytes:
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_UPLOAD:
            raise ValueError("文件过大（上限 60 MB）")
        return self.rfile.read(n) if n else b""

    def _upload(self) -> tuple[str, bytes]:
        raw = self.headers.get("X-Filename") or "upload.bin"
        name = urllib.parse.unquote(raw)
        return safe_filename(name), self._body()

    # ---------- GET ----------
    def _gate(self, path: str) -> bool:
        """可选的访问码门禁（设置 PHYSCRAFT_CODE 后生效）。"""
        if not ACCESS_CODE or path == "/api/health":
            return True
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        if (q.get("code") or [""])[0] == ACCESS_CODE:
            cookie = hashlib.sha256(ACCESS_CODE.encode("utf-8")).hexdigest()
            rest = urllib.parse.urlencode({k: v[0] for k, v in q.items() if k != "code"})
            loc = u.path + (("?" + rest) if rest else "")
            self.send_response(302)
            self.send_header("Location", loc)
            self.send_header("Set-Cookie", f"pscode={cookie}; Path=/; Max-Age=2592000; SameSite=Lax")
            self.end_headers()
            return False
        cookies = {}
        for part in (self.headers.get("Cookie") or "").split(";"):
            if "=" in part:
                k, v = part.split("=", 1)
                cookies[k.strip()] = v.strip()
        if cookies.get("pscode") == hashlib.sha256(ACCESS_CODE.encode("utf-8")).hexdigest():
            return True
        body = (
            "<!doctype html><meta charset='utf-8'><title>访问验证</title>"
            "<style>body{background:#0b1220;color:#e8eff9;font-family:sans-serif;display:grid;place-items:center;height:100vh}"
            "form{background:#121d30;padding:28px 32px;border-radius:14px;border:1px solid #253855}"
            "input{width:240px;padding:9px 12px;border-radius:8px;border:1px solid #253855;background:#0a111c;color:#fff}"
            "button{margin-top:12px;padding:9px 16px;border:0;border-radius:8px;background:#38bdf8;font-weight:700;cursor:pointer}"
            "p{color:#8fa3bf;font-size:13px}</style>"
            "<form method='get'><h2>悟理智课</h2><p>请输入访问码</p>"
            "<input name='code' autofocus /><br><button>进入</button></form>"
        ).encode("utf-8")
        self._send(body, 401, "text/html; charset=utf-8")
        return False

    def do_GET(self):
        try:
            u = urllib.parse.urlparse(self.path)
            path = urllib.parse.unquote(u.path)
            q = urllib.parse.parse_qs(u.query)
            if path == "/api/health":
                return self._json({"ok": True, "code": bool(ACCESS_CODE)})
            if not self._gate(path):
                return

            if path in ("/", "/index.html"):
                return self._file(WEB / "index.html", inline=True)
            if path.startswith("/play/"):
                return self._file(WEB / "play.html", inline=True)
            if path.startswith("/api/"):
                return self.api_get(path, q)
            return self.static(path)
        except Exception as e:
            traceback.print_exc()
            self._err(f"服务异常：{e}", 500)

    def static(self, path: str):
        rel = path.lstrip("/")
        target = (WEB / rel).resolve()
        try:
            target.relative_to(WEB.resolve())
        except ValueError:
            return self._err("非法路径", 403)
        if not target.exists() or target.is_dir():
            return self._err("Not Found", 404)
        self._file(target, inline=True)

    def api_get(self, path: str, q: dict):
        kb = get_kb()
        if path == "/api/kb":
            return self._json({"tree": kb.tree(), "stats": kb.stats()})
        if path == "/api/kb/search":
            query = (q.get("q") or [""])[0]
            res = kb.search(query, 12)
            return self._json({"results": res})
        m = re.match(r"^/api/kb/point/([\w-]+)$", path)
        if m:
            p = kb.point(m.group(1))
            if not p:
                return self._err("知识点不存在", 404)
            out = dict(p)
            out["related"] = [{"id": r["id"], "title": r["title"]} for r in kb.related(p["id"])]
            return self._json(out)
        if path == "/api/labs":
            stage = (q.get("stage") or [""])[0]
            typ = (q.get("type") or [""])[0]
            word = (q.get("q") or [""])[0]
            return self._json({"items": labs.query(stage, typ, word), "stats": labs.stats()})
        m = re.match(r"^/api/labs/([\w-]+)$", path)
        if m:
            it = labs.get(m.group(1))
            if not it:
                return self._err("实验不存在", 404)
            return self._json(it)
        if path == "/api/textbook":
            return self._json({"stages": [textbook.build(s) for s in ("初中", "高中")]})
        m = re.match(r"^/api/textbook/(初中|高中)(?:/(docx|pdf))?$", path)
        if m:
            stage, fmt = m.group(1), m.group(2)
            if not fmt:
                return self._json(textbook.build(stage))
            d = OUT / ("book-" + ("junior" if stage == "初中" else "senior"))
            d.mkdir(parents=True, exist_ok=True)
            if fmt == "docx":
                fp = d / "textbook.docx"
                if not fp.exists():
                    textbook.export_docx(stage, fp)
                return self._file(fp, f"{stage}物理-电子教材.docx")
            fp = d / "textbook.pdf"
            if not fp.exists():
                textbook.export_pdf(stage, fp)
            return self._file(fp, f"{stage}物理-电子教材.pdf")
        if path == "/api/questions":
            return self._json(
                {
                    "items": questionbank.query(
                        q.get("stage", [""])[0],
                        q.get("type", [""])[0],
                        q.get("difficulty", [""])[0],
                        q.get("point", [""])[0],
                        q.get("q", [""])[0],
                        int(q.get("limit", ["0"])[0] or 0),
                        int(q.get("offset", ["0"])[0] or 0),
                    ),
                    "stats": questionbank.stats(),
                }
            )
        if path == "/api/questions/export":
            ids = [x for x in (q.get("ids", [""])[0] or "").split(",") if x]
            fmt = (q.get("format", ["docx"])[0] or "docx").lower()
            picked = [x for x in (questionbank.get(i) for i in ids) if x]
            if not picked:
                return self._err("请先选择试题", 400)
            tmp = OUT / "exports"
            tmp.mkdir(parents=True, exist_ok=True)
            name = "物理练习-" + str(len(picked)) + "题"
            if fmt == "pdf":
                fp = questionbank.export_pdf(picked, tmp / (name + ".pdf"), name)
            else:
                fp = questionbank.export_docx(picked, tmp / (name + ".docx"), name)
            return self._file(fp, name + fp.suffix)

        m = re.match(r"^/api/questions/([\w-]+)/(explain|similar)$", path)
        if m:
            qid, act = m.group(1), m.group(2)
            if act == "explain":
                data = questionbank.explain(qid)
            else:
                data = {"items": questionbank.similar(qid, 3)}
            if not data:
                return self._err("试题不存在", 404)
            return self._json(data)
        m = re.match(r"^/api/questions/([\w-]+)$", path)
        if m:
            q0 = questionbank.get(m.group(1))
            if not q0:
                return self._err("试题不存在", 404)
            return self._json(q0)
        if path == "/api/textbook/library":
            return self._json({"books": textbook_lib.list_books()})
        m = re.match(r"^/api/textbook/file/([\w-]+)$", path)
        if m:
            fp = textbook_lib.pdf_path(m.group(1))
            if not fp:
                return self._err("教材不存在", 404)
            meta = textbook_lib.get(m.group(1)) or {}
            return self._file(fp, (meta.get("title") or "教材") + ".pdf", inline=True)
        m = re.match(r"^/api/textbook/page/([\w-]+)/(\d+)$", path)
        if m:
            pp = textbook_lib.page_path(m.group(1), int(m.group(2)))
            if not pp:
                return self._err("页图不存在", 404)
            return self._file(pp)
        if path == "/api/network":
            port = int(server_address_port(self) or 8770)
            return self._json(netinfo.info(port))
        if path == "/api/library":
            return self._json(library())

        m = re.match(r"^/api/deck/([\w-]+)(?:/(pptx|html|report))?$", path)
        if m:
            did, what = m.group(1), m.group(2)
            kind, obj = load_any(did)
            if kind != "deck":
                return self._err("课件不存在", 404)
            if not what:
                return self._json(obj)
            deck = obj
            if what == "pptx":
                p = ensure_pptx(deck)
                return self._file(p, f"{deck['meta'].get('title','课件')}.pptx")
            if what == "html":
                p = ensure_html(deck)
                return self._file(p, f"{deck['meta'].get('title','课件')}-交互版.html")
            if what == "report":
                diag = deck.get("diagnosis")
                if not diag:
                    return self._err("该课件不是由 PPT 优化生成的，没有诊断报告", 400)
                p = deck_dir(did) / "report.docx"
                if not p.exists():
                    docx_export.export_report_docx(diag, deck, p)
                return self._file(p, f"诊断报告-{deck['meta'].get('title','')}.docx")

        m = re.match(r"^/api/lesson/([\w-]+)(?:/(docx))?$", path)
        if m:
            lid, what = m.group(1), m.group(2)
            kind, obj = load_any(lid)
            if kind != "lesson":
                return self._err("教案不存在", 404)
            if not what:
                return self._json({"id": lid, "plan": obj})
            p = ensure_docx(obj)
            return self._file(p, f"{obj.get('title','教案')}.docx")

        if path == "/api/sample/lesson":
            from .samples_build import ensure_samples

            ensure_samples()
            return self._file(SAMPLES / "示例教案-凸透镜成像.docx", "示例教案-凸透镜成像.docx")
        if path == "/api/sample/lesson-pdf":
            from .samples_build import ensure_samples

            ensure_samples()
            p = SAMPLES / "示例教案-凸透镜成像.pdf"
            if not p.exists():
                return self._err("示例 PDF 未生成（需要本机安装 Office 才能自动生成），请直接上传你的 PDF", 404)
            return self._file(p, "示例教案-凸透镜成像.pdf")
        if path == "/api/sample/scanned-pdf":
            p = SAMPLES / "示例教案-扫描版.pdf"
            if not p.exists():
                return self._err("示例扫描版 PDF 不存在", 404)
            return self._file(p, "示例教案-扫描版.pdf")
        if path == "/api/sample/pptx":
            from .samples_build import ensure_samples

            ensure_samples()
            return self._file(SAMPLES / "示例-凸透镜成像(原版).pptx", "示例-凸透镜成像(原版).pptx")

        m = re.match(r"^/api/tools/([\w-]+)(?:/(docx|pdf|txt))?$", path)
        if m:
            tid, what = m.group(1), m.group(2)
            d = OUT / tid
            if not (d / "meta.json").exists():
                return self._err("转换结果不存在", 404)
            if not what:
                return self._json(read_json(d / "meta.json") or {})
            names = {"docx": ("converted.docx", "转换结果.docx"), "pdf": ("converted.pdf", "转换结果-可复制.pdf"), "txt": ("converted.txt", "转换结果.txt")}
            fn, label = names[what]
            p = d / fn
            if not p.exists():
                return self._err("该格式未生成", 404)
            return self._file(p, label)

        return self._err("接口不存在", 404)

    # ---------- POST ----------
    def do_POST(self):
        try:
            path = urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
            if not self._gate(path):
                return
            return self.api_post(path)
        except ValueError as e:
            self._err(str(e), 400)
        except Exception as e:
            traceback.print_exc()
            self._err(f"处理失败：{e}", 500)

    def api_post(self, path: str):
        kb = get_kb()
        if path == "/api/lesson/generate":
            data = json.loads(self._body() or b"{}")
            point_ids = data.get("pointIds") or []
            if not point_ids and data.get("q"):
                hits = kb.search(data["q"], 1) or kb.pick_for_text(data["q"], 1)
                point_ids = [hits[0]["id"]] if hits else []
            plan = lessonplan.generate(point_ids, data.get("profile") or {}, {"duration": data.get("duration"), "style": data.get("style")})
            save_plan(plan)
            return self._json({"id": plan["id"], "plan": plan})

        if path == "/api/lesson/optimize":
            name, body = self._upload()
            parsed = textparse.parse_bytes(name, body)
            res = lessonplan.optimize_plan(parsed["text"])
            plan = res["plan"]
            save_plan(plan)
            (OUT / plan["id"] / "source").mkdir(parents=True, exist_ok=True)
            (OUT / plan["id"] / "source" / name).write_bytes(body)
            return self._json({"id": plan["id"], "plan": plan, "diagnosis": res["diagnosis"]})

        if path == "/api/deck/generate":
            name, body = self._upload()
            parsed = textparse.parse_bytes(name, body)
            if parsed["kind"] not in ("docx", "text", "pdf"):
                raise ValueError("请上传教案文件（.docx / .pdf / .txt / .md）")
            deck = generation.deck_from_lesson_text(parsed["text"], {"fileName": name}, {})
            save_deck(deck)
            (OUT / deck["id"] / "source").mkdir(parents=True, exist_ok=True)
            (OUT / deck["id"] / "source" / name).write_bytes(body)
            return self._json(deck)

        if path == "/api/deck/from-point":
            data = json.loads(self._body() or b"{}")
            point = None
            if data.get("pointId"):
                point = kb.point(data["pointId"])
            if point is None and data.get("q"):
                point = kb.point(str(data["q"]).strip())
            if point is None:
                q = (data.get("q") or "").strip()
                hits = kb.search(q, 1) or kb.pick_for_text(q, 1)
                if hits:
                    point = hits[0]
                else:
                    for p in kb.points.values():
                        if q and (q in p["title"] or p["title"] in q):
                            point = p
                            break
            if not point:
                raise ValueError("未找到匹配的知识点，请输入更准确的名称")
            plan = lessonplan.generate([point["id"]], {"classLevel": data.get("classLevel") or "中等"}, {"duration": data.get("duration") or 45})
            deck = generation.build_deck(plan)
            save_deck(deck)
            return self._json(deck)

        if path == "/api/deck/from-lesson":
            data = json.loads(self._body() or b"{}")
            lid = data.get("lessonId")
            kind, plan = load_any(lid or "")
            if kind != "lesson":
                raise ValueError("教案不存在")
            deck = generation.build_deck(plan)
            save_deck(deck)
            return self._json(deck)

        if path == "/api/deck/optimize":
            name, body = self._upload()
            parsed = textparse.parse_bytes(name, body)
            if parsed["kind"] != "pptx":
                raise ValueError("请上传 .pptx 文件")
            res = generation.optimize_deck(parsed, {"fileName": name}, {})
            deck = res["deck"]
            save_deck(deck)
            (OUT / deck["id"] / "source").mkdir(parents=True, exist_ok=True)
            (OUT / deck["id"] / "source" / name).write_bytes(body)
            return self._json(res)

        if path == "/api/textbook/upload":
            name, body = self._upload()
            title = urllib.parse.unquote(self.headers.get("X-Title") or Path(name).stem)
            book_id = urllib.parse.unquote(self.headers.get("X-Book-Id") or "")
            stage = urllib.parse.unquote(self.headers.get("X-Stage") or "")
            meta = textbook_lib.save(body, title, book_id, stage)
            return self._json(meta)

        if path == "/api/tools/pdf-convert":
            name, body = self._upload()
            if not name.lower().endswith(".pdf"):
                raise ValueError("请上传 PDF 文件")
            tid = new_id("T")
            info = ocr.convert_pdf(body, OUT / tid, title=Path(name).stem)
            return self._json(info)

        if path == "/api/deck/from-tool":
            data = json.loads(self._body() or b"{}")
            tid = data.get("id")
            src = OUT / (tid or "") / "converted.txt"
            if not src.exists():
                raise ValueError("转换结果不存在，请先完成 PDF 转换")
            text = src.read_text(encoding="utf-8")
            deck = generation.deck_from_lesson_text(text, {"fileName": "converted.pdf"}, {})
            save_deck(deck)
            return self._json(deck)

        return self._err("接口不存在", 404)


def server_address_port(handler) -> int:
    try:
        return handler.server.server_address[1]
    except Exception:
        return 8770


def _lan_ips() -> list[str]:
    import socket

    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ips.append(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip not in ips and not ip.startswith("127."):
                ips.append(ip)
    except Exception:
        pass
    return ips[:4]


def serve(host: str = "0.0.0.0", port: int = 8770):
    try:
        from .samples_build import ensure_samples

        ensure_samples()
    except Exception as e:
        print("示例文件生成失败（不影响使用）：", e)
    httpd = ThreadingHTTPServer((host, port), Handler)
    print("\n  悟理智课 · 中学物理智能备课平台")
    if host in ("0.0.0.0", "::"):
        print(f"  → 本机访问：http://127.0.0.1:{port}")
        for ip in netinfo.local_ips():
            print(f"  → 局域网访问：http://{ip}:{port}")
        print("  提示：其他设备必须与本机在同一网段；被拒时请允许 Windows 防火墙的专用网络访问。")
    else:
        print(f"  → http://{host}:{port}")
    print()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止。")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    serve()