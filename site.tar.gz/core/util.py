"""通用工具：ID、JSON 读写、中文文本处理。"""
from __future__ import annotations

import json
import os
import re
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
OUT = DATA / "out"
UPLOADS = DATA / "uploads"
for _d in (DATA, OUT, UPLOADS):
    _d.mkdir(parents=True, exist_ok=True)


def new_id(prefix: str = "d") -> str:
    return f"{prefix}{time.strftime('%y%m%d')}{uuid.uuid4().hex[:6]}"


def read_json(path: Path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path: Path, obj) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


CN_NUM = "一二三四五六七八九十"


def cn_index(i: int) -> str:
    """1 -> 一, 11 -> 十一"""
    if i <= 10:
        return CN_NUM[i - 1]
    if i < 20:
        return "十" + CN_NUM[i - 11]
    return str(i)


SENT_SPLIT = re.compile(r"(?<=[。！？；!?;])")


def sentences(text: str) -> list[str]:
    out = [s.strip() for s in SENT_SPLIT.split(text or "") if s and s.strip()]
    return out


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def short(text: str, n: int = 40) -> str:
    text = (text or "").strip().replace("\n", " ")
    return text if len(text) <= n else text[: n - 1] + "…"


STOPWORDS = set(
    "的 了 和 与 及 或 在 是 为 对 从 到 把 被 让 使 有 无 不 也 就 都 而 其 这 那 一个 一种 可以 通过 进行 学生 教师 教学 学习 知识 内容 我们 你们 他们 它 中 上 下 内 外 时 后 前 会 能 要 应 该 需要 利用 根据 以及 并 等 之 所 以 于".split()
)


def keywords(text: str, limit: int = 8) -> list[str]:
    """极简中文关键词抽取：双字/三字/四字高频片段。"""
    text = re.sub(r"[\s，。；：、！？（）()《》“”\"'·,.;:!?\-—/\\|\[\]{}<>+=*#@%&]+", " ", text or "")
    counts: dict[str, int] = {}
    for seg in text.split():
        if len(seg) < 2:
            continue
        for n in (4, 3, 2):
            for i in range(len(seg) - n + 1):
                w = seg[i : i + n]
                if w in STOPWORDS or all(c in STOPWORDS for c in w):
                    continue
                counts[w] = counts.get(w, 0) + 1
    ranked = sorted(counts.items(), key=lambda kv: (-kv[1] * len(kv[0]), kv[0]))
    out: list[str] = []
    for w, _ in ranked:
        if any(w in o or o in w for o in out):
            continue
        out.append(w)
        if len(out) >= limit:
            break
    return out


def split_sections(text: str) -> dict[str, str]:
    """按常见教案小标题切分文本。"""
    heads = [
        "教材分析", "学情分析", "教学目标", "教学重点", "教学难点", "重点难点",
        "教学准备", "教学方法", "教学方法与手段", "教学过程", "教学活动",
        "板书设计", "作业设计", "分层作业", "教学反思", "评价", "教学评价",
        "设计意图", "课标要求", "核心素养",
    ]
    pattern = re.compile(r"(?:^|\n)\s*(?:[一二三四五六七八九十]+[、.]|\d+[、.])?\s*(" + "|".join(heads) + r")\s*[:：]?\s*")
    matches = list(pattern.finditer(text or ""))
    if not matches:
        return {}
    out: dict[str, str] = {}
    for i, m in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        key = m.group(1)
        body = text[m.end() : end].strip()
        if body:
            out[key] = (out.get(key, "") + "\n" + body).strip()
    return out


def fmt_minutes(n: int) -> str:
    return f"{n} 分钟"


def safe_filename(name: str, default: str = "file") -> str:
    name = os.path.basename(name or default)
    name = re.sub(r'[\\/:*?"<>|\r\n\t]', "_", name).strip()
    return name[:80] or default