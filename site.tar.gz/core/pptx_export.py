"""课件 → PPTX：版式系统、矢量图示、讲稿备注。"""
from __future__ import annotations

import math
import re
from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Inches, Pt

# ---------------------------------------------------------------- 设计令牌
BG = RGBColor(0x0B, 0x12, 0x20)
PANEL = RGBColor(0x12, 0x1D, 0x30)
PANEL2 = RGBColor(0x16, 0x24, 0x3B)
LINE = RGBColor(0x25, 0x38, 0x55)
FG = RGBColor(0xE8, 0xEF, 0xF9)
MUTED = RGBColor(0x93, 0xA7, 0xC2)
ACCENT = RGBColor(0x38, 0xBD, 0xF8)
ACCENT2 = RGBColor(0xA7, 0x8B, 0xFA)
WARN = RGBColor(0xF5, 0x9E, 0x0B)
OK = RGBColor(0x34, 0xD3, 0x99)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)

FONT = "Microsoft YaHei"
FONT_LIGHT = "Microsoft YaHei Light"

W, H = 13.333, 7.5
M = 0.72
CW = W - 2 * M


def _rgb(hexstr: str) -> RGBColor:
    h = hexstr.lstrip("#")
    return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


class Deck:
    def __init__(self, accent: str = "#38BDF8", accent2: str = "#A78BFA"):
        self.prs = Presentation()
        self.prs.slide_width = Inches(W)
        self.prs.slide_height = Inches(H)
        self.blank = self.prs.slide_layouts[6]
        self.accent = _rgb(accent)
        self.accent2 = _rgb(accent2)

    # ---------- 基础绘制 ----------
    def new(self, accent: RGBColor | None = None):
        slide = self.prs.slides.add_slide(self.blank)
        bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Inches(W), Inches(H))
        bg.fill.solid()
        bg.fill.fore_color.rgb = BG
        bg.line.fill.background()
        bg.shadow.inherit = False
        # 装饰
        c1 = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(W - 3.6), Inches(-2.1), Inches(6.2), Inches(6.2))
        c1.fill.solid()
        c1.fill.fore_color.rgb = _rgb("#132238")
        c1.line.fill.background()
        c1.shadow.inherit = False
        c2 = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(-2.4), Inches(H - 2.6), Inches(4.4), Inches(4.4))
        c2.fill.solid()
        c2.fill.fore_color.rgb = _rgb("#101B2C")
        c2.line.fill.background()
        c2.shadow.inherit = False
        self._slide_accent = accent or self.accent
        return slide

    def text(
        self,
        slide,
        x,
        y,
        w,
        h,
        content,
        size=18,
        color=None,
        bold=False,
        align=PP_ALIGN.LEFT,
        font=FONT,
        anchor=MSO_ANCHOR.TOP,
        spacing=1.25,
        space_after=4,
        wrap=True,
        italic=False,
    ):
        box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = box.text_frame
        tf.word_wrap = wrap
        tf.vertical_anchor = anchor
        tf.margin_left = 0
        tf.margin_right = 0
        tf.margin_top = 0
        tf.margin_bottom = 0
        lines = content if isinstance(content, (list, tuple)) else [content]
        for i, line in enumerate(lines):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.alignment = align
            p.line_spacing = spacing
            p.space_after = Pt(space_after)
            run = p.add_run()
            run.text = str(line)
            f = run.font
            f.name = font
            f.size = Pt(size)
            f.bold = bold
            f.italic = italic
            f.color.rgb = color or FG
        return box

    def card(self, slide, x, y, w, h, fill=None, line=None, radius=0.045, line_w=1.0):
        shp = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
        try:
            shp.adjustments[0] = radius
        except Exception:
            pass
        shp.fill.solid()
        shp.fill.fore_color.rgb = fill or PANEL
        if line is None:
            shp.line.fill.background()
        else:
            shp.line.color.rgb = line
            shp.line.width = Pt(line_w)
        shp.shadow.inherit = False
        return shp

    def pill(self, slide, x, y, w, h, label, color=None, size=11, fill=None):
        color = color or self._slide_accent
        shp = self.card(slide, x, y, w, h, fill=fill or _rgb("#0F1A2B"), line=color, radius=0.5)
        tf = shp.text_frame
        tf.word_wrap = False
        tf.margin_left = 0
        tf.margin_right = 0
        tf.margin_top = 0
        tf.margin_bottom = 0
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        run = p.add_run()
        run.text = label
        run.font.size = Pt(size)
        run.font.name = FONT
        run.font.color.rgb = color
        run.font.bold = True
        return shp

    def header(self, slide, kicker, title, tag=None):
        self.text(slide, M, 0.42, 8, 0.3, kicker.upper(), size=11, color=self._slide_accent, bold=True)
        self.text(slide, M, 0.72, CW - 1.2, 0.75, title, size=32, bold=True, color=WHITE)
        bar = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(M), Inches(1.52), Inches(0.62), Inches(0.055))
        bar.fill.solid()
        bar.fill.fore_color.rgb = self._slide_accent
        bar.line.fill.background()
        bar.shadow.inherit = False
        if tag:
            self.pill(slide, W - M - 1.5, 0.78, 1.5, 0.34, tag, color=WARN, fill=_rgb("#241A08"))

    def footer(self, slide, idx, total, note=""):
        line = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(M), Inches(7.02), Inches(CW), Emu(9525))
        line.fill.solid()
        line.fill.fore_color.rgb = LINE
        line.line.fill.background()
        line.shadow.inherit = False
        self.text(slide, M, 7.12, 7.2, 0.26, note or "悟理智课 · 中学物理智能备课平台", size=9, color=MUTED)
        self.text(slide, W - M - 2.0, 7.12, 2.0, 0.26, f"{idx:02d} / {total:02d}", size=9, color=MUTED, align=PP_ALIGN.RIGHT)

    def notes(self, slide, text):
        if not text:
            return
        slide.notes_slide.notes_text_frame.text = text

    # ---------- 矢量图示 ----------
    def motif(self, slide, kind, x, y, w, h, color=None):
        color = color or self._slide_accent
        cx, cy = x + w / 2, y + h / 2
        s = min(w, h)

        def ln(x1, y1, x2, y2, c=None, width=1.6, dash=False):
            conn = slide.shapes.add_connector(1, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
            conn.line.color.rgb = c or color
            conn.line.width = Pt(width)
            if dash:
                conn.line.dash_style = MSO_LINE_DASH_STYLE.DASH

        def dot(px, py, r=0.07, c=None):
            o = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(px - r), Inches(py - r), Inches(2 * r), Inches(2 * r))
            o.fill.solid()
            o.fill.fore_color.rgb = c or color
            o.line.fill.background()
            o.shadow.inherit = False

        def poly(points, c=None, width=1.8, close=False, fill=None):
            pts = points + ([points[0]] if close else [])
            fb = slide.shapes.build_freeform(Inches(pts[0][0]), Inches(pts[0][1]))
            fb.add_line_segments([(Inches(px), Inches(py)) for px, py in pts[1:]], close=close)
            shp = fb.convert_to_shape()
            if fill is None:
                shp.fill.background()
            else:
                shp.fill.solid()
                shp.fill.fore_color.rgb = fill
            shp.line.color.rgb = c or color
            shp.line.width = Pt(width)
            shp.shadow.inherit = False

        if kind == "projectile":
            ln(x, y + h * 0.86, x + w, y + h * 0.86, c=LINE, width=1.2)
            ln(x + 0.14, y + h * 0.12, x + 0.14, y + h * 0.92, c=LINE, width=1.2)
            pts = []
            for i in range(41):
                t = i / 40
                pts.append((x + 0.2 + t * (w - 0.3), y + h * 0.8 - (4 * t * (1 - t)) * h * 0.62))
            poly(pts)
            dot(x + 0.2, y + h * 0.8)
            ln(x + w - 0.9, y + h * 0.86, x + w - 0.9, y + h * 0.55, c=MUTED, dash=True, width=1.0)
            ln(x + w - 1.05, y + h * 0.62, x + w - 0.75, y + h * 0.62, c=MUTED, width=1.0)
            dot(x + w - 0.9, y + h * 0.5, 0.1, c=WARN)

        elif kind == "incline":
            poly([(x + 0.2, y + h * 0.85), (x + w - 0.25, y + h * 0.85), (x + w - 0.25, y + h * 0.3)], close=True, width=1.4)
            ln(x + w - 0.25, y + h * 0.3, x + w - 0.25, y + h * 0.85, c=LINE, width=1.0)
            bx = x + w * 0.4
            by = y + h * 0.85 - (bx - x - 0.2) * math.tan(math.radians(28))
            sq = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(bx - 0.2), Inches(by - 0.34), Inches(0.42), Inches(0.3))
            sq.fill.solid()
            sq.fill.fore_color.rgb = color
            sq.line.fill.background()
            sq.shadow.inherit = False
            sq.rotation = -28
            ln(bx, by - 0.15, bx, by - 0.7, c=WARN, width=1.2)
            ln(bx, by - 0.15, bx - 0.28 * 0.5, by - 0.15 - 0.3, c=ACCENT2, width=1.2)

        elif kind == "pulley":
            r = 0.16
            for px in (x + w * 0.5, x + w * 0.5):
                o = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(px - r), Inches(y + h * 0.18 - r), Inches(2 * r), Inches(2 * r))
                o.fill.background()
                o.line.color.rgb = color
                o.line.width = Pt(2.2)
                o.shadow.inherit = False
            ln(x + w * 0.5 - 0.16, y + h * 0.18, x + w * 0.5 - 0.16, y + h * 0.78)
            ln(x + w * 0.5 + 0.16, y + h * 0.18, x + w * 0.5 + 0.16, y + h * 0.78)
            box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x + w * 0.5 - 0.3), Inches(y + h * 0.7), Inches(0.6), Inches(0.34))
            box.fill.solid()
            box.fill.fore_color.rgb = color
            box.line.fill.background()
            box.shadow.inherit = False
            ln(x + w * 0.5 + 0.16, y + h * 0.18, x + w * 0.86, y + h * 0.18, c=ACCENT2, width=1.4)

        elif kind == "lens":
            ln(x + 0.1, cy, x + w - 0.1, cy, c=LINE, width=1.2)
            lens = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(cx - 0.1), Inches(cy - h * 0.3), Inches(0.2), Inches(h * 0.6))
            lens.fill.solid()
            lens.fill.fore_color.rgb = _rgb("#0E2233")
            lens.line.color.rgb = color
            lens.line.width = Pt(2.0)
            lens.shadow.inherit = False
            ln(x + 0.3, cy - 0.25, cx, cy)
            ln(cx, cy, x + w - 0.4, cy + 0.3)
            ln(cx - 0.02, cy - 0.4, cx - 0.02, cy + 0.4, c=ACCENT2, dash=True, width=1.0)
            ln(cx, cy, x + w - 0.4, cy + 0.3, c=ACCENT2, width=1.0)
            dot(cx - 0.32, cy - 0.25, 0.06, WARN)
            dot(cx + 1.15, cy + 0.3, 0.06, OK)

        elif kind == "circuit":
            pts = [(x + 0.2, y + 0.32), (x + w - 0.25, y + 0.32), (x + w - 0.25, y + h * 0.82), (x + 0.2, y + h * 0.82), (x + 0.2, y + 0.32)]
            poly(pts, width=1.6)
            rr = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x + w * 0.4), Inches(y + h * 0.25), Inches(0.5), Inches(0.14))
            rr.fill.solid()
            rr.fill.fore_color.rgb = color
            rr.line.fill.background()
            rr.shadow.inherit = False
            ln(x + w - 0.25, y + h * 0.55, x + w - 0.55, y + h * 0.55, c=LINE, width=1.0)
            battery = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x + 0.08), Inches(y + h * 0.52), Inches(0.2), Inches(0.2))
            battery.fill.background()
            battery.line.color.rgb = OK
            battery.line.width = Pt(1.6)
            battery.shadow.inherit = False

        elif kind == "buoyancy":
            wk = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x + 0.18), Inches(y + 0.18), Inches(w - 0.36), Inches(h - 0.36))
            wk.fill.solid()
            wk.fill.fore_color.rgb = _rgb("#0D2130")
            wk.line.color.rgb = LINE
            wk.line.width = Pt(1.2)
            wk.shadow.inherit = False
            water = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x + 0.18), Inches(y + h * 0.45), Inches(w - 0.36), Inches(h * 0.55 - 0.2))
            water.fill.solid()
            water.fill.fore_color.rgb = _rgb("#123B52")
            water.line.fill.background()
            water.shadow.inherit = False
            blk = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(cx - 0.3), Inches(y + h * 0.3), Inches(0.6), Inches(0.4))
            blk.fill.solid()
            blk.fill.fore_color.rgb = color
            blk.line.fill.background()
            blk.shadow.inherit = False
            blk.rotation = -8
            ln(cx, y + h * 0.3, cx, y + h * 0.12, c=WARN, width=1.2)
            ln(cx, y + h * 0.7, cx, y + h * 0.86, c=ACCENT2, width=1.2)

        elif kind == "wave":
            ln(x + 0.1, cy, x + w - 0.1, cy, c=LINE, width=1.0)
            pts = []
            for i in range(49):
                t = i / 48
                pts.append((x + 0.1 + t * (w - 0.2), cy - math.sin(t * 4 * math.pi) * h * 0.26))
            poly(pts, width=2.2)
            for i in range(5):
                px = x + 0.2 + i * (w - 0.4) / 4
                ln(px, cy - h * 0.34, px, cy + h * 0.34, c=ACCENT2, dash=True, width=0.8)
                dot(px, cy, 0.045, ACCENT2)

        elif kind == "vector":
            ox, oy = x + w * 0.28, y + h * 0.72
            ex, ey = ox + w * 0.42, oy - h * 0.42
            fx, fy = ox + w * 0.52, oy - h * 0.12
            ln(ox, oy, ex, ey, c=color, width=2.4)
            ln(ox, oy, fx, fy, c=ACCENT2, width=2.4)
            ln(ex, ey, ex + (fx - ox), ey + (fy - oy), c=MUTED, dash=True, width=1.0)
            ln(fx, fy, fx + (ex - ox), fy + (ey - oy), c=MUTED, dash=True, width=1.0)
            ln(ox, oy, ex + (fx - ox), ey + (fy - oy), c=OK, width=2.8)
            dot(ex, ey, 0.05, color)
            dot(fx, fy, 0.05, ACCENT2)
            dot(ex + (fx - ox), ey + (fy - oy), 0.06, OK)

        elif kind == "thermal":
            wk = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x + 0.2), Inches(y + 0.12), Inches(w - 0.4), Inches(h - 0.24))
            wk.fill.solid()
            wk.fill.fore_color.rgb = _rgb("#0D1A2A")
            wk.line.color.rgb = LINE
            wk.line.width = Pt(1.2)
            wk.shadow.inherit = False
            import random

            rnd = random.Random(7)
            for i in range(34):
                dot(
                    x + 0.32 + rnd.random() * (w - 0.64),
                    y + 0.24 + rnd.random() * (h - 0.48),
                    0.028 + rnd.random() * 0.02,
                    color if i % 3 else ACCENT2,
                )

        elif kind == "vr":
            o = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(cx - s * 0.34), Inches(cy - s * 0.34), Inches(s * 0.68), Inches(s * 0.68))
            o.fill.background()
            o.line.color.rgb = color
            o.line.width = Pt(2.4)
            o.shadow.inherit = False
            ln(cx - s * 0.34, cy, cx + s * 0.34, cy, c=LINE, dash=True, width=1.0)
            for ang, c in ((-60, WARN), (20, OK), (140, ACCENT2)):
                px = cx + math.cos(math.radians(ang)) * s * 0.34
                py = cy - math.sin(math.radians(ang)) * s * 0.3
                dot(px, py, 0.065, c)
            ln(cx, cy - 0.16, cx, cy + 0.16, c=MUTED, width=1.0)
            ln(cx - 0.16, cy, cx + 0.16, cy, c=MUTED, width=1.0)

        elif kind == "book":
            for i, dx in enumerate((-0.5, 0.0, 0.5)):
                bx = cx - 0.55 + dx
                pg = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(bx), Inches(cy - h * 0.3), Inches(0.95), Inches(h * 0.6))
                pg.fill.solid()
                pg.fill.fore_color.rgb = _rgb("#1B2A42") if i != 1 else _rgb("#243B5C")
                pg.line.color.rgb = color if i == 1 else LINE
                pg.line.width = Pt(1.2 if i == 1 else 0.8)
                pg.shadow.inherit = False
                pg.rotation = (i - 1) * -6
                for j in range(4):
                    ln(bx + 0.14, cy - h * 0.16 + j * 0.15, bx + 0.78, cy - h * 0.16 + j * 0.15, c=LINE, width=0.8)
        else:
            dot(cx, cy, 0.2, color)


def _clip(text: str, n: int) -> str:
    text = (text or "").replace("\n", " ").strip()
    return text if len(text) <= n else text[: n - 1] + "…"


def _chunks(items: list[str], max_chars: int = 46) -> list[list[str]]:
    """把长条目按标点拆成两行，避免 PPT 溢出。"""
    out = []
    for it in items:
        it = it.strip()
        if len(it) <= max_chars:
            out.append([it])
        else:
            parts = [p for p in re.split(r"[，；：]", it) if p]
            buf, cur = [], ""
            for p in parts:
                if len(cur) + len(p) + 1 <= max_chars:
                    cur = (cur + "，" + p) if cur else p
                else:
                    if cur:
                        buf.append(cur)
                    cur = p
            if cur:
                buf.append(cur)
            out.append(buf[:2])
    return out


def export_pptx(deck: dict, path: Path, images: dict | None = None) -> Path:
    d = Deck()
    scenes = deck["scenes"]
    total = len(scenes)
    accent = d.accent
    images = images or {}

    for idx, sc in enumerate(scenes, start=1):
        t = sc["type"]
        slide = d.new(accent)

        if t == "cover":
            d.text(slide, M, 0.85, 7.6, 0.34, sc.get("kicker", ""), size=12, color=accent, bold=True)
            d.text(slide, M, 1.35, 7.8, 1.9, sc.get("title", ""), size=48, bold=True, color=WHITE, spacing=1.05)
            d.text(slide, M, 3.4, 7.2, 0.4, sc.get("subtitle", ""), size=15, color=MUTED)
            chips = sc.get("chips", [])
            for i, chip in enumerate(chips[:3]):
                d.pill(slide, M + i * 2.05, 4.15, 1.9, 0.4, _clip(chip, 12), color=accent, size=11)

            # 装饰：轨道环
            for rr, cc in ((1.55, LINE), (1.15, _rgb("#1E3A5F"))):
                o = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(10.3 - rr), Inches(3.2 - rr), Inches(2 * rr), Inches(2 * rr))
                o.fill.background()
                o.line.color.rgb = cc
                o.line.width = Pt(1.0)
                o.shadow.inherit = False
            import math as _m

            for ang, r, c in ((20, 1.55, accent), (150, 1.55, ACCENT2), (260, 1.15, OK)):
                px = 10.3 + _m.cos(_m.radians(ang)) * r
                py = 3.2 - _m.sin(_m.radians(ang)) * r
                o = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(px - 0.07), Inches(py - 0.07), Inches(0.14), Inches(0.14))
                o.fill.solid()
                o.fill.fore_color.rgb = c
                o.line.fill.background()
                o.shadow.inherit = False
            core = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(9.85), Inches(2.75), Inches(0.9), Inches(0.9))
            core.fill.solid()
            core.fill.fore_color.rgb = _rgb("#12233A")
            core.line.color.rgb = accent
            core.line.width = Pt(1.5)
            core.shadow.inherit = False
            d.text(slide, 9.85, 2.95, 0.9, 0.5, "Φ", size=26, color=accent, bold=True, align=PP_ALIGN.CENTER)
            d.text(slide, M, 6.55, 8, 0.4, sc.get("meta", deck["meta"].get("textbook", "")), size=11, color=MUTED)

        elif t == "objectives":
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""))
            items = sc.get("items", [])[:4]
            for i, it in enumerate(items):
                y = 1.95 + i * 1.14
                d.card(slide, M, y, CW, 0.98, fill=PANEL, line=LINE)
                num = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(M + 0.24), Inches(y + 0.24), Inches(0.5), Inches(0.5))
                num.fill.solid()
                num.fill.fore_color.rgb = _rgb("#0E2C3F")
                num.line.color.rgb = accent
                num.line.width = Pt(1.0)
                num.shadow.inherit = False
                d.text(slide, M + 0.24, y + 0.32, 0.5, 0.3, str(i + 1), size=13, color=accent, bold=True, align=PP_ALIGN.CENTER)
                d.text(slide, M + 0.95, y + 0.16, 1.35, 0.3, it.get("dim", ""), size=11, color=ACCENT2, bold=True)
                d.text(slide, M + 0.95, y + 0.44, CW - 1.3, 0.5, _clip(it.get("text", ""), 62), size=15, color=FG)

        elif t == "hook":
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""), tag="情境")
            d.card(slide, M, 1.9, 6.4, 3.3, fill=PANEL, line=LINE)
            d.text(slide, M + 0.35, 2.12, 1.2, 0.28, "现实情境", size=11, color=accent, bold=True)
            d.text(slide, M + 0.35, 2.5, 5.7, 1.9, sc.get("context", ""), size=19, color=FG, spacing=1.4)
            d.card(slide, 7.35, 1.9, 5.25, 3.3, fill=_rgb("#0F1B2B"), line=LINE)
            d.text(slide, 7.6, 2.12, 2, 0.28, "驱动问题", size=11, color=ACCENT2, bold=True)
            for i, q in enumerate(sc.get("questions", [])[:2]):
                yy = 2.55 + i * 1.25
                o = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(7.6), Inches(yy), Inches(0.42), Inches(0.42))
                o.fill.solid()
                o.fill.fore_color.rgb = _rgb("#2A1E3F")
                o.line.color.rgb = ACCENT2
                o.line.width = Pt(1.0)
                o.shadow.inherit = False
                d.text(slide, 7.6, yy + 0.07, 0.42, 0.3, "?", size=13, color=ACCENT2, bold=True, align=PP_ALIGN.CENTER)
                d.text(slide, 8.18, yy, 4.2, 1.0, _clip(q, 44), size=15, color=FG, spacing=1.3)
            d.text(slide, M, 5.45, CW, 0.4, "提示：先让学生用自己的话描述现象，不急于给出结论。", size=11, color=MUTED)
            d.motif(slide, "wave", 9.4, 5.1, 3.2, 1.2, accent)

        elif t == "concept":
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""), tag=sc.get("tag"))
            bullets = sc.get("bullets", [])[:4]
            d.text(slide, M, 1.95, 7.6, 0.3, "核心结论", size=11, color=accent, bold=True)
            for i, lines in enumerate(_chunks(bullets, 40)):
                y = 2.35 + i * 0.95
                bar = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(M), Inches(y + 0.06), Inches(0.07), Inches(0.55))
                bar.fill.solid()
                bar.fill.fore_color.rgb = accent
                bar.line.fill.background()
                bar.shadow.inherit = False
                d.text(slide, M + 0.26, y, 7.2, 0.8, lines, size=17, color=FG, spacing=1.25, space_after=0)
            if sc.get("formula"):
                d.card(slide, 8.35, 1.95, 4.25, 2.5, fill=_rgb("#0E1B2C"), line=accent, line_w=1.2)
                d.text(slide, 8.6, 2.12, 2, 0.26, "公式 / 规律", size=10, color=accent, bold=True)
                d.text(slide, 8.6, 2.6, 3.75, 1.4, sc["formula"], size=24, color=WHITE, bold=True, align=PP_ALIGN.CENTER, font="Cambria Math")
            d.motif(slide, "orbit", 8.7, 4.75, 2.6, 1.7, accent)

        elif t == "formula":
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""), tag="重点")
            fs = sc.get("formulas", [])[:3]
            for i, f in enumerate(fs):
                y = 1.9 + i * 1.32
                d.card(slide, M, y, 6.6, 1.12, fill=PANEL, line=_rgb("#2B4A6B"))
                d.text(slide, M + 0.3, y + 0.22, 6.0, 0.7, f, size=24, color=WHITE, bold=True, font="Cambria Math")
            d.card(slide, 7.75, 1.9, 4.85, 3.95, fill=_rgb("#0E1B2C"), line=LINE)
            d.text(slide, 8.0, 2.1, 4.3, 0.3, "式中各量的意义", size=11, color=accent, bold=True)
            notes = sc.get("bullets", [])[:3]
            d.text(slide, 8.0, 2.5, 4.35, 3.0, notes or ["请结合学案标注每个符号的物理意义与单位"], size=13, color=MUTED, spacing=1.5)
            d.motif(slide, "vector", 8.4, 4.9, 3.2, 1.6, ACCENT2)

        elif t == "simulation":
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""), tag="交互")
            d.card(slide, M, 1.9, 6.9, 4.35, fill=_rgb("#0A1626"), line=_rgb("#1E4A6B"))
            d.text(slide, M + 0.3, 2.06, 4, 0.28, "仿真窗口 · 可实时调节参数", size=10, color=accent, bold=True)
            d.motif(slide, sc.get("widget", "projectile"), M + 0.45, 2.4, 6.0, 3.0, accent)
            d.pill(slide, M + 5.05, 5.55, 1.55, 0.36, "课堂投屏可用", color=OK, size=9, fill=_rgb("#0C241C"))
            d.card(slide, 8.0, 1.9, 4.6, 4.35, fill=PANEL, line=LINE)
            d.text(slide, 8.25, 2.08, 4.1, 0.3, "探究任务", size=11, color=ACCENT2, bold=True)
            tasks = sc.get("tasks", [])[:3]
            for i, task in enumerate(tasks):
                yy = 2.45 + i * 1.2
                d.text(slide, 8.25, yy, 0.3, 0.3, f"{i+1}", size=12, color=ACCENT2, bold=True)
                d.text(slide, 8.55, yy, 3.8, 1.0, _clip(task, 48), size=12, color=FG, spacing=1.3)
            d.text(slide, 8.25, 5.98, 4.1, 0.28, "记录 3 组数据 → 归纳规律", size=10, color=MUTED)

        elif t == "vr":
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""), tag="VR")
            d.card(slide, M, 1.9, 7.5, 4.35, fill=_rgb("#0B1524"), line=_rgb("#243B5C"))
            d.motif(slide, "vr", M + 1.6, 2.3, 4.2, 3.4, accent)
            d.text(slide, M + 0.35, 2.1, 4, 0.3, "360° 环视 · 拖拽转向 · 准星选中热点", size=10, color=accent, bold=True)
            d.card(slide, 8.55, 1.9, 4.05, 4.35, fill=PANEL, line=LINE)
            d.text(slide, 8.8, 2.08, 3.6, 0.3, "观察任务", size=11, color=ACCENT2, bold=True)
            for i, task in enumerate(sc.get("tasks", [])[:2]):
                d.text(slide, 8.8, 2.5 + i * 1.5, 3.55, 1.3, f"{i+1}. {_clip(task, 42)}", size=12, color=FG, spacing=1.35)
            d.text(slide, 8.8, 5.4, 3.6, 0.6, "场景：" + sc.get("vr", ""), size=10, color=MUTED)

        elif t == "game":
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""), tag="闯关")
            d.card(slide, M, 1.9, 7.2, 4.35, fill=_rgb("#0B1626"), line=_rgb("#2A3F63"))
            d.text(slide, M + 0.35, 2.1, 4, 0.3, "游戏化任务 · 调参数通关", size=10, color=accent, bold=True)
            d.text(slide, M + 0.35, 2.5, 6.4, 0.8, "用本课规律算出应满足的条件，再调参数通关", size=19, color=WHITE, bold=True)
            cxg, cyg = M + 3.6, 5.2
            for rr, cc in ((1.15, _rgb("#1E3A5F")), (0.78, _rgb("#24486B")), (0.42, _rgb("#2C5A85"))):
                o = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(cxg - rr), Inches(cyg - rr), Inches(2 * rr), Inches(2 * rr))
                o.fill.background()
                o.line.color.rgb = cc
                o.line.width = Pt(1.4)
                o.shadow.inherit = False
            o = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(cxg - 0.09), Inches(cyg - 0.09), Inches(0.18), Inches(0.18))
            o.fill.solid()
            o.fill.fore_color.rgb = WARN
            o.line.fill.background()
            o.shadow.inherit = False
            d.text(slide, cxg - 1.3, cyg - 0.2, 2.6, 0.4, "目标", size=10, color=MUTED, align=PP_ALIGN.CENTER)
            d.card(slide, 8.25, 1.9, 4.35, 4.35, fill=PANEL, line=LINE)
            d.text(slide, 8.5, 2.08, 3.9, 0.3, "课堂组织", size=11, color=ACCENT2, bold=True)
            tips = [
                "4 人一组，每组一台设备进入闯关页",
                "先试 2 次并记录失败参数，再理论计算",
                "通关后口述成功条件，组间互评",
                "教师用投屏展示最优参数与轨迹",
            ]
            for i, tip in enumerate(tips):
                d.text(slide, 8.5, 2.5 + i * 0.78, 3.85, 0.7, f"{i+1}. {_clip(tip, 26)}", size=11.5, color=FG, spacing=1.25)
            d.text(slide, 8.5, 5.75, 3.85, 0.3, "对应游戏：" + sc.get("game", ""), size=9.5, color=MUTED)

        elif t == "avatar":
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""), tag="难点")
            d.card(slide, M, 1.9, 3.5, 4.35, fill=_rgb("#101C2E"), line=LINE)
            # 数字人半身像
            cx = M + 1.75
            head = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(cx - 0.55), Inches(2.25), Inches(1.1), Inches(1.1))
            head.fill.solid()
            head.fill.fore_color.rgb = _rgb("#F1D3B8")
            head.line.color.rgb = _rgb("#D9B08C")
            head.shadow.inherit = False
            body = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(cx - 1.05), Inches(3.35), Inches(2.1), Inches(1.9))
            body.fill.solid()
            body.fill.fore_color.rgb = _rgb("#1E4A6B")
            body.line.fill.background()
            body.shadow.inherit = False
            for ex in (-0.22, 0.22):
                e = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(cx + ex - 0.055), Inches(2.62), Inches(0.11), Inches(0.13))
                e.fill.solid()
                e.fill.fore_color.rgb = _rgb("#1F2937")
                e.line.fill.background()
                e.shadow.inherit = False
            smile = slide.shapes.add_shape(MSO_SHAPE.ARC, Inches(cx - 0.18), Inches(2.9), Inches(0.36), Inches(0.22))
            smile.line.color.rgb = _rgb("#B45309")
            smile.line.width = Pt(1.4)
            smile.fill.background()
            smile.shadow.inherit = False
            d.text(slide, M + 0.3, 5.4, 2.9, 0.3, "李老师 · 物理", size=10, color=accent, bold=True, align=PP_ALIGN.CENTER)
            d.text(slide, M + 0.3, 5.7, 2.9, 0.3, "数字人语音讲解", size=9, color=MUTED, align=PP_ALIGN.CENTER)
            d.card(slide, 4.5, 1.9, 8.1, 4.35, fill=PANEL, line=LINE)
            d.text(slide, 4.78, 2.1, 4, 0.3, "本节难点", size=11, color=WARN, bold=True)
            d.text(slide, 4.78, 2.48, 7.5, 0.7, _clip(sc.get("focus", ""), 42), size=19, color=WHITE, bold=True)
            for i, p in enumerate(sc.get("points", [])[:3]):
                d.text(slide, 4.78, 3.35 + i * 0.55, 7.5, 0.5, _clip(p, 46), size=13, color=FG)
            if sc.get("misconception"):
                d.card(slide, 4.78, 5.25, 7.55, 0.8, fill=_rgb("#241A08"), line=WARN)
                d.text(slide, 4.98, 5.36, 7.2, 0.6, "常见误区：" + _clip(sc["misconception"], 40), size=11, color=WARN)

        elif t == "book3d":
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""), tag="立体")
            book = sc.get("book", {})
            d.text(slide, M, 1.9, 6, 0.3, book.get("subtitle", ""), size=10, color=MUTED)
            pages = book.get("pages", [])[:4]
            for i, pg in enumerate(pages):
                x = M + i * 2.95
                d.card(slide, x, 2.3, 2.72, 3.7, fill=_rgb("#F3EDE0"), line=_rgb("#D6C9B0"))
                d.text(slide, x + 0.22, 2.48, 2.3, 0.3, pg.get("title", ""), size=11, color=_rgb("#7A3F1D"), bold=True)
                body = []
                for b in pg.get("blocks", []):
                    if b.get("type") == "formula":
                        body.append("  " + b.get("text", ""))
                    elif b.get("type") == "list":
                        body.extend(["· " + _clip(x, 14) for x in b.get("items", [])[:2]])
                    elif b.get("type") == "note":
                        body.append("※ " + _clip(b.get("text", ""), 26))
                    else:
                        body.append(_clip(b.get("text", ""), 34))
                d.text(slide, x + 0.22, 2.85, 2.3, 3.0, body[:6], size=8.5, color=_rgb("#3B3226"), spacing=1.35, space_after=3)
            d.text(slide, M, 6.2, CW, 0.4, "课堂用法：翻到“概念卡”对照课本表述；翻到“易错卡”做辨析。", size=10, color=MUTED)

        elif t == "example":
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""), tag="例题")
            d.card(slide, M, 1.9, 7.4, 2.5, fill=PANEL, line=LINE)
            d.text(slide, M + 0.3, 2.05, 1.2, 0.28, "题目", size=10, color=accent, bold=True)
            d.text(slide, M + 0.3, 2.4, 6.85, 1.85, sc.get("stem", ""), size=15, color=FG, spacing=1.45)
            steps = sc.get("steps", [])[:3]
            for i, st in enumerate(steps):
                y = 4.55 + i * 0.62
                d.text(slide, M, y, 0.35, 0.3, f"{i+1}", size=11, color=ACCENT2, bold=True)
                d.text(slide, M + 0.32, y, 6.9, 0.55, _clip(st, 52), size=12, color=FG)
            d.card(slide, 8.5, 1.9, 4.1, 3.0, fill=_rgb("#0D241E"), line=OK)
            d.text(slide, 8.75, 2.08, 3.5, 0.28, "答案", size=10, color=OK, bold=True)
            d.text(slide, 8.75, 2.45, 3.6, 2.2, sc.get("answer", ""), size=17, color=WHITE, bold=True, spacing=1.3)
            d.text(slide, 8.75, 5.15, 3.7, 0.8, "规范：写公式 → 代数据 → 带单位", size=10, color=MUTED)
            d.motif(slide, "incline", 9.0, 5.05, 3.2, 1.5, ACCENT2)

        elif t == "quiz":
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""), tag="检测")
            items = sc.get("items", [])[:3]
            for i, q in enumerate(items):
                y = 1.9 + i * 1.45
                d.card(slide, M, y, CW, 1.28, fill=PANEL, line=LINE)
                badge = {"judge": "判断", "mcq": "选择", "calc": "计算", "short": "简答"}.get(q.get("type"), "题目")
                d.pill(slide, M + 0.25, y + 0.18, 0.8, 0.3, badge, color=accent, size=9)
                has_opts = bool(q.get("options"))
                is_mcq = q.get("type") == "mcq" and len(q.get("options") or []) >= 2
                if is_mcq:
                    d.text(slide, M + 1.2, y + 0.15, CW - 1.6, 0.55, _clip(q.get("stem", ""), 42), size=12, color=FG, spacing=1.25)
                    opts = []
                    for oi, o in enumerate(q["options"][:4]):
                        opts.append(f"{'ABCD'[oi]}. {_clip(o.split('.', 1)[-1], 11)}")
                    d.text(slide, M + 1.2, y + 0.74, CW - 1.5, 0.4, "　".join(opts), size=9, color=MUTED, spacing=1.2)
                else:
                    stem_w = CW - 1.6 - (2.5 if has_opts else 0)
                    d.text(slide, M + 1.2, y + 0.17, stem_w, 0.9, _clip(q.get("stem", ""), 60), size=13, color=FG, spacing=1.3)
                    if has_opts:
                        d.text(slide, W - M - 2.4, y + 0.2, 2.2, 0.3, "  /  ".join(q["options"]), size=10, color=MUTED, align=PP_ALIGN.RIGHT)
            d.text(slide, M, 6.4, CW, 0.35, "答案与解析见讲稿备注；建议当堂互批，统计正确率。", size=10, color=MUTED)
            notes = []
            for q in items:
                notes.append(f"【{q.get('type')}】答案：{q.get('answer')}　解析：{q.get('explain')}")
            d.notes(slide, (sc.get("narration", "") + "\n\n" + "\n".join(notes)).strip())

        elif t == "summary":
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""))
            branches = sc.get("branches", [])[:3]
            for i, b in enumerate(branches):
                x = M + i * 3.98
                d.card(slide, x, 1.95, 3.72, 3.45, fill=PANEL, line=LINE)
                d.text(slide, x + 0.25, 2.12, 3.2, 0.3, b.get("label", ""), size=11, color=[accent, ACCENT2, WARN][i], bold=True)
                lines = []
                for it in b.get("items", [])[:3]:
                    lines.extend(_chunks([_clip(it, 34)], 20)[0][:1] if len(it) > 34 else [it])
                d.text(slide, x + 0.25, 2.55, 3.25, 2.6, lines[:4], size=12, color=FG, spacing=1.4)
            d.card(slide, M, 5.62, CW, 0.95, fill=_rgb("#0F1B2B"), line=accent)
            d.text(slide, M + 0.3, 5.78, 1.2, 0.3, "出门条", size=10, color=accent, bold=True)
            d.text(slide, M + 1.45, 5.78, CW - 1.9, 0.6, sc.get("exitTicket", ""), size=12, color=FG)

        elif t == "homework":
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""))
            tiers = sc.get("tiers", [])[:3]
            for i, tier in enumerate(tiers):
                x = M + i * 3.98
                color = [OK, accent, ACCENT2][i]
                d.card(slide, x, 1.95, 3.72, 4.0, fill=PANEL, line=LINE)
                d.text(slide, x + 0.25, 2.1, 2.0, 0.3, tier.get("level", ""), size=12, color=color, bold=True)
                d.pill(slide, x + 2.55, 2.08, 0.95, 0.3, tier.get("tag", ""), color=color, size=9, fill=_rgb("#0F1A2B"))
                lines = []
                for it in tier.get("items", [])[:3]:
                    lines.append("· " + _clip(it, 30))
                d.text(slide, x + 0.25, 2.55, 3.3, 3.2, lines, size=11, color=FG, spacing=1.45)

        elif t == "report":
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""), tag="教师版")
            d.card(slide, M, 1.9, 3.2, 2.2, fill=PANEL, line=LINE)
            d.text(slide, M + 0.3, 2.05, 2.6, 0.28, "优化前", size=10, color=MUTED, bold=True)
            d.text(slide, M + 0.3, 2.4, 2.6, 1.0, str(sc.get("before", "")), size=44, color=WARN, bold=True)
            d.card(slide, 4.15, 1.9, 3.2, 2.2, fill=PANEL, line=LINE)
            d.text(slide, 4.45, 2.05, 2.6, 0.28, "优化后", size=10, color=MUTED, bold=True)
            d.text(slide, 4.45, 2.4, 2.6, 1.0, str(sc.get("after", "")), size=44, color=OK, bold=True)
            d.text(slide, M, 4.35, 6.8, 0.28, "主要改动", size=10, color=accent, bold=True)
            changes = []
            for c in sc.get("changes", [])[:5]:
                changes.append("· " + _clip(c, 34))
            d.text(slide, M, 4.68, 6.9, 2.0, changes, size=10.5, color=FG, spacing=1.35)
            d.text(slide, 7.6, 1.95, 5.0, 0.28, "诊断结论", size=10, color=ACCENT2, bold=True)
            issues = []
            for it in sc.get("issues", [])[:6]:
                issues.append(f"[{it.get('level')}] {_clip(it.get('title',''), 22)}")
            d.text(slide, 7.6, 2.3, 5.0, 3.6, issues, size=10, color=MUTED, spacing=1.3)

        else:
            d.header(slide, sc.get("kicker", ""), sc.get("title", ""))
            d.text(slide, M, 2.0, CW, 3.0, sc.get("bullets", []), size=16)

        if t not in ("quiz",):
            d.notes(slide, sc.get("narration", ""))
        d.footer(slide, idx, total)

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    d.prs.save(str(path))
    return path