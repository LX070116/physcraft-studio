"""轻量 PDF 生成器（标准库）。

- 文本 PDF：使用 PDF 预定义 CJK 字体 STSong-Light + UniGB-UCS2-H，
  无需嵌入字体即可显示/复制中文；同时写入 ToUnicode，保证搜索与复制。
- 图片 PDF：把 JPEG 作为 DCTDecode 图像写入页面，可用来构造/导出扫描件。

仅支持 A4 纵向、单栏排版；足够用于"OCR 结果转可复制文字 PDF"与"电子教材下载"。
"""
from __future__ import annotations

import struct
import zlib
from pathlib import Path

W, H = 595.28, 841.89  # A4 pt
MARGIN = 56.0


def _hex_text(s: str) -> str:
    out = []
    for ch in s:
        o = ord(ch)
        if o > 0xFFFF:
            o = 0x3F
        out.append("%04X" % o)
    return "".join(out)


def _width_units(s: str) -> float:
    u = 0.0
    for ch in s:
        o = ord(ch)
        if o < 128:
            u += 0.55 if ch not in "il.,;:'|!" else 0.32
        else:
            u += 1.0
    return u


def _wrap(line: str, max_units: float) -> list[str]:
    if not line:
        return [""]
    out, cur, cu = [], "", 0.0
    for ch in line:
        w = _width_units(ch)
        if cu + w > max_units and cur:
            out.append(cur)
            cur, cu = ch, w
        else:
            cur += ch
            cu += w
    if cur:
        out.append(cur)
    return out


class _PDF:
    def __init__(self):
        self.objs: list[bytes] = [b""]

    def add(self, body: bytes) -> int:
        self.objs.append(body)
        return len(self.objs) - 1

    def stream(self, data: bytes, extra: bytes = b"") -> int:
        comp = zlib.compress(data, 9)
        body = (
            b"<< /Length %d /Filter /FlateDecode %s >>\nstream\n" % (len(comp), extra)
            + comp
            + b"\nendstream"
        )
        return self.add(body)

    def build(self, catalog: int, root_pages: int) -> bytes:
        out = bytearray(b"%PDF-1.5\n%\xe2\xe3\xcf\xd3\n")
        offsets = [0] * len(self.objs)
        for i in range(1, len(self.objs)):
            offsets[i] = len(out)
            out += b"%d 0 obj\n" % i + self.objs[i] + b"\nendobj\n"
        xref = len(out)
        out += b"xref\n0 %d\n" % len(self.objs)
        out += b"0000000000 65535 f \n"
        for i in range(1, len(self.objs)):
            out += b"%010d 00000 n \n" % offsets[i]
        out += (
            b"trailer\n<< /Size %d /Root %d 0 R >>\nstartxref\n%d\n%%%%EOF\n"
            % (len(self.objs), catalog, xref)
        )
        return bytes(out)


def _font_objects(p: _PDF, chars: set[str]) -> tuple[int, int]:
    """写入 Type0 中文字体与 ToUnicode，返回 (font_obj, cmap_obj)。"""
    cmap = bytearray()
    cmap += b"/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n"
    cmap += b"/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n"
    cmap += b"/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n"
    cmap += b"1 begincodespacerange\n<0000> <FFFF>\nendcodespacerange\n"
    codes = sorted({ord(c) for c in chars if ord(c) <= 0xFFFF})
    for i in range(0, len(codes), 100):
        chunk = codes[i : i + 100]
        cmap += b"%d beginbfchar\n" % len(chunk)
        for code in chunk:
            cmap += b"<%04X> <%04X>\n" % (code, code)
        cmap += b"endbfchar\n"
    cmap += b"endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend\n"
    cmap_obj = p.stream(bytes(cmap))

    desc = p.add(
        b"<< /Type /FontDescriptor /FontName /STSong-Light /Flags 6 "
        b"/FontBBox [-25 -254 1000 880] /ItalicAngle 0 /Ascent 880 /Descent -120 "
        b"/CapHeight 880 /StemV 93 >>"
    )
    cid = p.add(
        b"<< /Type /Font /Subtype /CIDFontType0 /BaseFont /STSong-Light "
        b"/CIDSystemInfo << /Registry (Adobe) /Ordering (GB1) /Supplement 2 >> "
        b"/FontDescriptor %d 0 R /DW 1000 >>" % desc
    )
    font = p.add(
        b"<< /Type /Font /Subtype /Type0 /BaseFont /STSong-Light "
        b"/Encoding /UniGB-UCS2-H /DescendantFonts [%d 0 R] /ToUnicode %d 0 R >>" % (cid, cmap_obj)
    )
    return font, cmap_obj


def write_text_pdf(blocks, path: Path, title: str = "") -> Path:
    """blocks: list of {text, level}；level 0 正文，1/2 标题，-1 小字注释。"""
    if isinstance(blocks, str):
        blocks = [{"text": ln, "level": 0} for ln in blocks.split("\n")]
    blocks = [b for b in blocks if (b.get("text") or "").strip()]

    chars: set[str] = set()
    for b in blocks:
        chars.update(b["text"])
    chars.update(title or "")

    p = _PDF()
    font, _ = _font_objects(p, chars)
    catalog = p.add(b"")  # 占位，最后回填
    pages_obj = p.add(b"")

    pages: list[int] = []
    # 先做分页
    page_lines: list[list[tuple[str, int, float]]] = []
    cur: list[tuple[str, int, float]] = []
    y = H - MARGIN
    for b in blocks:
        level = int(b.get("level", 0))
        size = {1: 17.0, 2: 13.5, 0: 10.8, -1: 9.0}.get(level, 10.8)
        lead = size * 1.75
        text = b["text"].replace("\t", "    ")
        max_units = (W - 2 * MARGIN) / size
        lines = _wrap(text, max_units)
        for i, ln in enumerate(lines):
            if y - lead < MARGIN:
                page_lines.append(cur)
                cur = []
                y = H - MARGIN
            cur.append((ln, int(size), y))
            y -= lead
            if level == 1 and i == 0:
                y -= size * 0.4
        if level == 1:
            y -= size * 0.5
    if cur:
        page_lines.append(cur)

    for lines in page_lines:
        content = [b"BT", b"/F1 1 Tf"]
        prev_size = None
        for text, size, yy in lines:
            if size != prev_size:
                content.append(("1 0 0 1 %.2f %.2f Tm" % (MARGIN, yy)).encode())
                prev_size = size
            else:
                content.append(("1 0 0 1 %.2f %.2f Tm" % (MARGIN, yy)).encode())
            content.append(("<%s> Tj" % _hex_text(text)).encode())
            content.append(b"ET BT")
            # 每行重新声明字体大小，避免状态错乱
            content.append(("/F1 %d Tf" % size).encode())
        content.append(b"ET")
        stream = p.stream(b"\n".join(content))
        pages.append(
            p.add(
                b"<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %.2f %.2f] "
                b"/Resources << /Font << /F1 %d 0 R >> >> /Contents %d 0 R >>"
                % (pages_obj, W, H, font, stream)
            )
        )

    kids = b" ".join(b"%d 0 R" % x for x in pages)
    p.objs[pages_obj] = (
        b"<< /Type /Pages /Count %d /Kids [%s] >>" % (len(pages), kids)
    )
    p.objs[catalog] = b"<< /Type /Catalog /Pages %d 0 R >>" % pages_obj

    data = p.build(catalog, pages_obj)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return path


def _jpeg_size(data: bytes) -> tuple[int, int]:
    i = 2
    while i < len(data) - 9:
        if data[i] != 0xFF:
            i += 1
            continue
        marker = data[i + 1]
        if marker in (0xC0, 0xC1, 0xC2, 0xC3):
            h, w = struct.unpack(">HH", data[i + 5 : i + 9])
            return w, h
        if marker in (0xD8, 0xD9):
            i += 2
            continue
        seg = struct.unpack(">H", data[i + 2 : i + 4])[0]
        i += 2 + seg
    return 0, 0


def write_image_pdf(images, path: Path) -> Path:
    """images: [(jpeg_bytes, width, height)] → 每张一页的图片 PDF。"""
    p = _PDF()
    catalog = p.add(b"")
    pages_obj = p.add(b"")
    pages = []
    for data, w, h in images:
        if not w or not h:
            w, h = _jpeg_size(data)
        pw, ph = W, W * h / w if w else H
        ph = min(ph, H)
        scale = min(pw / w, ph / h)
        dw, dh = w * scale, h * scale
        img = p.add(
            b"<< /Type /XObject /Subtype /Image /Width %d /Height %d "
            b"/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length %d >>\nstream\n"
            % (w, h, len(data))
            + data
            + b"\nendstream"
        )
        x = (pw - dw) / 2
        y = (ph - dh) / 2
        content = ("q %.2f 0 0 %.2f %.2f %.2f cm /Im0 Do Q" % (dw, dh, x, y)).encode()
        stream = p.stream(content)
        pages.append(
            p.add(
                b"<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %.2f %.2f] "
                b"/Resources << /XObject << /Im0 %d 0 R >> >> /Contents %d 0 R >>"
                % (pages_obj, pw, ph, img, stream)
            )
        )
    kids = b" ".join(b"%d 0 R" % x for x in pages)
    p.objs[pages_obj] = b"<< /Type /Pages /Count %d /Kids [%s] >>" % (len(pages), kids)
    p.objs[catalog] = b"<< /Type /Catalog /Pages %d 0 R >>" % pages_obj
    data = p.build(catalog, pages_obj)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return path