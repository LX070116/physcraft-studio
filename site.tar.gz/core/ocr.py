"""扫描版 / 纯图 PDF 转 DOCX 与可复制文字 PDF。

文字版 PDF：直接抽取文字 → 生成 DOCX + 干净的可复制 PDF。
扫描版 PDF：调用 Windows 自带 OCR（Windows.Media.Ocr，中文引擎）渲染识别 →
生成 DOCX + 可复制文字 PDF。无需联网、无需安装 tesseract。

Windows OCR 对低分辨率扫描件会有少量错字，转换结果可在 DOCX 中直接修改。
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

from . import pdf_writer
from .pdf_extract import extract_pdf, extract_text

ROOT = Path(__file__).resolve().parent.parent
PS1 = ROOT / "core" / "tools" / "pdf_ocr.ps1"
CJK = re.compile(r"[\u4e00-\u9fff]")
HEADING = re.compile(
    r"^(第[一二三四五六七八九十]+[章节]|[一二三四五六七八九十]+[、.．]|"
    r"\d+[、.．]\s*[^\d]|教学目标|教学重点|教学难点|教学过程|板书设计|作业|学情分析|"
    r"实验目的|实验器材|实验步骤|注意事项|探究|教材分析|课堂小结)"
)


def _powershell() -> str:
    for p in (
        r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
        "powershell.exe",
    ):
        if p == "powershell.exe" or Path(p).exists():
            return p
    return "powershell.exe"


def ocr_available() -> bool:
    if sys.platform != "win32" or not PS1.exists():
        return False
    try:
        out = subprocess.run(
            [
                _powershell(),
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                "Add-Type -AssemblyName System.Runtime.WindowsRuntime;"
                "[Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime]|Out-Null;"
                "([Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages|ForEach-Object{$_.LanguageTag}) -join ','",
            ],
            capture_output=True,
            text=True,
            timeout=25,
        )
        return "zh-Hans" in (out.stdout or "")
    except Exception:
        return False


def clean_ocr_text(text: str) -> str:
    """合并中文之间的空格、修正分页标记、压缩空行。"""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # 中文字符之间被 OCR 插入的空格
    prev = None
    while prev != text:
        prev = text
        text = re.sub(r"(?<=[\u4e00-\u9fff，。；：、！？（）《》])\s+(?=[\u4e00-\u9fff，。；：、！？（）《》])", "", text)
        text = re.sub(r"(?<=[\u4e00-\u9fff])\s+(?=[A-Za-z0-9])", " ", text)
    text = re.sub(r"\s+(?=[，。；：、！？）】》])", "", text)
    text = re.sub(r"(?<=[（【《])\s+", "", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _run_ocr(pdf_path: Path, workdir: Path) -> tuple[str, int]:
    workdir.mkdir(parents=True, exist_ok=True)
    cmd = [
        _powershell(),
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(PS1),
        "-Pdf",
        str(pdf_path),
        "-OutDir",
        str(workdir),
    ]
    res = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    out = workdir / "ocr.txt"
    if res.returncode != 0 or not out.exists():
        msg = (res.stderr or res.stdout or "").strip().splitlines()
        raise RuntimeError("OCR 失败：" + ("；".join(msg[-3:]) if msg else "未知错误"))
    raw = out.read_text(encoding="utf-8", errors="ignore")
    pages = [p for p in re.split(r"=== PAGE \d+ ===", raw) if p.strip()]
    try:
        n = int((workdir / "pages.txt").read_text(encoding="utf-8").strip())
    except Exception:
        n = len(pages)
    return "\n\n".join(clean_ocr_text(p) for p in pages), max(n, len(pages))


def _docx_from_text(text: str, path: Path, title: str = "") -> Path:
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Microsoft YaHei"
    style.font.size = Pt(10.5)
    style.element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    sec = doc.sections[0]
    sec.left_margin = sec.right_margin = Pt(56)
    if title:
        p = doc.add_paragraph()
        r = p.add_run(title)
        r.bold = True
        r.font.size = Pt(18)
        p.alignment = 1
    for line in text.split("\n"):
        s = line.strip()
        if not s:
            doc.add_paragraph("")
            continue
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(4)
        p.paragraph_format.line_spacing = 1.45
        r = p.add_run(s)
        if len(s) <= 30 and HEADING.match(s):
            r.bold = True
            r.font.size = Pt(13.5)
            r.font.color.rgb = RGBColor(0x03, 0x69, 0xA1)
        else:
            r.font.size = Pt(10.5)
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))
    return path


def _pdf_from_text(text: str, path: Path, title: str = "") -> Path:
    blocks = []
    if title:
        blocks.append({"text": title, "level": 1})
    for line in text.split("\n"):
        s = line.strip()
        if not s:
            continue
        lvl = 2 if (len(s) <= 30 and HEADING.match(s)) else 0
        blocks.append({"text": s, "level": lvl})
    return pdf_writer.write_text_pdf(blocks, path)


def convert_pdf(data: bytes, outdir: Path, title: str = "") -> dict:
    """检测类型 → 抽取/OCR → 生成 DOCX、可复制 PDF、TXT。"""
    if not data.startswith(b"%PDF"):
        raise ValueError("不是有效的 PDF 文件")
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    src = outdir / "source.pdf"
    src.write_bytes(data)

    pages = 0
    text = ""
    mode = "text"
    try:
        text = extract_pdf(data, min_chars=1)
        pages = len(re.findall(rb"/Type\s*/Page\b", data))
    except Exception:
        text = ""

    compact = re.sub(r"\s", "", text)
    if len(compact) < 40:
        mode = "ocr"
        if not ocr_available():
            raise ValueError("这台电脑没有可用的中文 OCR（需要 Windows 10/11 中文 OCR 组件），请先安装中文语言包，或改用 DOCX。")
        text, ocr_pages = _run_ocr(src, outdir / "ocr")
        if len(re.sub(r"\s", "", text)) < 20:
            raise ValueError("OCR 未识别到文字：请确认 PDF 页面清晰、方向正确。")
        pages = max(pages, ocr_pages)
    else:
        # 文字版也做一次轻度整理（合并断行、去多余空格）
        text = clean_ocr_text(text)

    (outdir / "converted.txt").write_text(text, encoding="utf-8")
    _docx_from_text(text, outdir / "converted.docx", title)
    try:
        _pdf_from_text(text, outdir / "converted.pdf", title)
    except Exception:
        pass

    info = {
        "mode": mode,
        "pages": pages,
        "chars": len(re.sub(r"\s", "", text)),
        "preview": text[:600],
    }
    (outdir / "meta.json").write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"id": outdir.name, **info,
            "docx": f"/api/tools/{outdir.name}/docx",
            "pdf": f"/api/tools/{outdir.name}/pdf",
            "txt": f"/api/tools/{outdir.name}/txt"}