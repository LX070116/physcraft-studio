"""悟理智课 core 包。"""

__version__ = "1.0.0"