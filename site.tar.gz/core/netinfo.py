"""局域网访问信息：本机地址、可用 URL 与防火墙提示。"""
from __future__ import annotations

import socket

PORT_FALLBACK = 8770


def local_ips() -> list[str]:
    ips: list[str] = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ips.append(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip not in ips and not ip.startswith("127."):
                ips.append(ip)
    except Exception:
        pass
    # 过滤 APIPA
    return [ip for ip in ips if not ip.startswith("169.254.")]


def info(port: int = PORT_FALLBACK) -> dict:
    ips = local_ips()
    urls = [f"http://{ip}:{port}" for ip in ips]
    return {
        "port": port,
        "ips": ips,
        "urls": urls,
        "primary": urls[0] if urls else f"http://127.0.0.1:{port}",
        "loopback": f"http://127.0.0.1:{port}",
        "sameLan": "其他设备必须与本机在同一网段（例如本机 172.18.x.x，手机也应是 172.18.x.x），仅有同一个 Wi-Fi 名称还不够。",
        "firewallCommand": 'netsh advfirewall firewall add rule name="PhysCraft 8770" dir=in action=allow protocol=TCP localport=8770',
        "tips": [
            "本平台默认监听 0.0.0.0，启动日志会打印可用地址。",
            "Windows 防火墙默认拦截入站：首次运行请允许“专用网络”，或以管理员执行防火墙命令。",
            "若本机只有有线网卡（如 172.18.x.x）而手机连的是家用 Wi-Fi（如 192.168.x.x），两者不同网段，无法互访。",
            "企业/校园网可能开启客户端隔离（AP isolation），此时同网段也无法互访。",
        ],
    }