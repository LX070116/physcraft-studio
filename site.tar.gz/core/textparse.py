"""文档解析：docx / pptx / 纯文本 → 结构化文本。"""
from __future__ import annotations

import io
import re
from pathlib import Path

from docx import Document
from pptx import Presentation
from pptx.util import Emu

from .util import split_sections
from .pdf_extract import extract_pdf


def _docx_text(data: bytes) -> tuple[str, list[str]]:
    doc = Document(io.BytesIO(data))
    paras: list[str] = []
    for p in doc.paragraphs:
        t = (p.text or "").strip()
        if t:
            paras.append(t)
    for tb in doc.tables:
        for row in tb.rows:
            cells = [c.text.strip() for c in row.cells if c.text.strip()]
            if cells:
                paras.append(" | ".join(dict.fromkeys(cells)))
    return "\n".join(paras), paras


def _shape_text(shape) -> str:
    try:
        if shape.has_text_frame:
            return "\n".join(p.text for p in shape.text_frame.paragraphs if p.text and p.text.strip())
    except Exception:
        pass
    return ""


def _walk_shapes(shapes):
    for sh in shapes:
        try:
            if sh.shape_type == 6:  # group
                yield from _walk_shapes(sh.shapes)
                continue
        except Exception:
            pass
        yield sh


def _pptx_parse(data: bytes) -> dict:
    prs = Presentation(io.BytesIO(data))
    width = prs.slide_width or Emu(12192000)
    height = prs.slide_height or Emu(6858000)
    slides = []
    for idx, slide in enumerate(prs.slides, start=1):
        texts: list[str] = []
        sizes: list[float] = []
        images = 0
        for sh in _walk_shapes(slide.shapes):
            t = _shape_text(sh)
            if t:
                texts.append(t)
            if sh.shape_type == 13:  # picture
                images += 1
            try:
                if sh.has_text_frame:
                    for p in sh.text_frame.paragraphs:
                        for r in p.runs:
                            if r.font.size:
                                sizes.append(round(r.font.size.pt, 1))
            except Exception:
                pass
        notes = ""
        try:
            if slide.has_notes_slide:
                notes = (slide.notes_slide.notes_text_frame.text or "").strip()
        except Exception:
            pass
        title = ""
        for t in texts:
            line = t.split("\n")[0].strip()
            if 2 <= len(line) <= 40:
                title = line
                break
        slide_text = "\n".join(dict.fromkeys(texts))
        slides.append(
            {
                "index": idx,
                "title": title or f"第 {idx} 页",
                "texts": texts,
                "text": slide_text,
                "chars": len(re.sub(r"\s", "", slide_text)),
                "minFont": min(sizes) if sizes else None,
                "images": images,
                "notes": notes,
            }
        )
    ratio = round((width / height), 3) if height else 1.778
    return {
        "kind": "pptx",
        "slideWidth": width,
        "slideHeight": height,
        "ratio": ratio,
        "slides": slides,
        "text": "\n".join(s["text"] for s in slides),
    }


def parse_bytes(name: str, data: bytes) -> dict:
    suffix = Path(name).suffix.lower()
    if suffix == ".docx":
        text, paras = _docx_text(data)
        return {"kind": "docx", "name": name, "text": text, "paragraphs": paras, "sections": split_sections(text)}
    if suffix == ".pptx":
        out = _pptx_parse(data)
        out["name"] = name
        return out
    if suffix == ".pdf":
        text = extract_pdf(data)
        return {
            "kind": "pdf",
            "name": name,
            "text": text,
            "paragraphs": [p for p in text.split("\n") if p.strip()],
            "sections": split_sections(text),
        }
    if suffix in (".txt", ".md", ".markdown", ".json", ".csv"):
        text = data.decode("utf-8", errors="ignore")
        return {"kind": "text", "name": name, "text": text, "paragraphs": [p for p in text.split("\n") if p.strip()], "sections": split_sections(text)}
    if suffix == ".doc":
        raise ValueError("暂不支持 .doc 旧格式，请另存为 .docx 后上传")
    raise ValueError(f"不支持的文件类型：{suffix or '未知'}（支持 .docx / .pptx / .txt / .md）")


# ---------- 教案结构识别 ----------
SECTION_ALIASES = {
    "objectives": ["教学目标", "教学目的", "学习目标", "核心素养"],
    "key": ["教学重点", "重点", "教学重点难点"],
    "hard": ["教学难点", "难点"],
    "students": ["学情分析", "学生分析", "学情"],
    "process": ["教学过程", "教学活动", "教学环节", "教学过程设计"],
    "board": ["板书设计", "板书"],
    "homework": ["作业设计", "分层作业", "作业"],
    "reflection": ["教学反思", "反思"],
    "materials": ["教学准备", "教具", "教学资源"],
    "methods": ["教学方法", "教法", "学法"],
    "analysis": ["教材分析", "教材"],
}


def normalize_plan(text: str) -> dict:
    """把任意教案文本整理成结构化字段（缺失字段给出兜底）。"""
    secs = split_sections(text)
    out: dict = {"sections": secs}

    def find(names: list[str]) -> str:
        for n in names:
            for k, v in secs.items():
                if n in k:
                    return v.strip()
        return ""

    out["objectives"] = find(SECTION_ALIASES["objectives"])
    out["key"] = find(SECTION_ALIASES["key"])
    out["hard"] = find(SECTION_ALIASES["hard"])
    out["students"] = find(SECTION_ALIASES["students"])
    out["process"] = find(SECTION_ALIASES["process"])
    out["board"] = find(SECTION_ALIASES["board"])
    out["homework"] = find(SECTION_ALIASES["homework"])
    out["methods"] = find(SECTION_ALIASES["methods"])
    out["analysis"] = find(SECTION_ALIASES["analysis"])

    # 行内提取“重点：xxx / 难点：xxx”
    if not out["key"]:
        m = re.search(r"(?:教学)?重点\s*[:：]\s*([^\n]{2,120})", text)
        out["key"] = m.group(1).strip() if m else ""
    if not out["hard"]:
        m = re.search(r"(?:教学)?难点\s*[:：]\s*([^\n]{2,120})", text)
        out["hard"] = m.group(1).strip() if m else ""
    return out


def plan_signals(text: str) -> dict:
    """教案质量信号（用于诊断）。"""
    t = text or ""
    m = re.search(r"(?:课时|时长|时间)\s*[:：]?\s*(\d{2,3})\s*(?:分钟|min)", t)
    duration = int(m.group(1)) if m else None
    clocks = [int(x) for x in re.findall(r"(\d{1,3})\s*(?:分钟|min)", t)]
    return {
        "duration": duration,
        "timeMentions": clocks,
        "timeSum": sum(clocks) if clocks else 0,
        "hasObjectives": bool(re.search(r"(教学目标|学习目标|核心素养)", t)),
        "hasKeyHard": bool(re.search(r"(教学重点|教学难点|重点|难点)", t)),
        "hasStudents": bool(re.search(r"(学情|学生分析|前测|已有基础|认知)", t)),
        "hasProcess": bool(re.search(r"(教学过程|教学环节|活动设计)", t)),
        "hasBoard": bool(re.search(r"板书", t)),
        "hasHomework": bool(re.search(r"(作业|练习|任务)", t)),
        "hasAssessment": bool(re.search(r"(评价|检测|达标|反馈)", t)),
        "hasExperiment": bool(re.search(r"(实验|探究|演示|仿真|测量)", t)),
        "hasDifferentiation": bool(re.search(r"(分层|基础层|提高层|拓展|学困|学优)", t)),
        "measurable": len(re.findall(r"(说出|列举|解释|运用|计算|测量|绘制|设计|分析|归纳|说明|比较|建构)", t)),
        "chars": len(re.sub(r"\s", "", t)),
    }