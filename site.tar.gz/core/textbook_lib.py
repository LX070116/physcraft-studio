"""官方教材 PDF 管理：导入、页图渲染、列表、下载。

平台不内置受版权保护的教材原文；教师可导入自己合法持有的教材 PDF，
平台负责存储、逐页渲染与重难点注释展示，不做二次分发。
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

from .util import new_id

ROOT = Path(__file__).resolve().parent.parent
LIB = ROOT / "data" / "textbooks"
PS1 = ROOT / "core" / "tools" / "pdf_render.ps1"


def _powershell() -> str:
    p = r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
    return p if Path(p).exists() else "powershell.exe"


def _render(pdf: Path, outdir: Path, width: int = 1500) -> int:
    if sys.platform != "win32" or not PS1.exists():
        return 0
    try:
        res = subprocess.run(
            [_powershell(), "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(PS1), "-Pdf", str(pdf), "-OutDir", str(outdir), "-Width", str(width)],
            capture_output=True,
            text=True,
            timeout=600,
        )
        if res.returncode != 0:
            return 0
        return int((outdir / "pages.txt").read_text(encoding="utf-8").strip() or 0)
    except Exception:
        return 0


def save(data: bytes, title: str, book_id: str = "", stage: str = "") -> dict:
    if not data.startswith(b"%PDF"):
        raise ValueError("不是有效的 PDF 文件")
    LIB.mkdir(parents=True, exist_ok=True)
    tid = new_id("B")
    d = LIB / tid
    d.mkdir(parents=True, exist_ok=True)
    src = d / "source.pdf"
    src.write_bytes(data)
    pages = _render(src, d / "pages")
    meta = {
        "id": tid,
        "title": title or "未命名教材",
        "bookId": book_id,
        "stage": stage,
        "pages": pages,
        "size": len(data),
        "filename": src.name,
    }
    (d / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return meta


def list_books() -> list[dict]:
    out = []
    if not LIB.exists():
        return out
    for d in LIB.iterdir():
        if not d.is_dir():
            continue
        try:
            meta = json.loads((d / "meta.json").read_text(encoding="utf-8"))
        except Exception:
            continue
        meta["hasPages"] = (d / "pages" / "page-001.png").exists()
        out.append(meta)
    out.sort(key=lambda m: m.get("id", ""), reverse=True)
    return out


def get(tid: str) -> dict | None:
    d = LIB / tid
    if not (d / "meta.json").exists():
        return None
    try:
        return json.loads((d / "meta.json").read_text(encoding="utf-8"))
    except Exception:
        return None


def pdf_path(tid: str) -> Path | None:
    p = LIB / tid / "source.pdf"
    return p if p.exists() else None


def page_path(tid: str, n: int) -> Path | None:
    p = LIB / tid / "pages" / ("page-%03d.png" % n)
    return p if p.exists() else None


def delete(tid: str) -> bool:
    d = LIB / tid
    if not d.exists():
        return False
    for f in d.rglob("*"):
        if f.is_file():
            f.unlink()
    for f in sorted(d.rglob("*"), reverse=True):
        if f.is_dir():
            f.rmdir()
    d.rmdir()
    return True