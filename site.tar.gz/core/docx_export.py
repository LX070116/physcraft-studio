"""教案 / 诊断报告 → DOCX。"""
from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

FONT = "Microsoft YaHei"
INK = RGBColor(0x1F, 0x29, 0x37)
MUTED = RGBColor(0x6B, 0x72, 0x80)
ACCENT = RGBColor(0x03, 0x69, 0xA1)


def _font(run, size=None, bold=None, color=None, name=FONT):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), name)
    if size:
        run.font.size = Pt(size)
    if bold is not None:
        run.font.bold = bold
    if color is not None:
        run.font.color.rgb = color


def _shade(cell, hexcolor: str):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hexcolor)
    tcPr.append(shd)


def _cell(cell, text, size=10.5, bold=False, color=INK, align=WD_ALIGN_PARAGRAPH.LEFT):
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = align
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(text)
    _font(r, size, bold, color)


def _h(doc, text, level=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(14 if level == 1 else 8)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(text)
    _font(r, 15 if level == 1 else 12, True, ACCENT if level == 1 else INK)
    if level == 1:
        pPr = p._p.get_or_add_pPr()
        pbdr = OxmlElement("w:pBdr")
        bottom = OxmlElement("w:bottom")
        bottom.set(qn("w:val"), "single")
        bottom.set(qn("w:sz"), "8")
        bottom.set(qn("w:color"), "0369A1")
        pbdr.append(bottom)
        pPr.append(pbdr)
    return p


def _p(doc, text, size=10.5, color=INK, bold=False, indent=0.0, space_after=3):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = 1.35
    if indent:
        p.paragraph_format.left_indent = Cm(indent)
    r = p.add_run(text)
    _font(r, size, bold, color)
    return p


def export_plan_docx(plan: dict, path: Path) -> Path:
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Cm(2.0)
    sec.bottom_margin = Cm(2.0)
    sec.left_margin = Cm(2.2)
    sec.right_margin = Cm(2.2)

    style = doc.styles["Normal"]
    style.font.name = FONT
    style.font.size = Pt(10.5)
    style.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)

    # 标题
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(plan.get("title", "教学设计"))
    _font(r, 20, True, INK)
    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    meta = plan.get("meta", {})
    sub = " ｜ ".join(
        x
        for x in [
            meta.get("textbook", ""),
            meta.get("chapter", ""),
            f"{meta.get('duration', 45)} 分钟",
            f"学情：{meta.get('classLevel', '中等')}",
            meta.get("date", ""),
        ]
        if x
    )
    r = p2.add_run(sub)
    _font(r, 9, False, MUTED)

    # 基本信息表
    tb = doc.add_table(rows=2, cols=4)
    tb.style = "Table Grid"
    tb.alignment = WD_TABLE_ALIGNMENT.CENTER
    heads = ["学科", "年级", "课型", "课时"]
    vals = ["物理", meta.get("grade", ""), meta.get("style", "探究式"), f"{meta.get('duration', 45)} 分钟"]
    for i in range(4):
        _cell(tb.rows[0].cells[i], heads[i], 9, True, MUTED, WD_ALIGN_PARAGRAPH.CENTER)
        _shade(tb.rows[0].cells[i], "F3F4F6")
        _cell(tb.rows[1].cells[i], vals[i], 10, False, INK, WD_ALIGN_PARAGRAPH.CENTER)

    _h(doc, "一、教材与学情分析")
    sa = plan.get("studentAnalysis", {})
    _p(doc, f"【教材】{plan.get('summary', '')}")
    _p(
        doc,
        f"【学情】班级层次：{sa.get('level', '中等')}"
        + (f"；前测均分：{sa.get('preScore')}" if sa.get("preScore") else "")
        + (f"；已有基础：{sa.get('prior')}" if sa.get("prior") else ""),
    )
    if sa.get("gaps"):
        _p(doc, "【认知障碍】", bold=True)
        for g in sa["gaps"]:
            _p(doc, "· " + g, indent=0.5)
    if sa.get("strategies"):
        _p(doc, "【教学对策】", bold=True)
        for s in sa["strategies"]:
            _p(doc, "· " + s, indent=0.5)

    _h(doc, "二、教学目标")
    for o in plan.get("objectives", []):
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(3)
        r = p.add_run(f"{o['dim']}：")
        _font(r, 10.5, True, INK)
        r2 = p.add_run(o["text"])
        _font(r2, 10.5, False, INK)

    _h(doc, "三、教学重点与难点")
    _p(doc, "【重点】" + "；".join(plan.get("keyPoints", [])), bold=False)
    _p(doc, "【难点】" + "；".join(plan.get("hardPoints", [])), bold=False)
    if plan.get("misconceptions"):
        _p(doc, "【预判误区】" + "；".join(plan["misconceptions"]), color=MUTED, size=9.5)

    _h(doc, "四、教学方法与准备")
    _p(doc, "教学方法：" + "、".join(plan.get("methods", [])))
    _p(doc, "教学准备：" + "；".join(plan.get("materials", [])))

    _h(doc, "五、教学过程")
    rows = len(plan.get("process", [])) + 1
    tb = doc.add_table(rows=rows, cols=5)
    tb.style = "Table Grid"
    widths = [Cm(2.0), Cm(1.5), Cm(5.0), Cm(4.6), Cm(3.4)]
    headers = ["环节", "时间", "教师活动", "学生活动", "设计意图"]
    for i, hd in enumerate(headers):
        c = tb.rows[0].cells[i]
        _cell(c, hd, 9, True, RGBColor(0xFF, 0xFF, 0xFF), WD_ALIGN_PARAGRAPH.CENTER)
        _shade(c, "0369A1")
        c.width = widths[i]
    for ri, st in enumerate(plan.get("process", []), start=1):
        vals = [st["name"], f"{st['minutes']}′", st["teacher"], st["student"], st["intent"]]
        for ci, v in enumerate(vals):
            c = tb.rows[ri].cells[ci]
            _cell(c, v, 9, ci == 0, INK)
            c.width = widths[ci]
            if ci == 0:
                _shade(c, "F8FAFC")

    _h(doc, "六、板书设计")
    board = plan.get("board", {})
    _p(doc, f"课题：{board.get('title', '')}", bold=True, size=12)
    for b in board.get("blocks", []):
        if not b.get("lines"):
            continue
        _p(doc, f"【{b['label']}】", bold=True, size=10)
        for ln in b["lines"]:
            _p(doc, "　" + ln, indent=0.4, size=10)

    _h(doc, "七、分层作业")
    hw = plan.get("homework", {})
    for label, key, tag in (("基础层（必做）", "basic", "★"), ("提高层（选做）", "improve", "★★"), ("拓展层（挑战）", "extend", "★★★")):
        _p(doc, f"{label} {tag}", bold=True, size=10)
        for it in hw.get(key, []):
            _p(doc, "· " + it, indent=0.4, size=10)

    _h(doc, "八、评价设计")
    asm = plan.get("assessment", {})
    _p(doc, "课堂观察点：", bold=True, size=10)
    for o in asm.get("observations", []):
        _p(doc, "· " + o, indent=0.4, size=10)
    _p(doc, "目标检测题：", bold=True, size=10)
    for i, q in enumerate(asm.get("items", []), start=1):
        _p(doc, f"{i}. {q.get('stem', '')}", indent=0.3, size=10)
        if q.get("answer"):
            _p(doc, f"   参考答案：{q['answer']}", indent=0.3, size=9, color=MUTED)
    if asm.get("rubric"):
        _p(doc, "评分维度：" + "；".join(asm["rubric"]), size=9, color=MUTED)

    _h(doc, "九、教学反思（课后填写）")
    for _ in range(3):
        _p(doc, "　", size=10)
    _p(doc, "提示：记录目标达成率、学生典型错误、仿真/VR 环节的实际效果与改进点。", size=9, color=MUTED)

    if plan.get("narration"):
        doc.add_page_break()
        _h(doc, "附：数字人讲稿（可直接用于课件配音）")
        for n in plan["narration"]:
            _p(doc, f"【{n['scene']}】{n['text']}", size=10)

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))
    return path


def export_report_docx(diag: dict, deck: dict, path: Path) -> Path:
    doc = Document()
    sec = doc.sections[0]
    sec.left_margin = Cm(2.0)
    sec.right_margin = Cm(2.0)
    style = doc.styles["Normal"]
    style.font.name = FONT
    style.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("课件诊断与优化报告")
    _font(r, 18, True, INK)
    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p2.add_run(f"{deck.get('meta', {}).get('title', '')}　｜　{deck.get('meta', {}).get('date', '')}")
    _font(r, 9, False, MUTED)

    _h(doc, "一、总体评分")
    tb = doc.add_table(rows=2, cols=5)
    tb.style = "Table Grid"
    heads = ["诊断得分", "页数", "总字数", "平均字数/页", "最小字号"]
    vals = [
        f"{diag.get('score')} / 100",
        str(diag.get("slideCount")),
        str(diag.get("chars")),
        f"{diag.get('avgChars')}",
        f"{diag.get('minFont') or '—'} pt",
    ]
    for i in range(5):
        _cell(tb.rows[0].cells[i], heads[i], 9, True, MUTED, WD_ALIGN_PARAGRAPH.CENTER)
        _shade(tb.rows[0].cells[i], "F3F4F6")
        _cell(tb.rows[1].cells[i], vals[i], 12, True, INK, WD_ALIGN_PARAGRAPH.CENTER)

    _h(doc, "二、问题清单")
    cols = ["级别", "问题", "证据", "改进建议"]
    tb = doc.add_table(rows=len(diag.get("issues", [])) + 1, cols=4)
    tb.style = "Table Grid"
    for i, hd in enumerate(cols):
        c = tb.rows[0].cells[i]
        _cell(c, hd, 9, True, RGBColor(0xFF, 0xFF, 0xFF), WD_ALIGN_PARAGRAPH.CENTER)
        _shade(c, "B45309")
    for ri, it in enumerate(diag.get("issues", []), start=1):
        for ci, key in enumerate(["level", "title", "evidence", "fix"]):
            _cell(tb.rows[ri].cells[ci], str(it.get(key, "")), 9, ci == 1, INK)

    _h(doc, "三、优化后结构")
    for i, s in enumerate(deck.get("scenes", []), start=1):
        _p(doc, f"{i:02d}　[{s.get('type')}] {s.get('title', '')}", size=10)

    _h(doc, "四、使用说明")
    _p(doc, "1. 优化后的 .pptx 可直接编辑；交互仿真、VR、数字人、立体课本页为入口页，配套交互课件在浏览器中打开。")
    _p(doc, "2. 每页讲稿已写入 PPT 备注，可用于课堂提词或数字人配音。")
    _p(doc, "3. 若需调整结构，可在平台中重新生成或修改知识点后再次优化。", )

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))
    return path