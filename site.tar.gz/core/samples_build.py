"""生成演示用示例文件（一份待优化的教案 + 一份待优化的原版 PPT）。"""
from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.oxml.ns import qn
from docx.shared import Pt
from pptx import Presentation
from pptx.util import Inches, Pt as PPt

ROOT = Path(__file__).resolve().parent.parent
SAMPLES = ROOT / "samples"

LESSON_TEXT = """《凸透镜成像的规律》教学设计

一、教学目标
1. 了解凸透镜成像的规律。
2. 掌握实验探究的方法。

二、教学重点
凸透镜成像的规律。

三、教学难点
物距与像距的关系。

四、教学过程
1. 导入：用放大镜观察课本上的字，引导学生思考为什么字会变大。
2. 新授：讲解凸透镜成像的规律，分别介绍 u>2f、f<u<2f、u<f 三种情况。
3. 实验：学生分组进行实验，记录物距、像距和像的性质。
4. 小结：总结凸透镜成像规律。
5. 作业：完成课后练习第 1、2 题。

五、板书设计
凸透镜成像规律：
u>2f  倒立缩小实像
f<u<2f 倒立放大实像
u<f  正立放大虚像
"""


def _font(doc):
    style = doc.styles["Normal"]
    style.font.name = "Microsoft YaHei"
    style.font.size = Pt(10.5)
    style.element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")


def build_lesson() -> Path:
    path = SAMPLES / "示例教案-凸透镜成像.docx"
    if path.exists():
        return path
    doc = Document()
    _font(doc)
    for i, line in enumerate(LESSON_TEXT.strip().split("\n")):
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(4)
        r = p.add_run(line)
        if i == 0:
            r.bold = True
            r.font.size = Pt(16)
    SAMPLES.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))
    return path


PPT_SLIDES = [
    (
        "凸透镜成像",
        "八年级物理上册 第五章\n人教版",
    ),
    (
        "学习目标",
        "1. 了解凸透镜成像的规律，知道凸透镜在生活中的应用。\n"
        "2. 通过实验探究，掌握物距、像距和像的性质之间的关系，能够根据物距判断像的性质。\n"
        "3. 培养观察能力、实验操作能力和归纳总结能力，体会物理与生活的联系。",
    ),
    (
        "认识凸透镜",
        "凸透镜是中间厚、边缘薄的透镜，对光有会聚作用。\n"
        "平行于主光轴的光线经凸透镜折射后会聚于焦点。\n"
        "焦点到光心的距离叫焦距，用 f 表示。\n"
        "凸透镜有三个特殊光线：平行于主光轴的光线过焦点；过光心的光线方向不变；过焦点的光线平行于主光轴射出。\n"
        "利用这三条特殊光线可以作出物体经凸透镜所成的像。",
    ),
    (
        "凸透镜成像规律",
        "当物距大于二倍焦距时，成倒立、缩小的实像，像距在一倍焦距和二倍焦距之间，照相机利用这一原理。\n"
        "当物距在一倍焦距和二倍焦距之间时，成倒立、放大的实像，像距大于二倍焦距，投影仪利用这一原理。\n"
        "当物距小于一倍焦距时，成正立、放大的虚像，放大镜利用这一原理。\n"
        "当物距等于二倍焦距时，成倒立、等大的实像。\n"
        "当物距等于一倍焦距时，不成像。",
    ),
    (
        "实验：探究凸透镜成像规律",
        "实验器材：光具座、凸透镜、蜡烛、光屏、火柴。\n"
        "实验步骤：\n"
        "1. 把蜡烛、凸透镜、光屏依次放在光具座上。\n"
        "2. 调节烛焰、凸透镜、光屏的中心大致在同一高度。\n"
        "3. 把蜡烛放在较远处，调整光屏位置，直到光屏上出现清晰的像。\n"
        "4. 记录物距、像距和像的性质。\n"
        "5. 改变物距，重复上述步骤。",
    ),
    (
        "实验结论",
        "凸透镜成像的规律可以概括为：物距越大，像距越小，像越小；物距越小，像距越大，像越大。\n"
        "实像都是倒立的，虚像都是正立的。\n"
        "物体在二倍焦距以外成缩小的像，在一倍焦距和二倍焦距之间成放大的像。",
    ),
    (
        "课堂练习",
        "1. 凸透镜焦距为 10 cm，物体放在距透镜 30 cm 处，成的像是什么性质？\n"
        "2. 照相机、投影仪、放大镜分别利用了凸透镜成像的哪种情况？",
    ),
    (
        "谢谢",
        "请完成课后练习",
    ),
]


def build_pptx() -> Path:
    path = SAMPLES / "示例-凸透镜成像(原版).pptx"
    if path.exists():
        return path
    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)
    blank = prs.slide_layouts[6]
    for title, body in PPT_SLIDES:
        s = prs.slides.add_slide(blank)
        tb = s.shapes.add_textbox(Inches(0.6), Inches(0.5), Inches(8.8), Inches(0.9))
        tf = tb.text_frame
        tf.word_wrap = True
        r = tf.paragraphs[0].add_run()
        r.text = title
        r.font.size = PPt(28)
        r.font.name = "Microsoft YaHei"
        r.font.bold = True
        if body:
            tb2 = s.shapes.add_textbox(Inches(0.6), Inches(1.6), Inches(8.8), Inches(5.4))
            tf2 = tb2.text_frame
            tf2.word_wrap = True
            for i, line in enumerate(body.split("\n")):
                p = tf2.paragraphs[0] if i == 0 else tf2.add_paragraph()
                run = p.add_run()
                run.text = line
                run.font.size = PPt(14)
                run.font.name = "Microsoft YaHei"
    SAMPLES.mkdir(parents=True, exist_ok=True)
    prs.save(str(path))
    return path


def ensure_samples() -> tuple[Path, Path]:
    return build_lesson(), build_pptx()


if __name__ == "__main__":
    a, b = ensure_samples()
    print("已生成：", a.name, b.name)