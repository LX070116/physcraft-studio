"""电子教材：把知识库编排成可在线阅读、可下载的教材读本。

说明：这是平台依据教材目录与课标要点自行编排的“知识读本”，
不是出版社教材的扫描件或原文复制。
"""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

from . import pdf_writer
from .kb import get_kb
from .util import read_json

ROOT = Path(__file__).resolve().parent.parent
INK = RGBColor(0x1F, 0x29, 0x37)
ACCENT = RGBColor(0x03, 0x69, 0xA1)
FONT = "Microsoft YaHei"


def _experiments() -> list[dict]:
    data = read_json(ROOT / "core" / "experiments.json") or {}
    return data.get("items", [])


def _point_payload(p: dict, exps: list[dict]) -> dict:
    related = [e for e in exps if p["id"] in (e.get("points") or []) or (p.get("title") and p["title"] in (e.get("title") or ""))]
    return {
        "id": p["id"],
        "title": p["title"],
        "summary": p.get("summary", ""),
        "core": p.get("core", []),
        "key": p.get("key", []),
        "hard": p.get("hard", []),
        "formulas": p.get("formulas", []),
        "misconceptions": p.get("misconceptions", []),
        "experiments": p.get("experiments", []),
        "importance": p.get("importance", 2),
        "difficulty": p.get("difficulty", 2),
        "sim": p.get("sim", ""),
        "vr": p.get("vr", ""),
        "labTitles": [e.get("title", "") for e in related][:4],
    }


def build(stage: str) -> dict:
    kb = get_kb()
    exps = _experiments()
    books_out = []
    n_ch = n_pt = 0
    for tb in kb.textbooks.values():
        if tb.get("stage") != stage:
            continue
        chapters = []
        for ch in kb.chapters_of(tb["id"]):
            pts = kb.points_of_chapter(ch["id"])
            if not pts:
                continue
            n_ch += 1
            n_pt += len(pts)
            chapters.append(
                {
                    "id": ch["id"],
                    "no": ch.get("no", 0),
                    "title": ch["title"],
                    "theme": ch.get("theme", ""),
                    "points": [_point_payload(p, exps) for p in pts],
                }
            )
        if chapters:
            books_out.append({"id": tb["id"], "name": tb["name"], "grade": tb.get("grade", ""), "chapters": chapters})
    return {
        "stage": stage,
        "title": f"{stage}物理 · 电子教材（知识读本）",
        "subtitle": "依据教材目录与课标要点编排，可在线阅读或下载",
        "generated": date.today().isoformat(),
        "books": books_out,
        "stats": {"books": len(books_out), "chapters": n_ch, "points": n_pt, "experiments": len(exps) if exps else 0},
    }


def _blocks(stage: str) -> list[dict]:
    data = build(stage)
    blocks = [{"text": data["title"], "level": 1}, {"text": data["subtitle"], "level": -1}]
    blocks.append({"text": "编写说明", "level": 2})
    blocks.append(
        {
            "text": "本读本由平台依据中学物理教材目录与课程标准要点编排，用于教师备课与学生复习；"
            "内容为知识要点、公式、易错辨析与实验建议的整理，不含教材原文与插图。",
            "level": 0,
        }
    )
    for book in data["books"]:
        blocks.append({"text": book["name"], "level": 2})
        for ch in book["chapters"]:
            blocks.append({"text": f"第{ch['no']}章  {ch['title']}".replace("第第", "第"), "level": 2})
            for p in ch["points"]:
                blocks.append({"text": p["title"], "level": 2})
                if p["summary"]:
                    blocks.append({"text": p["summary"], "level": 0})
                if p["core"]:
                    blocks.append({"text": "核心结论", "level": -1})
                    for c in p["core"]:
                        blocks.append({"text": "· " + c, "level": 0})
                if p["formulas"]:
                    blocks.append({"text": "公式：" + "；".join(p["formulas"]), "level": 0})
                if p["key"]:
                    blocks.append({"text": "重点：" + "；".join(p["key"]), "level": 0})
                if p["hard"]:
                    blocks.append({"text": "难点：" + "；".join(p["hard"]), "level": 0})
                if p["misconceptions"]:
                    blocks.append({"text": "易错辨析", "level": -1})
                    for m in p["misconceptions"][:3]:
                        blocks.append({"text": "× " + m.replace("认为", "", 1), "level": 0})
                if p["labTitles"]:
                    blocks.append({"text": "相关实验：" + "；".join(p["labTitles"]), "level": -1})
                blocks.append({"text": "", "level": 0})
    return blocks


def export_docx(stage: str, path: Path) -> Path:
    data = build(stage)
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = FONT
    style.font.size = Pt(10.5)
    style.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    sec = doc.sections[0]
    sec.left_margin = sec.right_margin = Cm(2.2)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(data["title"])
    r.bold = True
    r.font.size = Pt(24)
    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p2.add_run(data["subtitle"] + "　·　" + data["generated"])
    r.font.size = Pt(9)
    r.font.color.rgb = RGBColor(0x6B, 0x72, 0x80)

    doc.add_paragraph("编写说明")
    doc.paragraphs[-1].runs[0].bold = True
    doc.add_paragraph(
        "本读本由平台依据中学物理教材目录与课程标准要点编排，用于教师备课与学生复习；"
        "内容为知识要点、公式、易错辨析与实验建议的整理，不含教材原文与插图。"
    )

    for book in data["books"]:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(16)
        r = p.add_run(book["name"])
        r.bold = True
        r.font.size = Pt(15)
        r.font.color.rgb = ACCENT
        for ch in book["chapters"]:
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(10)
            r = p.add_run(f"第{ch['no']}章　{ch['title']}")
            r.bold = True
            r.font.size = Pt(12.5)
            for pt in ch["points"]:
                p = doc.add_paragraph()
                p.paragraph_format.space_before = Pt(6)
                r = p.add_run(pt["title"])
                r.bold = True
                r.font.size = Pt(11)
                if pt["summary"]:
                    doc.add_paragraph(pt["summary"])
                for c in pt["core"]:
                    doc.add_paragraph("· " + c)
                if pt["formulas"]:
                    doc.add_paragraph("公式：" + "；".join(pt["formulas"]))
                if pt["key"]:
                    doc.add_paragraph("重点：" + "；".join(pt["key"]))
                if pt["hard"]:
                    doc.add_paragraph("难点：" + "；".join(pt["hard"]))
                for m in pt["misconceptions"][:3]:
                    doc.add_paragraph("× " + m.replace("认为", "", 1))
                if pt["labTitles"]:
                    doc.add_paragraph("相关实验：" + "；".join(pt["labTitles"]))
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))
    return path


def export_pdf(stage: str, path: Path) -> Path:
    return pdf_writer.write_text_pdf(_blocks(stage), Path(path), title=build(stage)["title"])