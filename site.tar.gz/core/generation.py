"""课件（场景 DSL）生成：教案 → 可交互课件；PPT 优化。"""
from __future__ import annotations

import re
from datetime import date

from . import physics_problems as pp
from . import questionbank
from .kb import get_kb
from .lessonplan import generate as generate_plan, scenario, SIM_TASKS, VR_TASKS
from .textparse import normalize_plan, plan_signals
from .util import cn_index, new_id, short

SIM_DEFAULTS = {
    "projectile": {"v0": 20, "angle": 45},
    "incline": {"theta": 30, "mu": 0.2, "m": 2},
    "pulley": {"n": 2, "G": 100, "F": 60},
    "lens": {"f": 10, "u": 30, "h": 3},
    "circuit": {"mode": "series", "U": 6, "R1": 10, "R2": 20},
    "buoyancy": {"rhoObj": 0.6, "rhoLiq": 1.0, "V": 500},
    "wave": {"A": 1, "f": 2, "v": 8},
    "vector": {"F1": 6, "F2": 8, "theta": 60},
    "thermal": {"T": 300},
}

SIM_TITLES = {
    "projectile": "抛体运动仿真",
    "incline": "斜面与摩擦力仿真",
    "pulley": "滑轮组机械效率仿真",
    "lens": "凸透镜成像光路仿真",
    "circuit": "串并联电路仿真",
    "buoyancy": "浮力与浮沉条件仿真",
    "wave": "机械波传播仿真",
    "vector": "力的合成仿真",
    "thermal": "分子热运动仿真",
}

VR_TITLES = {
    "mechanics": "力学实验室（VR 环视）",
    "circuit": "电学实验室（VR 环视）",
    "optics": "光学暗室（VR 环视）",
    "field": "磁场空间（VR 环视）",
}

GAME_TITLES = {
    "projectile-hoop": "抛体投篮挑战",
    "lens-focus": "调焦成像挑战",
    "float-sink": "浮沉判断挑战",
}

# 公式符号释义（用于"规律与公式"页的说明栏）
SYMBOLS = {
    "f": "焦距", "u": "物距", "v": "像距（或速度）", "m": "质量 / 放大率", "ρ": "密度",
    "V": "体积", "p": "压强", "F": "力", "S": "受力面积", "g": "重力加速度（取 10 N/kg）",
    "h": "高度 / 深度", "G": "重力", "W": "功", "s": "距离", "t": "时间", "P": "功率",
    "η": "机械效率", "Q": "热量", "c": "比热容", "Δt": "温度变化量", "I": "电流", "U": "电压",
    "R": "电阻", "E": "电动势 / 能量", "r": "内阻 / 半径", "B": "磁感应强度", "L": "长度 / 摆长",
    "a": "加速度", "T": "周期", "ω": "角速度", "n": "匝数 / 绳子段数", "λ": "波长", "A": "振幅",
    "Ek": "动能", "Ep": "重力势能", "q": "电荷量", "k": "静电力常量",
}


def _formula_notes(point: dict) -> list[str]:
    text = " ".join(point.get("formulas", []))
    override: dict[str, str] = {}
    if "1/f" in text:
        override = {"f": "焦距", "u": "物距", "v": "像距", "m": "放大率（像高 / 物高）", "h": "物高"}
    elif "ρ = m" in text:
        override = {"ρ": "密度", "m": "质量", "V": "体积"}
    elif "F浮" in text:
        override = {"F": "浮力", "ρ": "液体密度", "g": "重力加速度（取 10 N/kg）", "V": "排开液体体积"}
    seen: list[str] = []
    for sym in sorted(SYMBOLS, key=len, reverse=True):
        if not sym.isascii():
            if sym in text and sym not in seen:
                seen.append(sym)
            continue
        if re.search(r"(?<![A-Za-z])" + re.escape(sym) + r"(?![A-Za-z])", text) and sym not in seen:
            seen.append(sym)
    notes = [f"{s} —— {override.get(s, SYMBOLS[s])}" for s in seen][:4]
    return notes


def _scene_id(i: int) -> str:
    return f"s{i:02d}"


def _point_params(point: dict) -> dict:
    sim = point.get("sim")
    return dict(SIM_DEFAULTS.get(sim, {})) if sim else {}


def _book_pages(point: dict) -> list[dict]:
    pages = [
        {
            "title": "概念卡",
            "blocks": [{"type": "p", "text": point.get("summary", "")}]
            + [{"type": "list", "items": point.get("core", [])[:3]}],
        },
        {
            "title": "公式卡",
            "blocks": [{"type": "formula", "text": f} for f in point.get("formulas", [])[:3]]
            or [{"type": "p", "text": "本课以定性规律为主，请用文字准确表述。"}],
        },
        {
            "title": "实验卡",
            "blocks": [{"type": "list", "items": point.get("experiments", [])[:3] or ["观察与体验"]}]
            + [{"type": "note", "text": "记录数据时注意：单位、有效数字与多次测量。"}],
        },
        {
            "title": "易错卡",
            "blocks": [{"type": "list", "items": [f"× {m}" for m in point.get("misconceptions", [])[:3]]}]
            + [{"type": "note", "text": "判断正误时，先找条件，再看结论。"}],
        },
    ]
    return pages


def _narration_for(scene_type: str, point: dict, plan: dict | None = None) -> str:
    hook, questions = scenario(point)
    core = point.get("core", [])
    hard = point.get("hard", [])
    formulas = point.get("formulas", [])
    if scene_type == "cover":
        return f"同学们好，今天我们学习《{point['title']}》。{point.get('chapterTitle','')}，这一节是后面内容的基础，请准备好学案。"
    if scene_type == "objectives":
        return "先看本节课的三个目标：知道什么、会做什么、能解释什么。下课前我们会逐条对照检查。"
    if scene_type == "hook":
        return f"先看这个现象：{hook}。请大家思考：{questions[0]}"
    if scene_type == "concept":
        return f"通过观察和讨论，我们得到：{core[0] if core else point.get('summary','')}。注意这里的条件，它决定了结论能不能用。"
    if scene_type == "formula":
        f = formulas[0] if formulas else ""
        return f"把文字结论写成物理语言就是 {f}。式中每个字母的含义和单位，请在学案上标注。" if f else "我们把刚才的结论用物理语言再表述一遍。"
    if scene_type == "simulation":
        task = (SIM_TASKS.get(point.get("sim"), [""])[0])
        return f"现在请大家动手操作仿真。任务：{task} 边操作边记录数据，稍后我们一起分析。"
    if scene_type == "vr":
        task = (VR_TASKS.get(point.get("vr"), [""])[0])
        return f"进入 VR 实验室，环视四周，找到关键器材。观察任务：{task}"
    if scene_type == "avatar":
        return f"这里是最容易出错的地方：{hard[0] if hard else '条件的适用范围'}。我给大家一个判断顺序：先看条件，再定方向，最后代数值。"
    if scene_type == "book":
        return "翻开立体课本的概念卡，把我们刚才的结论和课本表述对照一下，注意课本用词的严谨性。"
    if scene_type == "example":
        return "看这道例题。先审题：已知什么、求什么；再建模：选择哪条规律；最后列式、代入、检验单位。"
    if scene_type == "quiz":
        return "随堂检测，三道题，独立完成。做完后同桌互批，重点看错在哪一步。"
    if scene_type == "summary":
        return "一起回顾：现象—概念—公式—应用。请用一句话说出本课最核心的结论。"
    if scene_type == "homework":
        return "作业分三层：基础层必做，提高层选做，拓展层挑战。把疑问记在学案上，下节课我们集中解决。"
    if scene_type == "report":
        return "这一页给老师看：原课件的诊断结果与本次优化的改动清单。"
    return ""


def build_deck(plan: dict, options: dict | None = None) -> dict:
    kb = get_kb()
    options = options or {}
    point = kb.point(plan["pointIds"][0])
    if not point:
        raise ValueError("教案未关联到知识点")
    scenes: list[dict] = []

    def add(scene: dict) -> None:
        scene["id"] = _scene_id(len(scenes) + 1)
        scenes.append(scene)

    # 1 封面
    add(
        {
            "type": "cover",
            "title": point["title"],
            "kicker": f"{point.get('textbookName','')} · {point.get('chapterTitle','')}",
            "subtitle": f"{plan['meta'].get('grade','')} · {plan['meta'].get('duration',45)} 分钟 · {plan['meta'].get('style','探究式')}",
            "chips": [point.get("theme", ""), f"{len(point.get('core', []))} 个核心结论", "含交互仿真"],
            "narration": _narration_for("cover", point),
        }
    )

    # 2 学习目标
    add(
        {
            "type": "objectives",
            "title": "学习目标",
            "kicker": "学完这节课，你能……",
            "items": [{"dim": o["dim"], "text": o["text"]} for o in plan["objectives"]],
            "narration": _narration_for("objectives", point),
        }
    )

    # 3 情境导入
    hook, questions = scenario(point)
    add(
        {
            "type": "hook",
            "title": "情境导入",
            "kicker": "从生活走向物理",
            "context": hook,
            "questions": questions,
            "bullets": point.get("key", [])[:1],
            "narration": _narration_for("hook", point),
        }
    )

    # 4 核心概念（重点）
    add(
        {
            "type": "concept",
            "title": f"核心概念：{point['title']}",
            "kicker": "教学重点",
            "bullets": point.get("core", [])[:4],
            "formula": (point.get("formulas") or [""])[0],
            "tag": "重点",
            "narration": _narration_for("concept", point),
        }
    )

    # 5 规律/公式（若有）
    if point.get("formulas"):
        add(
            {
                "type": "formula",
                "title": "规律与公式",
                "kicker": "从定性到定量",
                "formulas": point.get("formulas", [])[:3],
                "bullets": _formula_notes(point) or point.get("core", [])[1:4],
                "narration": _narration_for("formula", point),
            }
        )

    # 6 仿真
    if point.get("sim"):
        add(
            {
                "type": "simulation",
                "title": SIM_TITLES.get(point["sim"], "交互仿真"),
                "kicker": "动手探究 · 改变条件看响应",
                "widget": point["sim"],
                "params": _point_params(point),
                "tasks": SIM_TASKS.get(point["sim"], [])[:3],
                "dataTable": True,
                "narration": _narration_for("simulation", point),
            }
        )

    # 7 VR
    if point.get("vr"):
        add(
            {
                "type": "vr",
                "title": VR_TITLES.get(point["vr"], "VR 实验场景"),
                "kicker": "360° 环视 · 沉浸式观察",
                "vr": point["vr"],
                "tasks": VR_TASKS.get(point["vr"], [])[:2],
                "narration": _narration_for("vr", point),
            }
        )

    # 7.5 知识闯关（游戏化）
    if point.get("game"):
        add(
            {
                "type": "game",
                "title": GAME_TITLES.get(point["game"], "物理闯关"),
                "kicker": "知识游戏 · 调参数闯关",
                "game": point["game"],
                "params": {"mode": point["game"]},
                "tasks": [
                    "先独立试 2 次，记录失败时的参数与现象。",
                    "用本课规律算出应满足的条件，再据此调参通关。",
                    "通关后说出“为什么这组参数能成功”。",
                ],
                "narration": f"现在进入闯关环节。任务是：{GAME_TITLES.get(point['game'],'用规律通关')}。先想清楚要满足什么物理条件，再动手调参数。",
            }
        )

    # 8 数字人微讲解（难点）
    add(
        {
            "type": "avatar",
            "title": "难点突破",
            "kicker": "数字人微讲解",
            "focus": (point.get("hard") or ["条件的适用范围"])[0],
            "points": [f"{cn_index(i+1)}、{h}" for i, h in enumerate(point.get("hard", [])[:3])],
            "misconception": (point.get("misconceptions") or [""])[0],
            "narration": _narration_for("avatar", point),
        }
    )

    # 9 立体课本
    add(
        {
            "type": "book3d",
            "title": "立体课本",
            "kicker": "翻开课本 · 对照原文",
            "book": {
                "title": point["title"],
                "subtitle": f"{point.get('textbookName','')} {point.get('chapterTitle','')}",
                "pages": _book_pages(point),
            },
            "narration": _narration_for("book", point),
        }
    )

    # 10 例题
    ex = pp.build_example(point)
    bank_qs = questionbank.for_point(point["id"], 4)
    bank_calc = next((q for q in bank_qs if q.get("type") == "计算" and q.get("solution")), None)
    if bank_calc:
        ex = {
            "stem": bank_calc["stem"],
            "answer": bank_calc.get("answer", ""),
            "steps": bank_calc.get("solution") or [bank_calc.get("analysis", "")],
        }
    if ex:
        add(
            {
                "type": "example",
                "title": "例题精讲",
                "kicker": "审题 → 建模 → 列式 → 检验",
                "stem": ex["stem"],
                "steps": ex["steps"],
                "answer": ex["answer"],
                "narration": _narration_for("example", point),
            }
        )

    # 11 随堂检测
    quiz_items = questionbank.quiz_items(point["id"], 3) or pp.quiz_for_deck(point)
    add(
        {
            "type": "quiz",
            "title": "随堂检测",
            "kicker": "独立完成 · 同桌互批",
            "items": quiz_items,
            "narration": _narration_for("quiz", point),
        }
    )

    # 12 小结
    add(
        {
            "type": "summary",
            "title": "课堂小结",
            "kicker": "现象 → 概念 → 规律 → 应用",
            "branches": [
                {"label": "核心结论", "items": point.get("core", [])[:3]},
                {"label": "公式工具", "items": point.get("formulas", [])[:2] or ["定性表述"]},
                {"label": "易错提醒", "items": [f"× {m}" for m in point.get("misconceptions", [])[:2]]},
            ],
            "exitTicket": "用一句话说出本课最核心的结论，并举一个生活中的例子。",
            "narration": _narration_for("summary", point),
        }
    )

    # 13 分层作业
    hw = plan["homework"]
    add(
        {
            "type": "homework",
            "title": "分层作业",
            "kicker": "基础必做 · 提高选做 · 拓展挑战",
            "tiers": [
                {"level": "基础层", "tag": "必做", "items": hw["basic"]},
                {"level": "提高层", "tag": "选做", "items": hw["improve"]},
                {"level": "拓展层", "tag": "挑战", "items": hw["extend"]},
            ],
            "narration": _narration_for("homework", point),
        }
    )

    deck = {
        "id": new_id("D"),
        "kind": "deck",
        "meta": {
            "title": plan["title"],
            "pointId": point["id"],
            "pointTitle": point["title"],
            "stage": point.get("stage"),
            "grade": point.get("grade"),
            "textbook": point.get("textbookName"),
            "chapter": point.get("chapterTitle"),
            "duration": plan["meta"].get("duration", 45),
            "classLevel": plan["meta"].get("classLevel"),
            "date": date.today().isoformat(),
            "source": "generate",
            "author": "悟理智课",
            "lessonId": plan.get("id"),
        },
        "analysis": {
            "keyPoints": plan.get("keyPoints", []),
            "hardPoints": plan.get("hardPoints", []),
            "student": plan.get("studentAnalysis", {}),
            "misconceptions": point.get("misconceptions", []),
            "formulas": point.get("formulas", []),
            "experiments": point.get("experiments", []),
        },
        "scenes": scenes,
        "interactive": {
            "sim": point.get("sim", ""),
            "vr": point.get("vr", ""),
            "game": point.get("game", ""),
            "avatar": True,
            "book3d": True,
        },
    }
    return deck


# ---------------------------------------------------------------- 由教案文本生成
def deck_from_lesson_text(text: str, meta: dict | None = None, options: dict | None = None) -> dict:
    """上传教案 → 解析重难点/学情 → 生成课件。"""
    kb = get_kb()
    meta = meta or {}
    options = options or {}
    parsed = normalize_plan(text)
    sig = plan_signals(text)
    matches = kb.pick_for_text(text, 3)
    if not matches:
        first = next((ln.strip() for ln in text.split("\n") if ln.strip()), "")
        cands = [p for p in kb.points.values() if p["title"] in first or first in p["title"]]
        if not cands:
            raise ValueError("未能从教案中识别出教材知识点，请在教案中写明课题（如“凸透镜成像的规律”）")
        matches = cands
    point = matches[0]

    # 用教案中的重难点/学情覆盖默认分析
    prof = {
        "classLevel": meta.get("classLevel") or "中等",
        "preScore": meta.get("preScore"),
        "prior": parsed.get("students", "") or meta.get("prior", ""),
        "duration": sig.get("duration") or meta.get("duration") or 45,
    }
    plan = generate_plan([point["id"]], prof, {"duration": prof["duration"], "style": meta.get("style") or "探究式"})

    # 保留教师原文目标（若有）
    if parsed.get("objectives"):
        lines = [ln.strip(" 　·-—") for ln in parsed["objectives"].split("\n") if ln.strip()]
        if lines:
            plan["objectives"] = [
                {"dim": plan["objectives"][0]["dim"], "text": "；".join(lines[:2])[:120]}
            ] + plan["objectives"][1:]
    if parsed.get("key"):
        ks = [x for x in re.split(r"[；;、\n]", parsed["key"]) if x.strip()]
        if ks:
            plan["keyPoints"] = [x.strip(" 　·-—") for x in ks][:3]
    if parsed.get("hard"):
        hs = [x for x in re.split(r"[；;、\n]", parsed["hard"]) if x.strip()]
        if hs:
            plan["hardPoints"] = [x.strip(" 　·-—") for x in hs][:3]

    deck = build_deck(plan, options)
    deck["meta"]["source"] = "lesson-upload"
    deck["meta"]["lessonFile"] = meta.get("fileName", "")
    deck["meta"]["lessonChars"] = sig["chars"]
    deck["analysis"]["keyPoints"] = plan["keyPoints"]
    deck["analysis"]["hardPoints"] = plan["hardPoints"]
    deck["analysis"]["student"] = plan["studentAnalysis"]
    deck["analysis"]["fromLesson"] = {
        "objectives": parsed.get("objectives", ""),
        "key": parsed.get("key", ""),
        "hard": parsed.get("hard", ""),
        "students": parsed.get("students", ""),
        "signals": sig,
    }
    return deck


# ---------------------------------------------------------------- PPT 诊断与优化
def diagnose_pptx(parsed: dict) -> dict:
    slides = parsed.get("slides", [])
    n = len(slides) or 1
    all_text = parsed.get("text", "")
    total_chars = sum(s.get("chars", 0) for s in slides)
    avg_chars = total_chars / n
    fonts = [s["minFont"] for s in slides if s.get("minFont")]
    min_font = min(fonts) if fonts else None
    images = sum(s.get("images", 0) for s in slides)
    empty = [s["index"] for s in slides if s.get("chars", 0) < 12]
    overload = [s["index"] for s in slides if s.get("chars", 0) > 180]
    issues: list[dict] = []

    def add(level, title, evidence, fix, weight):
        issues.append({"level": level, "title": title, "evidence": evidence, "fix": fix, "weight": weight})

    if len(slides) < 8:
        add("重要", "页数偏少，容量不足", f"共 {len(slides)} 页，平均每页 {avg_chars:.0f} 字", "按“导入—概念—探究—例题—检测—小结”补足到 12 页以上", 8)
    if avg_chars > 150:
        add("严重", "文字过载，认知负荷高", f"平均每页 {avg_chars:.0f} 字（建议 ≤120 字）", "每页提炼 3~4 条要点，长句改为关键词 + 图示", 14)
    if overload:
        add("重要", "部分页面文字过多", f"第 {', '.join(map(str, overload[:6]))} 页超过 180 字", "拆分为两页或降为讲稿", 8)
    if min_font is not None and min_font < 18:
        add("严重", "字号过小，后排看不清", f"最小字号 {min_font} pt（建议正文 ≥20 pt）", "正文统一 20~24 pt，标题 32 pt 以上", 12)
    if images == 0:
        add("严重", "缺少可视化素材", "全篇未检测到图片", "为概念页与实验页配示意图/仿真截图，图文比不低于 4:6", 10)
    if not re.search(r"(实验|探究|仿真|操作|测量)", all_text):
        add("重要", "缺少探究活动", "未出现实验/探究/仿真相关表述", "插入 1~2 页交互仿真或分组实验页，给出任务单", 10)
    if not re.search(r"(目标|学习目标)", all_text):
        add("重要", "缺少学习目标页", "未检测到目标页", "增加学习目标页，用可观测动词表述", 6)
    if not re.search(r"(重点|难点)", all_text):
        add("建议", "未显性标注重难点", "未检测到重点/难点字样", "在概念页与例题页标注“重点/难点”标签", 5)
    if not re.search(r"(练习|检测|例题|随堂)", all_text):
        add("重要", "缺少练习与检测", "未检测到例题或检测题", "增加 1 页例题精讲 + 1 页分层检测", 8)
    if not re.search(r"(小结|总结|思维导图|回顾)", all_text):
        add("建议", "缺少课堂小结", "未检测到小结页", "增加结构化小结（概念图/知识树）", 5)
    if not re.search(r"(作业|任务)", all_text):
        add("建议", "缺少作业设计", "未检测到作业页", "增加分层作业页", 4)
    if empty:
        add("建议", "存在空页或信息极少的页", f"第 {', '.join(map(str, empty[:6]))} 页内容少于 12 字", "删除空页或补充要点", 3)
    if parsed.get("ratio") and abs(parsed["ratio"] - 1.778) > 0.02:
        add("建议", "页面比例非 16:9", f"当前比例约 {parsed['ratio']}:1", "统一为 16:9，适配大多数教室投影", 2)

    penalty = sum(i["weight"] for i in issues)
    score = max(38, 100 - penalty)
    return {
        "score": score,
        "slideCount": len(slides),
        "chars": total_chars,
        "avgChars": round(avg_chars, 0),
        "minFont": min_font,
        "images": images,
        "issues": issues,
        "slides": [
            {"index": s["index"], "title": s["title"], "chars": s["chars"], "minFont": s.get("minFont"), "images": s.get("images", 0)}
            for s in slides
        ],
    }


def _clean_line(line: str) -> str:
    line = re.sub(r"^[\s·•\-—*（）()0-9.、]+", "", line or "").strip()
    line = re.sub(r"\s+", " ", line)
    return line


def _pool_bullets(parsed: dict, limit: int = 24) -> list[str]:
    out: list[str] = []
    for s in parsed.get("slides", []):
        for t in s.get("texts", []):
            for line in re.split(r"[\n。；;]", t):
                line = _clean_line(line)
                if 6 <= len(line) <= 60 and line not in out:
                    out.append(line)
    # 优先含物理术语的句子
    kw = re.compile(r"(力|速度|加速度|电流|电压|电阻|功率|能量|密度|压强|浮力|光|声|热|磁|公式|定律|原理|实验|现象|结论)")
    out.sort(key=lambda x: (-len(kw.findall(x)), -len(x)))
    return out[:limit]


def optimize_deck(parsed: dict, meta: dict | None = None, options: dict | None = None) -> dict:
    """上传 PPT → 诊断 → 重构优化（保留原有要点与图片）。"""
    kb = get_kb()
    meta = meta or {}
    options = options or {}
    diag = diagnose_pptx(parsed)
    text = parsed.get("text", "")
    matches = kb.pick_for_text(text, 3)
    if not matches:
        # 用第一页标题猜
        first = (parsed.get("slides") or [{}])[0].get("title", "")
        cands = [p for p in kb.points.values() if p["title"] in first or first in p["title"]]
        if not cands:
            cands = kb.search(first, 1)
        if not cands:
            raise ValueError("未能识别课件对应的教材知识点，请在首页写明课题（如“欧姆定律”）")
        matches = cands
    point = matches[0]

    pool = _pool_bullets(parsed)
    prof = {
        "classLevel": meta.get("classLevel") or "中等",
        "duration": meta.get("duration") or 45,
    }
    plan = generate_plan([point["id"]], prof, {"duration": prof["duration"], "style": "探究式"})
    deck = build_deck(plan, options)
    deck["meta"]["source"] = "pptx-optimize"
    deck["meta"]["originalFile"] = meta.get("fileName", "")
    deck["meta"]["title"] = f"{point['title']}（优化版）"
    deck["meta"]["sourceSlides"] = diag["slideCount"]

    # 用原课件要点替换概念页/情境页的占位内容
    concept = next((s for s in deck["scenes"] if s["type"] == "concept"), None)
    if concept and pool:
        concept["bullets"] = pool[:4]
        concept["kicker"] = "教学重点 · 已按原课件要点重组"
    # 保留原页标题作为章节线索
    orig_titles = [s["title"] for s in parsed.get("slides", []) if s.get("title")][:6]
    if orig_titles:
        deck["analysis"]["originalOutline"] = orig_titles

    # 诊断对比页
    deck["diagnosis"] = diag
    recap = {
        "type": "report",
        "title": "优化说明",
        "kicker": "给授课教师",
        "before": diag["score"],
        "after": min(96, diag["score"] + 8 + 3 * len(diag["issues"])),
        "issues": diag["issues"][:8],
        "changes": [
            f"页数：{diag['slideCount']} → {len(deck['scenes'])}，按教学结构补全",
            f"平均字数：{diag['avgChars']:.0f} → 约 90，控制认知负荷",
            f"最小字号：{diag['minFont'] or '—'} pt → 22 pt",
            "新增：交互仿真、VR 场景、数字人微讲解、立体课本",
            "新增：学习目标、例题精讲、分层检测与作业",
        ],
        "narration": _narration_for("report", point),
    }
    recap["id"] = _scene_id(len(deck["scenes"]) + 1)
    deck["scenes"].append(recap)
    deck["meta"]["diagnosisScore"] = diag["score"]
    return {"deck": deck, "diagnosis": diag}