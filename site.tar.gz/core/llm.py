"""可选的大模型适配层（OpenAI 兼容接口）。

默认不启用：平台的核心生成完全离线、可复现。若希望用大模型润色讲稿或在
例句上做个性化改写，设置以下环境变量即可：

    OPENAI_API_KEY=sk-...
    OPENAI_BASE_URL=https://api.openai.com/v1     # 或任意兼容服务
    OPENAI_MODEL=gpt-4o-mini

注意：调用失败一律返回 None，由调用方回退到离线文本，不能影响主流程。
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request


def available() -> bool:
    return bool(os.environ.get("OPENAI_API_KEY"))


def _base() -> str:
    return os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")


def chat(messages: list[dict], temperature: float = 0.4, timeout: int = 40) -> str | None:
    if not available():
        return None
    payload = {
        "model": os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
        "messages": messages,
        "temperature": temperature,
    }
    req = urllib.request.Request(
        _base() + "/chat/completions",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + os.environ["OPENAI_API_KEY"],
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"].strip()
    except (urllib.error.URLError, KeyError, ValueError, TimeoutError):
        return None


def polish(text: str, instruction: str = "在不改变物理事实的前提下，让这段课堂讲稿更口语化、更有吸引力，控制在 120 字以内。") -> str:
    """润色一段文字；不可用时原样返回。"""
    if not text or not available():
        return text
    out = chat(
        [
            {"role": "system", "content": "你是一位中学物理教研员，语言准确、简洁、面向初中/高中学生。"},
            {"role": "user", "content": f"{instruction}\n\n原文：{text}"},
        ]
    )
    return out or text