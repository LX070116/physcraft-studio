"""教案生成与优化：基于教材知识库 + 学情画像的结构化教学设计。"""
from __future__ import annotations

import re
from datetime import date

from . import physics_problems as pp
from .kb import get_kb
from .textparse import normalize_plan, plan_signals
from .util import cn_index, new_id, short

# ---------------------------------------------------------------- 情境库
SCEN = {
    "p-j8a-01": ("教室里的课桌、铅笔与操场跑道", ["不用尺子，你怎样比较两支铅笔的长短？", "测量结果为什么必须带单位？"]),
    "p-j8a-02": ("乘坐高铁时，窗外的树木“向后退”", ["树木真的在后退吗？", "为什么站台上的人看你是在运动？"]),
    "p-j8a-03": ("苏炳添百米冲刺与高铁运行", ["如何比较跑得快还是车开得快？", "100 m 成绩 9.83 s，平均速度多大？"]),
    "p-j8a-04": ("敲击音叉、拨动琴弦、水中的鱼被岸上脚步声惊走", ["声音从哪里来？", "月球上的宇航员为什么要用无线电通话？"]),
    "p-j8a-05": ("钢琴高音区与低音区、雷声与蚊鸣", ["为什么有的声音“尖”，有的声音“沉”？", "用力敲鼓和轻敲鼓，声音哪里不同？"]),
    "p-j8a-06": ("冰雕融化、铁水浇铸、蜡烛流泪", ["冰化成水温度一直升高吗？", "为什么金属能铸造而蜡不能？"]),
    "p-j8a-07": ("晾衣服、烧开水、眼镜起雾", ["怎样让湿衣服干得更快？", "水沸腾后继续加热，温度会升高吗？"]),
    "p-j8a-08": ("激光笔照镜子、水中倒影", ["为什么我们能看见不发光的物体？", "平面镜里的像能被光屏承接吗？"]),
    "p-j8a-09": ("筷子插入水中“折断”、池水看起来变浅", ["光从空气进入水中，传播方向怎样变化？", "渔民叉鱼为什么要瞄准鱼的下方？"]),
    "p-j8a-10": ("照相机、投影仪、放大镜", ["同一凸透镜为什么能成不同的像？", "物距变化时，像距和像的大小怎样变化？"]),
    "p-j8a-11": ("金条与泡沫砖、医院 CT 与密度", ["体积大的物体一定重吗？", "怎样鉴别一枚戒指是不是纯金？"]),
    "p-j8b-01": ("拉弹簧、踢足球、苹果落地", ["力看不见，我们如何感知它？", "为什么踢球时脚也疼？"]),
    "p-j8b-02": ("公交车急刹车时乘客前倾", ["物体运动需要力来维持吗？", "急刹车时人为什么会向前倾？"]),
    "p-j8b-03": ("拔河、推箱子、传送带", ["两个力满足什么条件才能平衡？", "推不动箱子时，摩擦力有多大？"]),
    "p-j8b-04": ("潜水服、拦河大坝、吸盘挂钩", ["为什么大坝要上窄下宽？", "吸盘为什么能吸在墙上？"]),
    "p-j8b-05": ("轮船、潜水艇、热气球", ["钢铁做的轮船为什么能浮在水面？", "潜水艇怎样实现上浮和下潜？"]),
    "p-j8b-06": ("起重机吊装、过山车", ["有力作用在物体上，就一定做功吗？", "过山车在最高点的能量是什么形式？"]),
    "p-j8b-07": ("撬石头、升旗、建筑工地滑轮", ["一根棍子为什么能撬起重物？", "滑轮组为什么既省力又费距离？"]),
    "p-j9-01": ("闻到花香、墨水扩散、压缩空气", ["为什么香水味能飘满整个房间？", "压缩空气时筒壁为什么会变热？"]),
    "p-j9-02": ("沿海昼夜温差小、汽车发动机水冷", ["为什么海水和沙滩白天温度不同？", "同样加热，为什么水温升高得慢？"]),
    "p-j9-03": ("手电筒、教室日光灯、家庭电路", ["手电筒的电流路径是怎样的？", "教室里的灯为什么能各自独立开关？"]),
    "p-j9-04": ("干电池、手机充电器、滑动变阻器调光", ["电压和电流是什么关系？", "调光台灯靠什么改变亮度？"]),
    "p-j9-05": ("伏安法测电阻、调光台灯电路", ["电流与电压、电阻有什么定量关系？", "滑动变阻器滑片移动时，电流表怎样变化？"]),
    "p-j9-06": ("电饭锅、节能灯、输电线路损耗", ["灯泡的亮度由什么决定？", "为什么输电要用高压？"]),
    "p-j9-07": ("电磁起重机、电动机、发电机", ["电和磁之间有什么联系？", "电动机和发电机的原理有什么不同？"]),
    "p-h1-01": ("GPS 定位、高铁时刻表", ["研究地球公转时，地球能看作质点吗？", "位移和路程有什么不同？"]),
    "p-h1-02": ("汽车刹车距离、自由落体", ["刹车后汽车做什么运动？", "反应时间内汽车做什么运动？"]),
    "p-h1-03": ("斜拉桥钢索、拔河", ["两个力共同作用的效果怎样等效替代？", "为什么钢索要斜着拉？"]),
    "p-h1-04": ("电梯超重失重、火箭发射", ["电梯加速上升时，体重秤示数怎样变化？", "合力与加速度有什么定量关系？"]),
    "p-h2-01": ("平抛小球、飞机投弹", ["平抛运动的水平方向和竖直方向各做什么运动？", "落地时间与初速度有关吗？"]),
    "p-h2-02": ("过山车、洗衣机脱水、汽车转弯", ["做圆周运动的物体受什么力？", "为什么转弯要限速？"]),
    "p-h2-03": ("北斗导航、神舟飞船", ["卫星为什么不会掉下来？", "轨道越高，运行速度越大还是越小？"]),
    "p-h2-04": ("过山车、蹦极、水力发电", ["为什么过山车不需要发动机也能飞驰？", "摩擦力做功时机械能还守恒吗？"]),
    "p-h3-01": ("静电除尘、验电器", ["两个点电荷之间的力与什么有关？", "电场看不见，怎样描述它？"]),
    "p-h3-02": ("手机电池、电动车续航", ["路端电压为什么随电流增大而减小？", "电源输出功率最大时外电阻多大？"]),
    "p-h3-03": ("电磁炉、无线充电、发电机", ["磁通量变化为什么能产生电流？", "感应电流的方向由什么决定？"]),
    "p-hs1-01": ("安全气囊、火箭反冲", ["为什么气囊能减轻伤害？", "碰撞中什么量是守恒的？"]),
    "p-hs1-02": ("荡秋千、钟摆、地震仪", ["单摆的周期与什么有关？", "为什么摆长越长，摆动越慢？"]),
}

SIM_TASKS = {
    "projectile": [
        "保持初速度不变，把抛射角从 30° 调到 60°，记录射程与最高点的变化。",
        "固定抛射角，逐步增大初速度，观察射程如何变化，尝试找出射程最大的角度。",
        "观察速度矢量分解：水平分速度是否变化？竖直分速度如何变化？",
    ],
    "incline": [
        "固定倾角，逐渐增大动摩擦因数 μ，观察加速度与小车的运动状态。",
        "把倾角调到很小，使 μ > tanθ，观察小车是否还能自行下滑，并解释原因。",
        "读取合力与加速度的数值，验证 a = g(sinθ − μcosθ)。",
    ],
    "pulley": [
        "改变绳子段数 n，比较拉力大小，验证 F = G/n。",
        "增大物重，观察机械效率的变化趋势。",
        "比较有用功、总功与额外功，说明“省力不省功”。",
    ],
    "lens": [
        "把物距从 3f 逐渐减小到 1.5f，记录像距与像的大小变化。",
        "把物距调到小于 f，观察虚像的出现，说明放大镜原理。",
        "找到 u = 2f 的位置，验证此时成等大倒立的实像。",
    ],
    "circuit": [
        "保持 R1 不变，增大 R2，观察串联电路中电流与电压的重新分配。",
        "切换为并联，比较总电阻与各支路电阻的大小关系。",
        "记录每次的电流表、电压表示数，验证 I = U/R。",
    ],
    "buoyancy": [
        "保持物体体积不变，改变物体密度，观察漂浮、悬浮、下沉三种状态。",
        "换用不同密度的液体，记录浸入体积比例，验证漂浮时 ρ物/ρ液 = V排/V物。",
        "读取浮力数值，验证 F浮 = ρ液gV排。",
    ],
    "wave": [
        "增大频率，观察波长如何变化（波速不变）。",
        "增大振幅，观察质点振动幅度与波形的关系。",
        "暂停动画，观察某一质点的振动方向与波的传播方向。",
    ],
    "vector": [
        "保持两个力大小不变，把夹角从 0° 调到 180°，记录合力大小。",
        "找到合力等于分力大小的特殊角度，验证公式。",
        "用三角形法则重新作图，比较与平行四边形法则的结果。",
    ],
    "thermal": [
        "升高温度，观察分子平均速率与碰撞频率的变化。",
        "比较不同温度下速度分布的形状，说明“温度是分子平均动能的标志”。",
        "暂停后观察单个分子的运动轨迹，说明分子运动的无规则性。",
    ],
}

VR_TASKS = {
    "mechanics": ["环视实验室，找到斜面与打点计时器，说明各器材的作用。", "观察小车在斜面上的运动，判断它做的是什么运动。"],
    "circuit": ["找出电源、开关、灯泡与导线，描述电流的完整路径。", "观察灯泡亮度变化，猜测电路中电阻发生了什么变化。"],
    "optics": ["找到光具座上的蜡烛、凸透镜与光屏，说明它们的作用。", "观察光屏上的像，判断像是放大还是缩小、倒立还是正立。"],
    "field": ["环视磁场空间，观察磁感线的分布特点。", "找到线圈与磁体，说明怎样操作才能产生感应电流。"],
}

SIM_LABEL = {
    "projectile": "抛体运动仿真",
    "incline": "斜面与摩擦力仿真",
    "pulley": "滑轮组机械效率仿真",
    "lens": "凸透镜成像光路仿真",
    "circuit": "串并联电路仿真",
    "buoyancy": "浮力与浮沉条件仿真",
    "wave": "机械波传播仿真",
    "vector": "力的合成仿真",
    "thermal": "分子热运动仿真",
}
VR_LABEL = {
    "mechanics": "力学实验室（VR 环视）",
    "circuit": "电学实验室（VR 环视）",
    "optics": "光学暗室（VR 环视）",
    "field": "磁场空间（VR 环视）",
}


def _chapter_context(point: dict) -> str:
    return f"{point.get('textbookName', '')}{point.get('chapterTitle', '')}"


def scenario(point: dict) -> tuple[str, list[str]]:
    if point["id"] in SCEN:
        return SCEN[point["id"]]
    theme = point.get("theme", "")
    return (
        f"与“{point['title']}”相关的生活现象",
        [f"生活中哪些现象与“{point['title']}”有关？", f"这些现象背后遵循什么物理规律？"],
    )


def _objectives(point: dict, senior: bool) -> list[dict]:
    core = point.get("core", [])
    key = point.get("key", [])
    hard = point.get("hard", [])
    exp = point.get("experiments", [])
    obs = [
        ("物理观念", f"理解“{point['title']}”的核心内容，能说出：{core[0] if core else point.get('summary','')}"),
        ("科学思维", f"能运用建模与推理分析{key[0] if key else point['title']}，解释相关现象并作出判断"),
        ("科学探究", f"通过{('“' + exp[0] + '”') if exp else '观察与实验'}收集证据，归纳得出结论"),
        ("科学态度与责任", "体会物理学与生产生活的联系，养成尊重事实、严谨求实的科学态度"),
    ]
    if senior:
        return [{"dim": d, "text": t} for d, t in obs]
    return [
        {"dim": "知识与技能", "text": f"理解“{point['title']}”的核心内容，能说出：{core[0] if core else point.get('summary','')}"},
        {"dim": "过程与方法", "text": f"经历{('“' + exp[0] + '”') if exp else '观察、实验与推理'}的探究过程，学会用控制变量法、图像法分析问题"},
        {"dim": "情感态度与价值观", "text": "在解释生活现象中体验物理的价值，保持好奇心与求知欲"},
    ]


def _student_analysis(point: dict, profile: dict) -> dict:
    level = profile.get("classLevel") or "中等"
    score = profile.get("preScore")
    prior = profile.get("prior") or ""
    mis = point.get("misconceptions", [])
    hard = point.get("hard", [])
    gaps = [f"常见误区：{m.replace('认为', '', 1)}" for m in mis[:3]]
    if hard:
        gaps.append(f"在“{hard[0]}”上存在思维断点")
    strategies = {
        "薄弱": [
            "降低起点：先用生活实例与直观演示建立表象，再引入符号与公式",
            "小步子推进：每个环节设置 1 个可回答的问题，及时反馈",
            "提供支架：给出公式卡片、受力分析模板与解题步骤清单",
        ],
        "中等": [
            "以问题链驱动，让学生在“猜想—证据—结论”中完成建构",
            "设置一道变式训练，暴露并纠正前概念",
            "用仿真实验把抽象过程可视化，再回到公式表达",
        ],
        "优秀": [
            "压缩讲授，把时间留给建模与迁移",
            "增加开放性任务与多解法比较，鼓励质疑与论证",
            "引导自主设计实验方案，进行误差分析",
        ],
    }.get(level, [])
    return {
        "level": level,
        "preScore": score,
        "prior": prior,
        "gaps": gaps,
        "strategies": strategies,
        "note": profile.get("note", ""),
    }


def _process(point: dict, profile: dict, duration: int, senior: bool) -> list[dict]:
    hook, questions = scenario(point)
    core = point.get("core", [])
    key = point.get("key", [])
    hard = point.get("hard", [])
    formulas = point.get("formulas", [])
    sim = point.get("sim")
    vr = point.get("vr")
    ex = pp.build_example(point)
    ratio = duration / 45.0

    def m(x: int) -> int:
        return max(3, round(x * ratio))

    stages: list[dict] = []
    stages.append(
        {
            "name": "情境导入",
            "minutes": m(5),
            "teacher": f"呈现“{hook}”的图片/视频或现场演示，提出驱动问题：①{questions[0]} ②{questions[1]}",
            "student": "观察现象，尝试用已有经验作出猜想，把猜想记录在学案上",
            "intent": "从生活走向物理，激活前概念，形成认知冲突",
            "media": "情境视频 + 问题链",
        }
    )

    steps = core[:3] if core else [point.get("summary", "")]
    teacher_lines = [
        f"引导学生分析现象，归纳出：{steps[0]}" if steps else "",
        f"追问“为什么”，组织小组讨论，形成结论：{steps[1]}" if len(steps) > 1 else "",
        f"联系实例辨析，深化理解：{steps[2]}" if len(steps) > 2 else "",
    ]
    stages.append(
        {
            "name": "概念建构 / 规律探究",
            "minutes": m(14),
            "teacher": "；".join([t for t in teacher_lines if t]),
            "student": "小组合作完成观察记录表，用自己的话说出规律，并在全班交流",
            "intent": f"突出重点：{key[0] if key else point['title']}；在证据基础上建构概念",
            "media": "演示实验 / 学生分组实验" + ("（可用仿真预演）" if sim else ""),
        }
    )

    model_bits = []
    if formulas:
        model_bits.append(f"板书推导 {formulas[0]}，明确各量含义与单位")
    if hard:
        model_bits.append(f"针对难点“{hard[0]}”设置对比辨析")
    if ex:
        model_bits.append("示范一道规范例题，展示“审题—建模—列式—检验”的解题结构")
    stages.append(
        {
            "name": "模型深化",
            "minutes": m(9),
            "teacher": "；".join(model_bits) or "引导学生把文字结论转化为公式或图像表达",
            "student": "跟随推导，独立完成例题的第 1 问，同桌互评步骤",
            "intent": "由定性走向定量，形成可迁移的物理模型",
            "media": "板书 + 例题学案",
        }
    )

    if sim or vr:
        sim_task = (SIM_TASKS.get(sim) or [""])[0]
        vr_task = (VR_TASKS.get(vr) or [""])[0]
        stages.append(
            {
                "name": "仿真 / VR 探究",
                "minutes": m(9),
                "teacher": f"发布探究任务：{sim_task or vr_task}；巡视指导，提示学生记录数据",
                "student": "操作交互仿真（或环视 VR 场景），记录 3 组数据，尝试归纳规律并解释异常",
                "intent": "把不可见的过程可视化，在“改变条件—观察响应”中深化理解",
                "media": "交互仿真 / VR 实验室",
            }
        )
    else:
        ex = pp.build_example(point)
        stages.append(
            {
                "name": "例题精讲与变式",
                "minutes": m(9),
                "teacher": (
                    f"示范一道规范例题，展示“审题—建模—列式—检验”的解题结构；再给出一个变式让学生独立完成。"
                    if ex
                    else f"围绕“{point['title']}”设计一组递进问题，引导学生把结论迁移到新情境。"
                ),
                "student": "先独立完成第 1 问，再对照讲解修正；同桌互评步骤与单位",
                "intent": "由定性走向定量，形成可迁移的解题模型",
                "media": "例题学案 + 变式训练",
            }
        )

    quiz = pp.build_quiz(point, 3)
    stages.append(
        {
            "name": "分层训练",
            "minutes": m(5),
            "teacher": "发布基础层（全体）、提高层（选做）、拓展层（挑战）三级任务，当堂反馈共性问题",
            "student": "按层完成，组内互批，记录错因",
            "intent": "检测目标达成度，实现分层落实",
            "media": f"随堂检测（{len(quiz)} 题）+ 分层任务单",
        }
    )

    stages.append(
        {
            "name": "小结与作业",
            "minutes": m(3),
            "teacher": "引导学生用“概念图”回顾本课，指出与下一课的联系；布置分层作业",
            "student": "独立绘制概念图，提出仍未解决的问题",
            "intent": "结构化知识，形成学习闭环",
            "media": "板书 / 思维导图",
        }
    )
    return stages


def _board(point: dict) -> dict:
    formulas = point.get("formulas", [])
    core = point.get("core", [])
    key = point.get("key", [])
    hard = point.get("hard", [])
    mis = point.get("misconceptions", [])
    return {
        "title": point["title"],
        "blocks": [
            {"label": "核心概念", "lines": core[:3]},
            {"label": "公式 / 规律", "lines": formulas[:3]},
            {"label": "重点", "lines": key[:2]},
            {
                "label": "易错 / 难点",
                "lines": [f"× {m.replace('认为', '', 1)}" for m in mis[:2]] + ([f"△ 需突破：{hard[0]}"] if hard else []),
            },
        ],
    }


def _homework(point: dict, level: str) -> dict:
    ex = pp.build_example(point)
    exp = point.get("experiments", [])
    tags = point.get("tags", [])
    basic = [
        f"完成教材课后练习中与“{point['title']}”相关的基础题",
        f"用自己的话写出{point['title']}的 3 条核心结论，并各配一个生活实例",
    ]
    improve = []
    if ex:
        improve.append(f"完成变式题：{short(ex['stem'], 60)}（改变一个条件后重新求解）")
    improve.append(f"整理本课易错点，制作一张“{tags[0] if tags else point['title']}”辨析卡")
    extend = [
        f"用手机拍摄一个与“{point['title']}”有关的生活现象，并用本课原理解释（100 字以内）",
    ]
    if exp:
        extend.append(f"自主设计“{exp[0]}”的改进方案，说明如何减小误差")
    if level == "薄弱":
        basic.append("观看平台上的 3 分钟微讲解，完成 5 道基础判断")
    if level == "优秀":
        extend.append("尝试用两种不同方法解决同一问题，比较哪种更简洁")
    return {"basic": basic, "improve": improve, "extend": extend}


def _assessment(point: dict) -> dict:
    quiz = pp.build_quiz(point, 3)
    return {
        "observations": [
            "能否用自己的语言准确表述核心概念（不照读课本）",
            "能否在仿真/实验中规范操作并记录数据",
            "能否在新情境中调用本课模型解决问题",
        ],
        "items": quiz,
        "rubric": ["概念表述准确（40%）", "推理过程完整（30%）", "规范表达与单位（20%）", "迁移应用（10%）"],
    }


def _narration(point: dict, profile: dict) -> list[dict]:
    hook, questions = scenario(point)
    core = point.get("core", [])
    hard = point.get("hard", [])
    mis = point.get("misconceptions", [])
    formulas = point.get("formulas", [])
    lines = [
        {
            "scene": "导入",
            "text": f"同学们好。先看这个现象：{hook}。请大家想一想：{questions[0]} 带着这个问题，我们进入今天的学习——{point['title']}。",
        },
        {
            "scene": "建构",
            "text": f"通过观察和讨论，我们可以得到这样的认识：{core[0] if core else point.get('summary','')}。请注意关键词，它们决定了这个结论的适用条件。",
        },
    ]
    if formulas:
        lines.append(
            {
                "scene": "建模",
                "text": f"把文字结论写成物理语言，就是 {formulas[0]}。式中每个字母表示什么、单位是什么，请大家在学案上标注清楚。",
            }
        )
    if hard:
        lines.append(
            {
                "scene": "难点",
                "text": f"这里是本课最容易出错的地方：{hard[0]}。我给大家一个判断顺序——先看条件，再定方向，最后代数值。",
            }
        )
    if mis:
        lines.append(
            {
                "scene": "辨析",
                "text": f"有同学可能会认为：{mis[0]}。这个说法错在哪里？请大家用今天学到的规律来反驳它。",
            }
        )
    lines.append(
        {
            "scene": "小结",
            "text": "回顾一下：我们从一个现象出发，建立了概念，写出了公式，还用它解决了问题。课后请完成分层作业，并把你的疑问带到下节课。",
        }
    )
    return lines


def generate(point_ids: list[str], profile: dict | None = None, options: dict | None = None) -> dict:
    kb = get_kb()
    profile = profile or {}
    options = options or {}
    points = [kb.point(pid) for pid in point_ids]
    points = [p for p in points if p]
    if not points:
        raise ValueError("请至少选择一个知识点")
    main = points[0]
    senior = main.get("stage") == "高中"
    duration = int(options.get("duration") or profile.get("duration") or 45)
    if len(points) > 1:
        title = f"{main['title']}（含{'、'.join(p['title'] for p in points[1:3])}）"
    else:
        title = main["title"]

    plan = {
        "id": new_id("L"),
        "kind": "lesson",
        "title": title,
        "pointIds": [p["id"] for p in points],
        "points": [{"id": p["id"], "title": p["title"]} for p in points],
        "meta": {
            "stage": main.get("stage"),
            "grade": main.get("grade"),
            "textbook": main.get("textbookName"),
            "chapter": main.get("chapterTitle"),
            "duration": duration,
            "classLevel": profile.get("classLevel", "中等"),
            "style": options.get("style") or profile.get("style") or "探究式",
            "date": date.today().isoformat(),
            "author": options.get("author") or "悟理智课 · 自动生成",
        },
        "objectives": _objectives(main, senior),
        "keyPoints": main.get("key", [])[:3],
        "hardPoints": main.get("hard", [])[:3],
        "studentAnalysis": _student_analysis(main, profile),
        "methods": (
            ["情境教学法", "问题链驱动", "实验探究法", "建模式教学", "分层训练"]
            if (options.get("style") or "探究式") == "探究式"
            else ["讲授法", "演示实验", "变式训练", "归纳总结"]
        ),
        "materials": (
            [f"交互仿真：{SIM_LABEL.get(main.get('sim'), main.get('sim'))}"] if main.get("sim") else []
        )
        + ([f"VR 场景：{VR_LABEL.get(main.get('vr'), main.get('vr'))}"] if main.get("vr") else [])
        + [f"实验 / 探究：{e}" for e in main.get("experiments", [])[:2]]
        + ["学案、分层任务单、随堂检测"],
        "process": _process(main, profile, duration, senior),
        "board": _board(main),
        "homework": _homework(main, profile.get("classLevel", "中等")),
        "assessment": _assessment(main),
        "narration": _narration(main, profile),
        "summary": main.get("summary", ""),
        "formulas": main.get("formulas", []),
        "misconceptions": main.get("misconceptions", []),
        "experiments": main.get("experiments", []),
        "sim": main.get("sim", ""),
        "vr": main.get("vr", ""),
        "game": main.get("game", ""),
    }
    plan["materials"] = [x for x in plan["materials"] if x]
    return plan


# ---------------------------------------------------------------- 优化
def _issues_for_plan(text: str, plan_in: dict, sig: dict, kb_point: dict | None) -> list[dict]:
    issues: list[dict] = []

    def add(level, title, evidence, fix):
        issues.append({"level": level, "title": title, "evidence": evidence, "fix": fix})

    if not sig["hasObjectives"]:
        add("严重", "缺少明确的教学目标", "全文未检测到“教学目标/学习目标/核心素养”段落", "按核心素养四维（或三维目标）补写可观测、可评价的目标")
    elif sig["measurable"] < 3:
        add("重要", "目标表述不可测", f"仅检测到 {sig['measurable']} 个行为动词（说出/解释/计算…）", "把“了解/掌握”改为“说出/解释/计算/设计”等可观测动词")
    if not sig["hasKeyHard"]:
        add(
            "严重",
            "未明确教学重难点",
            "未检测到重点/难点段落",
            f"依据教材与课标，重点应落在“{(kb_point or {}).get('key', ['核心概念'])[0]}”，难点定位在“{(kb_point or {}).get('hard', ['思维断点'])[0]}”",
        )
    if not sig["hasStudents"]:
        add("重要", "缺少学情分析", "未检测到学情/前测/认知起点相关表述", "补充班级层次、前测数据、已有基础与典型错误三要素")
    elif not re.search(r"\d", plan_in.get("students", "") or ""):
        add("建议", "学情分析缺少数据支撑", "学情段落中没有出现具体数据（人数/正确率/得分）", "加入前测正确率或作业错误率等数据，使教学决策有依据")
    if not sig["hasProcess"]:
        add("严重", "缺少教学过程设计", "未检测到教学环节/活动设计", "按“情境—建构—建模—探究—训练—小结”六环节重构，并标注时间")
    if sig["timeMentions"] and sig["duration"] and sig["timeSum"] and sig["timeSum"] > sig["duration"] * 1.15:
        add("重要", "环节时间超出课时", f"各环节时间合计约 {sig['timeSum']} 分钟，超过课时 {sig['duration']} 分钟", "压缩讲授环节，把探究与训练时间控制在课时内")
    if not sig["hasExperiment"]:
        add("重要", "缺少实验/探究活动", "全文未出现实验、探究、测量等字样", "增加一个 5~8 分钟的探究活动（可用平台交互仿真替代）")
    if not sig["hasDifferentiation"]:
        add("建议", "作业未分层", "未检测到分层/基础层/拓展层等表述", "按基础、提高、拓展三层设计作业，控制总量")
    if not sig["hasAssessment"]:
        add("重要", "缺少评价与反馈设计", "未检测到评价/检测/达标等表述", "增加课堂观察点与 2~3 道目标检测题，形成“教—学—评”一致")
    if not sig["hasBoard"]:
        add("建议", "缺少板书设计", "未检测到板书设计", "补一张结构化板书，呈现概念、公式与易错辨析")
    if sig["chars"] < 600:
        add("建议", "教案过于简略", f"正文约 {sig['chars']} 字", "补充教师活动、学生活动与设计意图三栏，便于直接上课")
    return issues


def optimize_plan(text: str, profile: dict | None = None, options: dict | None = None) -> dict:
    kb = get_kb()
    profile = profile or {}
    options = options or {}
    sig = plan_signals(text)
    parsed = normalize_plan(text)
    matches = kb.pick_for_text(text, 3)
    main = matches[0] if matches else None
    if main is None:
        # 从标题猜
        first = next((ln for ln in (text or "").split("\n") if ln.strip()), "")
        cands = [p for p in kb.points.values() if p["title"] in first]
        main = cands[0] if cands else list(kb.points.values())[0]
        matches = [main]

    merged_profile = dict(profile)
    if not merged_profile.get("classLevel"):
        merged_profile["classLevel"] = "中等"
    if parsed.get("students"):
        merged_profile["prior"] = short(parsed["students"], 120)

    base = generate([p["id"] for p in matches[:1]], merged_profile, options)
    issues = _issues_for_plan(text, parsed, sig, main)

    diffs: list[dict] = []

    def diff(field, before, after, reason):
        diffs.append(
            {
                "field": field,
                "before": short(before, 160) if before else "（缺失）",
                "after": short(after, 160) if isinstance(after, str) else after,
                "reason": reason,
            }
        )

    if not parsed.get("objectives"):
        diff("教学目标", "", " / ".join(o["text"] for o in base["objectives"]), "原教案缺少目标，按核心素养四维补全")
    else:
        base["objectives"] = [
            {"dim": base["objectives"][0]["dim"], "text": parsed["objectives"].split("\n")[0][:120]}
        ] + base["objectives"][1:]
        diff("教学目标", parsed["objectives"], base["objectives"][0]["text"], "保留原有表述，补充可观测的行为动词与素养维度")

    if not parsed.get("key"):
        diff("教学重点", "", "；".join(base["keyPoints"]), "依据教材与课标定位重点")
    else:
        base["keyPoints"] = [x.strip(" 　·-—") for x in re.split(r"[；;、\n]", parsed["key"]) if x.strip()][:3] or base["keyPoints"]
        diff("教学重点", parsed["key"], "；".join(base["keyPoints"]), "保留教师原有判断并做条目化")
    if not parsed.get("hard"):
        diff("教学难点", "", "；".join(base["hardPoints"]), "结合常见误区定位难点")
    else:
        base["hardPoints"] = [x.strip(" 　·-—") for x in re.split(r"[；;、\n]", parsed["hard"]) if x.strip()][:3] or base["hardPoints"]
        diff("教学难点", parsed["hard"], "；".join(base["hardPoints"]), "保留教师原有判断并做条目化")

    diff("学情分析", parsed.get("students", ""), "；".join(base["studentAnalysis"]["strategies"]), "补充前测数据、典型错误与分层策略")
    diff("教学过程", parsed.get("process", ""), f"{len(base['process'])} 个环节，含时间分配、师生活动与设计意图", "按六环节重构并补齐时间与意图")
    diff("评价设计", "", f"{len(base['assessment']['items'])} 道检测题 + 3 条观察点", "增加“教—学—评”一致性设计")
    diff("作业设计", parsed.get("homework", ""), "基础 / 提高 / 拓展 三层", "落实分层作业，控制总量")
    diff("板书设计", parsed.get("board", ""), base["board"]["title"], "补结构化板书")

    base["title"] = f"{base['title']}（优化版）"
    base["source"] = {"type": "optimize", "originalChars": sig["chars"], "matchedPoints": [p["id"] for p in matches]}
    base["optimization"] = {
        "scoreBefore": _score(sig),
        "scoreAfter": min(96, _score(sig) + 6 * sum(1 for i in issues if i["level"] in ("严重", "重要")) + 4),
        "issues": issues,
        "diffs": diffs,
        "signals": sig,
        "original": {
            "objectives": parsed.get("objectives", ""),
            "key": parsed.get("key", ""),
            "hard": parsed.get("hard", ""),
            "students": parsed.get("students", ""),
            "process": parsed.get("process", ""),
        },
    }
    return {"plan": base, "diagnosis": base["optimization"]}


def _score(sig: dict) -> int:
    score = 40
    weights = {
        "hasObjectives": 10,
        "hasKeyHard": 10,
        "hasStudents": 8,
        "hasProcess": 10,
        "hasExperiment": 6,
        "hasAssessment": 6,
        "hasDifferentiation": 4,
        "hasBoard": 3,
        "hasHomework": 3,
    }
    for k, w in weights.items():
        if sig.get(k):
            score += w
    if sig.get("measurable", 0) >= 4:
        score += 4
    if sig.get("chars", 0) > 900:
        score += 4
    return min(95, score)