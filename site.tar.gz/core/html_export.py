"""课件 → 单文件交互 HTML（内联 CSS / 播放器 / 控件 / 数据）。"""
from __future__ import annotations

import json
from pathlib import Path

WEB = Path(__file__).resolve().parent.parent / "web"


def _read(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8")
    except Exception:
        return ""


def export_html(deck: dict, path: Path) -> Path:
    css = _read(WEB / "css" / "app.css")
    scripts = []
    for rel in (
        "js/widgets/sims-core.js",
        "js/widgets/sims-extra.js",
        "js/widgets/vr.js",
        "js/widgets/book3d.js",
        "js/widgets/avatar.js",
        "js/widgets/game.js",
        "js/player.js",
    ):
        src = _read(WEB / rel)
        if src:
            scripts.append(f"<script>/* {rel} */\n{src}\n</script>")

    deck_json = json.dumps(deck, ensure_ascii=False).replace("</", "<\\/")
    title = (deck.get("meta") or {}).get("title", "交互课件")
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>{title} · 悟理智课交互课件</title>
<style>
{css}
html, body {{ height: 100%; }}
#root {{ position: fixed; inset: 0; }}
</style>
</head>
<body>
<div id="root"></div>
{''.join(scripts)}
<script>
const DECK = {deck_json};
(function () {{
  try {{
    PSPlayer.mount(document.getElementById('root'), DECK, {{ offline: true, autoSpeak: false }});
  }} catch (e) {{
    document.getElementById('root').innerHTML = '<div style="padding:40px;color:#e8eff9;font-family:sans-serif">课件加载失败：' + e.message + '</div>';
  }}
}})();
</script>
</body>
</html>
"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(html, encoding="utf-8")
    return path