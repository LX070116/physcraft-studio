"""PDF 文本提取（纯标准库，支持中文 CID 字体）。

流程：
1. 读取 PDF 对象表，定位每页的 /Contents 内容流；
2. 解析 /Resources → /Font → /ToUnicode，为每个字体建立 CID→Unicode 映射
   （同一文档里不同子集字体的编码会冲突，必须按页按字体区分）；
3. 按文本算子抽取字符串，结合 Td/TD/T*/Tm 还原换行；
4. 清理装饰性文本（页码、语言标记），抽不到文字时给出明确提示。

不依赖 pypdf / poppler / Office。
"""
from __future__ import annotations

import re
import zlib

CJK = re.compile(r"[\u3400-\u9fff\uf900-\ufaff]")
GOOD = re.compile(
    r"[\u3400-\u9fff\uf900-\ufaff\u3000-\u303f\uff00-\uffefA-Za-z0-9\s\.,;:!?\-+*/=()\[\]{}%<>_\"'`~@#$&|\\^]"
)
OBJ_RE = re.compile(rb"(\d+)\s+0\s+obj\b(.*?)\bendobj", re.S)
TOKEN = re.compile(
    rb"<<|>>|\((?:[^()\\]|\\.)*\)|<[0-9A-Fa-f\s]*>|/[A-Za-z0-9#._+-]*|[A-Za-z'\"*]+|[-+]?\d*\.?\d+"
)


# ---------------------------------------------------------------- 基础解析
def _load_objects(data: bytes) -> dict[int, bytes]:
    return {int(m.group(1)): m.group(2) for m in OBJ_RE.finditer(data)}


def _stream_of(body: bytes) -> bytes | None:
    m = re.search(rb"stream\r?\n", body)
    if not m:
        return None
    start = m.end()
    end = re.search(rb"\r?\nendstream", body[start:])
    if not end:
        return None
    raw = body[start : start + end.start()]
    head = body[:start][-800:]
    if b"FlateDecode" in head:
        try:
            raw = zlib.decompress(raw)
        except zlib.error:
            try:
                raw = zlib.decompress(raw, -15)
            except zlib.error:
                return None
    return raw


def _dict_at(body: bytes, start: int) -> bytes:
    depth = 0
    i = start
    n = len(body)
    while i < n - 1:
        two = body[i : i + 2]
        if two == b"<<":
            depth += 1
            i += 2
            continue
        if two == b">>":
            depth -= 1
            i += 2
            if depth == 0:
                return body[start:i]
            continue
        i += 1
    return body[start:]


def _value_after(body: bytes, key: bytes, objs: dict[int, bytes]) -> bytes | None:
    """取 /Key 的值：内联字典返回字典文本，间接引用返回对象体。"""
    m = re.search(re.escape(key) + rb"\s*", body)
    if not m:
        return None
    i = m.end()
    if body[i : i + 2] == b"<<":
        return _dict_at(body, i)
    ref = re.match(rb"(\d+)\s+0\s+R", body[i:])
    if ref:
        return objs.get(int(ref.group(1)))
    arr = re.match(rb"\[(.*?)\]", body[i:], re.S)
    if arr:
        return arr.group(1)
    return None


def _parse_cmap(data: bytes) -> dict[int, str]:
    text = data.decode("latin-1", errors="ignore")
    mapping: dict[int, str] = {}

    def uni(hexstr: str) -> str:
        hexstr = re.sub(r"\s+", "", hexstr)
        try:
            b = bytes.fromhex(hexstr + ("0" if len(hexstr) % 2 else ""))
        except ValueError:
            return ""
        if len(b) == 2:
            return b.decode("utf-16-be", errors="ignore")
        if len(b) > 2 and len(b) % 2 == 0:
            return b.decode("utf-16-be", errors="ignore")
        return b.decode("latin-1", errors="ignore")

    for block in re.findall(r"beginbfchar(.*?)endbfchar", text, re.S):
        for src, dst in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", block):
            try:
                mapping[int(src, 16)] = uni(dst)
            except ValueError:
                continue
    for block in re.findall(r"beginbfrange(.*?)endbfrange", text, re.S):
        for m in re.finditer(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*(?:<([0-9A-Fa-f]+)>|\[(.*?)\])", block, re.S):
            try:
                lo, hi = int(m.group(1), 16), int(m.group(2), 16)
            except ValueError:
                continue
            if m.group(3):
                base = m.group(3)
                try:
                    base_int = int(base, 16)
                except ValueError:
                    continue
                width = max(2, len(base))
                for k in range(min(hi - lo + 1, 4096)):
                    mapping[lo + k] = uni(format(base_int + k, "0%dx" % width))
            elif m.group(4):
                for k, it in enumerate(re.findall(r"<([0-9A-Fa-f]+)>", m.group(4))[: hi - lo + 1]):
                    mapping[lo + k] = uni(it)
    return mapping


def _decode_pdf_string(raw: bytes, is_hex: bool) -> bytes:
    if is_hex:
        h = re.sub(rb"[^0-9A-Fa-f]", b"", raw)
        if len(h) % 2:
            h += b"0"
        try:
            return bytes.fromhex(h.decode("ascii"))
        except ValueError:
            return b""
    out = bytearray()
    i, n = 0, len(raw)
    while i < n:
        c = raw[i]
        if c != 0x5C:
            out.append(c)
            i += 1
            continue
        i += 1
        if i >= n:
            break
        e = raw[i]
        if e in b"nrtbf":
            out.append({0x6E: 10, 0x72: 13, 0x74: 9, 0x62: 8, 0x66: 12}[e])
            i += 1
        elif e in b"()\\":
            out.append(e)
            i += 1
        elif 0x30 <= e <= 0x37:
            digits = bytes([e])
            i += 1
            while i < n and len(digits) < 3 and 0x30 <= raw[i] <= 0x37:
                digits += bytes([raw[i]])
                i += 1
            out.append(int(digits, 8) & 0xFF)
        elif e in b"\r\n":
            if e == 13 and i + 1 < n and raw[i + 1] == 10:
                i += 2
            else:
                i += 1
        else:
            out.append(e)
            i += 1
    return bytes(out)


# ---------------------------------------------------------------- 内容流
def _extract_content(content: bytes, font_cmaps: dict[str, dict[int, str]], fallback: dict[int, str]) -> str:
    parts: list[str] = []
    nums: list[float] = []
    arr: list[str] = []
    in_arr = False
    dict_depth = 0
    last_y = None
    cur_font = ""
    last_name = ""

    def decode(b: bytes, cmap: dict[int, str]) -> str:
        if not b:
            return ""
        if cmap:
            if len(b) % 2 == 0 and len(b) >= 2:
                chars, hit = [], 0
                for i in range(0, len(b), 2):
                    code = (b[i] << 8) | b[i + 1]
                    ch = cmap.get(code)
                    if ch is not None:
                        chars.append(ch)
                        hit += 1
                    else:
                        chars.append("")
                if hit >= max(1, len(b) // 6):
                    return "".join(chars)
            if len(b) == 1 and b[0] in cmap:
                return cmap[b[0]]
        if b[:2] == b"\xfe\xff":
            return b[2:].decode("utf-16-be", errors="ignore")
        try:
            s = b.decode("utf-8")
            if s and CJK.search(s):
                return s
        except UnicodeDecodeError:
            pass
        return b.decode("latin-1", errors="ignore")

    for tok in TOKEN.finditer(content):
        t = tok.group(0)
        if t == b"<<":
            dict_depth += 1
            continue
        if t == b">>":
            dict_depth = max(0, dict_depth - 1)
            continue
        if dict_depth:
            continue
        if t == b"[":
            in_arr = True
            arr = []
            continue
        if t == b"]":
            in_arr = False
            if arr:
                parts.append("".join(arr))
                arr = []
            continue
        if t.startswith(b"/"):
            last_name = t[1:].decode("latin-1", errors="ignore")
            continue
        if t.startswith(b"(") or (t.startswith(b"<") and t.endswith(b">") and not t.startswith(b"<<")):
            is_hex = t.startswith(b"<")
            raw = t[1:-1]
            cmap = font_cmaps.get(cur_font) or font_cmaps.get(last_name) or fallback
            s = decode(_decode_pdf_string(raw, is_hex), cmap)
            (arr if in_arr else parts).append(s)
            continue
        if re.fullmatch(rb"[-+]?\d*\.?\d+", t):
            try:
                v = float(t)
            except ValueError:
                continue
            nums.append(v)
            if in_arr and v < -180:
                arr.append(" ")
            continue
        op = t.decode("latin-1", errors="ignore")
        if op == "Tf":
            if last_name:
                cur_font = last_name
        elif op == "Tm" and len(nums) >= 6:
            y = nums[-1]
            if last_y is not None and abs(y - last_y) > 3:
                parts.append("\n")
            last_y = y
        elif op in ("Td", "TD") and len(nums) >= 2:
            ty = nums[-1]
            if abs(ty) > 0.1:
                parts.append("\n")
                last_y = (last_y or 0) + ty
        elif op == "T*":
            parts.append("\n")
        elif op in ("'", '"'):
            parts.append("\n")
        nums = []
    return "".join(parts)


def _page_streams(objs: dict[int, bytes]) -> list[tuple[bytes, dict[str, dict[int, str]]]]:
    """返回 [(内容流, {字体资源名: CMap})]，按页对象编号排序。"""
    # 先建立 font 对象 → cmap
    font_cmap: dict[int, dict[int, str]] = {}
    cmap_cache: dict[int, dict[int, str]] = {}
    for num, body in objs.items():
        m = re.search(rb"/ToUnicode\s+(\d+)\s+0\s+R", body)
        if not m:
            continue
        cid = int(m.group(1))
        if cid not in cmap_cache:
            raw = _stream_of(objs.get(cid, b""))
            cmap_cache[cid] = _parse_cmap(raw) if raw else {}
        if cmap_cache[cid]:
            font_cmap[num] = cmap_cache[cid]

    pages: list[tuple[int, bytes, dict[int, dict[int, str]]]] = []
    for num, body in objs.items():
        if not re.search(rb"/Type\s*/Page\b", body):
            continue
        res = _value_after(body, b"/Resources", objs)
        if not res:
            continue
        fontdict = _value_after(res, b"/Font", objs)
        mapping: dict[str, dict[int, str]] = {}
        if fontdict:
            for fm in re.finditer(rb"/([A-Za-z0-9#._+-]+)\s+(\d+)\s+0\s+R", fontdict):
                name = fm.group(1).decode("latin-1")
                fnum = int(fm.group(2))
                if fnum in font_cmap:
                    mapping[name] = font_cmap[fnum]
        # Contents：单个引用或数组
        contents = _value_after(body, b"/Contents", objs if b" 0 R" not in body else objs)
        refs: list[int] = []
        cm = re.search(rb"/Contents\s*\[(.*?)\]", body, re.S)
        if cm:
            refs = [int(x) for x in re.findall(rb"(\d+)\s+0\s+R", cm.group(1))]
        else:
            cm2 = re.search(rb"/Contents\s+(\d+)\s+0\s+R", body)
            if cm2:
                refs = [int(cm2.group(1))]
        if not refs:
            continue
        pages.append((num, b"\n".join(filter(None, [_stream_of(objs.get(r, b"")) for r in refs])), mapping))
    pages.sort(key=lambda x: x[0])
    return [(content, m) for _, content, m in pages]


def _clean(text: str) -> str:
    text = text.replace("\x00", "")
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    lines = []
    for line in text.split("\n"):
        s = line.strip()
        if not s:
            lines.append("")
            continue
        if s in ("en-US", "zh-CN", "zh-TW", "ja-JP", "ko-KR"):
            continue
        # 丢弃明显是乱码的短行
        good = sum(1 for ch in s if GOOD.match(ch))
        if good / len(s) < 0.6 and not CJK.search(s):
            continue
        lines.append(s)
    out = "\n".join(lines)
    out = re.sub(r"\n{3,}", "\n\n", out)
    return out.strip()


def extract_text(data: bytes) -> str:
    objs = _load_objects(data)
    pages = _page_streams(objs)

    # 全局 CMap 兜底
    fallback: dict[int, str] = {}
    for body in objs.values():
        if b"beginbfchar" in body or b"beginbfrange" in body:
            raw = _stream_of(body)
            if raw:
                fallback.update(_parse_cmap(raw))

    chunks: list[str] = []
    if pages:
        for content, font_map in pages:
            chunks.append(_extract_content(content, font_map, fallback))
    else:
        # 退化路径：直接扫所有内容流
        for body in objs.values():
            raw = _stream_of(body)
            if raw and (b"BT" in raw) and (b"Tj" in raw or b"TJ" in raw):
                chunks.append(_extract_content(raw, {}, fallback))
    return _clean("\n".join(chunks))


def quality(text: str) -> float:
    if not text:
        return 0.0
    return sum(1 for ch in text if GOOD.match(ch)) / len(text)


def extract_pdf(data: bytes, min_chars: int = 40) -> str:
    if not data.startswith(b"%PDF"):
        raise ValueError("不是有效的 PDF 文件")
    try:
        text = extract_text(data)
    except Exception as e:  # 解析失败也要给出可操作的提示
        raise ValueError(f"PDF 解析失败：{e}。请另存为 DOCX 后上传。")
    if len(re.sub(r"\s", "", text)) < min_chars:
        raise ValueError("未能从 PDF 中提取到文字：可能是扫描版或纯图片 PDF。请改用 DOCX，或上传可复制文字的 PDF。")
    if quality(text) < 0.55:
        raise ValueError("这个 PDF 的文字编码无法可靠识别（可能使用了特殊字体子集）。请另存为 DOCX 后上传。")
    return text