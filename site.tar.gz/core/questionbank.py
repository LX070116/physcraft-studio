"""题库：加载、检索、同类题、讲解、导出。

题库是静态 JSON（人工校对）；"同类题"用同一知识点的题型模板生成变式，
"AI 讲解"由解析 + 解题步骤 + 知识点要点拼装，均为本地可复现逻辑。
"""
from __future__ import annotations

import re
from functools import lru_cache
from pathlib import Path

from . import physics_problems as pp
from .kb import get_kb
from .util import read_json

HERE = Path(__file__).resolve().parent

TYPE_ORDER = ["选择", "填空", "计算", "实验探究", "简答"]


@lru_cache(maxsize=1)
def _items() -> tuple[dict, ...]:
    data = read_json(HERE / "questions.json") or {}
    return tuple(data.get("items", []))


def stats() -> dict:
    items = _items()
    by_stage: dict[str, int] = {}
    by_type: dict[str, int] = {}
    by_diff: dict[str, int] = {}
    for q in items:
        by_stage[q.get("stage", "其他")] = by_stage.get(q.get("stage", "其他"), 0) + 1
        by_type[q.get("type", "其他")] = by_type.get(q.get("type", "其他"), 0) + 1
        by_diff[str(q.get("difficulty", 2))] = by_diff.get(str(q.get("difficulty", 2)), 0) + 1
    return {"total": len(items), "byStage": by_stage, "byType": by_type, "byDifficulty": by_diff}


def query(stage="", typ="", difficulty="", point="", word="", limit=0, offset=0) -> list[dict]:
    word = (word or "").strip().lower()
    out = []
    for q in _items():
        if stage and q.get("stage") != stage:
            continue
        if typ and q.get("type") != typ:
            continue
        if difficulty and str(q.get("difficulty")) != str(difficulty):
            continue
        if point and point not in (q.get("pointIds") or []):
            continue
        if word:
            hay = " ".join([q.get("stem", ""), q.get("chapter", ""), " ".join(q.get("tags", []))]).lower()
            if word not in hay:
                continue
        out.append(q)
    out.sort(key=lambda q: (TYPE_ORDER.index(q.get("type")) if q.get("type") in TYPE_ORDER else 9, q.get("id", "")))
    if offset:
        out = out[offset:]
    if limit:
        out = out[:limit]
    return out


def get(qid: str) -> dict | None:
    for q in _items():
        if q.get("id") == qid:
            return q
    return None


def for_point(pid: str, n: int = 3) -> list[dict]:
    qs = [q for q in _items() if pid in (q.get("pointIds") or [])]
    # 优先选择/计算
    order = {"选择": 0, "判断": 0, "计算": 1, "填空": 2, "实验探究": 3, "简答": 4}
    qs.sort(key=lambda q: (order.get(q.get("type"), 9), q.get("difficulty", 2)))
    return qs[:n]


def quiz_items(pid: str, n: int = 3) -> list[dict] | None:
    """转成课件 quiz 场景需要的结构；没有题库时返回 None。"""
    qs = for_point(pid, n)
    if not qs:
        return None
    out = []
    for q in qs:
        opts = q.get("options") or []
        answer = q.get("answer", "")
        if q.get("type") == "选择" and len(opts) >= 2:
            # 选项形如 "A. xxx"，播放器按包含匹配，这里用选项文本
            letters = re.findall(r"([A-D])[\.、]", answer)
            letter = letters[0] if letters else ""
            idx = "ABCD".index(letter) if letter in "ABCD" else -1
            correct = opts[idx] if 0 <= idx < len(opts) else answer
            out.append(
                {
                    "type": "mcq",
                    "stem": q["stem"],
                    "options": [o.split(".", 1)[-1].strip() for o in opts],
                    "answer": correct.split(".", 1)[-1].strip(),
                    "explain": q.get("analysis", ""),
                }
            )
        else:
            out.append(
                {
                    "type": "calc" if q.get("type") == "计算" else "short",
                    "stem": q["stem"],
                    "options": [],
                    "answer": answer,
                    "explain": q.get("analysis", ""),
                }
            )
    return out


def explain(qid: str) -> dict | None:
    q = get(qid)
    if not q:
        return None
    kb = get_kb()
    pts = [kb.point(p) for p in (q.get("pointIds") or [])]
    pts = [p for p in pts if p]
    steps = q.get("solution") or []
    parts = []
    if q.get("analysis"):
        parts.append(q["analysis"])
    if pts:
        p = pts[0]
        parts.append(f"这道题考的是「{p['title']}」。核心结论：{p.get('core', [''])[0]}")
        if p.get("formulas"):
            parts.append("可用公式：" + "；".join(p["formulas"]))
        if p.get("hard"):
            parts.append("易错点：" + p["hard"][0])
    return {
        "id": qid,
        "title": "试题讲解",
        "answer": q.get("answer", ""),
        "steps": steps,
        "explanation": "\n\n".join(parts),
        "points": [{"id": p["id"], "title": p["title"]} for p in pts],
        "script": build_script(q, pts, steps),
    }


def build_script(q: dict, pts: list[dict], steps: list[str]) -> str:
    head = "我们来看这道题。" + (q.get("stem", "")[:60])
    body = ""
    if pts:
        body = f"它考查的是{pts[0]['title']}。"
    tail = "解题步骤是：" + "；".join(steps[:4]) if steps else "先审题，再套用本课规律。"
    return head + body + tail + " 你学会了吗？"


def similar(qid: str, count: int = 3) -> list[dict]:
    """同型题：优先取题库中同知识点同题型；不足时用模板生成变式。"""
    q = get(qid)
    if not q:
        return []
    out = []
    for other in _items():
        if other.get("id") == q.get("id"):
            continue
        if other.get("type") == q.get("type") and set(other.get("pointIds") or []) & set(q.get("pointIds") or []):
            out.append(other)
        if len(out) >= count:
            break
    result = [
        {"id": o["id"], "stem": o["stem"], "answer": o.get("answer", ""), "source": "题库"}
        for o in out
    ]
    # 同章同题型
    if len(result) < count:
        for other in _items():
            if len(result) >= count:
                break
            if other.get("id") == q.get("id") or other.get("id") in {r["id"] for r in result}:
                continue
            if other.get("type") == q.get("type") and other.get("chapter") == q.get("chapter"):
                result.append({"id": other["id"], "stem": other["stem"], "answer": other.get("answer", ""), "source": "同章题"})
    # 同学段同题型
    if len(result) < count:
        for other in _items():
            if len(result) >= count:
                break
            if other.get("id") == q.get("id") or other.get("id") in {r["id"] for r in result}:
                continue
            if other.get("type") == q.get("type") and other.get("stage") == q.get("stage"):
                result.append({"id": other["id"], "stem": other["stem"], "answer": other.get("answer", ""), "source": "同型题"})
    if len(result) < count:
        kb = get_kb()
        for pid in q.get("pointIds") or []:
            p = kb.point(pid)
            if not p:
                continue
            # 用模板的第二个变式生成一道
            for variant in (0, 1):
                ex = pp.build_example(p, variant)
                if ex and len(result) < count:
                    result.append({"id": None, "stem": ex["stem"], "answer": ex["answer"], "source": "AI 变式"})
    return result[:count]


def export_docx(questions: list[dict], path: Path, title: str = "物理练习") -> Path:
    from docx import Document
    from docx.oxml.ns import qn
    from docx.shared import Pt, RGBColor

    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Microsoft YaHei"
    style.font.size = Pt(10.5)
    style.element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    h = doc.add_paragraph()
    r = h.add_run(title)
    r.bold = True
    r.font.size = Pt(18)
    for i, q in enumerate(questions, start=1):
        p = doc.add_paragraph()
        r = p.add_run(f"{i}. {q['stem']}")
        r.font.size = Pt(10.5)
        for o in q.get("options") or []:
            doc.add_paragraph(o)
        doc.add_paragraph("【答案】" + str(q.get("answer", "")))
        if q.get("analysis"):
            doc.add_paragraph("【解析】" + re.sub(r"^解析[:：]\s*", "", q["analysis"]))
        doc.add_paragraph("")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(path))
    return path


def export_pdf(questions: list[dict], path: Path, title: str = "物理练习") -> Path:
    from . import pdf_writer

    blocks = [{"text": title, "level": 1}]
    for i, q in enumerate(questions, start=1):
        blocks.append({"text": f"{i}. {q['stem']}", "level": 0})
        for o in q.get("options") or []:
            blocks.append({"text": "    " + o, "level": 0})
        blocks.append({"text": "答案：" + str(q.get("answer", "")), "level": -1})
        if q.get("analysis"):
            blocks.append({"text": "解析：" + re.sub(r"^解析[:：]\s*", "", q["analysis"]), "level": -1})
        blocks.append({"text": "", "level": 0})
    return pdf_writer.write_text_pdf(blocks, Path(path), title=title)