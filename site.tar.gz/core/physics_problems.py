"""物理例题/随堂检测生成：模板化、数值可验证（取 g=10 N/kg）。"""
from __future__ import annotations

import math
import re

# 每个模板返回 (题干, 答案, 步骤列表)
TEMPLATES: dict[str, callable] = {}


def _t(fn):
    TEMPLATES[fn.__name__] = fn
    return fn


@_t
def lens_imaging(v=0):
    f, u, h = (10, 30, 4) if not v else (8, 24, 3)
    vv = 1 / (1 / f - 1 / u)
    m = vv / u
    return (
        f"凸透镜焦距 f={f} cm，物体高 {h} cm，放在距透镜 {u} cm 处。求像距、像高，并说明像的性质。",
        f"v = {vv:.0f} cm，像高 {h*m:.1f} cm，成倒立缩小的实像",
        [
            f"由 1/f = 1/u + 1/v 得 v = uf/(u−f) = {u}×{f}/({u}−{f}) = {vv:.0f} cm",
            f"放大率 m = v/u = {vv:.0f}/{u} = {m:.2f}，像高 = {h} × {m:.2f} = {h*m:.1f} cm",
            f"u = {u} cm > 2f = {2*f} cm，故成倒立、缩小的实像（照相机原理）",
        ],
    )


@_t
def speed():
    s, t = 144, 2
    v = s / t
    return (
        f"一辆汽车在高速公路上匀速行驶，2 h 内通过的路程为 {s} km。求汽车的速度是多少 km/h？合多少 m/s？",
        f"{v:.0f} km/h，合 {v/3.6:.0f} m/s",
        [f"v = s/t = {s} km ÷ {t} h = {v:.0f} km/h", f"{v:.0f} km/h = {v:.0f} ÷ 3.6 m/s = {v/3.6:.0f} m/s"],
    )


@_t
def density():
    m, V = 2.7, 500
    rho = m * 1000 / V
    name = "铝" if abs(rho - 2.7) < 0.05 else "未知物质"
    return (
        f"一个金属块的质量为 {m} kg，体积为 {V} cm³。求它的密度，并判断它可能是什么金属（ρ铝=2.7 g/cm³）。",
        f"{rho:.1f} g/cm³（{rho*1000:.1f} kg/m³），可能是{name}",
        [f"ρ = m/V = {m*1000} g ÷ {V} cm³ = {rho:.1f} g/cm³", f"与铝的密度 2.7 g/cm³ 相同，故可能是铝"],
    )


@_t
def weight():
    m = 50
    G = m * 10
    return (
        f"一名中学生的质量为 {m} kg，取 g=10 N/kg，求他受到的重力。",
        f"{G} N",
        [f"G = mg = {m} kg × 10 N/kg = {G} N"],
    )


@_t
def pressure_solid():
    F, S = 500, 0.02
    p = F / S
    return (
        f"一个人重 {F} N，双脚与地面的总接触面积为 {S} m²。求他对地面的压强。",
        f"{p:.0f} Pa",
        [f"p = F/S = {F} N ÷ {S} m² = {p:.0f} Pa"],
    )


@_t
def pressure_liquid():
    h = 2
    p = 1000 * 10 * h
    return (
        f"某水池水深 {h} m，求水对池底的压强（ρ水=1.0×10³ kg/m³，g=10 N/kg）。",
        f"{p:.0e} Pa".replace("e+0", "×10^").replace("e+", "×10^"),
        [f"p = ρgh = 1.0×10³ kg/m³ × 10 N/kg × {h} m = {p:.1e} Pa"],
    )


@_t
def buoyancy(v=0):
    V, rho = (1e-3, 1000) if not v else (2e-3, 1000)
    F = rho * 10 * V
    return (
        f"一个体积为 {V*1e3:.0f} dm³ 的物体全部浸没在水中，求它受到的浮力（ρ水=1.0×10³ kg/m³，g=10 N/kg）。",
        f"{F:.0f} N",
        [f"{V*1e3:.0f} dm³ = {V:.0e} m³".replace("e-03", "×10⁻³"), f"F浮 = ρ液gV排 = 1.0×10³ × 10 × {V:.0e} = {F:.0f} N".replace("e-03", "×10⁻³")],
    )


@_t
def work_power():
    F, s, t = 50, 10, 20
    W, P = F * s, F * s / t
    return (
        f"用 {F} N 的水平推力使物体沿力的方向移动 {s} m，用时 {t} s。求推力做的功和功率。",
        f"W = {W} J，P = {P:.0f} W",
        [f"W = Fs = {F} N × {s} m = {W} J", f"P = W/t = {W} J ÷ {t} s = {P:.0f} W"],
    )


@_t
def efficiency():
    G, h, F, s = 200, 2, 80, 6
    eta = G * h / (F * s) * 100
    return (
        f"用滑轮组把重 {G} N 的物体匀速提升 {h} m，绳端拉力为 {F} N，绳子自由端移动 {s} m。求有用功、总功和机械效率。",
        f"W有={G*h} J，W总={F*s} J，η={eta:.1f}%",
        [
            f"W有 = Gh = {G} N × {h} m = {G*h} J",
            f"W总 = Fs = {F} N × {s} m = {F*s} J",
            f"η = W有/W总 = {G*h}/{F*s} × 100% ≈ {eta:.1f}%",
        ],
    )


@_t
def heat():
    m, dt = 2, 50
    Q = 4200 * m * dt
    return (
        f"将 {m} kg 的水从 20℃ 加热到 70℃，求水吸收的热量（c水=4.2×10³ J/(kg·℃)）。",
        f"{Q:.1e} J",
        [f"Δt = 70℃ − 20℃ = {dt}℃", f"Q = cmΔt = 4.2×10³ × {m} × {dt} = {Q:.1e} J"],
    )


@_t
def ohm(v=0):
    U, R = (6, 12) if not v else (9, 18)
    I = U / R
    return (
        f"一段导体两端电压为 {U} V 时，通过它的电流为 {I:.1f} A。求这段导体的电阻；若电压增大到 {2*U} V，电流为多少？",
        f"R = {R} Ω，I′ = {2*I:.1f} A",
        [f"R = U/I = {U} V ÷ {I:.1f} A = {R} Ω", f"电阻不变，I′ = U′/R = {2*U} V ÷ {R} Ω = {2*I:.1f} A"],
    )


@_t
def power_electric():
    U, I = 220, 0.5
    P = U * I
    return (
        f"一只灯泡接在 220 V 的电路中，通过的电流为 {I} A。求它的电功率和 1 h 消耗的电能。",
        f"P = {P:.0f} W，W = 0.11 kW·h",
        [f"P = UI = 220 V × {I} A = {P:.0f} W", f"W = Pt = {P/1000:.2f} kW × 1 h = {P/1000:.2f} kW·h ≈ 0.11 kW·h"],
    )


@_t
def projectile():
    h, v0 = 20, 10
    t = math.sqrt(2 * h / 10)
    x = v0 * t
    return (
        f"小球以 {v0} m/s 的速度水平抛出，抛出点距地面 {h} m，取 g=10 m/s²。求落地时间与水平射程。",
        f"t = {t:.0f} s，x = {x:.0f} m",
        [f"竖直方向自由落体：h = ½gt² → t = √(2h/g) = √(2×{h}/10) = {t:.0f} s", f"水平方向匀速：x = v0t = {v0} × {t:.0f} = {x:.0f} m"],
    )


@_t
def kinematics():
    a, t = 2, 5
    v, x = a * t, 0.5 * a * t * t
    return (
        f"一辆汽车从静止开始以 {a} m/s² 的加速度做匀加速直线运动，求 {t} s 末的速度和 {t} s 内的位移。",
        f"v = {v} m/s，x = {x:.0f} m",
        [f"v = at = {a} × {t} = {v} m/s", f"x = ½at² = 0.5 × {a} × {t}² = {x:.0f} m"],
    )


@_t
def newton_second():
    m, F, f = 2, 10, 2
    a = (F - f) / m
    return (
        f"质量为 {m} kg 的物体放在水平面上，受到 {F} N 的水平拉力，摩擦力为 {f} N。求物体的加速度。",
        f"a = {a:.0f} m/s²",
        [f"合力 F合 = F − f = {F} − {f} = {F-f} N", f"a = F合/m = {F-f} N ÷ {m} kg = {a:.0f} m/s²"],
    )


@_t
def circular():
    r, T = 0.5, 2
    v = 2 * math.pi * r / T
    a = v * v / r
    return (
        f"一个小球在半径为 {r} m 的圆周上做匀速圆周运动，周期为 {T} s。求线速度和向心加速度。",
        f"v ≈ {v:.2f} m/s，a ≈ {a:.1f} m/s²",
        [f"v = 2πr/T = 2π×{r}/{T} ≈ {v:.2f} m/s", f"a = v²/r ≈ {v:.2f}²/{r} ≈ {a:.1f} m/s²"],
    )


@_t
def gravitational():
    R, g = 6.4e6, 10
    v = math.sqrt(g * R)
    return (
        "已知地球半径 R=6.4×10⁶ m，地表重力加速度 g=10 m/s²。求近地卫星的环绕速度（第一宇宙速度）。",
        f"v ≈ {v/1000:.1f} km/s",
        ["近地卫星轨道半径近似等于地球半径", f"v = √(gR) = √(10 × 6.4×10⁶) ≈ {v:.0f} m/s ≈ {v/1000:.1f} km/s"],
    )


@_t
def kinetic_energy():
    m, v = 2, 4
    Ek = 0.5 * m * v * v
    return (
        f"质量为 {m} kg 的物体以 {v} m/s 的速度运动，求它的动能；若速度增大到 8 m/s，动能变为多少？",
        f"Ek = {Ek:.0f} J；速度加倍后 Ek′ = {Ek*4:.0f} J",
        [f"Ek = ½mv² = 0.5 × {m} × {v}² = {Ek:.0f} J", "动能与速度的平方成正比，速度加倍则动能变为 4 倍"],
    )


@_t
def coulomb():
    q1, q2, r = 1e-6, 2e-6, 0.3
    F = 9e9 * q1 * q2 / (r * r)
    return (
        f"真空中两个点电荷 q1=1×10⁻⁶ C、q2=2×10⁻⁶ C，相距 {r} m。求它们之间的库仑力。",
        f"F ≈ {F:.2f} N（引力）",
        [f"F = kq1q2/r² = 9×10⁹ × 1×10⁻⁶ × 2×10⁻⁶ ÷ {r}² ≈ {F:.2f} N", "两电荷电性相反，故为引力"],
    )


@_t
def closed_circuit():
    E, r, R = 6, 1, 5
    I = E / (R + r)
    U = E - I * r
    return (
        f"电源电动势 E={E} V、内阻 r={r} Ω，外接 R={R} Ω 的电阻。求电路中的电流和路端电压。",
        f"I = {I:.0f} A，U = {U:.0f} V",
        [f"I = E/(R+r) = {E}/({R}+{r}) = {I:.0f} A", f"U = E − Ir = {E} − {I:.0f}×{r} = {U:.0f} V"],
    )


@_t
def emf():
    B, L, v = 0.5, 1, 2
    E = B * L * v
    return (
        f"一根长 {L} m 的导体棒在磁感应强度 B={B} T 的匀强磁场中以 {v} m/s 的速度垂直切割磁感线。求感应电动势。",
        f"E = {E:.1f} V",
        [f"E = BLv = {B} × {L} × {v} = {E:.1f} V"],
    )


@_t
def momentum():
    m1, v1, m2, v2 = 2, 3, 1, 0
    v = (m1 * v1 + m2 * v2) / (m1 + m2)
    return (
        f"质量为 {m1} kg 的小球以 {v1} m/s 的速度与静止的、质量为 {m2} kg 的小球发生完全非弹性碰撞。求碰后共同速度。",
        f"v = {v:.0f} m/s",
        [f"动量守恒：m1v1 = (m1+m2)v", f"v = {m1}×{v1} ÷ ({m1}+{m2}) = {v:.0f} m/s"],
    )


@_t
def pendulum():
    L = 1.0
    T = 2 * math.pi * math.sqrt(L / 10)
    return (
        f"一个单摆的摆长为 {L} m，取 g=10 m/s²，求它的周期。",
        f"T ≈ {T:.2f} s",
        [f"T = 2π√(L/g) = 2π√({L}/10) ≈ {T:.2f} s"],
    )


# 知识点 → 例题模板
POINT_TEMPLATE = {
    "p-j8a-03": "speed",
    "p-j8a-11": "density",
    "p-j8a-10": "lens_imaging",
    "p-j8a-09": "lens_imaging",
    "p-j8b-01": "weight",
    "p-j8b-04": "pressure_liquid",
    "p-j8b-05": "buoyancy",
    "p-j8b-06": "work_power",
    "p-j8b-07": "efficiency",
    "p-j9-02": "heat",
    "p-j9-05": "ohm",
    "p-j9-06": "power_electric",
    "p-j8b-02": "newton_second",
    "p-h1-02": "kinematics",
    "p-h1-04": "newton_second",
    "p-h2-01": "projectile",
    "p-h2-02": "circular",
    "p-h2-03": "gravitational",
    "p-h2-04": "kinetic_energy",
    "p-h3-01": "coulomb",
    "p-h3-02": "closed_circuit",
    "p-h3-03": "emf",
    "p-hs1-01": "momentum",
    "p-hs1-02": "pendulum",
    "p-j9-03": "ohm",
    "p-j9-04": "ohm",
}

# 按公式回退匹配
FORMULA_TEMPLATE = [
    ("v = s", "speed"),
    ("ρ = m", "density"),
    ("G = mg", "weight"),
    ("p = ρgh", "pressure_liquid"),
    ("F浮", "buoyancy"),
    ("W = Fs", "work_power"),
    ("η =", "efficiency"),
    ("Q = c", "heat"),
    ("I = U", "ohm"),
    ("P = UI", "power_electric"),
    ("x = v0t", "projectile"),
    ("F合 = ma", "newton_second"),
    ("a = v²/r", "circular"),
    ("F = G m1", "gravitational"),
    ("W合 = ΔEk", "kinetic_energy"),
    ("F = k q1", "coulomb"),
    ("I = E /", "closed_circuit"),
    ("E = BLv", "emf"),
    ("p = mv", "momentum"),
    ("T = 2π", "pendulum"),
]


def build_example(point: dict, variant: int = 0) -> dict | None:
    key = POINT_TEMPLATE.get(point.get("id", ""))
    if not key:
        for frag, tpl in FORMULA_TEMPLATE:
            if any(frag in f for f in point.get("formulas", [])):
                key = tpl
                break
    if not key or key not in TEMPLATES:
        return None
    fn = TEMPLATES[key]
    try:
        stem, answer, steps = fn(variant)
    except TypeError:
        stem, answer, steps = fn()
    return {"stem": stem, "answer": answer, "steps": steps, "template": key, "variant": variant}


def _judge_from_misconception(mis: str, correct: str = "") -> dict:
    m = mis.strip().rstrip("。")
    if m.startswith("认为"):
        m = m[2:]
    stem = f"判断正误：{m}。"
    explain = f"这是典型误区。正确理解：{correct}" if correct else "请结合本课核心概念与成立条件辨析。"
    return {
        "type": "judge",
        "stem": stem,
        "options": ["正确", "错误"],
        "answer": "错误",
        "explain": explain,
    }


def build_quiz(point: dict, n: int = 3) -> list[dict]:
    qs: list[dict] = []
    ex = build_example(point, 1)
    if ex:
        qs.append(
            {
                "type": "calc",
                "stem": ex["stem"],
                "options": [],
                "answer": ex["answer"],
                "explain": "；".join(ex["steps"]),
            }
        )
    for mis in point.get("misconceptions", [])[: max(0, n - len(qs))]:
        qs.append(_judge_from_misconception(mis, (point.get("core") or [""])[0]))
    # 概念辨析：把核心结论改写成判断
    if len(qs) < n:
        for core in point.get("core", [])[: n - len(qs)]:
            qs.append(
                {
                    "type": "short",
                    "stem": f"简答：结合本课所学，说明“{core}”的物理依据。",
                    "options": [],
                    "answer": core,
                    "explain": "回答应包含概念、条件与结论三部分。",
                }
            )
    return qs[:n]


JUDGE_CACHE: dict[str, list[dict]] = {}


def quiz_for_deck(point: dict) -> list[dict]:
    pid = point.get("id", "")
    if pid not in JUDGE_CACHE:
        JUDGE_CACHE[pid] = build_quiz(point, 3)
    return JUDGE_CACHE[pid]