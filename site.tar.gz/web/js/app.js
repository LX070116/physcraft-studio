/* 应用外壳：路由、导航、状态 */
window.PS = window.PS || {};
PS.state = { kb: null, tree: null, library: { decks: [], lessons: [] }, title: "工作台" };
PS.views = PS.views || {};

(function () {
  const view = document.getElementById("view");
  const inner = document.getElementById("view-inner");

  function parse() {
    const raw = (location.hash || "#/home").replace(/^#\/?/, "");
    const [path, query] = raw.split("?");
    const parts = path.split("/").filter(Boolean);
    const params = {};
    (query || "").split("&").forEach((kv) => {
      if (!kv) return;
      const [k, v] = kv.split("=");
      params[decodeURIComponent(k)] = decodeURIComponent(v || "");
    });
    return { name: parts[0] || "home", arg: parts[1] || "", params };
  }

  function setNav(name) {
    document.querySelectorAll("[data-nav]").forEach((a) => a.classList.toggle("active", a.dataset.nav === name));
    const crumb = document.getElementById("crumb");
    const labels = { home: "工作台", kb: "教材知识库", labs: "实验库", textbook: "电子教材", questions: "题库", lesson: "教案工坊", deck: "课件工坊", library: "我的课堂", about: "架构与说明", play: "课堂" };
    crumb.innerHTML = `<b>${labels[name] || "工作台"}</b>`;
  }

  async function loadKb() {
    if (PS.state.tree) return;
    try {
      const data = await PS.api.get("/api/kb");
      PS.state.tree = data.tree;
      PS.state.kb = data;
      const n = data.stats.points;
      document.getElementById("nav-kb-count").textContent = n;
      document.getElementById("pill-kb").textContent = `知识库 · ${n} 个知识点 / ${data.stats.chapters} 章`;
    } catch (e) {
      PS.ui.toast("知识库加载失败：" + e.message, "err");
    }
  }

  async function loadLibrary() {
    try {
      const data = await PS.api.get("/api/library");
      PS.state.library = data;
    } catch (e) {
      /* 忽略 */
    }
  }

  async function route() {
    const r = parse();
    const name = r.name === "play" ? "play" : PS.views[r.name] ? r.name : "home";
    setNav(name);

    if (name === "play") {
      openPlay(r.arg, r.params);
      return;
    }
    closePlay();

    if (name === "home" || name === "library") await loadLibrary();
    const v = PS.views[name];
    document.title = `${v.title || "悟理智课"} · 悟理智课`;
    inner.innerHTML = `<div class="view-inner">${v.render(r)}</div>`;
    if (v.after) {
      try {
        await v.after(r);
      } catch (e) {
        console.error(e);
        PS.ui.toast(e.message || "页面加载失败", "err");
      }
    }
    view.scrollTop = 0;
  }

  /* ---------- 课堂全屏 ---------- */
  let playHandle = null;
  function closePlay() {
    const el = document.getElementById("play-root");
    if (el) el.remove();
    const app = document.getElementById("app");
    if (app) app.style.display = "";
    if (playHandle && playHandle.destroy) {
      try { playHandle.destroy(); } catch (e) {}
    }
    playHandle = null;
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
  }
  async function openPlay(id, params) {
    if (!id) { location.hash = "#/library"; return; }
    document.getElementById("app").style.display = "none";
    const root = document.createElement("div");
    root.id = "play-root";
    root.style.cssText = "position:fixed;inset:0;z-index:50;background:#05090f";
    document.body.appendChild(root);
    root.innerHTML = PS.ui.spinner("正在载入课堂…");
    try {
      const deck = await PS.api.get(`/api/deck/${id}`);
      root.innerHTML = "";
      playHandle = PSPlayer.mount(root, deck, {
        startIndex: +(params.s || 0),
        onExit: () => { location.hash = "#/library"; },
      });
      root.focus();
    } catch (e) {
      root.innerHTML = `<div class="empty" style="padding-top:18vh">${PS.ui.icon("warn")}<div>${PS.ui.esc(e.message)}</div><button class="btn btn-sm" style="margin-top:14px" onclick="location.hash='#/library'">返回</button></div>`;
    }
  }

  window.addEventListener("hashchange", route);
  window.addEventListener("DOMContentLoaded", async () => {
    await loadKb();
    await loadLibrary();
    route();
  });

  PS.app = { route, loadKb, loadLibrary, openPlay, closePlay, go: (h) => (location.hash = h) };
})();