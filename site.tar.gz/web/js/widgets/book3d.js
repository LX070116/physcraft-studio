/*!
 * 悟理智课 · 控件 book3d —— 立体课本（CSS 3D 翻页）
 * 零依赖：透视容器 + 双面页 + 点击/拖拽/键盘翻页
 * 注册：PSWidgets["book3d"] = { title, defaults, mount(root, params, ctx) }
 */
(function (global) {
  "use strict";

  var doc = global.document;
  if (!doc) { return; }

  var STYLE_KEY = "book3d";
  var SEQ = 0;

  var DEFAULTS = { book: null };

  var DEMO = {
    title: "声现象",
    subtitle: "人教版八年级上册 · 第二章",
    pages: [
      { title: "声音的世界", blocks: [
        { type: "p", text: "我们生活在声音的海洋里：上课的铃声、窗外的鸟鸣、老师讲课的声音，都是声现象。" },
        { type: "note", text: "本章从声的产生、传播、特性，一直讲到噪声控制与声的利用。" },
        { type: "list", items: ["声的产生与传播", "声音的特性", "噪声的危害与控制", "声的利用"] }
      ] },
      { title: "声音的产生", blocks: [
        { type: "p", text: "拨动张紧的橡皮筋，橡皮筋来回振动，同时发出嗡嗡声；用手按住，振动停止，声音也停止。" },
        { type: "formula", text: "声源 = 正在振动的物体" },
        { type: "note", text: "一切发声的物体都在振动，振动停止，发声也停止。" }
      ] },
      { title: "声音的传播", blocks: [
        { type: "p", text: "把正在响铃的闹钟放入玻璃罩，逐渐抽出罩内空气，铃声越来越小，说明声的传播需要介质。" },
        { type: "list", items: ["固体能传声", "液体能传声", "气体能传声", "真空不能传声"] },
        { type: "note", text: "声音以声波的形式向四周传播，介质是传播声的必要条件。" }
      ] },
      { title: "声速", blocks: [
        { type: "p", text: "声每秒传播的距离叫声速，它跟介质的种类和温度有关。15 ℃ 的空气中声速约为 340 m/s。" },
        { type: "formula", text: "v = s / t" },
        { type: "list", items: ["空气（15 ℃）：340 m/s", "水：约 1500 m/s", "钢：约 5200 m/s"] }
      ] },
      { title: "回声", blocks: [
        { type: "p", text: "声波遇到障碍物会反射回来，反射回来的声叫回声。人耳要区分回声与原声，时间间隔需大于 0.1 s。" },
        { type: "formula", text: "s = v·t / 2" },
        { type: "note", text: "测距时，t 是声往返的总时间，所以路程要除以 2。" }
      ] },
      { title: "音调", blocks: [
        { type: "p", text: "音调指声音的高低，由发声体振动的频率决定。频率越高，音调越高。" },
        { type: "formula", text: "f = 1 / T   （T 为周期）" },
        { type: "list", items: ["人耳听觉范围：20 Hz ~ 20000 Hz", "高于 20000 Hz：超声波", "低于 20 Hz：次声波"] }
      ] },
      { title: "响度", blocks: [
        { type: "p", text: "响度指声音的强弱，与发声体的振幅有关，还与距声源的远近、声音的分散程度有关。" },
        { type: "list", items: ["振幅越大，响度越大", "距声源越远，响度越小", "减少分散可增大响度"] },
        { type: "note", text: "用不同力度敲鼓，鼓面振幅不同，听到的响度也不同。" }
      ] },
      { title: "音色", blocks: [
        { type: "p", text: "音色反映声音的品质与特色，由发声体的材料和结构决定。不同乐器演奏同一音符，音调相同而音色不同。" },
        { type: "formula", text: "音色 ≈ 波形特征" },
        { type: "note", text: "“闻其声知其人”，靠的就是音色。" }
      ] },
      { title: "噪声的危害", blocks: [
        { type: "p", text: "从环保角度看，凡是妨碍人们正常休息、学习和工作的声音，以及对人们要听的声音起干扰作用的声音，都属于噪声。" },
        { type: "list", items: ["30 ~ 40 dB：较为理想的安静环境", "70 dB 以上：干扰谈话、影响学习", "150 dB：鼓膜破裂、失去听力"] },
        { type: "note", text: "噪声监测装置显示的是分贝值，单位是 dB。" }
      ] },
      { title: "噪声的控制", blocks: [
        { type: "p", text: "控制噪声可以从三个环节入手，这也是本章最重要的方法归纳。" },
        { type: "list", items: ["在声源处减弱：消声器、禁止鸣笛", "在传播过程中减弱：隔声墙、植树", "在人耳处减弱：耳罩、耳塞"] },
        { type: "formula", text: "声源 → 介质 → 人耳" }
      ] },
      { title: "声的利用", blocks: [
        { type: "p", text: "声既能传递信息，也能传递能量。", },
        { type: "list", items: ["传递信息：B 超、声呐、回声定位", "传递能量：超声波清洗、碎石"] },
        { type: "note", text: "蝙蝠靠超声波回声定位，科学家据此发明了声呐。" }
      ] },
      { title: "本章小结", blocks: [
        { type: "p", text: "声现象的主线：产生 → 传播 → 特性 → 控制 → 利用。" },
        { type: "list", items: ["振动产生声，介质传播声", "音调由频率决定，响度由振幅决定", "音色由材料与结构决定", "噪声三环节控制"] },
        { type: "note", text: "课后练习：教材 P38 第 2、4、5 题。" }
      ] }
    ]
  };

  var CSS = [
    '.psw-b3{position:absolute;inset:0;display:flex;flex-direction:column;overflow:hidden;',
    'background:radial-gradient(120% 100% at 50% 0%,#131d33 0%,#0b1220 60%,#080d17 100%);',
    'font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif;color:#e2e8f0;user-select:none;-webkit-user-select:none}',
    '.psw-b3 *{box-sizing:border-box}',
    '.psw-b3-head{flex:0 0 auto;display:flex;align-items:baseline;gap:10px;padding:9px 16px 7px;min-height:34px;',
    'border-bottom:1px solid rgba(148,163,184,.13);background:linear-gradient(180deg,rgba(15,23,42,.72),rgba(11,18,32,0))}',
    '.psw-b3-ht{font-size:14px;font-weight:600;letter-spacing:.04em;color:#eaf1fb;white-space:nowrap}',
    '.psw-b3-hs{font-size:11.5px;color:#94a3b8;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.psw-b3-hint{margin-left:auto;font-size:11px;color:#64748b;white-space:nowrap}',
    '.psw-b3-stage{flex:1 1 auto;min-height:0;display:flex;align-items:center;justify-content:center;',
    'perspective:1600px;perspective-origin:50% 50%;padding:6px 10px;cursor:grab;touch-action:pan-y}',
    '.psw-b3-stage.is-drag{cursor:grabbing}',
    '.psw-b3-stage.is-drag .psw-b3-book{filter:brightness(1.04)}',
    '.psw-b3-book{position:relative;transform-style:preserve-3d;aspect-ratio:1.52 / 1;flex:0 0 auto;transition:transform .28s ease}',
    '.psw-b3-fig{margin:4px 0 6px;border-radius:6px;overflow:hidden;border:1px solid rgba(120,100,70,.28);box-shadow:0 2px 6px rgba(80,60,40,.12)}',
    '.psw-b3-fig img{display:block;width:100%;height:auto}',
    '.psw-b3-prog{position:absolute;left:0;right:0;bottom:-9px;height:3px;border-radius:2px;background:rgba(255,255,255,.10);overflow:hidden}',
    '.psw-b3-prog i{display:block;height:100%;width:0;background:var(--b3-acc,#38bdf8);transition:width .45s cubic-bezier(.22,.61,.36,1)}',
    '.psw-b3-stack{position:absolute;inset:0;border-radius:3px;z-index:1;transform:translate(5px,6px);',
    'background:repeating-linear-gradient(180deg,#efe6d2 0 2px,#e2d7bd 2px 3px);box-shadow:0 22px 48px rgba(0,0,0,.55)}',
    '.psw-b3-base,.psw-b3-endcover{position:absolute;top:0;width:50%;height:100%;z-index:2;overflow:hidden;',
    'background:linear-gradient(145deg,var(--b3-acc,#38bdf8) 0%,#16243f 52%,#0b1526 100%)}',
    '.psw-b3-base{left:0;border-radius:10px 2px 2px 10px;box-shadow:inset -16px 0 26px -18px rgba(0,0,0,.9);',
    'transform-origin:right center;backface-visibility:hidden}',
    '.psw-b3-base.is-opening{animation:psw-b3-open .62s cubic-bezier(.22,.61,.36,1)}',
    '@keyframes psw-b3-open{0%{transform:rotateY(0deg);filter:brightness(1)}42%{transform:rotateY(15deg);filter:brightness(1.12)}100%{transform:rotateY(0deg);filter:brightness(1)}}',
    '.psw-b3-endcover{right:0;border-radius:2px 10px 10px 2px;background:linear-gradient(215deg,#1a2a44,#0c1524);',
    'box-shadow:inset 16px 0 26px -18px rgba(0,0,0,.9)}',
    '.psw-b3-cover-in{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:center;align-items:center;',
    'gap:2.2%;padding:12% 12%;text-align:center}',
    '.psw-b3-mark{font-size:calc(var(--b3-s,1) * 9px);letter-spacing:.42em;color:rgba(246,227,176,.72);text-transform:uppercase}',
    '.psw-b3-rule{width:38%;height:1px;background:linear-gradient(90deg,transparent,rgba(246,227,176,.75),transparent)}',
    '.psw-b3-ctitle{font-family:"Microsoft YaHei",sans-serif;font-weight:700;line-height:1.25;letter-spacing:.1em;',
    'font-size:calc(var(--b3-s,1) * 26px);background:linear-gradient(100deg,#c9a45c,#f8e7b6 42%,#d8b978 72%,#f4dfa8);',
    '-webkit-background-clip:text;background-clip:text;color:transparent;text-shadow:0 1px 0 rgba(0,0,0,.12)}',
    '.psw-b3-csub{font-family:"Source Han Serif SC","SimSun",serif;font-size:calc(var(--b3-s,1) * 10.5px);color:rgba(226,232,240,.72);letter-spacing:.06em}',
    '.psw-b3-emblem{width:22%;max-width:74px;opacity:.85;margin-top:2%}',
    '.psw-b3-cfoot{font-size:calc(var(--b3-s,1) * 9px);color:rgba(148,163,184,.78);letter-spacing:.28em}',
    '.psw-b3-leaf{position:absolute;top:0;right:0;width:50%;height:100%;transform-origin:left center;',
    'transform-style:preserve-3d;transition:transform .65s cubic-bezier(.22,.61,.36,1);will-change:transform}',
    '.psw-b3-leaf.is-flip{transform:rotateY(-180deg)}',
    '.psw-b3-face{position:absolute;inset:0;overflow:hidden;backface-visibility:hidden;-webkit-backface-visibility:hidden;',
    'background:linear-gradient(178deg,#fcf8ee 0%,#f7f0df 58%,#f1e8d4 100%);box-shadow:0 10px 26px rgba(0,0,0,.28)}',
    '.psw-b3-face--front{border-radius:2px 10px 10px 2px;box-shadow:inset 18px 0 24px -20px rgba(72,48,20,.75),0 12px 26px rgba(0,0,0,.3)}',
    '.psw-b3-face--back{transform:rotateY(180deg);border-radius:10px 2px 2px 10px;',
    'box-shadow:inset -18px 0 24px -20px rgba(72,48,20,.75),0 12px 26px rgba(0,0,0,.3)}',
    '.psw-b3-face::after{content:"";position:absolute;inset:0;pointer-events:none;border-radius:inherit;',
    'background:linear-gradient(180deg,rgba(255,255,255,.5),rgba(255,255,255,0) 22%,rgba(110,80,40,.05) 100%)}',
    '.psw-b3-pg{position:absolute;inset:0;padding:7% 8% 8.5%;display:flex;flex-direction:column;gap:calc(var(--b3-s,1) * 5px);',
    'overflow:hidden;color:#2a2a2c;font-family:"Source Han Serif SC","SimSun",serif;',
    'font-size:calc(var(--b3-s,1) * 12.2px);line-height:1.64}',
    '.psw-b3-ptitle{font-family:"Microsoft YaHei","PingFang SC",sans-serif;font-weight:700;color:#1d2b3a;',
    'font-size:calc(var(--b3-s,1) * 14.5px);line-height:1.32;padding-bottom:calc(var(--b3-s,1) * 3px);',
    'border-bottom:1px solid rgba(56,189,248,.28);letter-spacing:.02em}',
    '.psw-b3-p{margin:0}',
    '.psw-b3-formula{margin:0;padding:calc(var(--b3-s,1) * 4px) calc(var(--b3-s,1) * 5px);text-align:center;',
    'font-family:"Cascadia Mono",Consolas,"SFMono-Regular",monospace;font-size:calc(var(--b3-s,1) * 11px);',
    'line-height:1.45;color:#1b3550;background:linear-gradient(180deg,rgba(56,189,248,.13),rgba(56,189,248,.06));',
    'border-radius:5px;border:1px solid rgba(56,189,248,.22)}',
    '.psw-b3-list{margin:0;padding-left:0;list-style:none;display:flex;flex-direction:column;gap:calc(var(--b3-s,1) * 1.5px)}',
    '.psw-b3-list li{position:relative;padding-left:calc(var(--b3-s,1) * 12px)}',
    '.psw-b3-list li::before{content:"";position:absolute;left:2px;top:.66em;width:5px;height:5px;border-radius:1px;',
    'background:var(--b3-acc,#38bdf8);opacity:.85;transform:rotate(45deg)}',
    '.psw-b3-note{margin:0;padding:calc(var(--b3-s,1) * 4px) calc(var(--b3-s,1) * 7px);border-left:3px solid var(--b3-acc,#38bdf8);',
    'background:linear-gradient(90deg,rgba(56,189,248,.1),rgba(56,189,248,0));border-radius:0 5px 5px 0;color:#25415c}',
    '.psw-b3-pnum{position:absolute;bottom:4.5%;font-size:calc(var(--b3-s,1) * 9.5px);color:#8a7b63;letter-spacing:.08em;font-family:Consolas,monospace}',
    '.psw-b3-pg--front .psw-b3-pnum{right:9%}',
    '.psw-b3-pg--back .psw-b3-pnum{left:9%}',
    '.psw-b3-spine{position:absolute;left:50%;top:0;bottom:0;width:26px;margin-left:-13px;z-index:260;pointer-events:none;',
    'background:linear-gradient(90deg,rgba(60,40,16,0) 0%,rgba(60,40,16,.22) 42%,rgba(40,26,10,.42) 50%,rgba(60,40,16,.22) 58%,rgba(60,40,16,0) 100%)}',
    '.psw-b3-foot{flex:0 0 auto;display:flex;align-items:center;justify-content:center;gap:14px;padding:4px 12px 9px}',
    '.psw-b3-arrow{width:30px;height:30px;border-radius:9px;border:1px solid rgba(148,163,184,.24);background:rgba(18,28,47,.86);',
    'color:#cbd5e1;font:inherit;font-size:16px;line-height:1;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;',
    'transition:background .15s,border-color .15s,color .15s}',
    '.psw-b3-arrow:hover:not(:disabled){background:rgba(30,45,72,.96);border-color:var(--b3-acc,#38bdf8);color:#f0f9ff}',
    '.psw-b3-arrow:focus-visible{outline:2px solid var(--b3-acc,#38bdf8);outline-offset:2px}',
    '.psw-b3-arrow:disabled{opacity:.35;cursor:default}',
    '.psw-b3-num{font-family:Consolas,monospace;font-size:12.5px;color:#94a3b8;letter-spacing:.06em;min-width:64px;text-align:center}',
    '.psw-b3.is-sm .psw-b3-head{padding:6px 10px 5px;min-height:28px}',
    '.psw-b3.is-sm .psw-b3-ht{font-size:12.5px}',
    '.psw-b3.is-sm .psw-b3-hs,.psw-b3.is-sm .psw-b3-hint{display:none}',
    '.psw-b3.is-sm .psw-b3-foot{padding:2px 8px 6px;gap:8px}',
    '.psw-b3.is-sm .psw-b3-arrow{width:26px;height:26px;font-size:14px}',
    '.psw-b3.is-sm .psw-b3-num{font-size:11.5px;min-width:54px}'
  ].join("");

  /* ---------------- 工具 ---------------- */

  function esc(s) {
    return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }

  function injectStyle() {
    if (doc.querySelector('style[data-psw-style="' + STYLE_KEY + '"]')) { return; }
    var el = doc.createElement("style");
    el.setAttribute("data-psw-style", STYLE_KEY);
    el.appendChild(doc.createTextNode(CSS));
    (doc.head || doc.documentElement).appendChild(el);
  }

  function normalizeBook(src) {
    if (!src || !Array.isArray(src.pages) || !src.pages.length) { return DEMO; }
    var pages = [];
    for (var i = 0; i < src.pages.length; i++) {
      var pg = src.pages[i] || {};
      pages.push({
        title: pg.title != null ? String(pg.title) : "第 " + (i + 1) + " 页",
        blocks: Array.isArray(pg.blocks) ? pg.blocks : []
      });
    }
    return {
      title: src.title != null ? String(src.title) : "物理课本",
      subtitle: src.subtitle != null ? String(src.subtitle) : "",
      pages: pages
    };
  }

  function blocksHtml(blocks) {
    var out = [];
    for (var i = 0; i < blocks.length; i++) {
      var b = blocks[i] || {};
      var type = b.type || "p";
      if (type === "image" && b.src) {
        out.push('<div class="psw-b3-fig"><img src="' + esc(b.src) + '" alt="' + esc(b.alt || "") + '"></div>');
      } else if (type === "formula") {
        out.push('<div class="psw-b3-formula">' + esc(b.text) + "</div>");
      } else if (type === "list") {
        var items = Array.isArray(b.items) ? b.items : (b.text ? [b.text] : []);
        var lis = [];
        for (var j = 0; j < items.length; j++) { lis.push("<li>" + esc(items[j]) + "</li>"); }
        out.push('<ul class="psw-b3-list">' + lis.join("") + "</ul>");
      } else if (type === "note") {
        out.push('<div class="psw-b3-note">' + esc(b.text) + "</div>");
      } else {
        out.push('<p class="psw-b3-p">' + esc(b.text) + "</p>");
      }
    }
    return out.join("");
  }

  function pageHtml(page, num, side) {
    if (!page) { return ""; }
    return '<div class="psw-b3-pg psw-b3-pg--' + side + '">' +
      '<div class="psw-b3-ptitle">' + esc(page.title) + "</div>" +
      blocksHtml(page.blocks) +
      '<span class="psw-b3-pnum">' + num + "</span>" +
      "</div>";
  }

  function atomSvg(uid) {
    return '<svg viewBox="0 0 100 100" class="psw-b3-emblem" aria-hidden="true">' +
      '<g fill="none" stroke="#f0d59a" stroke-width="1.6" opacity=".9">' +
      '<ellipse cx="50" cy="50" rx="40" ry="15"/>' +
      '<ellipse cx="50" cy="50" rx="40" ry="15" transform="rotate(60 50 50)"/>' +
      '<ellipse cx="50" cy="50" rx="40" ry="15" transform="rotate(120 50 50)"/>' +
      "</g>" +
      '<circle cx="50" cy="50" r="5" fill="#f0d59a"/>' +
      '<circle cx="90" cy="50" r="2.6" fill="#f0d59a"/></svg>';
  }

  /* ---------------- 控件 ---------------- */

  function mount(root, params, ctx) {
    if (!root) { throw new Error("book3d.mount: root 不能为空"); }
    injectStyle();

    var p = { book: null };
    if (params) { p.book = params.book !== undefined ? params.book : null; }

    var theme = (ctx && ctx.theme) || {};
    var accent = theme.accent || "#38bdf8";
    var uid = "pswb3" + (++SEQ);

    var host = doc.createElement("div");
    host.className = "psw-b3";
    host.style.setProperty("--b3-acc", accent);
    root.appendChild(host);

    var st = {
      book: null,
      leaves: [],
      spread: 0,
      total: 0,
      raf: 0,
      settleTimer: 0,
      coverTimer: 0,
      armedAt: 0,
      drag: null,
      suppressClick: false,
      hover: false
    };

    var refs = {};

    function build() {
      var b = normalizeBook(p.book);
      st.book = b;
      var pages = b.pages;
      st.total = pages.length;
      var leaves = [];
      for (var i = 0; i < pages.length; i += 2) {
        leaves.push({ front: pages[i], back: pages[i + 1] || null, fi: i, bi: i + 1 });
      }
      st.leaves = leaves;
      st.spread = 0;
      render(b, leaves);
    }

    function render(b, leaves) {
      unbind();
      var cover = '' +
        '<div class="psw-b3-stack"></div>' +
        '<div class="psw-b3-base">' +
          '<div class="psw-b3-cover-in">' +
            '<div class="psw-b3-mark">悟理智课</div>' +
            '<div class="psw-b3-rule"></div>' +
            '<div class="psw-b3-ctitle">' + esc(b.title) + "</div>" +
            '<div class="psw-b3-csub">' + esc(b.subtitle || "物理 · 八年级") + "</div>" +
            atomSvg(uid) +
            '<div class="psw-b3-cfoot">物理</div>' +
          "</div>" +
        "</div>" +
        '<div class="psw-b3-endcover"></div>';

      var leafHtml = [];
      for (var i = 0; i < leaves.length; i++) {
        var lf = leaves[i];
        leafHtml.push(
          '<div class="psw-b3-leaf" data-leaf="' + i + '">' +
            '<div class="psw-b3-face psw-b3-face--front">' + pageHtml(lf.front, lf.fi + 1, "front") + "</div>" +
            '<div class="psw-b3-face psw-b3-face--back">' + pageHtml(lf.back, lf.bi + 1, "back") + "</div>" +
          "</div>");
      }

      host.innerHTML =
        '<div class="psw-b3-head">' +
          '<span class="psw-b3-ht">' + esc(b.title) + "</span>" +
          '<span class="psw-b3-hs">' + esc(b.subtitle || "") + "</span>" +
          '<span class="psw-b3-hint">点击 / 拖拽 / ← → 翻页</span>' +
        "</div>" +
        '<div class="psw-b3-stage">' +
          '<div class="psw-b3-book" tabindex="0" role="group" aria-label="立体课本：' + esc(b.title) + '">' +
          '<div class="psw-b3-prog"><i></i></div>' +
            cover + leafHtml.join("") +
            '<div class="psw-b3-spine"></div>' +
          "</div>" +
        "</div>" +
        '<div class="psw-b3-foot">' +
          '<button type="button" class="psw-b3-arrow" data-dir="-1" aria-label="上一页">‹</button>' +
          '<span class="psw-b3-num" aria-live="polite">1 / ' + st.total + "</span>" +
          '<button type="button" class="psw-b3-arrow" data-dir="1" aria-label="下一页">›</button>' +
        "</div>";

      refs.host = host;
      refs.stage = host.querySelector(".psw-b3-stage");
      refs.book = host.querySelector(".psw-b3-book");
      refs.cover = host.querySelector(".psw-b3-base");
      refs.num = host.querySelector(".psw-b3-num");
      refs.prev = host.querySelector('.psw-b3-arrow[data-dir="-1"]');
      refs.next = host.querySelector('.psw-b3-arrow[data-dir="1"]');
      refs.leaves = Array.prototype.slice.call(host.querySelectorAll(".psw-b3-leaf"));
      refs.prog = host.querySelector(".psw-b3-prog i");

      bind();
      applySpread(0, true);
      layout();
      st.armedAt = Date.now() + 260;   /* 挂载瞬间的偶发事件不翻页 */
    }

    function bind() {
      refs.stage.addEventListener("pointerdown", onDown);
      refs.stage.addEventListener("pointermove", onMove);
      refs.stage.addEventListener("pointerup", onUp);
      refs.stage.addEventListener("pointercancel", onCancel);
      refs.book.addEventListener("keydown", onKey);
      refs.stage.addEventListener("pointermove", onTilt);
      refs.stage.addEventListener("pointerleave", onTiltReset);
      refs.prev.addEventListener("click", onPrev);
      refs.next.addEventListener("click", onNext);
      doc.addEventListener("keydown", onDocKey, false);
    }

    function onTilt(e) {
      if (e.buttons) { return; }
      var r = refs.book.getBoundingClientRect();
      if (!r.width) { return; }
      var dx = (e.clientX - (r.left + r.width / 2)) / r.width;
      var dy = (e.clientY - (r.top + r.height / 2)) / r.height;
      refs.book.style.transform = "rotateX(" + (-dy * 4).toFixed(2) + "deg) rotateY(" + (dx * 5).toFixed(2) + "deg)";
    }
    function onTiltReset() {
      refs.book.style.transform = "";
    }

    function unbind() {
      if (!refs.stage) { return; }
      refs.stage.removeEventListener("pointerdown", onDown);
      refs.stage.removeEventListener("pointermove", onMove);
      refs.stage.removeEventListener("pointerup", onUp);
      refs.stage.removeEventListener("pointercancel", onCancel);
      refs.book.removeEventListener("keydown", onKey);
      refs.stage.removeEventListener("pointermove", onTilt);
      refs.stage.removeEventListener("pointerleave", onTiltReset);
      refs.prev.removeEventListener("click", onPrev);
      refs.next.removeEventListener("click", onNext);
      doc.removeEventListener("keydown", onDocKey, false);
    }

    /* ---------- 页面状态 ---------- */
    function applySpread(s, instant) {
      var max = st.leaves.length;
      st.spread = clamp(s, 0, max);
      for (var i = 0; i < refs.leaves.length; i++) {
        var el = refs.leaves[i];
        var flipped = i < st.spread;
        el.classList.toggle("is-flip", flipped);
        if (instant) { el.style.transition = "none"; }
      }
      if (instant) {
        /* 强制回流后恢复过渡，避免首屏动画 */
        void host.offsetWidth;
        for (var j = 0; j < refs.leaves.length; j++) { refs.leaves[j].style.transition = ""; }
      }
      zOrder();
      updateChrome();
    }

    function zOrder() {
      for (var i = 0; i < refs.leaves.length; i++) {
        var el = refs.leaves[i];
        if (i < st.spread) { el.style.zIndex = String(120 + i); }
        else { el.style.zIndex = String(100 + (refs.leaves.length - i)); }
      }
    }

    function updateChrome() {
      var s = st.spread;
      var max = st.leaves.length;
      var cur = s < max ? (2 * s + 1) : st.total;
      cur = clamp(cur, 1, st.total);
      if (refs.num) { refs.num.textContent = cur + " / " + st.total; }
      if (refs.prev) { refs.prev.disabled = s <= 0; }
      if (refs.next) { refs.next.disabled = s >= max; }
      if (refs.prog) { refs.prog.style.width = Math.round((s / max) * 100) + "%"; }
    }

    function go(delta) {
      var s = st.spread + delta;
      if (s < 0 || s > st.leaves.length) { return; }
      var moving = delta > 0 ? s - 1 : s;
      applySpread(s, false);
      var el = refs.leaves[moving];
      if (el) {
        el.style.zIndex = "300";
        if (st.settleTimer) { global.clearTimeout(st.settleTimer); }
        st.settleTimer = global.setTimeout(function () {
          st.settleTimer = 0;
          zOrder();
        }, 720);
      }
      updateChrome();
    }

    function armed() { return Date.now() >= st.armedAt; }

    function coverNudge() {
      var base = refs.cover;
      if (!base) { return; }
      base.classList.remove("is-opening");
      void base.offsetWidth;
      base.classList.add("is-opening");
      if (st.coverTimer) { global.clearTimeout(st.coverTimer); }
      st.coverTimer = global.setTimeout(function () {
        st.coverTimer = 0;
        base.classList.remove("is-opening");
      }, 660);
    }

    function next() { go(1); }
    function prev() { go(-1); }

    function onPrev(e) {
      if (e) { e.stopPropagation(); }
      if (!armed()) { return; }
      if (st.spread <= 0) { coverNudge(); return; }
      prev();
    }

    function onNext(e) {
      if (e) { e.stopPropagation(); }
      if (!armed()) { return; }
      next();
    }

    function onKey(e) {
      if (!armed()) { return; }
      var k = e.key || "";
      if (k === "ArrowRight" || k === "ArrowDown" || k === "PageDown") { e.preventDefault(); next(); }
      else if (k === "ArrowLeft" || k === "ArrowUp" || k === "PageUp") {
        e.preventDefault();
        if (st.spread <= 0) { coverNudge(); } else { prev(); }
      }
    }

    function onDocKey(e) {
      if (!st.hover || !armed()) { return; }
      var t = e.target;
      if (t && /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) { return; }
      var k = e.key || "";
      if (k === "ArrowRight" || k === "ArrowLeft") { e.preventDefault(); onKey(e); }
    }

    /* ---------- 指针：点击 + 拖拽 ---------- */
    function onDown(e) {
      if (e.button != null && e.button !== 0) { return; }
      st.drag = { x: e.clientX, y: e.clientY, dx: 0, id: e.pointerId, moved: false };
      st.suppressClick = false;
      try { refs.stage.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      refs.stage.classList.add("is-drag");
    }

    function onMove(e) {
      if (!st.drag || e.pointerId !== st.drag.id) { return; }
      st.drag.dx = e.clientX - st.drag.x;
      if (Math.abs(st.drag.dx) > 10) { st.drag.moved = true; }
    }

    function onUp(e) {
      if (!st.drag || e.pointerId !== st.drag.id) { return; }
      var dx = e.clientX - st.drag.x;
      var moved = st.drag.moved;
      st.drag = null;
      refs.stage.classList.remove("is-drag");
      try { refs.stage.releasePointerCapture(e.pointerId); } catch (err) { /* ignore */ }

      if (Math.abs(dx) > 60) {
        st.suppressClick = true;
        if (!armed()) { return; }
        if (dx < 0) { next(); } else if (st.spread <= 0) { coverNudge(); } else { prev(); }
        global.setTimeout(function () { st.suppressClick = false; }, 80);
        return;
      }
      if (moved || !armed()) { return; }
      /* 点击：以书脊中线区分左右 */
      var box = refs.book.getBoundingClientRect();
      if (e.clientX >= box.left + box.width / 2) { next(); }
      else if (st.spread <= 0) { coverNudge(); }     /* 封面：翻开动作，不跳过第 1 页 */
      else { prev(); }
    }

    function onCancel() {
      st.drag = null;
      refs.stage.classList.remove("is-drag");
    }

    /* ---------- 尺寸 ---------- */
    function layout() {
      if (!refs.stage) { return; }
      var sw = refs.stage.clientWidth;
      var sh = refs.stage.clientHeight;
      if (!sw || !sh) { return; }
      var ratio = 1.45;
      var maxW = Math.max(140, sw - 14);
      var maxH = Math.max(120, sh - 6);
      var fitH = Math.min(maxH, maxW / ratio);
      var bh = Math.max(260, fitH);          /* 书页最小高度 260px */
      if (bh > maxH) { bh = fitH; }          /* 容器太矮时优先保持 1.45:1，避免变形 */
      var bw = bh * ratio;
      if (bw > maxW) { bw = maxW; bh = bw / ratio; }
      refs.book.style.width = Math.round(bw) + "px";
      refs.book.style.height = Math.round(bh) + "px";
      host.style.setProperty("--b3-s", clamp(bh / 320, 0.62, 1.35).toFixed(3));
      host.classList.toggle("is-sm", sh < 250 || sw < 360);
    }

    var ro = null;
    if (typeof global.ResizeObserver === "function") {
      ro = new global.ResizeObserver(function () { layout(); });
      try { ro.observe(root); } catch (e) { ro = null; }
    }
    var onWinResize = function () { layout(); };
    global.addEventListener("resize", onWinResize);

    var onEnter = function () { st.hover = true; };
    var onLeave = function () { st.hover = false; };
    host.addEventListener("pointerenter", onEnter);
    host.addEventListener("pointerleave", onLeave);

    build();
    global.setTimeout(layout, 0);

    function setParams(nextP) {
      if (!nextP) { return; }
      if (nextP.book !== undefined) { p.book = nextP.book; }
      build();
    }

    function destroy() {
      unbind();
      if (st.settleTimer) { global.clearTimeout(st.settleTimer); st.settleTimer = 0; }
      if (st.coverTimer) { global.clearTimeout(st.coverTimer); st.coverTimer = 0; }
      if (ro) { try { ro.disconnect(); } catch (e) { /* ignore */ } ro = null; }
      global.removeEventListener("resize", onWinResize);
      host.removeEventListener("pointerenter", onEnter);
      host.removeEventListener("pointerleave", onLeave);
      if (host.parentNode) { host.parentNode.removeChild(host); }
      host.innerHTML = "";
      refs = {};
    }

    /* 只暴露契约约定的接口，避免宿主枚举调用 next/prev 之类的内部方法 */
    return {
      destroy: destroy,
      resize: function () { layout(); },
      setParams: setParams
    };
  }

  global.PSWidgets = global.PSWidgets || {};
  global.PSWidgets["book3d"] = {
    title: "立体课本",
    defaults: DEFAULTS,
    mount: mount
  };
}(typeof window !== "undefined" ? window : this));