/* 物理闯关 · 三个动手游戏（抛体投篮 / 调焦成像 / 浮沉判断）
 * 契约：PSWidgets.game = { title, defaults, mount(root, params, ctx) }
 * 交互：Pointer Events 拖拽 + 键盘 + WebAudio 合成音效；Canvas 2D + DOM 控件。
 * 依赖：无（不加载图片 / 字体 / CDN / 第三方库）。
 */
(function () {
  'use strict';

  var PS = (window.PSWidgets = window.PSWidgets || {});
  var FONT = '"Microsoft YaHei","PingFang SC",system-ui,sans-serif';
  var G = 9.8;
  var LAUNCH_H = 1.5;      // 发射点离地高度（m）
  var HOOP_R = 0.5;        // 篮筐半径（m）
  var V_MIN = 6, V_MAX = 34;
  var ANG_MIN = 5, ANG_MAX = 85;
  var LENS_TOL = 1.0;      // 像距与光屏偏差 ≤ 1.0 cm 视为清晰

  /* ============================ 工具 ============================ */
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function clamp(v, a, b) {
    if (!isFinite(v)) return a;
    return v < a ? a : v > b ? b : v;
  }
  function fmt(v, d) {
    if (v == null || !isFinite(v)) return '—';
    return (+v).toFixed(d == null ? 1 : d);
  }
  function hexRgb(hex) {
    if (typeof hex !== 'string') return null;
    var m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(hex.replace(/\s/g, ''));
    if (!m) return null;
    var h = m[1];
    if (h.length === 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
  }
  function rgba(hex, a) {
    var c = hexRgb(hex) || [56, 189, 248];
    return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + clamp(a, 0, 1) + ')';
  }
  function nowMs() {
    return window.performance && window.performance.now ? window.performance.now() : Date.now();
  }
  function closest(node, sel) {
    while (node && node.nodeType === 1) {
      if (node.matches && node.matches(sel)) return node;
      node = node.parentNode;
    }
    return null;
  }

  /* ============================ 样式 ============================ */
  var CSS = [
    '.psw-gm{--acc:#38bdf8;position:absolute;inset:0;display:flex;flex-direction:column;font-family:' + FONT + ';color:#e8eff9;background:#0b1220;overflow:hidden}',
    '.psw-gm *{box-sizing:border-box}',
    '.psw-gm button{font-family:inherit}',
    '.psw-gm-top{flex:none;display:flex;align-items:center;gap:10px;min-height:48px;padding:7px 12px;border-bottom:1px solid rgba(255,255,255,.07);background:linear-gradient(180deg,rgba(17,28,46,.92),rgba(11,18,32,.55))}',
    '.psw-gm-brand{display:flex;flex-direction:column;gap:1px;min-width:0;flex:none}',
    '.psw-gm-title{font-size:12.5px;font-weight:700;letter-spacing:.4px;white-space:nowrap}',
    '.psw-gm-sub{font-size:9.5px;color:#7f93ad;white-space:nowrap}',
    '.psw-gm-modes{display:flex;gap:3px;flex:none}',
    '.psw-gm-mode{border:1px solid rgba(255,255,255,.11);background:rgba(255,255,255,.04);color:#93a7c2;font-size:10.5px;line-height:1.2;padding:5px 9px;border-radius:7px;cursor:pointer;white-space:nowrap;transition:background .15s,border-color .15s,color .15s}',
    '.psw-gm-mode:hover{color:#e8eff9;background:rgba(255,255,255,.08)}',
    '.psw-gm-mode[aria-pressed="true"]{background:rgba(56,189,248,.15);border-color:var(--acc);color:#eff9ff}',
    '.psw-gm-stats{margin-left:auto;display:flex;align-items:center;gap:8px;flex:none}',
    '.psw-gm-levels{display:flex;gap:2px;padding:2px;border-radius:7px;background:rgba(255,255,255,.04)}',
    '.psw-gm-lv{border:0;background:transparent;color:#8aa0bb;font-size:10.5px;line-height:1.2;padding:3px 7px;border-radius:5px;cursor:pointer}',
    '.psw-gm-lv:hover{color:#e8eff9}',
    '.psw-gm-lv[aria-pressed="true"]{background:rgba(167,139,250,.2);color:#efe9ff;box-shadow:inset 0 0 0 1px rgba(167,139,250,.42)}',
    '.psw-gm-stars{font-size:13px;line-height:1;letter-spacing:1px;white-space:nowrap;font-family:system-ui,sans-serif}',
    '.psw-gm-stars span{color:var(--acc);text-shadow:0 0 8px rgba(56,189,248,.35)}',
    '.psw-gm-stars span.off{color:#3b4b60;text-shadow:none}',
    '.psw-gm-stat{font-size:10.5px;color:#8aa0bb;white-space:nowrap;font-variant-numeric:tabular-nums}',
    '.psw-gm-stat b{color:#e8eff9;font-weight:600}',
    '.psw-gm-mute{flex:none;width:27px;height:27px;border-radius:7px;border:1px solid rgba(255,255,255,.11);background:transparent;color:#9fb3cc;font-size:13px;line-height:1;cursor:pointer}',
    '.psw-gm-mute:hover{color:#e8eff9;background:rgba(255,255,255,.07)}',
    '.psw-gm-mute[aria-pressed="false"]{color:#5d6f86;text-decoration:line-through}',
    '.psw-gm-stage{position:relative;flex:1;min-height:0;display:flex;overflow:hidden}',
    '.psw-gm-canvas{flex:1;min-width:0;display:block;width:100%;height:100%;touch-action:none;outline:none;cursor:crosshair}',
    '.psw-gm-canvas:focus-visible{outline:2px solid var(--acc);outline-offset:-2px}',
    '.psw-gm-side{flex:none;width:172px;padding:9px;border-left:1px solid rgba(255,255,255,.07);background:rgba(13,22,38,.72);display:flex;flex-direction:column;gap:7px;overflow-y:auto;overflow-x:hidden;scrollbar-width:thin;scrollbar-color:rgba(148,163,184,.3) transparent}',
    '.psw-gm-side::-webkit-scrollbar{width:6px}',
    '.psw-gm-side::-webkit-scrollbar-thumb{background:rgba(148,163,184,.25);border-radius:3px}',
    '.psw-gm-goal{font-size:10px;line-height:1.55;color:#cfe0f4;background:rgba(56,189,248,.075);border:1px solid rgba(56,189,248,.18);border-radius:8px;padding:6px 8px}',
    '.psw-gm-goal b{color:var(--acc);font-weight:700}',
    '.psw-gm-reads{display:flex;flex-direction:column;gap:3px}',
    '.psw-gm-rrow{display:flex;align-items:baseline;justify-content:space-between;gap:5px;font-size:10px;color:#8aa0bb;padding-bottom:3px;border-bottom:1px dashed rgba(255,255,255,.06)}',
    '.psw-gm-rrow:last-child{border-bottom:0;padding-bottom:0}',
    '.psw-gm-rrow b{color:#e8eff9;font-weight:600;font-variant-numeric:tabular-nums;text-align:right;white-space:nowrap}',
    '.psw-gm-rrow b.hot{color:var(--acc)}',
    '.psw-gm-sec{font-size:9px;letter-spacing:.6px;color:#6b7f99;margin-top:1px}',
    '.psw-gm-btns{display:flex;gap:5px;flex-wrap:wrap}',
    '.psw-gm-btn{border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.05);color:#cfe0f4;border-radius:7px;padding:5px 9px;font-size:10.5px;line-height:1.2;cursor:pointer;min-width:0;transition:background .15s,border-color .15s}',
    '.psw-gm-btn:hover{background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.2)}',
    '.psw-gm-btn:disabled{opacity:.45;cursor:default}',
    '.psw-gm-btn.primary{background:var(--acc);border-color:transparent;color:#04121c;font-weight:700}',
    '.psw-gm-btn.primary:hover{filter:brightness(1.08)}',
    '.psw-gm-side .psw-gm-btn{flex:1 1 auto}',
    '.psw-gm-liq{display:flex;gap:3px}',
    '.psw-gm-liq button{flex:1;min-width:0;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#9fb3cc;border-radius:6px;padding:4px 2px;font-size:9.5px;line-height:1.25;cursor:pointer}',
    '.psw-gm-liq button:hover{color:#e8eff9}',
    '.psw-gm-liq button[aria-pressed="true"]{color:#eff9ff;background:rgba(56,189,248,.14);border-color:var(--acc)}',
    '.psw-gm-liq button i{display:block;height:3px;border-radius:2px;margin-top:2px;opacity:.9}',
    '.psw-gm-mats{display:grid;grid-template-columns:1fr 1fr;gap:4px}',
    '.psw-gm-mat{display:flex;align-items:center;gap:4px;min-width:0;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);border-radius:7px;padding:4px 4px;color:#cfe0f4;font-size:9.5px;line-height:1.2;cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none}',
    '.psw-gm-mat:hover{border-color:var(--acc);background:rgba(56,189,248,.08)}',
    '.psw-gm-mat:active{cursor:grabbing}',
    '.psw-gm-mat.is-sel{border-color:var(--acc);background:rgba(56,189,248,.14)}',
    '.psw-gm-mat i{flex:none;width:11px;height:11px;border-radius:50%;box-shadow:inset -2px -2px 3px rgba(0,0,0,.45)}',
    '.psw-gm-mat span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.psw-gm-mat em{font-style:normal;font-size:8.5px;color:#7f93ad;margin-left:auto}',
    '.psw-gm-toast{position:absolute;left:50%;top:9px;z-index:6;max-width:calc(100% - 24px);transform:translate(-50%,-6px);padding:6px 13px;border-radius:999px;background:rgba(8,14,24,.94);border:1px solid rgba(148,163,184,.28);color:#dbe7f5;font-size:11px;font-weight:600;line-height:1.3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;opacity:0;pointer-events:none;transition:opacity .18s,transform .18s}',
    '.psw-gm-toast.on{opacity:1;transform:translate(-50%,0)}',
    '.psw-gm-toast.ok{border-color:rgba(52,211,153,.6);color:#d6fff1}',
    '.psw-gm-toast.bad{border-color:rgba(251,113,133,.55);color:#ffe0e6}',
    '.psw-gm-foot{flex:none;display:flex;align-items:center;gap:10px;min-height:40px;padding:6px 12px;border-top:1px solid rgba(255,255,255,.06);background:rgba(9,15,27,.72)}',
    '.psw-gm-hint{flex:1;min-width:0;font-size:10px;line-height:1.45;color:#8aa0bb}',
    '.psw-gm-hint b{color:#cfe0f4;font-weight:600}',
    '.psw-gm-foot .psw-gm-btn{flex:none;padding:5px 10px}',
    '.psw-gm-ghost{position:fixed;left:0;top:0;z-index:2147483000;width:36px;height:36px;border-radius:50%;pointer-events:none;transform:translate(-50%,-50%);opacity:.96;box-shadow:0 10px 22px rgba(0,0,0,.5),0 0 0 1px rgba(255,255,255,.25);filter:saturate(1.1)}',
    '.psw-gm.is-narrow .psw-gm-side{width:150px;padding:8px}',
    '.psw-gm.is-narrow .psw-gm-sub{display:none}',
    '.psw-gm.is-narrow .psw-gm-top{gap:7px;padding:6px 9px;min-height:44px}',
    '.psw-gm.is-narrow .psw-gm-mode{padding:4px 6px;font-size:10px}',
    '.psw-gm.is-narrow .psw-gm-stats{gap:6px}',
    '.psw-gm.is-narrow .psw-gm-stat{font-size:10px}',
    '.psw-gm.is-narrow .psw-gm-hint{font-size:9.5px}',
    '.psw-gm.is-tiny .psw-gm-brand{display:none}',
    '.psw-gm.is-tiny .psw-gm-side{width:138px;padding:7px;gap:6px}',
    '.psw-gm.is-tiny .psw-gm-mats{grid-template-columns:1fr}',
    '.psw-gm.is-tiny .psw-gm-foot{padding:5px 8px;min-height:36px}',
    '.psw-gm.is-tiny .psw-gm-mute{display:none}',
  ].join('\n');

  function injectStyle() {
    if (document.querySelector('style[data-psw-style="game"]')) return;
    var s = document.createElement('style');
    s.setAttribute('data-psw-style', 'game');
    s.textContent = CSS;
    document.head.appendChild(s);
  }

  /* ============================ 数据 ============================ */
  var MODES = [
    { id: 'projectile-hoop', label: '抛体投篮' },
    { id: 'lens-focus', label: '调焦成像' },
    { id: 'float-sink', label: '浮沉判断' },
  ];

  var LEVELS = {
    'projectile-hoop': [
      { d: 8, h: 3.0, name: '近筐' },
      { d: 12, h: 4.2, name: '中距' },
      { d: 16, h: 5.5, name: '远投' },
    ],
    'lens-focus': [
      { f: 10, u0: 30, v0: 22, uMin: 12, uMax: 42, vMin: 8, vMax: 50, steps: 6, name: 'f=10cm' },
      { f: 15, u0: 30, v0: 20, uMin: 16, uMax: 44, vMin: 12, vMax: 58, steps: 5, name: 'f=15cm' },
      { f: 8, u0: 13, v0: 34, uMin: 9, uMax: 30, vMin: 8, vMax: 42, steps: 4, name: 'f=8cm' },
    ],
    'float-sink': [
      { target: 'levitate', liquid: 'water', name: '悬浮' },
      { target: 'half', liquid: 'water', name: '半浸' },
      { target: 'sink', liquid: 'water', name: '下沉' },
    ],
  };

  var TARGET_TEXT = {
    levitate: '悬浮（ρ物 = ρ液）',
    half: '半浸（ρ物 = 0.5ρ液）',
    sink: '下沉（ρ物 > ρ液）',
  };

  var MATERIALS = [
    { id: 'wood', name: '木', rho: 0.6, color: '#c0803f' },
    { id: 'ice', name: '冰', rho: 0.9, color: '#8fd3f4' },
    { id: 'plastic', name: '塑料', rho: 1.2, color: '#f472b6' },
    { id: 'alu', name: '铝', rho: 2.7, color: '#cbd5e1' },
    { id: 'iron', name: '铁', rho: 7.9, color: '#7c8ea6' },
  ];

  var LIQUIDS = {
    water: { name: '水', rho: 1.0, color: '#38bdf8' },
    alcohol: { name: '酒精', rho: 0.8, color: '#a78bfa' },
    salt: { name: '盐水', rho: 1.2, color: '#2dd4bf' },
  };

  function findMaterial(id) {
    for (var i = 0; i < MATERIALS.length; i++) if (MATERIALS[i].id === id) return MATERIALS[i];
    return null;
  }

  /* ============================ 音效（WebAudio 合成） ============================ */
  function makeSound() {
    var AC = window.AudioContext || window.webkitAudioContext;
    var ac = null, muted = false, dead = false;
    function ensure() {
      if (dead) return;
      if (!ac && AC) {
        try { ac = new AC(); } catch (e) { ac = null; }
      }
      if (ac && ac.state === 'suspended') {
        try { ac.resume(); } catch (e) { /* 无音频设备时静默 */ }
      }
    }
    function tone(freq, dur, type, vol, delay) {
      if (dead || muted || !ac) return;
      try {
        var t0 = ac.currentTime + (delay || 0);
        var o = ac.createOscillator();
        var g = ac.createGain();
        o.type = type || 'sine';
        o.frequency.setValueAtTime(freq, t0);
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol || 0.05), t0 + 0.012);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
        o.connect(g);
        g.connect(ac.destination);
        o.start(t0);
        o.stop(t0 + dur + 0.03);
      } catch (e) { /* 忽略单次音频失败 */ }
    }
    return {
      ensure: ensure,
      setMuted: function (v) { muted = !!v; },
      isMuted: function () { return muted; },
      hit: function () { tone(660, 0.09, 'sine', 0.055); tone(990, 0.12, 'sine', 0.045, 0.07); tone(1320, 0.16, 'sine', 0.035, 0.14); },
      fail: function () { tone(220, 0.12, 'triangle', 0.055); tone(160, 0.2, 'triangle', 0.045, 0.1); },
      click: function () { tone(520, 0.045, 'square', 0.016); },
      launch: function () { tone(430, 0.08, 'sawtooth', 0.022); tone(680, 0.12, 'sine', 0.028, 0.05); },
      splash: function () { tone(300, 0.14, 'sine', 0.03); tone(150, 0.2, 'sine', 0.02, 0.05); },
      tick: function () { tone(880, 0.03, 'square', 0.01); },
      destroy: function () {
        dead = true;
        if (ac) { try { ac.close(); } catch (e) { /* 已关闭 */ } ac = null; }
      },
    };
  }

  /* ============================ 挂载 ============================ */
  function mount(root, params, ctx) {
    injectStyle();
    params = params || {};
    ctx = ctx || {};

    var accent = (ctx.theme && typeof ctx.theme.accent === 'string' && hexRgb(ctx.theme.accent)) ? ctx.theme.accent : '#38bdf8';
    var motionOn = ctx.motion !== false;

    var mode = params.mode && LEVELS[params.mode] ? params.mode : 'projectile-hoop';
    var lv = clamp(parseInt(params.level, 10) || 0, 0, 2);

    var ui = el('div', 'psw-gm');
    ui.style.setProperty('--acc', accent);
    ui.innerHTML =
      '<div class="psw-gm-top">' +
        '<div class="psw-gm-brand"><div class="psw-gm-title">物理闯关</div><div class="psw-gm-sub">动手玩 · 三关三星</div></div>' +
        '<div class="psw-gm-modes" role="tablist" aria-label="模式切换"></div>' +
        '<div class="psw-gm-stats">' +
          '<div class="psw-gm-levels" role="group" aria-label="关卡"></div>' +
          '<div class="psw-gm-stars" role="img" aria-label="星级"></div>' +
          '<span class="psw-gm-stat">连击 <b data-stat="combo">0</b></span>' +
          '<span class="psw-gm-stat">尝试 <b data-stat="attempts">0</b></span>' +
          '<button class="psw-gm-mute" type="button" data-mute aria-label="音效开关" aria-pressed="true" title="音效开关">♪</button>' +
        '</div>' +
      '</div>' +
      '<div class="psw-gm-stage">' +
        '<canvas class="psw-gm-canvas" tabindex="0" role="application" aria-label="物理闯关舞台，可拖拽与键盘操作"></canvas>' +
        '<div class="psw-gm-side"></div>' +
        '<div class="psw-gm-toast" role="status" aria-live="polite"></div>' +
      '</div>' +
      '<div class="psw-gm-foot">' +
        '<div class="psw-gm-hint"></div>' +
        '<button class="psw-gm-btn" type="button" data-act="reset">重来本关</button>' +
      '</div>';
    root.appendChild(ui);

    var canvas = ui.querySelector('.psw-gm-canvas');
    var side = ui.querySelector('.psw-gm-side');
    var toastEl = ui.querySelector('.psw-gm-toast');
    var hintEl = ui.querySelector('.psw-gm-hint');
    var modesBox = ui.querySelector('.psw-gm-modes');
    var levelsBox = ui.querySelector('.psw-gm-levels');
    var starsBox = ui.querySelector('.psw-gm-stars');
    var comboEl = ui.querySelector('[data-stat="combo"]');
    var attemptsEl = ui.querySelector('[data-stat="attempts"]');
    var muteBtn = ui.querySelector('[data-mute]');
    var c2 = canvas.getContext('2d');
    if (!c2) { root.removeChild(ui); return { destroy: function () {}, resize: function () {}, setParams: function () {} }; }

    /* ---------------------------- 状态 ---------------------------- */
    var stars = { 'projectile-hoop': [0, 0, 0], 'lens-focus': [0, 0, 0], 'float-sink': [0, 0, 0] };
    var best = { 'projectile-hoop': [null, null, null] };
    var attempts = 0;
    var combo = 0;
    var time = 0;
    var last = 0;
    var raf = 0;
    var dead = false;
    var size = { w: 0, h: 0, dpr: 1 };
    var toastTimer = 0;
    var sound = makeSound();
    var muted = false;
    var ghost = null;
    var lastMatPointerAt = -1e9;

    var proj = {
      angle: 45, v0: 16, aiming: false, pointerId: -1, dragX: 0, dragY: 0, dragLen: 0,
      ball: null, predicted: null, shotPath: null, particles: [], flash: 0, miss: null,
    };
    var lens = {
      u: 30, f: 10, vScreen: 22, drag: null, solved: false, failed: false,
      keyAt: -1e9, pulse: 0,
    };
    var fl = {
      liquid: 'water', ball: null, sel: 0, wave: 0, wavePhase: 0, splash: [], bubbleAt: 0,
    };

    function levelCfg() { return LEVELS[mode][lv]; }

    /* ---------------------------- 顶部/侧栏 ---------------------------- */
    function buildTop() {
      var h = '';
      for (var i = 0; i < MODES.length; i++) {
        h += '<button type="button" class="psw-gm-mode" data-mode="' + MODES[i].id + '" aria-pressed="false">' + MODES[i].label + '</button>';
      }
      modesBox.innerHTML = h;
      h = '';
      for (var j = 0; j < 3; j++) {
        h += '<button type="button" class="psw-gm-lv" data-lv="' + j + '" aria-pressed="false" aria-label="第' + (j + 1) + '关">' + (j + 1) + '</button>';
      }
      levelsBox.innerHTML = h;
      starsBox.innerHTML = '<span>★</span><span>★</span><span>★</span>';
      updateModeButtons();
    }

    function updateModeButtons() {
      var bs = modesBox.querySelectorAll('[data-mode]');
      for (var i = 0; i < bs.length; i++) bs[i].setAttribute('aria-pressed', String(bs[i].getAttribute('data-mode') === mode));
    }

    function row(label, key) {
      return '<div class="psw-gm-rrow"><span>' + label + '</span><b data-r="' + key + '">—</b></div>';
    }

    function buildPanel() {
      if (mode === 'projectile-hoop') {
        side.innerHTML =
          '<div class="psw-gm-goal" data-goal></div>' +
          '<div class="psw-gm-reads">' +
            row('发射角', 'ang') + row('初速度', 'v0') + row('预计射程', 'range') +
            row('预计最高', 'peak') + row('过筐高度', 'hoop') + row('最佳记录', 'best') +
          '</div>' +
          '<div class="psw-gm-btns"><button type="button" class="psw-gm-btn primary" data-act="launch">发射</button></div>';
      } else if (mode === 'lens-focus') {
        side.innerHTML =
          '<div class="psw-gm-goal" data-goal></div>' +
          '<div class="psw-gm-reads">' +
            row('物距 u', 'u') + row('像距 v', 'v') + row('光屏位置', 'scr') +
            row('放大率 |v/u|', 'mag') + row('成像偏差', 'diff') + row('调整步数', 'steps') +
          '</div>' +
          '<div class="psw-gm-btns"><button type="button" class="psw-gm-btn" data-act="reset">重试本关</button></div>';
      } else {
        var liq = '';
        for (var id in LIQUIDS) {
          if (!LIQUIDS.hasOwnProperty(id)) continue;
          liq += '<button type="button" data-liquid="' + id + '" aria-pressed="false" title="' +
            LIQUIDS[id].name + ' ρ=' + LIQUIDS[id].rho.toFixed(1) + ' g/cm³">' + LIQUIDS[id].name +
            '<i style="background:' + LIQUIDS[id].color + '"></i></button>';
        }
        var mats = '';
        for (var i = 0; i < MATERIALS.length; i++) {
          var m = MATERIALS[i];
          mats += '<button type="button" class="psw-gm-mat" data-mat="' + m.id + '" aria-label="' + m.name + '球，密度 ' + m.rho + ' 克每立方厘米，可拖入液体">' +
            '<i style="background:' + m.color + '"></i><span>' + m.name + '</span><em>' + m.rho.toFixed(1) + '</em></button>';
        }
        side.innerHTML =
          '<div class="psw-gm-goal" data-goal></div>' +
          '<div class="psw-gm-reads">' +
            row('ρ物', 'rho') + row('ρ液', 'rl') + row('浸入比例', 'sub') + row('判定', 'verdict') +
          '</div>' +
          '<div class="psw-gm-sec">液体（点击切换）</div>' +
          '<div class="psw-gm-liq">' + liq + '</div>' +
          '<div class="psw-gm-sec">材料架 · 拖进液体</div>' +
          '<div class="psw-gm-mats">' + mats + '</div>';
      }
      syncPanel();
    }

    function setR(key, text, hot) {
      var n = side.querySelector('[data-r="' + key + '"]');
      if (!n) return;
      if (n.textContent !== text) n.textContent = text;
      if (hot != null) {
        if (hot) n.classList.add('hot'); else n.classList.remove('hot');
      }
    }
    function setGoal(html) {
      var n = side.querySelector('[data-goal]');
      if (n && n.innerHTML !== html) n.innerHTML = html;
    }

    function verdictOf(rho, rl) {
      if (rho > rl * 1.02) return '下沉';
      if (rho >= rl * 0.98) return '悬浮';
      return '漂浮';
    }

    function syncPanel() {
      if (!side.firstChild) return;
      if (mode === 'projectile-hoop') {
        var L = levelCfg();
        var pred = proj.predicted || simulateProjectile(proj.angle, proj.v0, L.d);
        proj.predicted = pred;
        setGoal('第 ' + (lv + 1) + ' 关 · 把球投进 <b>' + L.d + ' m</b> 外、高 <b>' + L.h + ' m</b> 的篮筐<br>从发射器拖出方向与力度，松手投篮');
        setR('ang', Math.round(proj.angle) + '°');
        setR('v0', fmt(proj.v0, 1) + ' m/s');
        setR('range', fmt(pred.range, 1) + ' m');
        setR('peak', fmt(pred.peak, 1) + ' m');
        setR('hoop', pred.yAtHoop == null ? '—' : fmt(pred.yAtHoop, 1) + ' m', pred.yAtHoop != null && Math.abs(pred.yAtHoop - L.h) <= 0.6);
        var rec = best['projectile-hoop'][lv];
        setR('best', rec ? Math.round(rec.angle) + '° · ' + fmt(rec.v0, 1) + ' m/s · ' + rec.attempts + ' 次' : '—');
        var lb = side.querySelector('[data-act="launch"]');
        if (lb) {
          var flying = !!(proj.ball && proj.ball.flying);
          lb.disabled = flying;
          lb.textContent = flying ? '飞行中…' : '发射';
        }
      } else if (mode === 'lens-focus') {
        var LL = levelCfg();
        var v = lens.u > lens.f + 0.001 ? lens.u * lens.f / (lens.u - lens.f) : Infinity;
        var diff = Math.abs(v - lens.vScreen);
        setGoal('第 ' + (lv + 1) + ' 关 · f = <b>' + fmt(LL.f, 0) + ' cm</b> 已固定<br>拖动蜡烛与光屏，让像清晰落在光屏上 · 限 <b>' + LL.steps + ' 步</b>');
        setR('u', fmt(lens.u, 1) + ' cm');
        setR('v', isFinite(v) ? fmt(v, 1) + ' cm' : '∞');
        setR('scr', fmt(lens.vScreen, 1) + ' cm');
        setR('mag', isFinite(v) ? fmt(Math.abs(v / lens.u), 2) + '×' : '—');
        setR('diff', isFinite(diff) ? fmt(diff, 1) + ' cm' : '—', isFinite(diff) && diff <= LENS_TOL);
        setR('steps', attempts + ' / ' + LL.steps);
      } else {
        var LF = levelCfg();
        var liquid = LIQUIDS[fl.liquid];
        var b = fl.ball;
        setGoal('第 ' + (lv + 1) + ' 关 · 让小球 <b>' + TARGET_TEXT[LF.target] + '</b><br>先选液体，再把材料球拖进液体里');
        setR('rho', b ? fmt(b.rho, 2) + ' g/cm³' : '—');
        setR('rl', fmt(liquid.rho, 2) + ' g/cm³');
        var subFrac = b ? (b.rho < liquid.rho ? b.rho / liquid.rho : 1) : 0;
        setR('sub', b ? Math.round(subFrac * 100) + '%' : '—');
        setR('verdict', b ? verdictOf(b.rho, liquid.rho) : '等待投放');
        var lbs = side.querySelectorAll('[data-liquid]');
        for (var i = 0; i < lbs.length; i++) {
          lbs[i].setAttribute('aria-pressed', String(lbs[i].getAttribute('data-liquid') === fl.liquid));
        }
        var mbs = side.querySelectorAll('[data-mat]');
        for (var j = 0; j < mbs.length; j++) {
          var on = mbs[j].getAttribute('data-mat') === MATERIALS[fl.sel].id;
          if (on) mbs[j].classList.add('is-sel'); else mbs[j].classList.remove('is-sel');
        }
      }
    }

    function syncStats() {
      var lvBtns = levelsBox.querySelectorAll('[data-lv]');
      for (var i = 0; i < lvBtns.length; i++) {
        lvBtns[i].setAttribute('aria-pressed', String(i === lv));
        var nm = LEVELS[mode][i] ? LEVELS[mode][i].name : '';
        lvBtns[i].title = '第 ' + (i + 1) + ' 关 · ' + nm;
        lvBtns[i].setAttribute('aria-label', '第 ' + (i + 1) + ' 关 ' + nm);
      }
      var spans = starsBox.querySelectorAll('span');
      var n = stars[mode][lv] || 0;
      for (var j = 0; j < spans.length; j++) {
        if (j < n) spans[j].classList.remove('off'); else spans[j].classList.add('off');
      }
      starsBox.setAttribute('aria-label', '本关星级 ' + n + ' 星（满分 3 星）');
      comboEl.textContent = String(combo);
      attemptsEl.textContent = String(attempts);
      muteBtn.setAttribute('aria-pressed', String(!muted));
    }

    function updateHint() {
      if (mode === 'projectile-hoop') {
        hintEl.innerHTML = '从发射器<b>拖拽</b>：距离 = 初速度，方向 = 发射角，松手投篮｜键盘 <b>←/→</b> 角度 · <b>↑/↓</b> 力度 · <b>空格</b> 发射';
      } else if (mode === 'lens-focus') {
        hintEl.innerHTML = '拖动<b>蜡烛</b>改物距 u、拖动<b>光屏</b>改像距 v，让像清晰落在光屏上｜键盘 <b>←/→</b> 物体 · <b>↑/↓</b> 光屏';
      } else {
        hintEl.innerHTML = '把右侧<b>材料球拖进液体</b>（点按球也可投放）｜键盘 <b>←/→</b> 选材料 · <b>↑/↓</b> 换液体 · <b>空格</b> 投放';
      }
    }

    function starForAttempts() { return attempts <= 1 ? 3 : attempts <= 3 ? 2 : 1; }

    function award(n) {
      if (!(n > 0)) return;
      if (n > (stars[mode][lv] || 0)) stars[mode][lv] = n;
      syncStats();
    }

    function toast(text, kind) {
      if (toastTimer) { clearTimeout(toastTimer); toastTimer = 0; }
      if (!text) {
        toastEl.className = 'psw-gm-toast';
        toastEl.textContent = '';
        return;
      }
      toastEl.textContent = text;
      toastEl.className = 'psw-gm-toast on' + (kind ? ' ' + kind : '');
      toastTimer = setTimeout(function () {
        toastEl.className = 'psw-gm-toast' + (kind ? ' ' + kind : '');
      }, kind === 'ok' ? 2800 : 2400);
    }

    /* ---------------------------- 关卡切换 ---------------------------- */
    function resetLevel() {
      attempts = 0;
      combo = 0;
      toast('', '');
      if (mode === 'projectile-hoop') {
        var L = levelCfg();
        proj.angle = 45;
        proj.v0 = 16;
        proj.aiming = false;
        proj.pointerId = -1;
        proj.dragLen = 0;
        proj.ball = null;
        proj.particles = [];
        proj.flash = 0;
        proj.miss = null;
        proj.shotPath = null;
        proj.predicted = simulateProjectile(proj.angle, proj.v0, L.d);
      } else if (mode === 'lens-focus') {
        var LL = levelCfg();
        lens.u = LL.u0;
        lens.f = LL.f;
        lens.vScreen = LL.v0;
        lens.drag = null;
        lens.solved = false;
        lens.failed = false;
        lens.overNotified = false;
        lens.pulse = 0;
        lens.keyAt = -1e9;
      } else {
        var LF = levelCfg();
        fl.liquid = LF.liquid;
        fl.ball = null;
        fl.sel = 0;
        fl.splash = [];
        fl.wave = 0;
        fl.wavePhase = 0;
        fl.bubbleAt = 0;
        removeGhost();
      }
      syncStats();
      syncPanel();
      updateHint();
      render();
    }

    function setMode(m) {
      if (!LEVELS[m] || m === mode) return;
      mode = m;
      lv = 0;
      removeGhost();
      updateModeButtons();
      buildPanel();
      resetLevel();
      canvas.style.cursor = mode === 'lens-focus' ? 'grab' : mode === 'float-sink' ? 'default' : 'crosshair';
      sound.click();
    }

    /* ---------------------------- 尺寸 ---------------------------- */
    function measure() {
      if (dead) return;
      var w = Math.max(2, Math.round(canvas.clientWidth || canvas.getBoundingClientRect().width));
      var h = Math.max(2, Math.round(canvas.clientHeight || canvas.getBoundingClientRect().height));
      var dpr = clamp(window.devicePixelRatio || 1, 1, 2.5);
      var narrow = ui.clientWidth > 0 && ui.clientWidth < 760;
      ui.classList.toggle('is-narrow', narrow);
      ui.classList.toggle('is-tiny', ui.clientWidth > 0 && ui.clientWidth < 560);
      if (w === size.w && h === size.h && dpr === size.dpr) return;
      size = { w: w, h: h, dpr: dpr };
      canvas.width = Math.max(1, Math.round(w * dpr));
      canvas.height = Math.max(1, Math.round(h * dpr));
      render();
    }

    function canvasPoint(clientX, clientY) {
      var r = canvas.getBoundingClientRect();
      var sx = r.width ? (canvas.clientWidth / r.width) : 1;
      var sy = r.height ? (canvas.clientHeight / r.height) : 1;
      return { x: (clientX - r.left) * sx, y: (clientY - r.top) * sy };
    }

    /* ---------------------------- 抛体投篮 ---------------------------- */
    function projectileLayout(w, h) {
      var L = levelCfg();
      var worldW = Math.max(12, L.d + 5);
      var worldH = Math.max(8.5, L.h + 3.6);
      var padL = w < 520 ? 38 : 50;
      var padR = w < 520 ? 18 : 24;
      var padT = h < 400 ? 36 : 50;
      var padB = h < 400 ? 32 : 42;
      var s = Math.min((w - padL - padR) / worldW, (h - padT - padB) / worldH);
      if (!isFinite(s) || s <= 0.4) s = 0.4;
      var ox = padL + Math.max(0, (w - padL - padR - worldW * s) / 2);
      var ground = h - padB;
      return {
        L: L, worldW: worldW, worldH: worldH, s: s, ox: ox, ground: ground,
        X: function (x) { return ox + x * s; },
        Y: function (y) { return ground - y * s; },
      };
    }

    function yAtX(angleDeg, v0, x) {
      var th = angleDeg * Math.PI / 180;
      var vx = v0 * Math.cos(th);
      if (vx < 0.001) return null;
      var t = x / vx;
      return LAUNCH_H + v0 * Math.sin(th) * t - 0.5 * G * t * t;
    }

    function simulateProjectile(angleDeg, v0, targetD) {
      var th = angleDeg * Math.PI / 180;
      var vx = v0 * Math.cos(th), vy = v0 * Math.sin(th);
      var pts = [], x = 0, y = LAUNCH_H, t = 0, dt = 0.02, peak = LAUNCH_H, guard = 0;
      while (y >= 0 && t < 15 && guard < 1200) {
        pts.push([x, y]);
        if (y > peak) peak = y;
        vy -= G * dt;
        x += vx * dt;
        y += vy * dt;
        t += dt;
        guard++;
      }
      if (y < 0) pts.push([x, 0]);
      var vy0 = v0 * Math.sin(th);
      var range = (v0 * Math.cos(th) / G) * (vy0 + Math.sqrt(vy0 * vy0 + 2 * G * LAUNCH_H));
      return { pts: pts, range: range, peak: peak, yAtHoop: yAtX(angleDeg, v0, targetD) };
    }

    function updateAim(pt) {
      var lay = projectileLayout(size.w, size.h);
      var lx = lay.X(0), ly = lay.Y(LAUNCH_H);
      var dx = pt.x - lx, dy = pt.y - ly;
      var dist = Math.sqrt(dx * dx + dy * dy);
      proj.dragLen = dist;
      proj.dragX = pt.x;
      proj.dragY = pt.y;
      proj.angle = clamp(Math.atan2(-dy, dx) * 180 / Math.PI, ANG_MIN, ANG_MAX);
      var rangePx = Math.max(140, Math.min(size.w, size.h) * 0.62);
      proj.v0 = clamp(dist / rangePx * V_MAX, V_MIN, V_MAX);
      proj.predicted = simulateProjectile(proj.angle, proj.v0, levelCfg().d);
      syncPanel();
    }

    function launch() {
      if (dead) return;
      if (proj.ball && proj.ball.flying) return;
      var L = levelCfg();
      var ang = proj.angle, v0 = proj.v0;
      var rad = ang * Math.PI / 180;
      attempts++;
      proj.ball = {
        x: 0, y: LAUNCH_H, vx: v0 * Math.cos(rad), vy: v0 * Math.sin(rad),
        flying: true, hit: false, t: 0, path: [[0, LAUNCH_H]], peak: LAUNCH_H,
        angle: ang, v0: v0, hoopX: L.d, hoopY: L.h, yAtHoop: yAtX(ang, v0, L.d), landX: null,
      };
      proj.miss = null;
      proj.flash = 0;
      proj.particles = [];
      proj.shotPath = simulateProjectile(ang, v0, L.d);
      proj.aiming = false;
      sound.launch();
      toast('', '');
      syncStats();
      syncPanel();
    }

    function confetti(x, y, count) {
      if (!motionOn) return;
      var colors = [accent, '#fbbf24', '#34d399', '#f472b6', '#f8fafc'];
      for (var i = 0; i < count; i++) {
        var a = Math.random() * Math.PI * 2;
        var sp = 60 + Math.random() * 210;
        proj.particles.push({
          x: x, y: y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 90,
          life: 0.75 + Math.random() * 0.65, max: 1.4, size: 3 + Math.random() * 4,
          color: colors[i % colors.length], rot: Math.random() * 6.28, vr: (Math.random() - 0.5) * 12,
        });
      }
    }

    function projectorHit(b) {
      var L = levelCfg();
      b.hit = true;
      b.flying = false;
      b.x = b.hoopX;
      b.y = b.hoopY;
      b.path.push([b.x, b.y]);
      proj.flash = 1;
      combo++;
      var n = starForAttempts();
      award(n);
      var rec = best['projectile-hoop'][lv];
      if (!rec || attempts < rec.attempts) best['projectile-hoop'][lv] = { angle: b.angle, v0: b.v0, attempts: attempts };
      var lay = projectileLayout(size.w, size.h);
      confetti(lay.X(b.hoopX), lay.Y(b.hoopY), 46);
      sound.hit();
      toast('命中！' + Math.round(b.angle) + '° / ' + fmt(b.v0, 1) + ' m/s · 第 ' + attempts + ' 次尝试 · ' + n + ' 星', 'ok');
      syncStats();
      syncPanel();
    }

    function projectileMiss(b) {
      if (b.hit) return;
      combo = 0;
      var dx = (b.landX != null ? b.landX : b.x) - b.hoopX;
      var dev = b.yAtHoop == null ? null : b.yAtHoop - b.hoopY;
      proj.miss = { landX: b.landX, planeY: b.yAtHoop, dx: dx, dev: dev };
      var msg = '差一点！';
      if (dev != null && b.yAtHoop >= 0 && Math.abs(dev) > 0.35) {
        msg += dev < 0 ? '过筐时还低 ' + fmt(-dev, 1) + ' m' : '过筐时高出 ' + fmt(dev, 1) + ' m';
      } else if (b.landX != null) {
        msg += '落点 ' + fmt(b.landX, 1) + ' m（筐在 ' + fmt(b.hoopX, 1) + ' m，' + (dx < 0 ? '短 ' : '远 ') + fmt(Math.abs(dx), 1) + ' m）';
      } else {
        msg += '球飞出界了，调低初速度试试';
      }
      toast(msg, 'bad');
      sound.fail();
      syncStats();
      syncPanel();
    }

    function updateProjectile(dt) {
      if (proj.flash > 0) proj.flash = Math.max(0, proj.flash - dt * 1.5);

      var b = proj.ball;
      if (!b || !b.flying) return;
      var steps = 5, h = dt / steps;
      for (var s = 0; s < steps; s++) {
        var px = b.x, py = b.y;
        b.vy -= G * h;
        b.x += b.vx * h;
        b.y += b.vy * h;
        b.t += h;
        if (b.y > b.peak) b.peak = b.y;
        if (!b.hit && b.vy < 0 && py >= b.hoopY && b.y <= b.hoopY) {
          var den = py - b.y;
          var f = den > 1e-6 ? (py - b.hoopY) / den : 0;
          var xc = px + (b.x - px) * f;
          if (Math.abs(xc - b.hoopX) <= HOOP_R * 1.25) {
            projectorHit(b);
            return;
          }
        }
        if (b.y <= 0) {
          b.y = 0;
          b.flying = false;
          b.landX = b.x;
          b.path.push([b.x, 0]);
          projectileMiss(b);
          return;
        }
        if (b.t > 12 || b.x > 260) {
          b.flying = false;
          b.landX = b.x;
          projectileMiss(b);
          return;
        }
      }
      b.path.push([b.x, b.y]);
      if (b.path.length > 900) b.path.shift();
    }

    /* ---------------------------- 调焦成像 ---------------------------- */
    function lensLayout(w, h) {
      var L = levelCfg();
      var padL = Math.max(24, w * 0.035), padR = padL;
      var span = L.uMax + L.vMax;
      var s = Math.min(14, (w - padL - padR) / span);
      if (!isFinite(s) || s < 0.5) s = 0.5;
      var total = span * s;
      var startX = (w - total) / 2;
      var lensX = startX + L.uMax * s;
      var railY = h - Math.max(22, h * 0.08);
      var midY = Math.max(68, Math.min(h * 0.44, railY - Math.max(92, h * 0.32)));
      var screenHalf = clamp(h * 0.20, 46, 100);
      var objH = clamp(h * 0.12, 28, 56);
      var lensHalf = clamp(h * 0.16, 38, 72);
      return {
        L: L, s: s, startX: startX, lensX: lensX, railY: railY, midY: midY,
        screenHalf: screenHalf, objH: objH, lensHalf: lensHalf, total: total,
        objX: lensX - lens.u * s, screenX: lensX + lens.vScreen * s,
      };
    }

    function lensImage() {
      var L = levelCfg();
      if (lens.u <= lens.f + 0.001) return { v: Infinity, mag: Infinity };
      var v = lens.u * lens.f / (lens.u - lens.f);
      return { v: v, mag: Math.abs(v / lens.u) };
    }

    function addLensStep() {
      var L = levelCfg();
      attempts++;
      if (attempts > L.steps && !lens.solved && !lens.failed) {
        lens.failed = true;
        combo = 0;
        sound.fail();
        toast('步数用尽（限 ' + L.steps + ' 步），按「重试本关」再来', 'bad');
      } else {
        sound.tick();
      }
      syncStats();
      syncPanel();
    }

    function checkLensSharp() {
      var img = lensImage();
      if (!isFinite(img.v)) return;
      var diff = Math.abs(img.v - lens.vScreen);
      if (diff > LENS_TOL) return;
      var L = levelCfg();
      if (lens.solved) return;
      if (attempts > L.steps) {
        if (!lens.overNotified) {
          lens.overNotified = true;
          toast('像清晰了，但超出 ' + L.steps + ' 步限定，重试可得星', 'bad');
          sound.fail();
        }
        return;
      }
      lens.solved = true;
      lens.pulse = 1;
      combo++;
      var n = (diff <= 0.55 && attempts <= Math.ceil(L.steps / 2)) ? 3 : 2;
      award(n);
      var lay = lensLayout(size.w, size.h);
      confetti(lay.screenX, lay.midY, 32);
      sound.hit();
      toast('清晰！u=' + fmt(lens.u, 1) + ' cm · v=' + fmt(img.v, 1) + ' cm · 放大 ' + fmt(img.mag, 2) + '× · ' + attempts + ' 步 · ' + n + ' 星', 'ok');
      syncStats();
      syncPanel();
    }

    function lensKeyAdjust(kind, delta) {
      var L = levelCfg();
      var now = nowMs();
      if (now - lens.keyAt > 700) addLensStep();
      lens.keyAt = now;
      if (kind === 'u') lens.u = clamp(Math.round((lens.u + delta) * 10) / 10, L.uMin, L.uMax);
      else lens.vScreen = clamp(Math.round((lens.vScreen + delta) * 10) / 10, L.vMin, L.vMax);
      checkLensSharp();
      syncPanel();
    }

    function startLensDrag(pt, pointerId) {
      var lay = lensLayout(size.w, size.h);
      var kind = null, offset = 0;
      if (Math.abs(pt.x - lay.objX) <= 34) {
        kind = 'u';
        offset = lens.u - (lay.lensX - pt.x) / lay.s;
      } else if (Math.abs(pt.x - lay.screenX) <= 30) {
        kind = 'screen';
        offset = lens.vScreen - (pt.x - lay.lensX) / lay.s;
      } else if (pt.x < lay.lensX - 26) {
        kind = 'u';
      } else if (pt.x > lay.lensX + 26) {
        kind = 'screen';
      }
      if (!kind) return false;
      lens.drag = { kind: kind, offset: offset, pointerId: pointerId, startX: pt.x, moved: false, counted: false };
      canvas.style.cursor = 'grabbing';
      return true;
    }

    function moveLensDrag(pt) {
      var d = lens.drag;
      if (!d) return;
      var lay = lensLayout(size.w, size.h);
      var L = lay.L;
      if (Math.abs(pt.x - d.startX) > 2) d.moved = true;
      if (d.moved && !d.counted) {
        d.counted = true;
        addLensStep();
      }
      if (d.kind === 'u') {
        lens.u = clamp(Math.round(((lay.lensX - pt.x) / lay.s + d.offset) * 10) / 10, L.uMin, L.uMax);
      } else {
        lens.vScreen = clamp(Math.round(((pt.x - lay.lensX) / lay.s + d.offset) * 10) / 10, L.vMin, L.vMax);
      }
      syncPanel();
    }

    function endLensDrag(check) {
      lens.drag = null;
      canvas.style.cursor = 'grab';
      if (check) checkLensSharp();
    }

    function updateConfetti(dt) {
      var arr = proj.particles;
      for (var i = arr.length - 1; i >= 0; i--) {
        var q = arr[i];
        q.vy += 520 * dt;
        q.x += q.vx * dt;
        q.y += q.vy * dt;
        q.rot += q.vr * dt;
        q.life -= dt;
        if (q.life <= 0) arr.splice(i, 1);
      }
    }

    function drawConfetti() {
      for (var i = 0; i < proj.particles.length; i++) {
        var q = proj.particles[i];
        c2.save();
        c2.globalAlpha = clamp(q.life / 0.55, 0, 1);
        c2.translate(q.x, q.y);
        c2.rotate(q.rot);
        c2.fillStyle = q.color;
        c2.fillRect(-q.size / 2, -q.size / 2, q.size, q.size * 0.6);
        c2.restore();
      }
      c2.globalAlpha = 1;
    }

    function updateLens(dt) {
      if (lens.pulse > 0) lens.pulse = Math.max(0, lens.pulse - dt * 1.4);
    }

    /* ---------------------------- 浮沉判断 ---------------------------- */
    function floatLayout(w, h) {
      var tankW = Math.min(w * 0.74, 460, w - 28);
      var tankH = Math.min(h * 0.76, 380, h - 30);
      if (tankW < 80) tankW = 80;
      if (tankH < 100) tankH = 100;
      var cx = w / 2;
      var tank = { x: cx - tankW / 2, y: (h - tankH) / 2 - 4, w: tankW, h: tankH };
      return {
        tank: tank,
        surfaceY: tank.y + tank.h * 0.24,
        floorY: tank.y + tank.h - 4,
        R: clamp(Math.min(tankW, tankH) * 0.095, 13, 30),
      };
    }

    function capFractionFor(f) {
      // 球冠体积占比 f = x^2(3-x)/4（x = 浸入高度 / R），二分求 x，再化为 / 直径 的比例
      f = clamp(f, 0.001, 0.999);
      var lo = 0, hi = 2, x = 1;
      for (var i = 0; i < 28; i++) {
        x = (lo + hi) / 2;
        var val = x * x * (3 - x) / 4;
        if (val < f) lo = x; else hi = x;
      }
      return x / 2;
    }

    function floatTargetY(b, lay, rl) {
      var surf = lay.surfaceY;
      var bottom = lay.floorY;
      var R = b.r;
      if (b.rho > rl * 1.02) return bottom - R;
      if (b.rho >= rl * 0.98) return lay.tank.y + lay.tank.h * 0.54;
      var f = clamp(b.rho / rl, 0.02, 1);
      var capPx = capFractionFor(f) * 2 * R;
      var cy = surf + capPx - R;
      return clamp(cy, lay.tank.y + R + 2, bottom - R);
    }

    function spawnSplash(x, y, color, n) {
      if (!motionOn) return;
      for (var i = 0; i < n; i++) {
        var a = -Math.PI / 2 + (Math.random() - 0.5) * 1.8;
        var sp = 40 + Math.random() * 130;
        fl.splash.push({
          x: x + (Math.random() - 0.5) * 16, y: y,
          vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
          life: 0.4 + Math.random() * 0.5, max: 0.9,
          color: color, size: 1.5 + Math.random() * 3,
        });
      }
    }

    function updateFloat(dt) {
      fl.wavePhase += dt * 5.5;
      if (fl.wave > 0.04) fl.wave *= Math.exp(-2.1 * dt); else fl.wave = 0;
      var i;
      for (i = fl.splash.length - 1; i >= 0; i--) {
        var p = fl.splash[i];
        p.vy += 420 * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.life -= dt;
        if (p.life <= 0) fl.splash.splice(i, 1);
      }
      var lay = floatLayout(size.w, size.h);
      var b = fl.ball;
      if (!b) return;
      b.r = lay.R;
      var rl = LIQUIDS[fl.liquid].rho;
      var target = floatTargetY(b, lay, rl);
      b.timer = b.timer || 0;
      if (b.phase === 'drop') {
        b.vy += 1500 * dt;
        b.y += b.vy * dt;
        if (!b.entered && b.y + b.r >= lay.surfaceY) {
          b.entered = true;
          fl.wave = Math.max(fl.wave, Math.min(11, 4 + b.rho * 1.4));
          fl.wavePhase = 0;
          spawnSplash(b.x, lay.surfaceY, LIQUIDS[fl.liquid].color, b.rho > rl ? 14 : 10);
          sound.splash();
        }
        if (b.y >= target) {
          b.y = target;
          b.vy = 0;
          if (!b.entered) {
            b.entered = true;
            fl.wave = Math.max(fl.wave, 7);
            spawnSplash(b.x, lay.surfaceY, LIQUIDS[fl.liquid].color, 10);
            sound.splash();
          }
          b.phase = 'settle';
          b.timer = 0;
        }
      } else {
        var k = Math.min(1, dt * (b.phase === 'settle' ? 8 : 6));
        b.y += (target - b.y) * k;
        b.timer += dt;
        if (b.phase === 'settle' && b.timer > 0.55) {
          b.phase = 'rest';
          b.timer = 0;
          b.settled = true;
        } else if (b.phase === 'rest' && b.timer > 0.55 && !b.judged) {
          judgeFloat();
        }
      }
      // 下沉气泡
      fl.bubbleAt += dt;
      if (b.rho > rl * 1.02 && fl.bubbleAt > 0.18) {
        fl.bubbleAt = 0;
        if (motionOn) {
          fl.splash.push({
            x: lay.tank.x + lay.tank.w * (0.2 + Math.random() * 0.6),
            y: lay.tank.y + lay.tank.h * (0.6 + Math.random() * 0.3),
            vx: 0, vy: -20 - Math.random() * 25, life: 0.7, max: 0.7,
            color: 'rgba(255,255,255,.35)', size: 1 + Math.random() * 2,
          });
        }
      }
    }

    function floatTargetText() {
      var cfg = levelCfg();
      return TARGET_TEXT[cfg.target] || cfg.target;
    }

    function judgeFloat() {
      var b = fl.ball;
      if (!b || b.judged) return;
      b.judged = true;
      var liq = LIQUIDS[fl.liquid];
      var rho = b.rho, rl = liq.rho;
      var sub = rho < rl ? rho / rl : 1;
      var isSink = rho > rl * 1.02;
      var isLevi = !isSink && rho >= rl * 0.98;
      var target = levelCfg().target;
      var ok = false, msg = '';
      if (target === 'levitate') {
        ok = isLevi;
        if (!ok) msg = isSink ? '下沉了：' + b.name + '的密度比' + liq.name + '大太多' : '漂浮着（浸入 ' + Math.round(sub * 100) + '%），要找密度等于液体的材料';
      } else if (target === 'half') {
        ok = !isSink && !isLevi && Math.abs(sub - 0.5) <= 0.06;
        if (!ok) msg = isSink ? '下沉了：需要 ρ物 = 0.5ρ液 的材料' : '浸入 ' + Math.round(sub * 100) + '%，还不是一半';
      } else {
        ok = isSink;
        if (!ok) msg = isLevi ? '悬浮了：要选密度更大的材料' : '漂浮着（浸入 ' + Math.round(sub * 100) + '%），密度还不够大';
      }
      if (ok) {
        combo++;
        var n = starForAttempts();
        award(n);
        fl.wave = Math.max(fl.wave, 8);
        var lay = floatLayout(size.w, size.h);
        confetti(fl.ball.x, fl.ball.y, 40);
        sound.hit();
        var where = target === 'levitate' ? '悬浮' : target === 'half' ? '半浸' : '下沉';
        toast(where + '成功！ρ物 = ' + fmt(rho, 2) + ' g/cm³ · ρ液 = ' + fmt(rl, 2) + ' g/cm³ · ' + n + ' 星', 'ok');
        // 让浮沉粒子出现在液面附近
        if (fl.ball) spawnSplash(fl.ball.x, lay.surfaceY, liq.color, 12);
      } else {
        combo = 0;
        sound.fail();
        toast('不对：' + msg, 'bad');
      }
      syncStats();
      syncPanel();
    }

    function dropMaterial(id, pt) {
      var mat = findMaterial(id);
      if (!mat) return;
      var lay = floatLayout(size.w, size.h);
      var inside;
      if (!pt) {
        pt = { x: lay.tank.x + lay.tank.w / 2, y: lay.tank.y + lay.tank.h * 0.45 };
        inside = true;
      } else {
        inside = pt.x >= lay.tank.x + 4 && pt.x <= lay.tank.x + lay.tank.w - 4 &&
          pt.y >= lay.tank.y - 24 && pt.y <= lay.tank.y + lay.tank.h + 6;
      }
      if (!inside) {
        toast('把材料球拖进液体里再松手', 'bad');
        sound.fail();
        return;
      }
      var R = lay.R;
      var x = clamp(pt.x, lay.tank.x + R + 4, lay.tank.x + lay.tank.w - R - 4);
      fl.ball = {
        rho: mat.rho, name: mat.name, color: mat.color,
        x: x, y: lay.tank.y + 10, r: R, vy: 0,
        phase: 'drop', timer: 0, entered: false, settled: false, judged: false,
      };
      attempts++;
      fl.sel = MATERIALS.indexOf(mat);
      sound.click();
      toast('', '');
      syncStats();
      syncPanel();
    }

    function setLiquid(id) {
      if (!LIQUIDS[id] || id === fl.liquid) return;
      fl.liquid = id;
      fl.wave = Math.max(fl.wave, 5);
      fl.wavePhase = 0;
      sound.click();
      if (fl.ball) {
        attempts++;
        fl.ball.phase = 'settle';
        fl.ball.timer = 0;
        fl.ball.settled = false;
        fl.ball.judged = false;
        fl.ball.entered = true;
      }
      syncStats();
      syncPanel();
    }

    /* ---------------------------- 绘制：通用 ---------------------------- */
    function render() {
      if (dead) return;
      var w = size.w, h = size.h, dpr = size.dpr;
      if (!w || !h) return;
      c2.setTransform(dpr, 0, 0, dpr, 0, 0);
      c2.clearRect(0, 0, w, h);
      drawBackdrop(w, h);
      if (mode === 'projectile-hoop') drawProjectile(w, h);
      else if (mode === 'lens-focus') drawLens(w, h);
      else drawFloat(w, h);
      drawConfetti();
    }

    function drawBackdrop(w, h) {
      var g = c2.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, '#0c1524');
      g.addColorStop(1, '#070d17');
      c2.fillStyle = g;
      c2.fillRect(0, 0, w, h);
      var rg = c2.createRadialGradient(w * 0.18, -h * 0.15, 8, w * 0.18, -h * 0.15, Math.max(w, h) * 0.95);
      rg.addColorStop(0, rgba(accent, 0.10));
      rg.addColorStop(1, rgba(accent, 0));
      c2.fillStyle = rg;
      c2.fillRect(0, 0, w, h);
      c2.fillStyle = 'rgba(148,163,184,.055)';
      var gx, gy;
      for (gx = 18; gx < w; gx += 40) {
        for (gy = 18; gy < h; gy += 40) c2.fillRect(gx, gy, 1.2, 1.2);
      }
    }

    function roundRectPath(x, y, w, h, r) {
      r = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
      c2.beginPath();
      c2.moveTo(x + r, y);
      c2.lineTo(x + w - r, y);
      c2.quadraticCurveTo(x + w, y, x + w, y + r);
      c2.lineTo(x + w, y + h - r);
      c2.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
      c2.lineTo(x + r, y + h);
      c2.quadraticCurveTo(x, y + h, x, y + h - r);
      c2.lineTo(x, y + r);
      c2.quadraticCurveTo(x, y, x + r, y);
      c2.closePath();
    }

    function arrow(x1, y1, x2, y2, color, lw) {
      c2.strokeStyle = color;
      c2.fillStyle = color;
      c2.lineWidth = lw || 2;
      c2.beginPath();
      c2.moveTo(x1, y1);
      c2.lineTo(x2, y2);
      c2.stroke();
      var a = Math.atan2(y2 - y1, x2 - x1);
      var head = 5 + (lw || 2) * 1.4;
      c2.beginPath();
      c2.moveTo(x2, y2);
      c2.lineTo(x2 - head * Math.cos(a - 0.42), y2 - head * Math.sin(a - 0.42));
      c2.lineTo(x2 - head * Math.cos(a + 0.42), y2 - head * Math.sin(a + 0.42));
      c2.closePath();
      c2.fill();
    }

    function pill(text, x, y, fg, bg, border) {
      c2.font = '600 10px ' + FONT;
      var tw = c2.measureText(text).width;
      var w = tw + 16, h = 20;
      roundRectPath(x, y, w, h, 10);
      c2.fillStyle = bg;
      c2.fill();
      if (border) {
        c2.strokeStyle = border;
        c2.lineWidth = 1;
        c2.stroke();
      }
      c2.fillStyle = fg;
      c2.textAlign = 'left';
      c2.textBaseline = 'middle';
      c2.fillText(text, x + 8, y + h / 2 + 0.5);
      c2.textBaseline = 'alphabetic';
      return w;
    }

    function sphere(cx, cy, r, color) {
      var g = c2.createRadialGradient(cx - r * 0.35, cy - r * 0.4, Math.max(1, r * 0.1), cx, cy, r * 1.05);
      g.addColorStop(0, 'rgba(255,255,255,.72)');
      g.addColorStop(0.28, rgba(color, 0.98));
      g.addColorStop(1, rgba(color, 0.72));
      c2.beginPath();
      c2.arc(cx, cy, r, 0, Math.PI * 2);
      c2.fillStyle = g;
      c2.fill();
      c2.strokeStyle = 'rgba(0,0,0,.32)';
      c2.lineWidth = 1.2;
      c2.stroke();
      c2.beginPath();
      c2.arc(cx - r * 0.32, cy - r * 0.36, r * 0.22, 0, Math.PI * 2);
      c2.fillStyle = 'rgba(255,255,255,.5)';
      c2.fill();
    }

    /* ---------------------------- 绘制：抛体 ---------------------------- */
    function drawProjectile(w, h) {
      var lay = projectileLayout(w, h);
      var L = lay.L;
      var X = lay.X, Y = lay.Y;
      var ox = lay.ox, ground = lay.ground, worldW = lay.worldW, worldH = lay.worldH;

      // 地面与网格
      var gd = c2.createLinearGradient(0, ground, 0, h);
      gd.addColorStop(0, rgba(accent, 0.11));
      gd.addColorStop(1, rgba(accent, 0));
      c2.fillStyle = gd;
      c2.fillRect(ox, ground, worldW * lay.s, h - ground);

      c2.lineWidth = 1;
      c2.strokeStyle = 'rgba(148,163,184,.12)';
      c2.font = '9px ' + FONT;
      c2.fillStyle = 'rgba(148,163,184,.48)';
      c2.textAlign = 'center';
      var step = L.d >= 14 ? 4 : 2;
      var gx, gy;
      for (gx = 0; gx <= worldW; gx += step) {
        var px = X(gx);
        if (px > ox + worldW * lay.s + 0.5) break;
        if (gx > 0) {
          c2.beginPath();
          c2.moveTo(px, Y(worldH));
          c2.lineTo(px, ground);
          c2.stroke();
          c2.fillText(String(gx), px, ground + 13);
        }
      }
      for (gy = 0; gy <= worldH; gy += 2) {
        var py = Y(gy);
        c2.beginPath();
        c2.moveTo(ox, py);
        c2.lineTo(ox + worldW * lay.s, py);
        c2.stroke();
        if (gy > 0) {
          c2.textAlign = 'right';
          c2.fillText(gy + 'm', ox - 5, py + 3);
          c2.textAlign = 'center';
        }
      }
      c2.strokeStyle = rgba(accent, 0.55);
      c2.lineWidth = 1.5;
      c2.beginPath();
      c2.moveTo(ox, ground);
      c2.lineTo(ox + worldW * lay.s, ground);
      c2.stroke();
      c2.fillStyle = 'rgba(148,163,184,.55)';
      c2.textAlign = 'left';
      c2.fillText('水平距离 / m', ox, ground + 27);

      drawHoop(lay);
      drawLaunchAim(lay);

      // 预测 / 实际轨迹
      c2.save();
      c2.beginPath();
      c2.rect(ox - 2, Math.max(0, Y(worldH) - 10), worldW * lay.s + 4, ground - Math.max(0, Y(worldH) - 10) + 46);
      c2.clip();
      var b = proj.ball;
      if (b && b.flying && proj.shotPath) {
        drawPolyline(proj.shotPath.pts, X, Y, rgba(accent, 0.28), 1.3, [5, 5]);
      } else if (proj.predicted && !(b && b.flying)) {
        drawPolyline(proj.predicted.pts, X, Y, rgba(accent, proj.aiming ? 0.85 : 0.5), proj.aiming ? 1.8 : 1.3, [6, 5]);
      }
      if (b && b.path && b.path.length > 1) {
        drawPolyline(b.path, X, Y, rgba(b.hit ? '#34d399' : accent, 0.95), 2.4, []);
      }
      if (b) {
        var bx = X(b.x), by = Y(b.y);
        c2.beginPath();
        c2.arc(bx, by, Math.max(4, Math.min(9, 0.17 * lay.s)), 0, Math.PI * 2);
        c2.fillStyle = b.hit ? '#34d399' : '#f8fafc';
        c2.fill();
        if (proj.flash > 0) {
          c2.strokeStyle = rgba('#34d399', proj.flash);
          c2.lineWidth = 2;
          c2.beginPath();
          c2.arc(bx, by, 8 + (1 - proj.flash) * 26, 0, Math.PI * 2);
          c2.stroke();
        }
      }
      // 未命中信息
      if (proj.miss) {
        if (proj.miss.landX != null) {
          var mx = X(clamp(proj.miss.landX, 0, worldW));
          c2.strokeStyle = 'rgba(251,113,133,.9)';
          c2.lineWidth = 2;
          c2.beginPath();
          c2.moveTo(mx - 6, ground - 6);
          c2.lineTo(mx + 6, ground + 6);
          c2.moveTo(mx + 6, ground - 6);
          c2.lineTo(mx - 6, ground + 6);
          c2.stroke();
          c2.fillStyle = 'rgba(251,113,133,.9)';
          c2.font = '9px ' + FONT;
          c2.textAlign = 'center';
          c2.fillText('落点 ' + fmt(proj.miss.landX, 1) + ' m', mx, ground + 27);
        }
        if (proj.miss.planeY != null && proj.miss.planeY >= 0) {
          var hy = Y(proj.miss.planeY);
          c2.strokeStyle = 'rgba(251,113,133,.55)';
          c2.setLineDash([4, 4]);
          c2.lineWidth = 1.2;
          c2.beginPath();
          c2.moveTo(X(L.d), Y(L.h));
          c2.lineTo(X(L.d), hy);
          c2.stroke();
          c2.setLineDash([]);
          c2.beginPath();
          c2.arc(X(L.d), hy, 4, 0, Math.PI * 2);
          c2.stroke();
        }
      }
      c2.restore();
    }

    function drawPolyline(pts, X, Y, color, lw, dash) {
      if (!pts || pts.length < 2) return;
      c2.save();
      c2.beginPath();
      for (var i = 0; i < pts.length; i++) {
        var p = pts[i];
        if (!p) continue;
        if (i === 0) c2.moveTo(X(p[0]), Y(p[1]));
        else c2.lineTo(X(p[0]), Y(p[1]));
      }
      c2.setLineDash(dash || []);
      c2.strokeStyle = color;
      c2.lineWidth = lw;
      c2.lineJoin = 'round';
      c2.lineCap = 'round';
      c2.stroke();
      c2.restore();
    }

    function drawHoop(lay) {
      var L = lay.L;
      var X = lay.X, Y = lay.Y, s = lay.s;
      var bx = X(L.d), by = Y(L.h);
      var poleX = X(L.d + 1.15);
      c2.strokeStyle = 'rgba(245,158,11,.5)';
      c2.lineWidth = 3;
      c2.beginPath();
      c2.moveTo(poleX, lay.ground);
      c2.lineTo(poleX, Y(L.h + 0.85));
      c2.stroke();
      c2.lineWidth = 2.5;
      c2.beginPath();
      c2.moveTo(poleX, Y(L.h + 0.28));
      c2.lineTo(bx + Math.max(3, 0.45 * s), Y(L.h + 0.28));
      c2.stroke();
      // 篮板
      var bw = Math.max(4, 0.09 * s), bh = Math.max(20, 0.95 * s);
      c2.fillStyle = 'rgba(226,232,240,.13)';
      c2.strokeStyle = 'rgba(226,232,240,.42)';
      c2.lineWidth = 1.2;
      roundRectPath(bx + 0.5 * s, by - 0.5 * s, bw, bh, 2);
      c2.fill();
      c2.stroke();
      // 篮筐
      var rx = Math.max(8, HOOP_R * s);
      var ry = Math.max(2.5, HOOP_R * s * 0.26);
      c2.beginPath();
      c2.ellipse(bx, by, rx, ry, 0, 0, Math.PI * 2);
      c2.fillStyle = 'rgba(245,158,11,.14)';
      c2.fill();
      c2.strokeStyle = '#f59e0b';
      c2.lineWidth = Math.max(2, 0.055 * s);
      c2.stroke();
      // 网
      c2.strokeStyle = 'rgba(245,158,11,.45)';
      c2.lineWidth = 1;
      for (var i = -2; i <= 2; i++) {
        var fx = bx + rx * (i / 2.6);
        c2.beginPath();
        c2.moveTo(fx, by + ry * 0.3);
        c2.lineTo(bx + fx * 0.42, by + Math.max(12, 0.34 * s));
        c2.stroke();
      }
      c2.fillStyle = 'rgba(245,158,11,.85)';
      c2.font = '600 9px ' + FONT;
      c2.textAlign = 'left';
      c2.fillText('筐高 ' + fmt(L.h, 1) + ' m', bx + rx + 8, by - 8);
      if (proj.flash > 0) {
        c2.strokeStyle = rgba('#34d399', proj.flash * 0.9);
        c2.lineWidth = 2;
        c2.beginPath();
        c2.arc(bx, by, 12 + (1 - proj.flash) * 44, 0, Math.PI * 2);
        c2.stroke();
      }
    }

    function drawLaunchAim(lay) {
      var X = lay.X, Y = lay.Y;
      var lx = X(0), ly = Y(LAUNCH_H);
      // 支架
      c2.fillStyle = 'rgba(148,163,184,.22)';
      c2.fillRect(lx - 3, ly, 6, lay.ground - ly);
      // 炮管
      c2.save();
      c2.translate(lx, ly);
      c2.rotate(-proj.angle * Math.PI / 180);
      c2.fillStyle = '#1d3f5c';
      c2.strokeStyle = rgba(accent, 0.8);
      c2.lineWidth = 1.5;
      roundRectPath(-4, -7, 36, 14, 6);
      c2.fill();
      c2.stroke();
      c2.fillStyle = rgba(accent, 0.95);
      roundRectPath(27, -4, 7, 8, 3);
      c2.fill();
      c2.restore();

      // 拖拽手柄
      var pulse = proj.aiming ? 1 : 0.62 + 0.18 * Math.sin(time * 3);
      c2.beginPath();
      c2.arc(lx, ly, 16, 0, Math.PI * 2);
      c2.fillStyle = 'rgba(8,14,24,.7)';
      c2.fill();
      c2.strokeStyle = rgba(accent, pulse);
      c2.lineWidth = 2;
      c2.stroke();
      c2.beginPath();
      c2.arc(lx, ly, 4, 0, Math.PI * 2);
      c2.fillStyle = rgba(accent, 0.95);
      c2.fill();
      c2.fillStyle = 'rgba(148,163,184,.75)';
      c2.font = '9px ' + FONT;
      c2.textAlign = 'center';
      c2.fillText('拖我瞄准', lx, ly + 30);

      if (proj.aiming) {
        c2.save();
        c2.setLineDash([5, 4]);
        c2.strokeStyle = rgba(accent, 0.75);
        c2.lineWidth = 1.5;
        c2.beginPath();
        c2.moveTo(lx, ly);
        c2.lineTo(proj.dragX, proj.dragY);
        c2.stroke();
        c2.restore();
        // 力度环
        var frac = clamp((proj.v0 - V_MIN) / (V_MAX - V_MIN), 0, 1);
        c2.strokeStyle = rgba(accent, 0.9);
        c2.lineWidth = 3;
        c2.beginPath();
        c2.arc(lx, ly, 23, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * frac);
        c2.stroke();
        c2.strokeStyle = 'rgba(255,255,255,.14)';
        c2.lineWidth = 1;
        c2.beginPath();
        c2.arc(lx, ly, 23, 0, Math.PI * 2);
        c2.stroke();
        var txt = Math.round(proj.angle) + '° · ' + fmt(proj.v0, 1) + ' m/s';
        c2.font = '600 11px ' + FONT;
        var tw = c2.measureText(txt).width;
        var bx = clamp(proj.dragX + 14, 4, size.w - tw - 20);
        var by = clamp(proj.dragY - 28, 6, size.h - 26);
        roundRectPath(bx, by, tw + 14, 22, 8);
        c2.fillStyle = 'rgba(8,14,24,.9)';
        c2.fill();
        c2.strokeStyle = rgba(accent, 0.6);
        c2.lineWidth = 1;
        c2.stroke();
        c2.fillStyle = '#e8eff9';
        c2.textAlign = 'left';
        c2.fillText(txt, bx + 7, by + 15);
      }
    }

    /* ---------------------------- 绘制：调焦 ---------------------------- */
    function drawLens(w, h) {
      var lay = lensLayout(w, h);
      var L = lay.L;
      var s = lay.s, lensX = lay.lensX, midY = lay.midY, railY = lay.railY;
      var objX = lay.objX, screenX = lay.screenX;
      var img = lensImage();
      var v = img.v;
      var diff = isFinite(v) ? Math.abs(v - lens.vScreen) : Infinity;
      var sharp = isFinite(diff) && diff <= LENS_TOL;

      // 光具座
      c2.fillStyle = 'rgba(148,163,184,.09)';
      c2.fillRect(lay.startX - 12, railY, lay.total + 24, 7);
      c2.strokeStyle = 'rgba(148,163,184,.32)';
      c2.lineWidth = 1;
      c2.beginPath();
      c2.moveTo(lay.startX - 12, railY + 0.5);
      c2.lineTo(lay.startX + lay.total + 12, railY + 0.5);
      c2.stroke();
      c2.font = '8px ' + FONT;
      c2.fillStyle = 'rgba(148,163,184,.55)';
      c2.textAlign = 'center';
      var startCm = -Math.ceil(L.uMax / 10) * 10;
      for (var cm = startCm; cm <= L.vMax; cm += 10) {
        var tx = lensX + cm * s;
        if (tx < lay.startX - 8 || tx > lay.startX + lay.total + 8) continue;
        var major = cm % 20 === 0;
        c2.strokeStyle = major ? 'rgba(148,163,184,.4)' : 'rgba(148,163,184,.2)';
        c2.beginPath();
        c2.moveTo(tx, railY);
        c2.lineTo(tx, railY + (major ? 10 : 6));
        c2.stroke();
        if (major) c2.fillText(cm === 0 ? '0' : String(cm), tx, railY + 21);
      }
      c2.fillStyle = 'rgba(148,163,184,.5)';
      c2.fillText('光具座 / cm（0 = 透镜位置）', lensX, railY + 33);

      // 主光轴
      c2.strokeStyle = rgba(accent, 0.28);
      c2.setLineDash([6, 5]);
      c2.lineWidth = 1;
      c2.beginPath();
      c2.moveTo(lay.startX - 10, midY);
      c2.lineTo(lay.startX + lay.total + 10, midY);
      c2.stroke();
      c2.setLineDash([]);

      // 焦点
      drawFocusMarks(lay);

      // 物体
      drawLensObject(lay);

      // 光屏
      drawScreen(lay, sharp);

      // 三条特殊光线 + 像
      if (isFinite(v) && v > 0) drawRaysAndImage(lay, img);

      // 透镜
      drawLensShape(lay);

      // 弥散圆
      drawBlur(lay, img);

      // 顶部/底部读数
      c2.font = '600 10.5px ' + FONT;
      c2.textAlign = 'left';
      c2.fillStyle = 'rgba(226,232,240,.9)';
      c2.fillText('凸透镜 f = ' + fmt(L.f, 1) + ' cm', 12, 16);
      c2.fillStyle = 'rgba(148,163,184,.75)';
      c2.fillText('u = ' + fmt(lens.u, 1) + ' cm   v = ' + (isFinite(v) ? fmt(v, 1) : '∞') + ' cm   放大 ' + (isFinite(img.mag) ? fmt(img.mag, 2) + '×' : '—'), 12, 30);
      c2.textAlign = 'right';
      c2.fillStyle = 'rgba(148,163,184,.75)';
      c2.fillText('步数 ' + attempts + ' / ' + L.steps + ' · 偏差 ' + (isFinite(diff) ? fmt(diff, 1) + ' cm' : '—'), w - 12, 16);
      if (lens.solved) {
        c2.fillStyle = '#34d399';
        c2.fillText('✓ 已调清晰', w - 12, 30);
      } else if (lens.failed) {
        c2.fillStyle = 'rgba(251,113,133,.9)';
        c2.fillText('步数已用尽', w - 12, 30);
      }
    }

    function drawFocusMarks(lay) {
      var s = lay.s, lensX = lay.lensX, midY = lay.midY;
      var f = lens.f;
      var marks = [
        { x: lensX - 2 * f * s, label: '2F', side: -1 },
        { x: lensX - f * s, label: 'F', side: -1 },
        { x: lensX + f * s, label: 'F', side: 1 },
        { x: lensX + 2 * f * s, label: '2F', side: 1 },
      ];
      c2.font = '9px ' + FONT;
      c2.textAlign = 'center';
      for (var i = 0; i < marks.length; i++) {
        var m = marks[i];
        if (m.x < lay.startX - 10 || m.x > lay.startX + lay.total + 10) continue;
        c2.fillStyle = 'rgba(167,139,250,.9)';
        c2.beginPath();
        c2.arc(m.x, midY, 2.6, 0, Math.PI * 2);
        c2.fill();
        c2.fillStyle = 'rgba(167,139,250,.75)';
        c2.fillText(m.label, m.x, midY + (m.side < 0 ? -7 : 14));
      }
    }

    function drawLensShape(lay) {
      var lensX = lay.lensX, midY = lay.midY, half = lay.lensHalf;
      c2.save();
      c2.translate(lensX, midY);
      c2.beginPath();
      c2.moveTo(0, -half);
      c2.bezierCurveTo(13, -half * 0.45, 13, half * 0.45, 0, half);
      c2.bezierCurveTo(-13, half * 0.45, -13, -half * 0.45, 0, -half);
      c2.fillStyle = rgba(accent, 0.10);
      c2.fill();
      c2.strokeStyle = rgba(accent, 0.95);
      c2.lineWidth = 2.6;
      c2.stroke();
      c2.strokeStyle = rgba(accent, 0.3);
      c2.lineWidth = 1;
      c2.beginPath();
      c2.moveTo(0, -half + 6);
      c2.lineTo(0, half - 6);
      c2.stroke();
      c2.restore();
      c2.fillStyle = rgba(accent, 0.9);
      c2.font = '600 9.5px ' + FONT;
      c2.textAlign = 'center';
      c2.fillText('f = ' + fmt(lay.L.f, 1) + ' cm', lensX, midY - lay.lensHalf - 9);
    }

    function drawLensObject(lay) {
      var objX = lay.objX, midY = lay.midY, oh = lay.objH;
      // 底座
      c2.fillStyle = 'rgba(148,163,184,.28)';
      c2.fillRect(objX - 13, midY + 4, 26, 5);
      c2.fillRect(objX - 2, midY + 8, 4, lay.railY - midY - 8);
      // 箭头物体
      c2.strokeStyle = '#f8fafc';
      c2.lineWidth = 2.4;
      c2.beginPath();
      c2.moveTo(objX, midY);
      c2.lineTo(objX, midY - oh);
      c2.stroke();
      c2.beginPath();
      c2.moveTo(objX - 5, midY - oh + 9);
      c2.lineTo(objX, midY - oh);
      c2.lineTo(objX + 5, midY - oh + 9);
      c2.stroke();
      // 手柄
      c2.beginPath();
      c2.arc(objX, midY + 16, 8, 0, Math.PI * 2);
      c2.fillStyle = 'rgba(8,14,24,.8)';
      c2.fill();
      c2.strokeStyle = rgba(accent, 0.9);
      c2.lineWidth = 1.5;
      c2.stroke();
      c2.fillStyle = rgba(accent, 0.95);
      c2.beginPath();
      c2.arc(objX, midY + 16, 2.4, 0, Math.PI * 2);
      c2.fill();
      // 标签
      c2.fillStyle = 'rgba(226,232,240,.92)';
      c2.font = '600 9.5px ' + FONT;
      c2.textAlign = 'center';
      c2.fillText('物体', objX, midY - oh - 8);
      c2.fillStyle = 'rgba(148,163,184,.8)';
      c2.font = '9px ' + FONT;
      c2.fillText('u = ' + fmt(lens.u, 1) + ' cm', objX, midY + 32);
      // 左右拖动提示
      c2.strokeStyle = rgba(accent, 0.3);
      c2.lineWidth = 1;
      c2.beginPath();
      c2.moveTo(objX - 24, midY + 16);
      c2.lineTo(objX - 12, midY + 16);
      c2.moveTo(objX + 12, midY + 16);
      c2.lineTo(objX + 24, midY + 16);
      c2.stroke();
    }

    function drawScreen(lay, sharp) {
      var screenX = lay.screenX, midY = lay.midY, sh = lay.screenHalf;
      // 支架
      c2.fillStyle = 'rgba(148,163,184,.28)';
      c2.fillRect(screenX - 2, midY + sh, 4, lay.railY - midY - sh);
      c2.fillRect(screenX - 13, lay.railY - 4, 26, 5);
      // 屏面
      var glow = c2.createLinearGradient(screenX - 30, 0, screenX + 30, 0);
      glow.addColorStop(0, 'rgba(226,232,240,0)');
      glow.addColorStop(0.5, sharp ? 'rgba(52,211,153,.16)' : 'rgba(226,232,240,.07)');
      glow.addColorStop(1, 'rgba(226,232,240,0)');
      c2.fillStyle = glow;
      c2.fillRect(screenX - 32, midY - sh - 8, 64, sh * 2 + 16);
      c2.fillStyle = 'rgba(226,232,240,.2)';
      c2.fillRect(screenX - 3.5, midY - sh, 7, sh * 2);
      c2.strokeStyle = sharp ? '#34d399' : 'rgba(226,232,240,.48)';
      c2.lineWidth = sharp ? 2.4 : 1.4;
      c2.strokeRect(screenX - 30, midY - sh - 6, 60, sh * 2 + 12);
      // 手柄
      c2.beginPath();
      c2.arc(screenX, midY + sh + 18, 8, 0, Math.PI * 2);
      c2.fillStyle = 'rgba(8,14,24,.8)';
      c2.fill();
      c2.strokeStyle = sharp ? '#34d399' : rgba(accent, 0.9);
      c2.lineWidth = 1.5;
      c2.stroke();
      c2.fillStyle = sharp ? '#34d399' : rgba(accent, 0.95);
      c2.beginPath();
      c2.arc(screenX, midY + sh + 18, 2.4, 0, Math.PI * 2);
      c2.fill();
      // 标签
      c2.textAlign = 'center';
      c2.font = '600 9.5px ' + FONT;
      c2.fillStyle = sharp ? '#34d399' : 'rgba(226,232,240,.85)';
      c2.fillText('光屏', screenX, midY - sh - 13);
      c2.fillStyle = 'rgba(148,163,184,.8)';
      c2.font = '9px ' + FONT;
      c2.fillText('v屏 = ' + fmt(lens.vScreen, 1) + ' cm', screenX, midY + sh + 36);
    }

    function drawRaysAndImage(lay, img) {
      var v = img.v;
      if (!isFinite(v) || v <= 0) return;
      var s = lay.s, lensX = lay.lensX, midY = lay.midY;
      var objX = lay.objX, oh = lay.objH;
      var imgX = lensX + v * s;
      var imgH = clamp(oh * Math.abs(v / lens.u), 0, layoutMaxH(lay));
      var topX = objX, topY = midY - oh;
      var tipX = imgX, tipY = midY + imgH;
      var fy = midY + (lens.u > lens.f ? oh * lens.f / (lens.u - lens.f) : 0);

      c2.save();
      c2.beginPath();
      c2.rect(lay.startX - 16, 4, lay.total + 32, lay.railY - 8);
      c2.clip();
      c2.strokeStyle = rgba(accent, 0.34);
      c2.lineWidth = 1;
      // 平行光线
      c2.beginPath();
      c2.moveTo(topX, topY);
      c2.lineTo(lensX, topY);
      c2.lineTo(tipX, tipY);
      c2.stroke();
      // 过光心
      c2.beginPath();
      c2.moveTo(topX, topY);
      c2.lineTo(lensX, midY);
      c2.lineTo(tipX, tipY);
      c2.stroke();
      // 过焦点光线
      c2.beginPath();
      c2.moveTo(topX, topY);
      c2.lineTo(lensX, fy);
      c2.lineTo(tipX, fy);
      c2.stroke();
      c2.restore();

      // 像
      if (imgX < lay.startX - 30 || imgX > lay.startX + lay.total + 30) {
        c2.fillStyle = 'rgba(52,211,153,.85)';
        c2.font = '9px ' + FONT;
        c2.textAlign = 'right';
        c2.fillText('像在光屏外', lay.startX + lay.total + 24, midY - 8);
        return;
      }
      c2.save();
      c2.strokeStyle = 'rgba(52,211,153,.9)';
      c2.lineWidth = 2;
      c2.setLineDash([]);
      c2.beginPath();
      c2.moveTo(imgX, midY);
      c2.lineTo(imgX, midY + imgH);
      c2.stroke();
      c2.beginPath();
      c2.moveTo(imgX - 5, midY + imgH - 9);
      c2.lineTo(imgX, midY + imgH);
      c2.lineTo(imgX + 5, midY + imgH - 9);
      c2.stroke();
      c2.fillStyle = 'rgba(52,211,153,.85)';
      c2.font = '9px ' + FONT;
      c2.textAlign = 'center';
      c2.fillText('像', imgX + 12, midY + imgH + 4);
      c2.restore();
    }

    function layoutMaxH(lay) {
      return Math.max(40, lay.railY - lay.midY - 16);
    }

    function drawBlur(lay, img) {
      var screenX = lay.screenX, midY = lay.midY;
      var diff = isFinite(img.v) ? Math.abs(img.v - lens.vScreen) : 99;
      var sharp = diff <= LENS_TOL;
      var br = clamp(diff * lay.s * 0.9, 2, 48);
      if (!sharp && br > 2.5) {
        var g = c2.createRadialGradient(screenX, midY, 0, screenX, midY, br);
        g.addColorStop(0, 'rgba(226,232,240,.5)');
        g.addColorStop(0.55, 'rgba(148,163,184,.18)');
        g.addColorStop(1, 'rgba(148,163,184,0)');
        c2.fillStyle = g;
        c2.beginPath();
        c2.arc(screenX, midY, br, 0, Math.PI * 2);
        c2.fill();
      } else if (sharp) {
        c2.fillStyle = '#e2e8f0';
        c2.beginPath();
        c2.arc(screenX, midY, 2.6, 0, Math.PI * 2);
        c2.fill();
        if (lens.pulse > 0) {
          c2.strokeStyle = rgba('#34d399', lens.pulse);
          c2.lineWidth = 2;
          c2.beginPath();
          c2.arc(screenX, midY, 8 + (1 - lens.pulse) * 40, 0, Math.PI * 2);
          c2.stroke();
        }
      }
      // 弥散圆读数
      c2.font = '9px ' + FONT;
      c2.textAlign = 'center';
      c2.fillStyle = sharp ? 'rgba(52,211,153,.9)' : 'rgba(148,163,184,.8)';
      c2.fillText(sharp ? '清晰' : '弥散圆 ⌀' + fmt(br * 2, 0) + ' px', screenX, midY + lay.screenHalf + 52);
    }

    /* ---------------------------- 绘制：浮沉 ---------------------------- */
    function drawFloat(w, h) {
      var lay = floatLayout(w, h);
      var tank = lay.tank, surfaceY = lay.surfaceY, floorY = lay.floorY;
      var liq = LIQUIDS[fl.liquid];
      var b = fl.ball;

      // 平台阴影
      c2.fillStyle = 'rgba(0,0,0,.28)';
      c2.beginPath();
      c2.ellipse(tank.x + tank.w / 2, tank.y + tank.h + 8, tank.w * 0.46, 8, 0, 0, Math.PI * 2);
      c2.fill();

      // 液体
      c2.save();
      roundRectPath(tank.x, tank.y, tank.w, tank.h, 12);
      c2.clip();
      var lg = c2.createLinearGradient(0, surfaceY, 0, floorY);
      lg.addColorStop(0, rgba(liq.color, 0.30));
      lg.addColorStop(1, rgba(liq.color, 0.12));
      c2.fillStyle = lg;
      c2.fillRect(tank.x, surfaceY, tank.w, tank.h - (surfaceY - tank.y));
      // 波动液面
      c2.beginPath();
      c2.moveTo(tank.x, surfaceY + 20);
      var amp = fl.wave;
      for (var x = tank.x; x <= tank.x + tank.w + 2; x += 6) {
        var y = surfaceY + Math.sin((x - tank.x) * 0.05 + fl.wavePhase) * amp +
          Math.sin((x - tank.x) * 0.11 + fl.wavePhase * 1.6) * amp * 0.35;
        c2.lineTo(x, y);
      }
      c2.lineTo(tank.x + tank.w, surfaceY + 20);
      c2.closePath();
      c2.fillStyle = rgba(liq.color, 0.30);
      c2.fill();
      c2.strokeStyle = rgba(liq.color, 0.85);
      c2.lineWidth = 1.6;
      c2.beginPath();
      for (var x2 = tank.x; x2 <= tank.x + tank.w + 2; x2 += 6) {
        var y2 = surfaceY + Math.sin((x2 - tank.x) * 0.05 + fl.wavePhase) * amp +
          Math.sin((x2 - tank.x) * 0.11 + fl.wavePhase * 1.6) * amp * 0.35;
        if (x2 === tank.x) c2.moveTo(x2, y2); else c2.lineTo(x2, y2);
      }
      c2.stroke();
      // 玻璃高光
      var gl = c2.createLinearGradient(tank.x, 0, tank.x + tank.w, 0);
      gl.addColorStop(0, 'rgba(255,255,255,.07)');
      gl.addColorStop(0.18, 'rgba(255,255,255,0)');
      gl.addColorStop(0.85, 'rgba(255,255,255,0)');
      gl.addColorStop(1, 'rgba(255,255,255,.05)');
      c2.fillStyle = gl;
      c2.fillRect(tank.x, tank.y, tank.w, tank.h);
      c2.restore();

      // 容器
      roundRectPath(tank.x, tank.y, tank.w, tank.h, 12);
      c2.strokeStyle = 'rgba(226,232,240,.42)';
      c2.lineWidth = 2.4;
      c2.stroke();
      c2.strokeStyle = 'rgba(255,255,255,.12)';
      c2.lineWidth = 1;
      roundRectPath(tank.x + 5, tank.y + 5, tank.w - 10, tank.h - 10, 9);
      c2.stroke();
      // 刻度
      c2.font = '8px ' + FONT;
      c2.fillStyle = 'rgba(226,232,240,.4)';
      c2.textAlign = 'left';
      for (var k = 1; k <= 4; k++) {
        var ty = surfaceY + (floorY - surfaceY) * (k / 5);
        c2.beginPath();
        c2.moveTo(tank.x + 8, ty);
        c2.lineTo(tank.x + (k % 2 === 0 ? 18 : 14), ty);
        c2.strokeStyle = 'rgba(226,232,240,.28)';
        c2.stroke();
        if (k % 2 === 0) c2.fillText(k * 200 + ' mL', tank.x + 22, ty + 3);
      }

      // 球体（含浸入部分着色）
      if (b) {
        var bob = b.phase === 'rest' ? Math.sin(time * 2.1) * (b.rho < LIQUIDS[fl.liquid].rho ? 1.6 : 0.5) : 0;
        var bx = b.x, by = b.y + bob;
        sphere(bx, by, b.r, b.color);
        // 浸入部分着色
        c2.save();
        c2.beginPath();
        c2.arc(bx, by, b.r, 0, Math.PI * 2);
        c2.clip();
        c2.fillStyle = rgba(liq.color, 0.28);
        c2.fillRect(tank.x, surfaceY, tank.w, tank.h);
        c2.restore();
        // 球上文字
        c2.fillStyle = 'rgba(8,14,24,.82)';
        c2.font = '700 ' + clamp(b.r * 0.52, 9, 14) + 'px ' + FONT;
        c2.textAlign = 'center';
        c2.textBaseline = 'middle';
        c2.fillText(b.name, bx, by - 1);
        c2.font = '8px ' + FONT;
        c2.fillStyle = 'rgba(8,14,24,.6)';
        c2.fillText(fmt(b.rho, 1), bx, by + Math.max(9, b.r * 0.42));
        c2.textBaseline = 'alphabetic';
      }

      // 受力箭头
      if (b) {
        var rl0 = LIQUIDS[fl.liquid].rho;
        var subFrac0 = b.rho < rl0 ? b.rho / rl0 : 1;
        var cy = b.y + (b.phase === 'rest' ? Math.sin(time * 2.1) * (b.rho < rl0 ? 1.6 : 0.5) : 0);
        var glen = clamp(14 + b.rho * 6, 18, 58);
        var flen = clamp(10 + rl0 * subFrac0 * 9, 12, 58);
        var ax = b.x - b.r - 12;
        arrow(ax, cy, ax, cy + glen, '#f59e0b', 1.8);
        c2.fillStyle = '#f59e0b';
        c2.font = '600 9px ' + FONT;
        c2.textAlign = 'right';
        c2.fillText('G', ax - 3, cy + glen + 3);
        arrow(b.x + b.r + 12, cy, b.x + b.r + 12, cy - flen, '#38bdf8', 1.8);
        c2.fillStyle = '#38bdf8';
        c2.textAlign = 'left';
        c2.fillText('F浮', b.x + b.r + 16, cy - flen - 3);
      }

      // 水花
      for (var i = 0; i < fl.splash.length; i++) {
        var p = fl.splash[i];
        c2.globalAlpha = clamp(p.life / p.max, 0, 1);
        c2.fillStyle = p.color;
        c2.beginPath();
        c2.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        c2.fill();
      }
      c2.globalAlpha = 1;

      // 顶部标签
      c2.textAlign = 'left';
      c2.font = '600 10.5px ' + FONT;
      c2.fillStyle = 'rgba(226,232,240,.9)';
      c2.fillText('液体：' + liq.name + ' ρ液 = ' + fmt(liq.rho, 2) + ' g/cm³', tank.x, tank.y - 10);
      c2.textAlign = 'right';
      c2.fillStyle = rgba(accent, 0.9);
      c2.fillText('目标：' + floatTargetText(), tank.x + tank.w, tank.y - 10);

      // 底部读数
      c2.textAlign = 'left';
      c2.font = '9.5px ' + FONT;
      c2.fillStyle = 'rgba(148,163,184,.8)';
      var subTxt = '—';
      if (b) {
        var rl = LIQUIDS[fl.liquid].rho;
        var sub = b.rho < rl ? b.rho / rl : 1;
        subTxt = 'ρ物 = ' + fmt(b.rho, 2) + ' · 浸入 ' + Math.round(sub * 100) + '% · ' + verdictOf(b.rho, rl);
      }
      c2.fillText(subTxt, tank.x, floorY + 20);
    }

    /* ---------------------------- Pointer 事件 ---------------------------- */
    function onPointerDown(e) {
      if (dead) return;
      sound.ensure();
      try { canvas.focus({ preventScroll: true }); } catch (err) { try { canvas.focus(); } catch (e2) { /* 忽略 */ } }
      try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件可能没有活动指针 */ }
      var pt = canvasPoint(e.clientX, e.clientY);
      if (mode === 'projectile-hoop') {
        if (proj.ball && proj.ball.flying) return;
        proj.aiming = true;
        proj.pointerId = e.pointerId;
        proj.dragLen = 0;
        updateAim(pt);
        e.preventDefault();
      } else if (mode === 'lens-focus') {
        if (startLensDrag(pt, e.pointerId)) e.preventDefault();
      } else {
        var lay = floatLayout(size.w, size.h);
        if (pt.x > lay.tank.x && pt.x < lay.tank.x + lay.tank.w && pt.y > lay.tank.y && pt.y < lay.tank.y + lay.tank.h) {
          fl.wave = Math.max(fl.wave, 4);
          fl.wavePhase = 0;
        }
      }
    }

    function onPointerMove(e) {
      if (dead) return;
      if (mode === 'projectile-hoop' && proj.aiming && e.pointerId === proj.pointerId) {
        updateAim(canvasPoint(e.clientX, e.clientY));
        e.preventDefault();
      } else if (mode === 'lens-focus' && lens.drag && e.pointerId === lens.drag.pointerId) {
        moveLensDrag(canvasPoint(e.clientX, e.clientY));
        e.preventDefault();
      }
    }

    function onPointerUp(e) {
      if (dead) return;
      if (mode === 'projectile-hoop' && proj.aiming && e.pointerId === proj.pointerId) {
        proj.aiming = false;
        proj.pointerId = -1;
        if (proj.dragLen > 14) launch();
        else {
          proj.predicted = simulateProjectile(proj.angle, proj.v0, levelCfg().d);
          syncPanel();
        }
      } else if (mode === 'lens-focus' && lens.drag && e.pointerId === lens.drag.pointerId) {
        endLensDrag(true);
      }
      try { canvas.releasePointerCapture(e.pointerId); } catch (err) { /* 忽略 */ }
    }

    function onPointerCancel(e) {
      if (dead) return;
      if (mode === 'projectile-hoop' && proj.aiming) {
        proj.aiming = false;
        proj.pointerId = -1;
        syncPanel();
      } else if (mode === 'lens-focus' && lens.drag) {
        endLensDrag(false);
      }
    }

    /* ---------------------------- 材料架拖拽 ---------------------------- */
    function showGhost(mat, x, y) {
      removeGhost();
      ghost = document.createElement('div');
      ghost.className = 'psw-gm-ghost';
      ghost.style.background =
        'radial-gradient(circle at 32% 26%, rgba(255,255,255,.8), rgba(255,255,255,0) 42%),' +
        'radial-gradient(circle at 70% 78%, rgba(0,0,0,.55), rgba(0,0,0,0) 58%),' +
        mat.color;
      ghost.style.left = x + 'px';
      ghost.style.top = y + 'px';
      document.body.appendChild(ghost);
    }
    function moveGhost(x, y) {
      if (!ghost) return;
      ghost.style.left = x + 'px';
      ghost.style.top = y + 'px';
    }
    function removeGhost() {
      if (ghost && ghost.parentNode) ghost.parentNode.removeChild(ghost);
      ghost = null;
    }

    function onMatPointerDown(e) {
      var btn = closest(e.target, '[data-mat]');
      if (!btn) return;
      if (e.button != null && e.button !== 0) return;
      sound.ensure();
      e.preventDefault();
      var mat = findMaterial(btn.getAttribute('data-mat'));
      if (!mat) return;
      var pid = e.pointerId;
      try { btn.setPointerCapture(pid); } catch (err) { /* 合成事件没有活动指针 */ }
      showGhost(mat, e.clientX, e.clientY);
      var startX = e.clientX, startY = e.clientY, moved = false;

      function onMove(ev) {
        if (ev.pointerId !== pid) return;
        if (Math.abs(ev.clientX - startX) + Math.abs(ev.clientY - startY) > 5) moved = true;
        moveGhost(ev.clientX, ev.clientY);
        ev.preventDefault();
      }
      function finish(ev, cancelled) {
        if (ev.pointerId !== pid) return;
        btn.removeEventListener('pointermove', onMove);
        btn.removeEventListener('pointerup', onUp);
        btn.removeEventListener('pointercancel', onCancel);
        removeGhost();
        try { btn.releasePointerCapture(pid); } catch (err) { /* 忽略 */ }
        lastMatPointerAt = nowMs();
        if (cancelled) return;
        if (!moved) dropMaterial(mat.id, null);
        else dropMaterial(mat.id, canvasPoint(ev.clientX, ev.clientY));
      }
      function onUp(ev) { finish(ev, false); }
      function onCancel(ev) { finish(ev, true); }
      btn.addEventListener('pointermove', onMove);
      btn.addEventListener('pointerup', onUp);
      btn.addEventListener('pointercancel', onCancel);
    }

    /* ---------------------------- 点击 / 键盘 ---------------------------- */
    function onClick(e) {
      if (dead) return;
      sound.ensure();
      var t = e.target;
      var mb = closest(t, '[data-mode]');
      if (mb) { setMode(mb.getAttribute('data-mode')); return; }
      var lb = closest(t, '[data-lv]');
      if (lb) {
        var n = clamp(parseInt(lb.getAttribute('data-lv'), 10) || 0, 0, 2);
        if (n !== lv) {
          lv = n;
          resetLevel();
          sound.ensure();
          sound.click();
        }
        return;
      }
      if (closest(t, '[data-mute]')) {
        muted = !muted;
        sound.setMuted(muted);
        sound.ensure();
        if (!muted) sound.click();
        syncStats();
        return;
      }
      var act = closest(t, '[data-act]');
      if (act) {
        var a = act.getAttribute('data-act');
        if (a === 'launch') launch();
        else if (a === 'reset') { resetLevel(); sound.ensure(); sound.click(); }
        return;
      }
      var liqBtn = closest(t, '[data-liquid]');
      if (liqBtn) { sound.ensure(); setLiquid(liqBtn.getAttribute('data-liquid')); return; }
      var matBtn = closest(t, '[data-mat]');
      if (matBtn) {
        // 键盘触发的 click（detail === 0）才直接投放，指针路径由 pointerup 处理
        if (e.detail === 0 || nowMs() - lastMatPointerAt > 600) dropMaterial(matBtn.getAttribute('data-mat'), null);
      }
    }

    function onKeyDown(e) {
      if (dead) return;
      var tag = (e.target && e.target.tagName) || '';
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || tag === 'BUTTON') return;
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      sound.ensure();
      var k = e.key;
      var handled = true;
      if (mode === 'projectile-hoop') {
        if (k === 'ArrowLeft') proj.angle = clamp(proj.angle - (e.shiftKey ? 5 : 1), ANG_MIN, ANG_MAX);
        else if (k === 'ArrowRight') proj.angle = clamp(proj.angle + (e.shiftKey ? 5 : 1), ANG_MIN, ANG_MAX);
        else if (k === 'ArrowUp') proj.v0 = clamp(proj.v0 + (e.shiftKey ? 2 : 0.5), V_MIN, V_MAX);
        else if (k === 'ArrowDown') proj.v0 = clamp(proj.v0 - (e.shiftKey ? 2 : 0.5), V_MIN, V_MAX);
        else if (k === ' ' || k === 'Enter') launch();
        else handled = false;
        if (handled) {
          e.preventDefault();
          sound.ensure();
          sound.tick();
          if (k !== ' ' && k !== 'Enter') {
            proj.predicted = simulateProjectile(proj.angle, proj.v0, levelCfg().d);
            syncPanel();
          }
        }
      } else if (mode === 'lens-focus') {
        if (k === 'ArrowLeft') lensKeyAdjust('u', e.shiftKey ? 2 : 0.5);
        else if (k === 'ArrowRight') lensKeyAdjust('u', e.shiftKey ? -2 : -0.5);
        else if (k === 'ArrowUp') lensKeyAdjust('screen', e.shiftKey ? 2 : 0.5);
        else if (k === 'ArrowDown') lensKeyAdjust('screen', e.shiftKey ? -2 : -0.5);
        else handled = false;
        if (handled) e.preventDefault();
      } else {
        if (k === 'ArrowLeft') { fl.sel = (fl.sel + MATERIALS.length - 1) % MATERIALS.length; syncPanel(); sound.tick(); }
        else if (k === 'ArrowRight') { fl.sel = (fl.sel + 1) % MATERIALS.length; syncPanel(); sound.tick(); }
        else if (k === 'ArrowUp' || k === 'ArrowDown') {
          var ids = ['water', 'alcohol', 'salt'];
          var idx = ids.indexOf(fl.liquid);
          idx = (idx + (k === 'ArrowUp' ? 1 : ids.length - 1)) % ids.length;
          setLiquid(ids[idx]);
        } else if (k === ' ' || k === 'Enter') dropMaterial(MATERIALS[fl.sel].id, null);
        else handled = false;
        if (handled) { e.preventDefault(); sound.ensure(); }
      }
    }

    /* ---------------------------- 主循环 ---------------------------- */
    function update(dt) {
      time += dt;
      updateConfetti(dt);
      if (mode === 'projectile-hoop') updateProjectile(dt);
      else if (mode === 'lens-focus') updateLens(dt);
      else updateFloat(dt);
    }

    function loop(ts) {
      if (dead) return;
      var dt = last ? Math.min(0.05, (ts - last) / 1000) : 0.016;
      last = ts;
      update(dt);
      render();
      raf = requestAnimationFrame(loop);
    }

    /* ---------------------------- 绑定 ---------------------------- */
    buildTop();
    buildPanel();
    resetLevel();
    measure();

    canvas.addEventListener('pointerdown', onPointerDown);
    canvas.addEventListener('pointermove', onPointerMove);
    canvas.addEventListener('pointerup', onPointerUp);
    canvas.addEventListener('pointercancel', onPointerCancel);
    ui.addEventListener('click', onClick);
    ui.addEventListener('pointerdown', onMatPointerDown);
    ui.addEventListener('keydown', onKeyDown);
    canvas.style.cursor = mode === 'lens-focus' ? 'grab' : mode === 'float-sink' ? 'default' : 'crosshair';

    var ro = null;
    if (window.ResizeObserver) {
      ro = new ResizeObserver(measure);
      ro.observe(canvas);
      ro.observe(ui);
    }
    window.addEventListener('resize', measure);

    raf = requestAnimationFrame(loop);

    return {
      destroy: function () {
        if (dead) return;
        dead = true;
        cancelAnimationFrame(raf);
        raf = 0;
        if (ro) { try { ro.disconnect(); } catch (e) { /* 忽略 */ } ro = null; }
        window.removeEventListener('resize', measure);
        if (toastTimer) { clearTimeout(toastTimer); toastTimer = 0; }
        removeGhost();
        sound.destroy();
        canvas.removeEventListener('pointerdown', onPointerDown);
        canvas.removeEventListener('pointermove', onPointerMove);
        canvas.removeEventListener('pointerup', onPointerUp);
        canvas.removeEventListener('pointercancel', onPointerCancel);
        ui.removeEventListener('click', onClick);
        ui.removeEventListener('pointerdown', onMatPointerDown);
        ui.removeEventListener('keydown', onKeyDown);
        if (ui.parentNode) ui.parentNode.removeChild(ui);
      },
      resize: measure,
      setParams: function (p) {
        if (dead || !p) return;
        var changed = false;
        if (p.mode && LEVELS[p.mode] && p.mode !== mode) {
          mode = p.mode;
          lv = 0;
          updateModeButtons();
          buildPanel();
          changed = true;
        }
        if (p.level != null) {
          var n = clamp(parseInt(p.level, 10) || 0, 0, 2);
          if (n !== lv) { lv = n; changed = true; }
        }
        if (changed) {
          removeGhost();
          resetLevel();
          canvas.style.cursor = mode === 'lens-focus' ? 'grab' : mode === 'float-sink' ? 'default' : 'crosshair';
        }
      },
    };
  }

  PS.game = {
    title: '物理闯关',
    defaults: { mode: 'projectile-hoop', level: 0 },
    mount: mount,
  };
})();