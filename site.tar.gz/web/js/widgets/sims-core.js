/*!
 * 悟理智课 · sims-core.js
 * 零依赖交互控件：斜抛运动 / 斜面摩擦 / 滑轮组 / 凸透镜成像 / 串并联电路
 * 契约 v1：window.PSWidgets[key] = { title, defaults, mount(root, params, ctx) }
 * 全部使用 Canvas 2D 绘制，无外部图片、字体与 CDN。
 */
(function () {
  'use strict';

  var PS = window.PSWidgets = window.PSWidgets || {};
  var FONT = '"Microsoft YaHei", "PingFang SC", system-ui, sans-serif';
  var MONO = 'Consolas, "SFMono-Regular", ui-monospace, "Courier New", monospace';
  var GRAV = 9.8;

  /* ======================================================================
   * 基础工具
   * ==================================================================== */

  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function num(v, d) { var n = parseFloat(v); return isFinite(n) ? n : d; }
  function fmt(v, d) {
    if (!isFinite(v)) return '—';
    if (d == null) d = 1;
    var p = Math.pow(10, d);
    var r = Math.round(v * p) / p;
    if (r === 0) r = 0;
    return r.toFixed(d);
  }
  function rgba(color, a) {
    if (typeof color !== 'string') return 'rgba(56,189,248,' + a + ')';
    var m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(color.replace(/\s/g, ''));
    if (!m) return color;
    var hx = m[1];
    if (hx.length === 3) hx = hx.charAt(0) + hx.charAt(0) + hx.charAt(1) + hx.charAt(1) + hx.charAt(2) + hx.charAt(2);
    var n = parseInt(hx, 16);
    return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }
  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return c === '&' ? '&amp;' : c === '<' ? '&lt;' : c === '>' ? '&gt;' : '&quot;';
    });
  }
  function themeOf(ctx) {
    var t = (ctx && ctx.theme) || {};
    return {
      accent: t.accent || '#38bdf8',
      bg: t.bg || '#0b1220',
      fg: t.fg || '#e2e8f0',
      muted: t.muted || '#94a3b8',
      grid: t.grid || 'rgba(148,163,184,.18)'
    };
  }

  /* ======================================================================
   * 样式（只注入一次）
   * ==================================================================== */

  var CSS = [
    '.psw-shell{position:absolute;inset:0;display:flex;align-items:stretch;background:#0b1220;color:#e2e8f0;',
    'font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif;overflow:hidden;border-radius:inherit;--psw-acc:#38bdf8}',
    '.psw-shell *{box-sizing:border-box}',
    '.psw-shell button{font-family:inherit}',
    '.psw-panel{flex:0 0 auto;width:clamp(150px,23%,262px);display:flex;flex-direction:column;gap:10px;',
    'padding:13px 12px 11px;background:linear-gradient(180deg,rgba(15,23,42,.94),rgba(9,15,27,.97));',
    'border-right:1px solid rgba(255,255,255,.07);overflow-y:auto;overflow-x:hidden;',
    'scrollbar-width:thin;scrollbar-color:rgba(148,163,184,.32) transparent}',
    '.psw-panel::-webkit-scrollbar{width:6px}',
    '.psw-panel::-webkit-scrollbar-thumb{background:rgba(148,163,184,.28);border-radius:3px}',
    '.psw-head{flex:0 0 auto}',
    '.psw-title{position:relative;padding-left:10px;font-size:14.5px;font-weight:600;letter-spacing:.5px;color:#f1f5f9;line-height:1.35}',
    '.psw-title::before{content:"";position:absolute;left:0;top:3px;bottom:3px;width:3px;border-radius:2px;',
    'background:var(--psw-acc);box-shadow:0 0 10px var(--psw-acc)}',
    '.psw-sub{margin-top:4px;font-size:10.5px;line-height:1.5;color:#94a3b8}',
    '.psw-ctrl-group{display:flex;flex-direction:column;gap:10px;flex:0 0 auto}',
    '.psw-ctrl{display:flex;flex-direction:column;gap:2px;min-width:0}',
    '.psw-row{display:flex;align-items:baseline;justify-content:space-between;gap:6px;min-width:0}',
    '.psw-label{font-size:11px;line-height:1.4;color:#cbd5e1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.psw-val{font-family:' + MONO + ';font-size:10.5px;line-height:1.4;color:var(--psw-acc);',
    'font-variant-numeric:tabular-nums;white-space:nowrap}',
    '.psw-range{-webkit-appearance:none;appearance:none;display:block;width:100%;height:16px;margin:2px 0 0;',
    'background:transparent;cursor:pointer}',
    '.psw-range:focus{outline:none}',
    '.psw-range::-webkit-slider-runnable-track{height:4px;border-radius:2px;background:rgba(148,163,184,.22)}',
    '.psw-range::-webkit-slider-thumb{-webkit-appearance:none;width:13px;height:13px;margin-top:-4.5px;',
    'border-radius:50%;background:#f8fafc;border:2px solid var(--psw-acc);',
    'box-shadow:0 0 0 3px rgba(56,189,248,.12),0 2px 5px rgba(0,0,0,.5)}',
    '.psw-range:focus-visible::-webkit-slider-thumb{box-shadow:0 0 0 4px rgba(56,189,248,.34)}',
    '.psw-range::-moz-range-track{height:4px;border-radius:2px;background:rgba(148,163,184,.22)}',
    '.psw-range::-moz-range-thumb{width:13px;height:13px;border-radius:50%;background:#f8fafc;',
    'border:2px solid var(--psw-acc);box-shadow:0 2px 5px rgba(0,0,0,.5)}',
    '.psw-actions{display:flex;gap:6px;flex-wrap:wrap}',
    '.psw-btn{appearance:none;display:inline-flex;align-items:center;justify-content:center;',
    'border:1px solid rgba(255,255,255,.11);background:rgba(148,163,184,.10);color:#cbd5e1;',
    'font-size:11px;line-height:1.2;padding:7px 8px;border-radius:9px;cursor:pointer;flex:1 1 40%;',
    'white-space:nowrap;transition:background .16s,border-color .16s,color .16s,filter .16s}',
    '.psw-btn:hover{background:rgba(148,163,184,.18);color:#f1f5f9}',
    '.psw-btn:active{transform:translateY(1px)}',
    '.psw-btn:disabled{opacity:.45;cursor:default;transform:none}',
    '.psw-btn.primary{background:linear-gradient(180deg,var(--psw-acc),#1d9fd6);border-color:transparent;',
    'color:#04121d;font-weight:600;box-shadow:0 4px 14px rgba(56,189,248,.22)}',
    '.psw-btn.primary:hover{filter:brightness(1.06);color:#04121d}',
    '.psw-btn.ghost{background:transparent}',
    '.psw-btn.toggle-on{background:rgba(56,189,248,.14);border-color:rgba(56,189,248,.38);color:#f1f5f9}',
    '.psw-btn.wide{flex:1 1 100%}',
    '.psw-seg{display:flex;gap:2px;padding:2px;border-radius:9px;background:rgba(8,14,26,.85);',
    'border:1px solid rgba(255,255,255,.08)}',
    '.psw-seg button{flex:1 1 0;min-width:0;appearance:none;border:0;background:transparent;color:#94a3b8;',
    'font-size:10.5px;line-height:1.2;padding:5px 2px;border-radius:7px;cursor:pointer;transition:background .15s,color .15s}',
    '.psw-seg button:hover{color:#e2e8f0}',
    '.psw-seg button[aria-pressed="true"]{background:rgba(56,189,248,.16);color:#f1f5f9;',
    'box-shadow:inset 0 0 0 1px rgba(56,189,248,.34)}',
    '.psw-chips{display:grid;grid-template-columns:1fr 1fr;gap:4px}',
    '.psw-chip{appearance:none;border:1px solid rgba(255,255,255,.08);background:rgba(148,163,184,.06);',
    'color:#94a3b8;font-size:9.5px;line-height:1.2;padding:4px 2px;border-radius:6px;cursor:pointer;white-space:nowrap}',
    '.psw-chip:hover{color:#e2e8f0;border-color:rgba(56,189,248,.4)}',
    '.psw-chip[aria-pressed="true"]{background:rgba(56,189,248,.16);color:#e2e8f0;border-color:rgba(56,189,248,.45)}',
    '.psw-alert{display:none;font-size:10px;line-height:1.55;color:#fca5a5;background:rgba(248,113,113,.08);',
    'border:1px solid rgba(248,113,113,.26);border-radius:8px;padding:6px 8px}',
    '.psw-alert.show{display:block}',
    '.psw-note{font-size:9.5px;line-height:1.55;color:#64748b}',
    '.psw-formula{margin-top:auto;padding-top:9px;border-top:1px dashed rgba(255,255,255,.08);',
    'font-size:9.5px;line-height:1.65;color:#94a3b8;flex:0 0 auto}',
    '.psw-formula b{color:#cbd5e1;font-weight:600}',
    '.psw--tight .psw-panel{gap:8px;padding:10px 10px 8px}',
    '.psw--tight .psw-ctrl-group{gap:8px}',
    '.psw--tight .psw-sub,.psw--tight .psw-note,.psw--tight .psw-formula{display:none}',
    '.psw-stage{position:relative;flex:1 1 auto;min-width:0;min-height:0;overflow:hidden;background:#0b1220}',
    '.psw-canvas{position:absolute;inset:0;display:block;width:100%;height:100%}',
    '.psw-hud{position:absolute;top:10px;right:10px;z-index:2;min-width:calc(152px * var(--psw-dk,1));max-width:46%;padding:8px 10px;',
    'border-radius:12px;background:rgba(2,6,23,.58);border:1px solid rgba(255,255,255,.08);',
    '-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);box-shadow:0 10px 28px rgba(0,0,0,.35);',
    'pointer-events:none}',
    '.psw-hud-t{display:flex;justify-content:space-between;gap:12px;margin-bottom:4px;',
    'font-size:calc(9px * var(--psw-dk,1));letter-spacing:1.3px;color:#64748b}',
    '.psw-hud-row{display:flex;justify-content:space-between;gap:12px;',
    'font-size:calc(10.5px * var(--psw-dk,1));line-height:1.6}',
    '.psw-hud-k{color:#94a3b8;white-space:nowrap}',
    '.psw-hud-v{font-family:' + MONO + ';color:#e2e8f0;white-space:nowrap;font-variant-numeric:tabular-nums}',
    '.psw-hud-v.acc{color:var(--psw-acc)}',
    '.psw-hud-v.warn{color:#f87171}',
    '.psw-hud-v.good{color:#34d399}',
    '.psw-hud-foot{margin-top:5px;padding-top:5px;border-top:1px solid rgba(255,255,255,.07);',
    'font-size:calc(9px * var(--psw-dk,1));line-height:1.45;color:#94a3b8;white-space:normal;word-break:break-word}',
    '.psw-badge{position:absolute;left:10px;top:10px;z-index:2;display:inline-flex;align-items:center;gap:6px;',
    'max-width:62%;padding:4px 10px;border-radius:999px;background:rgba(2,6,23,.62);',
    'border:1px solid rgba(255,255,255,.08);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);',
    'font-size:calc(10px * var(--psw-dk,1));line-height:1.4;color:#cbd5e1;pointer-events:none;white-space:nowrap;overflow:hidden;',
    'text-overflow:ellipsis}',
    '.psw-badge-dot{flex:0 0 auto;width:6px;height:6px;border-radius:50%;background:var(--psw-acc);',
    'box-shadow:0 0 8px var(--psw-acc)}',
    '.psw-badge--ok .psw-badge-dot{background:#34d399;box-shadow:0 0 8px #34d399}',
    '.psw-badge--warn .psw-badge-dot{background:#f87171;box-shadow:0 0 8px #f87171}',
    '.psw-badge--info .psw-badge-dot{background:var(--psw-acc);box-shadow:0 0 8px var(--psw-acc)}'
  ].join('');

  function injectStyle(name, css) {
    var sel = 'style[data-psw-style="' + name + '"]';
    if (document.querySelector(sel)) return;
    var st = document.createElement('style');
    st.setAttribute('data-psw-style', name);
    st.appendChild(document.createTextNode(css));
    (document.head || document.documentElement).appendChild(st);
  }

  /* ======================================================================
   * DOM 外壳 / 读数卡 / 状态徽标
   * ==================================================================== */

  function makeShell(root, th, opt) {
    root.style.position = 'relative';
    clear(root);
    var wrap = el('div', 'psw-shell');
    wrap.style.setProperty('--psw-acc', th.accent);
    var panel = el('div', 'psw-panel');
    var head = el('div', 'psw-head');
    head.appendChild(el('div', 'psw-title', opt.title));
    if (opt.sub) head.appendChild(el('div', 'psw-sub', opt.sub));
    panel.appendChild(head);
    var body = el('div', 'psw-ctrl-group');
    panel.appendChild(body);
    if (opt.formula) {
      var f = el('div', 'psw-formula');
      f.innerHTML = opt.formula;
      panel.appendChild(f);
    }
    var stage = el('div', 'psw-stage');
    wrap.appendChild(panel);
    wrap.appendChild(stage);
    root.appendChild(wrap);
    return { wrap: wrap, panel: panel, body: body, stage: stage, formula: null, root: root, _tight: false };
  }

  // 小尺寸下收起副标题/提示/公式，保证参数与按钮无需滚动即可操作
  function setTight(sh, h) {
    var tight = h < 430;
    if (sh._tight !== tight) {
      sh._tight = tight;
      sh.wrap.classList.toggle('psw--tight', tight);
    }
    var dk = Math.round(clamp(h / 360, 0.9, 1.25) * 100) / 100;
    if (sh._dk !== dk) {
      sh._dk = dk;
      sh.wrap.style.setProperty('--psw-dk', String(dk));
    }
  }

  function hudCtl(host) {
    var box = el('div', 'psw-hud');
    host.appendChild(box);
    var last = '';
    return {
      set: function (rows, foot) {
        var sig = '', i;
        for (i = 0; i < rows.length; i++) sig += rows[i].join('\u0001') + '\u0002';
        sig += foot || '';
        if (sig === last) return;
        last = sig;
        var html = '<div class="psw-hud-t"><span>实时读数</span><span>LIVE</span></div>';
        for (i = 0; i < rows.length; i++) {
          var r = rows[i];
          html += '<div class="psw-hud-row"><span class="psw-hud-k">' + esc(r[0]) +
            '</span><span class="psw-hud-v ' + (r[2] || '') + '">' + esc(r[1]) + '</span></div>';
        }
        if (foot) html += '<div class="psw-hud-foot">' + esc(foot) + '</div>';
        box.innerHTML = html;
      },
      destroy: function () { if (box.parentNode) box.parentNode.removeChild(box); }
    };
  }

  function badgeCtl(host) {
    var box = el('div', 'psw-badge');
    host.appendChild(box);
    var last = '';
    return {
      set: function (text, kind) {
        var sig = text + '|' + (kind || '');
        if (sig === last) return;
        last = sig;
        box.className = 'psw-badge' + (kind ? ' psw-badge--' + kind : '');
        box.innerHTML = '<span class="psw-badge-dot"></span><span>' + esc(text) + '</span>';
      }
    };
  }

  /* ======================================================================
   * 动画舞台：DPR + ResizeObserver + rAF + 后台暂停
   * ==================================================================== */

  function makeStage(host, onDraw) {
    var canvas = el('canvas', 'psw-canvas');
    host.appendChild(canvas);
    var c2 = canvas.getContext('2d');
    var st = { w: 0, h: 0, dpr: 1, time: 0, run: true, dead: false, raf: 0, last: 0 };

    function measure() {
      var rect = host.getBoundingClientRect();
      var w = Math.max(2, Math.round(rect.width || 1));
      var h = Math.max(2, Math.round(rect.height || 1));
      var dpr = clamp(window.devicePixelRatio || 1, 1, 3);
      if (w === st.w && h === st.h && dpr === st.dpr) return false;
      st.w = w; st.h = h; st.dpr = dpr;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      return true;
    }

    function frame(ts) {
      st.raf = 0;
      if (st.dead || !st.run) return;
      var dt = st.last ? clamp((ts - st.last) / 1000, 0, 0.05) : 0;
      st.last = ts;
      st.time += dt;
      measure();
      c2.setTransform(st.dpr, 0, 0, st.dpr, 0, 0);
      c2.__psK = clamp(Math.min(st.w, st.h) / 360, 0.9, 1.5);
      c2.clearRect(0, 0, st.w, st.h);
      onDraw(c2, dt, st.time, st.w, st.h);
      if (!st.dead && st.run) st.raf = window.requestAnimationFrame(frame);
    }

    function start() {
      if (st.dead || st.raf) return;
      st.run = true;
      st.last = 0;
      st.raf = window.requestAnimationFrame(frame);
    }

    function stop() {
      st.run = false;
      if (st.raf) window.cancelAnimationFrame(st.raf);
      st.raf = 0;
      st.last = 0;
    }

    function onVis() {
      if (st.dead) return;
      if (document.hidden) stop();
      else start();
    }

    document.addEventListener('visibilitychange', onVis);
    var ro = null;
    if (window.ResizeObserver) {
      ro = new ResizeObserver(function () { if (!st.dead) measure(); });
      ro.observe(host);
    }
    window.addEventListener('resize', measure);
    measure();
    start();

    return {
      get w() { return st.w; },
      get h() { return st.h; },
      pause: stop,
      resume: start,
      destroy: function () {
        st.dead = true;
        stop();
        document.removeEventListener('visibilitychange', onVis);
        window.removeEventListener('resize', measure);
        if (ro) { try { ro.disconnect(); } catch (e) {} }
        if (canvas.parentNode) canvas.parentNode.removeChild(canvas);
      }
    };
  }

  /* ======================================================================
   * Canvas 绘制辅助
   * ==================================================================== */

  function roundRect(c2, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2));
    c2.beginPath();
    c2.moveTo(x + r, y);
    c2.arcTo(x + w, y, x + w, y + h, r);
    c2.arcTo(x + w, y + h, x, y + h, r);
    c2.arcTo(x, y + h, x, y, r);
    c2.arcTo(x, y, x + w, y, r);
    c2.closePath();
  }

  function line(c2, x1, y1, x2, y2, o) {
    o = o || {};
    c2.save();
    c2.strokeStyle = o.color || 'rgba(148,163,184,.45)';
    c2.lineWidth = o.width || 1;
    c2.lineCap = o.cap || 'round';
    c2.setLineDash(o.dash || []);
    if (o.glow) { c2.shadowColor = o.glowColor || o.color || '#38bdf8'; c2.shadowBlur = o.glow; }
    c2.beginPath();
    c2.moveTo(x1, y1);
    c2.lineTo(x2, y2);
    c2.stroke();
    c2.restore();
  }

  function arrow(c2, x1, y1, x2, y2, o) {
    o = o || {};
    var col = o.color || '#38bdf8';
    var dx = x2 - x1, dy = y2 - y1;
    var len = Math.sqrt(dx * dx + dy * dy);
    if (!isFinite(len) || len < 0.6) return;
    var ux = dx / len, uy = dy / len;
    var k = c2.__psK || 1;
    var head = Math.min((o.head || 8) * k, len * 0.7);
    var bx = x2 - ux * head, by = y2 - uy * head;
    c2.save();
    c2.strokeStyle = col;
    c2.fillStyle = col;
    c2.lineWidth = (o.width || 2) * Math.min(k, 1.25);
    c2.lineCap = 'round';
    c2.setLineDash(o.dash || []);
    if (o.glow) { c2.shadowColor = col; c2.shadowBlur = o.glow; }
    c2.beginPath();
    c2.moveTo(x1, y1);
    c2.lineTo(bx, by);
    c2.stroke();
    c2.setLineDash([]);
    var px = -uy * head * 0.42, py = ux * head * 0.42;
    c2.beginPath();
    c2.moveTo(x2, y2);
    c2.lineTo(bx + px, by + py);
    c2.lineTo(bx - px, by - py);
    c2.closePath();
    c2.fill();
    c2.restore();
  }

  function txt(c2, str, x, y, o) {
    o = o || {};
    var k = c2.__psK || 1;
    c2.save();
    c2.font = (o.weight || 500) + ' ' + ((o.size || 12) * k) + 'px ' + (o.mono ? MONO : FONT);
    c2.fillStyle = o.color || '#e2e8f0';
    c2.textAlign = o.align || 'left';
    c2.textBaseline = o.base || 'alphabetic';
    if (o.halo !== false) {
      c2.strokeStyle = 'rgba(2,6,23,.85)';
      c2.lineWidth = (o.haloW || 3) * k;
      c2.lineJoin = 'round';
      c2.strokeText(str, x, y);
    }
    c2.fillText(str, x, y);
    c2.restore();
  }

  function dot(c2, x, y, r, color, glow) {
    c2.save();
    if (glow) { c2.shadowColor = color; c2.shadowBlur = glow; }
    c2.fillStyle = color;
    c2.beginPath();
    c2.arc(x, y, r, 0, Math.PI * 2);
    c2.fill();
    c2.restore();
  }

  function backdrop(c2, w, h, th) {
    var g = c2.createLinearGradient(0, 0, w * 0.6, h);
    g.addColorStop(0, '#0d1728');
    g.addColorStop(0.55, th.bg);
    g.addColorStop(1, '#070d18');
    c2.fillStyle = g;
    c2.fillRect(0, 0, w, h);
    var r = c2.createRadialGradient(w * 0.18, h * 0.05, 0, w * 0.18, h * 0.05, Math.max(w, h) * 0.72);
    r.addColorStop(0, rgba(th.accent, 0.12));
    r.addColorStop(1, 'rgba(0,0,0,0)');
    c2.fillStyle = r;
    c2.fillRect(0, 0, w, h);
    var v = c2.createRadialGradient(w * 0.5, h * 0.5, Math.min(w, h) * 0.18, w * 0.5, h * 0.5, Math.max(w, h) * 0.76);
    v.addColorStop(0, 'rgba(0,0,0,0)');
    v.addColorStop(1, 'rgba(0,0,0,.42)');
    c2.fillStyle = v;
    c2.fillRect(0, 0, w, h);
  }

  function hatch(c2, x, y, w, h, gap, color) {
    c2.save();
    c2.strokeStyle = color || 'rgba(148,163,184,.2)';
    c2.lineWidth = 1;
    for (var i = -h; i < w; i += gap) {
      c2.beginPath();
      c2.moveTo(x + i, y + h);
      c2.lineTo(x + i + h, y);
      c2.stroke();
    }
    c2.restore();
  }

  /* ======================================================================
   * 表单控件
   * ==================================================================== */

  function mkSlider(parent, o) {
    var wrap = el('div', 'psw-ctrl');
    var row = el('div', 'psw-row');
    var label = el('span', 'psw-label', o.label);
    var val = el('span', 'psw-val');
    row.appendChild(label);
    row.appendChild(val);
    var input = document.createElement('input');
    input.type = 'range';
    input.className = 'psw-range';
    input.min = String(o.min);
    input.max = String(o.max);
    input.step = String(o.step);
    input.value = String(o.value);
    input.setAttribute('aria-label', o.aria || o.label);
    wrap.appendChild(row);
    wrap.appendChild(input);
    parent.appendChild(wrap);
    var printer = o.format || function (v) {
      return fmt(v, o.digits == null ? 1 : o.digits) + (o.unit ? ' ' + o.unit : '');
    };
    function paint() { val.textContent = printer(parseFloat(input.value)); }
    function handle() {
      paint();
      if (o.onInput) o.onInput(parseFloat(input.value));
    }
    input.addEventListener('input', handle);
    paint();
    return {
      el: wrap,
      input: input,
      get value() { return parseFloat(input.value); },
      set: function (v) { input.value = String(v); paint(); },
      paint: paint
    };
  }

  function mkSeg(parent, o) {
    var wrap = el('div', 'psw-ctrl');
    if (o.label) {
      var row = el('div', 'psw-row');
      row.appendChild(el('span', 'psw-label', o.label));
      wrap.appendChild(row);
    }
    var seg = el('div', 'psw-seg');
    seg.setAttribute('role', 'group');
    seg.setAttribute('aria-label', o.aria || o.label || '选项');
    var btns = [];
    var cur = o.value;
    o.options.forEach(function (opt) {
      var b = document.createElement('button');
      b.type = 'button';
      b.textContent = opt.label;
      b.setAttribute('aria-pressed', String(opt.value === cur));
      b.addEventListener('click', function () {
        if (cur === opt.value) return;
        cur = opt.value;
        for (var i = 0; i < btns.length; i++) {
          btns[i].setAttribute('aria-pressed', String(btns[i].getAttribute('data-v') === String(cur)));
        }
        if (o.onChange) o.onChange(opt.value);
      });
      b.setAttribute('data-v', String(opt.value));
      btns.push(b);
      seg.appendChild(b);
    });
    wrap.appendChild(seg);
    parent.appendChild(wrap);
    return {
      el: wrap,
      get value() { return cur; },
      set: function (v) {
        cur = v;
        for (var i = 0; i < btns.length; i++) {
          btns[i].setAttribute('aria-pressed', String(btns[i].getAttribute('data-v') === String(cur)));
        }
      }
    };
  }

  function mkBtn(parent, text, kind, onClick, aria) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'psw-btn' + (kind ? ' ' + kind : '');
    b.textContent = text;
    if (aria) b.setAttribute('aria-label', aria);
    b.addEventListener('click', onClick);
    parent.appendChild(b);
    return b;
  }

  function mkChips(parent, items, onPick) {
    var box = el('div', 'psw-chips');
    var btns = [];
    items.forEach(function (it) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'psw-chip';
      b.textContent = it.label;
      b.setAttribute('aria-pressed', 'false');
      b.addEventListener('click', function () {
        for (var i = 0; i < btns.length; i++) btns[i].setAttribute('aria-pressed', String(btns[i] === b));
        onPick(it);
      });
      btns.push(b);
      box.appendChild(b);
    });
    parent.appendChild(box);
    return { el: box, clear: function () { for (var i = 0; i < btns.length; i++) btns[i].setAttribute('aria-pressed', 'false'); } };
  }

  injectStyle('sims-core', CSS);

  /* ======================================================================
   * 1. 斜抛运动
   * ==================================================================== */

  function mountProjectile(root, params, ctx) {
    params = params || {};
    var th = themeOf(ctx);
    var MOTION = !(ctx && ctx.motion === false);
    var sh = makeShell(root, th, {
      title: '斜抛运动',
      sub: '初速度与抛射角决定轨迹 · g = 9.8 m/s²',
      formula: '<b>位置</b> x = v₀cosθ·t，y = v₀sinθ·t − ½gt²<br>' +
        '<b>射程</b> R = v₀²sin2θ / g<br><b>最高点</b> H = (v₀sinθ)² / 2g'
    });
    var hud = hudCtl(sh.stage);
    var badge = badgeCtl(sh.stage);

    var p = {
      v0: clamp(num(params.v0, 20), 5, 40),
      angle: clamp(num(params.angle, 45), 5, 85),
      g: clamp(num(params.g, GRAV), 1, 30)
    };
    var target = null;
    if (params.target && isFinite(parseFloat(params.target.x)) && isFinite(parseFloat(params.target.y))) {
      target = {
        x: Math.max(0.5, parseFloat(params.target.x)),
        y: Math.max(0.5, parseFloat(params.target.y)),
        r: clamp(num(params.target.r, 2), 0.5, 12)
      };
    }

    var st = { t: 0, flying: false, landed: false, after: 0, hit: false, hitT: 0, ghosts: [] };

    function calc() {
      var rad = p.angle * Math.PI / 180;
      var vx = p.v0 * Math.cos(rad);
      var vy = p.v0 * Math.sin(rad);
      var tf = 2 * vy / p.g;
      return {
        rad: rad, vx: vx, vy: vy, tf: tf,
        R: vx * tf, H: vy * vy / (2 * p.g)
      };
    }

    function sample(d, n) {
      var arr = [];
      for (var i = 0; i <= n; i++) {
        var t = d.tf * i / n;
        arr.push([d.vx * t, d.vy * t - 0.5 * p.g * t * t]);
      }
      return arr;
    }

    function reset(clearGhosts) {
      st.flying = false;
      st.landed = false;
      st.after = 0;
      st.t = 0;
      st.hit = false;
      st.hitT = 0;
      if (clearGhosts) st.ghosts.length = 0;
    }

    function fire() {
      var d = calc();
      if (st.t > 0.001 && st.t < d.tf - 1e-6) {
        st.ghosts.push({ pts: sample(d, 70), a: 0.7, flying: true });
        if (st.ghosts.length > 3) st.ghosts.shift();
      }
      st.t = 0;
      st.flying = true;
      st.landed = false;
      st.after = 0;
      st.hit = false;
      st.hitT = 0;
    }

    var sV0 = mkSlider(sh.body, {
      label: '初速度 v₀', min: 5, max: 40, step: 0.5, value: p.v0, unit: 'm/s', digits: 1,
      onInput: function (v) { p.v0 = v; reset(false); }
    });
    var sAng = mkSlider(sh.body, {
      label: '抛射角 θ', min: 5, max: 85, step: 1, value: p.angle, unit: '°', digits: 0,
      onInput: function (v) { p.angle = v; reset(false); }
    });

    var acts = el('div', 'psw-actions');
    sh.body.appendChild(acts);
    var bFire = mkBtn(acts, '发 射', 'primary', fire, '发射小球');
    var bReset = mkBtn(acts, '重置', 'ghost', function () { reset(true); bFire.focus(); }, '清除轨迹并重置');
    var note = el('div', 'psw-note', target
      ? '目标环坐标 (' + fmt(target.x, 0) + ', ' + fmt(target.y, 0) + ') m · 命中即高亮'
      : '提示：传入 params.target = {x, y} 可显示目标环并判定命中。');
    sh.body.appendChild(note);

    var stage = makeStage(sh.stage, function (c2, dt, time, w, h) {
      var d = calc();

      /* ---------------- 物理推进 ---------------- */
      if (MOTION && st.flying) {
        var t0 = st.t;
        st.t = Math.min(d.tf, st.t + dt);
        if (target) {
          for (var k = 1; k <= 6; k++) {
            var ts = t0 + (st.t - t0) * k / 6;
            var xh = d.vx * ts;
            var yh = d.vy * ts - 0.5 * p.g * ts * ts;
            if (Math.sqrt((xh - target.x) * (xh - target.x) + (yh - target.y) * (yh - target.y)) <= target.r) {
              st.hit = true;
            }
          }
        }
        if (st.t >= d.tf - 1e-9) {
          st.t = d.tf;
          st.flying = false;
          st.landed = true;
          st.after = 0;
          st.ghosts.push({ pts: sample(d, 90), a: 1 });
          if (st.ghosts.length > 3) st.ghosts.shift();
        }
      } else if (MOTION && st.landed) {
        st.after += dt;
      }
      if (MOTION && st.hit) st.hitT += dt;

      var tt = st.t;
      var bx = d.vx * tt;
      var by = Math.max(0, d.vy * tt - 0.5 * p.g * tt * tt);
      var vx = d.vx;
      var vy = d.vy - p.g * tt;
      var spd = Math.sqrt(vx * vx + vy * vy);

      /* ---------------- 坐标与比例尺 ---------------- */
      var padL = clamp(w * 0.10, 40, 72);
      var padR = clamp(w * 0.07, 18, 52);
      var groundY = h - clamp(h * 0.12, 26, 46);
      var topPad = clamp(h * 0.10, 22, 54);
      var availW = Math.max(30, w - padL - padR);
      var availH = Math.max(30, groundY - topPad);
      var xNeed = Math.max(d.R, target ? target.x + target.r : 0, 1);
      var yNeed = Math.max(d.H, target ? target.y + target.r : 0, 1);
      var scale = Math.min(availW / (xNeed * 1.12), availH / (yNeed * 1.28));
      if (!isFinite(scale) || scale <= 0.01) scale = 1;
      var ox = padL, oy = groundY;
      function PX(x) { return ox + x * scale; }
      function PY(y) { return oy - y * scale; }

      var gridStep = 5;
      while (gridStep * scale < 18) gridStep *= 2;

      /* ---------------- 背景与网格 ---------------- */
      setTight(sh, h);
      backdrop(c2, w, h, th);

      c2.save();
      c2.strokeStyle = th.grid;
      c2.lineWidth = 1;
      var cellPx = gridStep * scale;
      var labelEvery = Math.max(1, Math.ceil(38 / Math.max(8, cellPx)));
      var idx = 0, gx;
      for (gx = 0; PX(gx) <= w - 6; gx += gridStep, idx++) {
        var px = PX(gx);
        c2.globalAlpha = (idx % 5 === 0) ? 0.95 : 0.5;
        c2.beginPath();
        c2.moveTo(px, groundY);
        c2.lineTo(px, 4);
        c2.stroke();
      }
      idx = 0;
      for (var gy = gridStep; PY(gy) > 4; gy += gridStep) {
        var py = PY(gy);
        c2.globalAlpha = (idx % 5 === 0) ? 0.85 : 0.42;
        c2.beginPath();
        c2.moveTo(padL, py);
        c2.lineTo(w - 4, py);
        c2.stroke();
        idx++;
      }
      c2.globalAlpha = 1;
      c2.restore();

      // 地面
      var gd = c2.createLinearGradient(0, groundY, 0, h);
      gd.addColorStop(0, rgba(th.accent, 0.13));
      gd.addColorStop(1, 'rgba(2,6,23,0)');
      c2.fillStyle = gd;
      c2.fillRect(0, groundY, w, h - groundY);
      c2.save();
      c2.strokeStyle = 'rgba(148,163,184,.16)';
      c2.lineWidth = 1;
      for (var hx = padL; hx < w; hx += 14) {
        c2.beginPath();
        c2.moveTo(hx, groundY + 1);
        c2.lineTo(hx - 7, groundY + 8);
        c2.stroke();
      }
      c2.restore();
      line(c2, padL - 8, groundY, w - 6, groundY, { color: rgba(th.accent, 0.55), width: 1.6 });

      // 刻度文字
      c2.save();
      idx = 0;
      for (gx = 0; PX(gx) <= w - 12; gx += gridStep, idx++) {
        if (idx === 0) {
          txt(c2, 'O', padL - 8, groundY + 13, { size: 9, color: '#94a3b8', align: 'right' });
        } else if (idx % labelEvery === 0) {
          txt(c2, String(Math.round(gx)), PX(gx), groundY + 13, { size: 9, color: '#94a3b8', align: 'center' });
        }
      }
      idx = 0;
      for (gy = gridStep; PY(gy) > topPad * 0.7; gy += gridStep) {
        if (idx % labelEvery === 0) {
          txt(c2, String(Math.round(gy)), padL - 7, PY(gy) + 3, { size: 9, color: '#94a3b8', align: 'right' });
        }
        idx++;
      }
      c2.restore();

      /* ---------------- 目标环 ---------------- */
      if (target) {
        var tx = PX(target.x), ty = PY(target.y);
        var rp = Math.max(9, target.r * scale);
        var tcol = st.hit ? '#34d399' : '#f59e0b';
        c2.save();
        c2.strokeStyle = rgba(tcol, 0.9);
        c2.lineWidth = 1.6;
        c2.beginPath();
        c2.arc(tx, ty, rp, 0, Math.PI * 2);
        c2.stroke();
        c2.setLineDash([4, 4]);
        c2.beginPath();
        c2.arc(tx, ty, rp * 0.6, 0, Math.PI * 2);
        c2.stroke();
        c2.setLineDash([]);
        c2.strokeStyle = rgba(tcol, 0.45);
        c2.lineWidth = 1;
        c2.beginPath();
        c2.moveTo(tx - rp * 1.35, ty);
        c2.lineTo(tx + rp * 1.35, ty);
        c2.moveTo(tx, ty - rp * 1.35);
        c2.lineTo(tx, ty + rp * 1.35);
        c2.stroke();
        c2.restore();
        dot(c2, tx, ty, 2.4, tcol, 6);
        txt(c2, '目标', tx + rp + 5, ty - 3, { size: 9.5, color: tcol });
        if (st.hit) {
          var hp = (st.hitT % 1.1) / 1.1;
          c2.save();
          c2.strokeStyle = rgba('#34d399', 1 - hp);
          c2.lineWidth = 2;
          c2.beginPath();
          c2.arc(tx, ty, rp + hp * 26, 0, Math.PI * 2);
          c2.stroke();
          c2.restore();
          txt(c2, '命中目标', tx, ty - rp - 10, { size: 11.5, color: '#34d399', align: 'center', weight: 600 });
        }
      }

      /* ---------------- 残影 ---------------- */
      for (var gi = st.ghosts.length - 1; gi >= 0; gi--) {
        var gh = st.ghosts[gi];
        if (MOTION && gh.a > 0) gh.a = Math.max(0, gh.a - dt * 0.018);
        if (gh.a <= 0.02) continue;
        c2.save();
        c2.strokeStyle = rgba(th.accent, 0.16 * gh.a);
        c2.lineWidth = 1.4;
        c2.setLineDash([3, 5]);
        c2.beginPath();
        for (var pi = 0; pi < gh.pts.length; pi++) {
          var X = PX(gh.pts[pi][0]), Y = PY(gh.pts[pi][1]);
          if (pi === 0) c2.moveTo(X, Y);
          else c2.lineTo(X, Y);
        }
        c2.stroke();
        c2.restore();
      }

      /* ---------------- 预测轨迹 ---------------- */
      if (!st.flying && !st.landed) {
        c2.save();
        c2.strokeStyle = rgba(th.accent, 0.30);
        c2.lineWidth = 1.2;
        c2.setLineDash([5, 6]);
        c2.beginPath();
        var np = 80;
        for (var ni = 0; ni <= np; ni++) {
          var tn = d.tf * ni / np;
          var xn = PX(d.vx * tn);
          var yn = PY(d.vy * tn - 0.5 * p.g * tn * tn);
          if (ni === 0) c2.moveTo(xn, yn);
          else c2.lineTo(xn, yn);
        }
        c2.stroke();
        c2.restore();
      }

      /* ---------------- 实际轨迹 ---------------- */
      if (st.t > 0.0005) {
        c2.save();
        c2.strokeStyle = th.accent;
        c2.lineWidth = 2.4;
        c2.lineCap = 'round';
        c2.lineJoin = 'round';
        c2.shadowColor = rgba(th.accent, 0.75);
        c2.shadowBlur = 10;
        c2.beginPath();
        var nt = 100;
        for (var ti = 0; ti <= nt; ti++) {
          var tc = st.t * ti / nt;
          var xc = PX(d.vx * tc);
          var yc = PY(Math.max(0, d.vy * tc - 0.5 * p.g * tc * tc));
          if (ti === 0) c2.moveTo(xc, yc);
          else c2.lineTo(xc, yc);
        }
        c2.stroke();
        c2.restore();
      }

      /* ---------------- 发射器 ---------------- */
      var LX = PX(0), LY = PY(0);
      var bk = c2.__psK || 1;
      c2.save();
      c2.translate(LX, LY);
      c2.rotate(-d.rad);
      c2.scale(bk, bk);
      var barrel = c2.createLinearGradient(0, -6, 0, 6);
      barrel.addColorStop(0, '#f1f5f9');
      barrel.addColorStop(1, '#64748b');
      c2.fillStyle = barrel;
      roundRect(c2, -9, -5, 34, 10, 4);
      c2.fill();
      c2.strokeStyle = 'rgba(15,23,42,.55)';
      c2.lineWidth = 1;
      c2.stroke();
      c2.restore();
      c2.save();
      c2.beginPath();
      c2.arc(LX, LY, 9 * bk, Math.PI, 0);
      c2.closePath();
      c2.fillStyle = 'rgba(148,163,184,.28)';
      c2.fill();
      c2.strokeStyle = 'rgba(148,163,184,.55)';
      c2.lineWidth = 1.2 * bk;
      c2.stroke();
      c2.restore();

      // 角度弧
      var arcR = clamp(Math.min(w, h) * 0.10, 22 * bk, 42 * bk);
      c2.save();
      c2.setLineDash([3, 3]);
      c2.strokeStyle = rgba(th.accent, 0.6);
      c2.lineWidth = 1.2;
      c2.beginPath();
      c2.arc(LX, LY, arcR, -d.rad, 0);
      c2.stroke();
      c2.restore();
      txt(c2, 'θ ' + fmt(p.angle, 0) + '°', LX + arcR * 1.1, LY - arcR * 0.26, { size: 9.5, color: th.accent });

      /* ---------------- 顶点与射程标记 ---------------- */
      var apexX = PX(d.R / 2), apexY = PY(d.H);
      c2.save();
      c2.setLineDash([3, 5]);
      c2.strokeStyle = 'rgba(148,163,184,.40)';
      c2.lineWidth = 1;
      c2.beginPath();
      c2.moveTo(apexX, apexY);
      c2.lineTo(apexX, groundY);
      c2.stroke();
      c2.restore();
      c2.save();
      c2.strokeStyle = 'rgba(226,232,240,.7)';
      c2.lineWidth = 1.2;
      c2.beginPath();
      c2.arc(apexX, apexY, 4, 0, Math.PI * 2);
      c2.stroke();
      c2.restore();
      txt(c2, '最高点 ' + fmt(d.H, 1) + ' m', apexX + 8, apexY - 7, { size: 9.5, color: '#cbd5e1' });

      // 射程标注
      var rbY = groundY - 13;
      var rx1 = PX(0), rx2 = PX(d.R);
      c2.save();
      c2.strokeStyle = rgba(th.accent, 0.6);
      c2.lineWidth = 1.1;
      c2.beginPath();
      c2.moveTo(rx1, rbY - 5);
      c2.lineTo(rx1, rbY + 4);
      c2.moveTo(rx2, rbY - 5);
      c2.lineTo(rx2, rbY + 4);
      c2.moveTo(rx1, rbY);
      c2.lineTo(rx2, rbY);
      c2.stroke();
      c2.fillStyle = rgba(th.accent, 0.6);
      c2.beginPath();
      c2.moveTo(rx1, rbY);
      c2.lineTo(rx1 + 7, rbY - 3);
      c2.lineTo(rx1 + 7, rbY + 3);
      c2.closePath();
      c2.fill();
      c2.beginPath();
      c2.moveTo(rx2, rbY);
      c2.lineTo(rx2 - 7, rbY - 3);
      c2.lineTo(rx2 - 7, rbY + 3);
      c2.closePath();
      c2.fill();
      c2.restore();
      txt(c2, '射程 ' + fmt(d.R, 1) + ' m', (rx1 + rx2) / 2, rbY - 5, { size: 9.5, color: th.accent, align: 'center' });

      // 落地涟漪
      if (st.landed) {
        var lp = (st.after % 1.2) / 1.2;
        c2.save();
        c2.strokeStyle = rgba(th.accent, (1 - lp) * 0.8);
        c2.lineWidth = 2;
        c2.beginPath();
        c2.arc(PX(d.R), groundY, 5 + lp * 22, 0, Math.PI * 2);
        c2.stroke();
        c2.restore();
      }

      /* ---------------- 小球与速度矢量 ---------------- */
      if (st.t > 0.0005 || st.flying) {
        var BX = PX(bx), BY = PY(by);
        var bk2 = c2.__psK || 1;
        var glow = c2.createRadialGradient(BX, BY, 0, BX, BY, 18 * bk2);
        glow.addColorStop(0, rgba(th.accent, 0.55));
        glow.addColorStop(1, rgba(th.accent, 0));
        c2.fillStyle = glow;
        c2.beginPath();
        c2.arc(BX, BY, 18 * bk2, 0, Math.PI * 2);
        c2.fill();
        c2.beginPath();
        c2.arc(BX, BY, 5 * bk2, 0, Math.PI * 2);
        c2.fillStyle = '#f8fafc';
        c2.fill();
        c2.lineWidth = 2 * bk2;
        c2.strokeStyle = th.accent;
        c2.stroke();

        // 速度与分量
        var kv = clamp(Math.min(w, h) * 0.17 / Math.max(p.v0, 1), 1.1, 7);
        var vxpx = vx * kv, vypx = -vy * kv;
        c2.save();
        c2.strokeStyle = 'rgba(226,232,240,.20)';
        c2.lineWidth = 1;
        c2.setLineDash([3, 4]);
        c2.beginPath();
        c2.moveTo(BX + vxpx, BY);
        c2.lineTo(BX + vxpx, BY + vypx);
        c2.moveTo(BX, BY + vypx);
        c2.lineTo(BX + vxpx, BY + vypx);
        c2.stroke();
        c2.restore();
        arrow(c2, BX, BY, BX + vxpx, BY + vypx, { color: '#f1f5f9', width: 1.8, head: 7, glow: 5 });
        arrow(c2, BX, BY, BX + vxpx, BY, { color: '#f59e0b', width: 1.6, head: 6, dash: [5, 4] });
        arrow(c2, BX, BY, BX, BY + vypx, { color: '#34d399', width: 1.6, head: 6, dash: [5, 4] });
        txt(c2, 'v ' + fmt(spd, 1), clamp(BX + vxpx * 0.62 + 8, 6, w - 52), BY + vypx * 0.55 - 8,
          { size: 9.5, color: '#e2e8f0', weight: 600 });
        txt(c2, 'vx ' + fmt(vx, 1), clamp(BX + vxpx * 0.5, 30, w - 24), BY + (vypx >= 0 ? 14 : -8),
          { size: 9, color: '#f59e0b', align: 'center' });
        txt(c2, 'vy ' + fmt(vy, 1), clamp(BX + (vxpx >= 0 ? 8 : -8), 6, w - 42), clamp(BY + vypx * 0.5, 12, h - 6),
          { size: 9, color: '#34d399', align: vxpx >= 0 ? 'left' : 'right' });
      }

      /* ---------------- 读数与状态 ---------------- */
      var btext, bkind;
      if (st.hit) { btext = '命中目标'; bkind = 'ok'; }
      else if (st.flying) { btext = '飞行中 · t = ' + fmt(st.t, 2) + ' s'; bkind = 'ok'; }
      else if (st.landed) { btext = '已落地 · 射程 ' + fmt(d.R, 1) + ' m'; bkind = 'info'; }
      else { btext = '就绪 · 点击「发射」'; bkind = 'info'; }
      badge.set(btext, bkind);

      hud.set([
        ['时间 t', fmt(tt, 2) + ' s'],
        ['速率 v', fmt(spd, 1) + ' m/s', 'acc'],
        ['分量 vx / vy', fmt(vx, 1) + ' / ' + fmt(vy, 1)],
        ['当前高度 y', fmt(by, 2) + ' m'],
        ['最高点 H', fmt(d.H, 2) + ' m'],
        ['射程 R', fmt(d.R, 2) + ' m'],
        ['飞行时间 T', fmt(d.tf, 2) + ' s']
      ], '网格 ' + gridStep + ' m / 格 · 1 m = ' + fmt(scale, 1) + ' px');
    });

    function applyParams(np) {
      if (!np) return;
      if (np.v0 != null) { p.v0 = clamp(num(np.v0, p.v0), 5, 40); sV0.set(p.v0); }
      if (np.angle != null) { p.angle = clamp(num(np.angle, p.angle), 5, 85); sAng.set(p.angle); }
      if (np.g != null) p.g = clamp(num(np.g, p.g), 1, 30);
      reset(true);
    }

    return {
      destroy: function () {
        stage.destroy();
        clear(root);
      },
      resize: function () { /* ResizeObserver 自动处理 */ },
      setParams: applyParams
    };
  }

  /* ======================================================================
   * 2. 滑轮组
   * ==================================================================== */

  function mountPulley(root, params, ctx) {
    params = params || {};
    var th = themeOf(ctx);
    var MOTION = !(ctx && ctx.motion === false);
    var sh = makeShell(root, th, {
      title: '滑轮组',
      sub: 'n 段绳共同承重 · 理想拉力 F = G/n',
      formula: '<b>理想拉力</b> F = G/n · <b>机械效率</b> η = Gh / (Fs) = G/(nF)<br>' +
        '<b>绳端距离</b> s = n·h · 省力 n 倍，费距离 n 倍'
    });
    var hud = hudCtl(sh.stage);
    var badge = badgeCtl(sh.stage);

    var HMAX = 1.2; // 最大提升高度（m）
    var p = {
      n: clamp(Math.round(num(params.n, 2)), 1, 3),
      G: clamp(num(params.G, 100), 10, 200),
      F: clamp(num(params.F, 60), 5, 200),
      loss: clamp(num(params.loss, 8), 0, 25)
    };
    var st = { h: 0, moving: false, done: false };

    function calc() {
      var ideal = p.G / p.n;
      var need = ideal * (1 + p.loss / 100);
      var ok = p.F + 1e-6 >= need;
      var eta = p.F > 1e-6 ? (p.G / (p.n * p.F)) * 100 : 0;
      return {
        ideal: ideal,
        need: need,
        ok: ok,
        eta: clamp(eta, 0, 100),
        canLift: p.n * p.F > p.G + 1e-9
      };
    }

    function reset() {
      st.h = 0;
      st.moving = false;
      st.done = false;
    }

    var sN = mkSeg(sh.body, {
      label: '绳段数 n', aria: '绳段数',
      value: p.n,
      options: [{ label: '1 段', value: 1 }, { label: '2 段', value: 2 }, { label: '3 段', value: 3 }],
      onChange: function (v) { p.n = v; reset(); }
    });
    var sG = mkSlider(sh.body, {
      label: '物重 G', min: 10, max: 200, step: 1, value: p.G, unit: 'N', digits: 0,
      onInput: function (v) { p.G = v; st.moving = st.moving && calc().ok; }
    });
    var sF = mkSlider(sh.body, {
      label: '拉力 F', min: 5, max: 200, step: 1, value: p.F, unit: 'N', digits: 0,
      onInput: function (v) { p.F = v; st.moving = st.moving && calc().ok; }
    });
    var sLoss = mkSlider(sh.body, {
      label: '摩擦损耗', min: 0, max: 25, step: 1, value: p.loss, unit: '%', digits: 0,
      onInput: function (v) { p.loss = v; st.moving = st.moving && calc().ok; }
    });

    var alertEl = el('div', 'psw-alert');
    sh.body.appendChild(alertEl);

    var acts = el('div', 'psw-actions');
    sh.body.appendChild(acts);
    var bLift = mkBtn(acts, '提 升', 'primary', function () {
      if (st.moving) { st.moving = false; return; }
      var cc = calc();
      if (cc.ok && st.h < HMAX - 1e-9) {
        st.done = false;
        st.moving = true;
      }
    }, '开始或暂停提升重物');
    var bReset = mkBtn(acts, '复位', 'ghost', reset, '重物回到地面');
    var bMatch = mkBtn(acts, 'F 设为所需', 'ghost', function () {
      var cc = calc();
      var val = clamp(Math.ceil(cc.need * 10) / 10, 5, 200);
      p.F = val;
      sF.set(val);
    }, '把拉力调整为含损耗所需值');
    bMatch.classList.add('wide');

    sh.body.appendChild(el('div', 'psw-note', '摩擦损耗计入所需拉力；额外拉力做的是额外功，效率随之降低。'));
    var lastAlert = '';

    var stage = makeStage(sh.stage, function (c2, dt, time, w, h) {
      var cc = calc();

      if (MOTION && st.moving) {
        if (!cc.ok) st.moving = false;
        else {
          st.h += 0.22 * dt;
          if (st.h >= HMAX) { st.h = HMAX; st.moving = false; st.done = true; }
        }
      }

      setTight(sh, h);
      backdrop(c2, w, h, th);

      var u = clamp(Math.min(w, h) / 380, 0.6, 1.35);
      var ceilY = clamp(h * 0.13, 22, 48);
      var groundY = h - clamp(h * 0.10, 26, 44);
      var rm = 13 * u, rf = 12 * u;
      var xm = w * 0.40;
      var yTop = ceilY + 34 * u;
      var crateW = 96 * u, crateH = 54 * u;
      var loadStart = groundY - crateH - 14 * u;
      var loadEnd = yTop + 94 * u;
      var loadTop = loadStart - (loadStart - loadEnd) * (st.h / HMAX);
      var pxPerM = (loadStart - loadEnd) / HMAX;
      var crateTop = loadTop;
      var ym = crateTop - 46 * u;
      var barY = ym + rm + 3 * u;

      var xf1, xf2 = 0, xA = 0, handX;
      if (p.n === 1) {
        xf1 = xm + rf;
        handX = xf1 + rf;
      } else if (p.n === 2) {
        xf1 = xm + rm + rf;
        handX = xf1 + rf;
      } else {
        xf1 = xm - rm - rf;
        xf2 = xm + rm + rf;
        xA = xf1 - rf;
        handX = xf2 + rf;
      }
      var handStart = yTop + 26 * u;
      var handY = Math.min(groundY - 8 * u, handStart + p.n * st.h * pxPerM);

      /* 地面与天花板 */
      var gd = c2.createLinearGradient(0, groundY, 0, h);
      gd.addColorStop(0, 'rgba(148,163,184,.14)');
      gd.addColorStop(1, 'rgba(2,6,23,0)');
      c2.fillStyle = gd;
      c2.fillRect(0, groundY, w, h - groundY);
      line(c2, 0, groundY, w, groundY, { color: 'rgba(148,163,184,.42)', width: 1.4 });
      hatch(c2, 0, groundY, w, Math.min(14, h - groundY), 13, 'rgba(148,163,184,.12)');

      var beamX0 = w * 0.09, beamX1 = w * 0.84;
      hatch(c2, beamX0, ceilY - 11 * u, beamX1 - beamX0, 11 * u, 11 * u, 'rgba(148,163,184,.22)');
      var beamGrad = c2.createLinearGradient(0, ceilY, 0, ceilY + 9 * u);
      beamGrad.addColorStop(0, '#cbd5e1');
      beamGrad.addColorStop(1, '#475569');
      c2.fillStyle = beamGrad;
      c2.fillRect(beamX0, ceilY, beamX1 - beamX0, 9 * u);
      c2.strokeStyle = 'rgba(15,23,42,.5)';
      c2.lineWidth = 1;
      c2.strokeRect(beamX0, ceilY, beamX1 - beamX0, 9 * u);

      /* 绳 */
      var ropeBase = 'rgba(203,213,225,.82)';
      c2.save();
      c2.strokeStyle = ropeBase;
      c2.lineWidth = 2.2 * u;
      c2.lineCap = 'round';
      c2.lineJoin = 'round';
      c2.beginPath();
      if (p.n === 1) {
        c2.moveTo(xm, crateTop);
        c2.lineTo(xm, yTop);
        c2.arc(xf1, yTop, rf, Math.PI, Math.PI * 2, false);
        c2.lineTo(handX, handY);
      } else if (p.n === 2) {
        c2.moveTo(xm - rm, ceilY + 9 * u);
        c2.lineTo(xm - rm, ym);
        c2.arc(xm, ym, rm, Math.PI, 0, true);
        c2.lineTo(xf1 - rf, yTop);
        c2.arc(xf1, yTop, rf, Math.PI, Math.PI * 2, false);
        c2.lineTo(handX, handY);
      } else {
        c2.moveTo(xA, barY);
        c2.lineTo(xA, yTop);
        c2.arc(xf1, yTop, rf, Math.PI, Math.PI * 2, false);
        c2.lineTo(xm - rm, ym);
        c2.arc(xm, ym, rm, Math.PI, 0, true);
        c2.lineTo(xm + rm, yTop);
        c2.arc(xf2, yTop, rf, Math.PI, Math.PI * 2, false);
        c2.lineTo(handX, handY);
      }
      c2.stroke();
      c2.restore();

      /* 承重绳段高亮 */
      var hot = st.moving;
      var segs = [];
      if (p.n === 1) {
        segs.push([xm, yTop, xm, crateTop]);
      } else if (p.n === 2) {
        segs.push([xm - rm, yTop, xm - rm, ym]);
        segs.push([xm + rm, yTop, xm + rm, ym]);
      } else {
        segs.push([xA, yTop, xA, barY]);
        segs.push([xm - rm, yTop, xm - rm, ym]);
        segs.push([xm + rm, yTop, xm + rm, ym]);
      }
      for (var si = 0; si < segs.length; si++) {
        var sgm = segs[si];
        c2.save();
        c2.strokeStyle = rgba(th.accent, hot ? 0.9 : 0.38);
        c2.lineWidth = (hot ? 3.2 : 2.4) * u;
        c2.lineCap = 'round';
        if (hot) { c2.shadowColor = rgba(th.accent, 0.7); c2.shadowBlur = 8; }
        c2.beginPath();
        c2.moveTo(sgm[0], sgm[1]);
        c2.lineTo(sgm[2], sgm[3]);
        c2.stroke();
        c2.restore();
      }

      /* 动滑轮组支架 */
      if (p.n >= 2) {
        var bx1 = xm - rm - 10 * u;
        var bx2 = xm + rm + 10 * u;
        if (p.n === 3) bx1 = Math.min(bx1, xA - 6 * u);
        var bracket = c2.createLinearGradient(0, barY, 0, barY + 7 * u);
        bracket.addColorStop(0, '#64748b');
        bracket.addColorStop(1, '#334155');
        roundRect(c2, bx1, barY, bx2 - bx1, 7 * u, 3.5 * u);
        c2.fillStyle = bracket;
        c2.fill();
        c2.strokeStyle = 'rgba(15,23,42,.6)';
        c2.lineWidth = 1;
        c2.stroke();
        // 吊钩
        line(c2, xm, barY + 7 * u, xm, crateTop, { color: '#cbd5e1', width: 2 * u });
      }

      /* 滑轮 */
      function drawPulley(x, y, r, fixed) {
        if (fixed) {
          line(c2, x, ceilY + 9 * u, x, y - r, { color: 'rgba(148,163,184,.65)', width: 2.2 * u });
          c2.fillStyle = 'rgba(148,163,184,.6)';
          c2.beginPath();
          c2.arc(x, ceilY + 9 * u, 3 * u, 0, Math.PI * 2);
          c2.fill();
        }
        c2.save();
        var pg = c2.createRadialGradient(x - r * 0.35, y - r * 0.38, r * 0.08, x, y, r);
        pg.addColorStop(0, '#f1f5f9');
        pg.addColorStop(0.45, '#94a3b8');
        pg.addColorStop(1, '#334155');
        c2.beginPath();
        c2.arc(x, y, r, 0, Math.PI * 2);
        c2.fillStyle = pg;
        c2.fill();
        c2.lineWidth = 2 * u;
        c2.strokeStyle = 'rgba(15,23,42,.75)';
        c2.stroke();
        c2.beginPath();
        c2.arc(x, y, r * 0.76, 0, Math.PI * 2);
        c2.strokeStyle = 'rgba(15,23,42,.45)';
        c2.lineWidth = 2 * u;
        c2.stroke();
        c2.beginPath();
        c2.arc(x, y, r * 0.24, 0, Math.PI * 2);
        c2.fillStyle = '#1e293b';
        c2.fill();
        c2.beginPath();
        c2.arc(x, y, r * 0.10, 0, Math.PI * 2);
        c2.fillStyle = '#cbd5e1';
        c2.fill();
        c2.restore();
      }

      if (p.n >= 2) drawPulley(xm, ym, rm, false);
      if (p.n === 3) {
        drawPulley(xf2, yTop, rf, true);
        drawPulley(xf1, yTop, rf, true);
      } else {
        drawPulley(xf1, yTop, rf, true);
      }

      /* 重物 */
      c2.save();
      var cg = c2.createLinearGradient(xm - crateW / 2, crateTop, xm + crateW / 2, crateTop + crateH);
      cg.addColorStop(0, 'rgba(51,65,85,.97)');
      cg.addColorStop(1, 'rgba(15,23,42,.97)');
      roundRect(c2, xm - crateW / 2, crateTop, crateW, crateH, 7 * u);
      c2.fillStyle = cg;
      c2.fill();
      c2.strokeStyle = rgba(th.accent, 0.55);
      c2.lineWidth = 1.6;
      c2.stroke();
      line(c2, xm - crateW / 2 + 9 * u, crateTop + 1, xm - crateW / 2 + 9 * u, crateTop + crateH - 1,
        { color: 'rgba(148,163,184,.22)', width: 2 * u });
      line(c2, xm + crateW / 2 - 9 * u, crateTop + 1, xm + crateW / 2 - 9 * u, crateTop + crateH - 1,
        { color: 'rgba(148,163,184,.22)', width: 2 * u });
      c2.beginPath();
      c2.arc(xm, crateTop - 4 * u, 5 * u, 0, Math.PI * 2);
      c2.strokeStyle = '#cbd5e1';
      c2.lineWidth = 2 * u;
      c2.stroke();
      txt(c2, '物重', xm, crateTop + crateH * 0.30, { size: 7.2 * u, color: '#94a3b8', align: 'center' });
      txt(c2, 'G = ' + fmt(p.G, 0) + ' N', xm, crateTop + crateH * 0.66,
        { size: 10.5 * u, color: '#f1f5f9', align: 'center', weight: 600 });
      c2.restore();

      /* 绳端与拉力 */
      line(c2, handX, yTop, handX, handY, { color: ropeBase, width: 2.2 * u });
      var gripGrad = c2.createLinearGradient(0, handY, 0, handY + 9 * u);
      gripGrad.addColorStop(0, th.accent);
      gripGrad.addColorStop(1, '#1d9fd6');
      roundRect(c2, handX - 16 * u, handY, 32 * u, 9 * u, 4.5 * u);
      c2.fillStyle = gripGrad;
      c2.fill();
      arrow(c2, handX + 22 * u, handY - 8 * u, handX + 22 * u, handY + 28 * u,
        { color: '#f59e0b', width: 2, head: 7, glow: 4 });
      txt(c2, 'F = ' + fmt(p.F, 1) + ' N', handX + 30 * u, handY + 12 * u, { size: 9.5, color: '#f59e0b' });

      /* 提升高度标注 */
      var y0 = loadStart + crateH;
      var y1 = crateTop + crateH;
      var xDim = clamp(xm - crateW / 2 - 30 * u, 16, w * 0.30);
      if (y0 - y1 > 1) {
        line(c2, xDim, y0, xDim + 26 * u, y0, { color: 'rgba(148,163,184,.30)', width: 1, dash: [3, 4] });
        line(c2, xDim, y1, xDim + 26 * u, y1, { color: 'rgba(148,163,184,.30)', width: 1, dash: [3, 4] });
        arrow(c2, xDim, y0, xDim, y1, { color: rgba(th.accent, 0.8), width: 1.3, head: 6 });
        arrow(c2, xDim, y1, xDim, y0, { color: rgba(th.accent, 0.8), width: 1.3, head: 6 });
      }
      var hLabelAlign = xDim > 64 ? 'right' : 'left';
      txt(c2, 'h = ' + fmt(st.h, 2) + ' m', xDim + (hLabelAlign === 'right' ? -6 : 40 * u),
        (y0 + y1) / 2, { size: 9.5, color: th.accent, align: hLabelAlign });

      /* 状态 */
      var btext, bkind;
      if (!cc.ok) { btext = '拉力不足 · 需 F ≥ ' + fmt(cc.need, 1) + ' N'; bkind = 'warn'; }
      else if (st.moving) { btext = '提升中 · 匀速 0.22 m/s'; bkind = 'ok'; }
      else if (st.h >= HMAX - 1e-9) { btext = '已到顶端 · 复位后可重试'; bkind = 'info'; }
      else { btext = '就绪 · 点击「提升」'; bkind = 'info'; }
      badge.set(btext, bkind);

      if (!cc.ok) {
        var msg = '拉力不足：nF = ' + fmt(p.n * p.F, 1) + ' N，匀速提升需 F ≥ ' + fmt(cc.need, 1) +
          ' N（含 ' + fmt(p.loss, 0) + '% 摩擦损耗）。';
        if (msg !== lastAlert) { alertEl.textContent = msg; lastAlert = msg; }
        alertEl.classList.add('show');
      } else {
        alertEl.classList.remove('show');
      }

      var lbl = st.moving ? '暂 停' : (st.h >= HMAX - 1e-9 ? '已到顶' : '提 升');
      if (bLift.textContent !== lbl) bLift.textContent = lbl;
      bLift.disabled = st.h >= HMAX - 1e-9 && !st.moving;

      hud.set([
        ['绳段数 n', p.n + ' 段 · 省力 ' + p.n + ' 倍'],
        ['理论 F = G/n', fmt(cc.ideal, 1) + ' N'],
        ['所需 F（含损耗）', fmt(cc.need, 1) + ' N', cc.ok ? '' : 'warn'],
        ['当前拉力 F', fmt(p.F, 1) + ' N'],
        ['机械效率 η', cc.ok ? fmt(cc.eta, 1) + ' %' : '不可提升', cc.ok ? 'acc' : 'warn'],
        ['提升 h / 绳端 s', fmt(st.h, 2) + ' / ' + fmt(p.n * st.h, 2) + ' m'],
        ['功 Gh / Fs', fmt(p.G * st.h, 1) + ' / ' + fmt(p.F * p.n * st.h, 1) + ' J']
      ], 'G = ' + fmt(p.G, 0) + ' N · 损耗 ' + fmt(p.loss, 0) + '% · 1 m = ' + fmt(pxPerM, 0) + ' px');
    });

    function applyParams(np) {
      if (!np) return;
      if (np.n != null) { p.n = clamp(Math.round(num(np.n, p.n)), 1, 3); sN.set(p.n); reset(); }
      if (np.G != null) { p.G = clamp(num(np.G, p.G), 10, 200); sG.set(p.G); }
      if (np.F != null) { p.F = clamp(num(np.F, p.F), 5, 200); sF.set(p.F); }
      if (np.loss != null) { p.loss = clamp(num(np.loss, p.loss), 0, 25); sLoss.set(p.loss); }
      st.moving = st.moving && calc().ok;
    }

    return {
      destroy: function () {
        stage.destroy();
        clear(root);
      },
      resize: function () {},
      setParams: applyParams
    };
  }

  /* ======================================================================
   * 3. 斜面摩擦
   * ==================================================================== */

  function mountIncline(root, params, ctx) {
    params = params || {};
    var th = themeOf(ctx);
    var MOTION = !(ctx && ctx.motion === false);
    var sh = makeShell(root, th, {
      title: '斜面摩擦',
      sub: '倾角、摩擦与质量共同决定下滑 · g = 9.8 m/s²',
      formula: '<b>加速度</b> a = g(sinθ − μcosθ)<br><b>支持力</b> N = mg cosθ · <b>摩擦</b> f = μN<br>' +
        'μ ≥ tanθ 时，静摩擦平衡，物体保持静止'
    });
    var hud = hudCtl(sh.stage);
    var badge = badgeCtl(sh.stage);

    var L = 6.0; // 斜面长度 6 m（世界坐标）
    var p = {
      // 兼容 SIM_DEFAULTS 的两种键名：angle/mass 与 theta/m
      theta: clamp(num(params.angle != null ? params.angle : params.theta, 30), 10, 60),
      mu: clamp(num(params.mu, 0.2), 0, 0.8),
      m: clamp(num(params.mass != null ? params.mass : params.m, 2), 0.5, 5)
    };
    var st = { s: 0, v: 0, moving: false, done: false };

    function calc() {
      var rad = p.theta * Math.PI / 180;
      var sin = Math.sin(rad), cos = Math.cos(rad);
      var tan = sin / cos;
      var isStatic = p.mu >= tan - 1e-6;
      var Gw = p.m * GRAV;
      var a = isStatic ? 0 : GRAV * (sin - p.mu * cos);
      if (a < 0) a = 0;
      var N = Gw * cos;
      var f = isStatic ? Gw * sin : p.mu * N;
      return { rad: rad, sin: sin, cos: cos, tan: tan, isStatic: isStatic, a: a, G: Gw, N: N, f: f };
    }

    function reset() {
      st.s = 0;
      st.v = 0;
      st.moving = false;
      st.done = false;
    }

    function release() {
      var c = calc();
      if (c.isStatic) { st.moving = false; return; }
      if (st.s >= L - 1e-6) reset();
      st.done = false;
      st.moving = true;
    }

    var sTheta = mkSlider(sh.body, {
      label: '倾角 θ', min: 10, max: 60, step: 1, value: p.theta, unit: '°', digits: 0,
      onInput: function (v) { p.theta = v; reset(); }
    });
    var sMu = mkSlider(sh.body, {
      label: '摩擦系数 μ', min: 0, max: 0.8, step: 0.05, value: p.mu, digits: 2,
      onInput: function (v) { p.mu = v; reset(); }
    });
    var sMass = mkSlider(sh.body, {
      label: '质量 m', min: 0.5, max: 5, step: 0.1, value: p.m, unit: 'kg', digits: 1,
      onInput: function (v) { p.m = v; reset(); }
    });

    var alertEl = el('div', 'psw-alert');
    sh.body.appendChild(alertEl);

    var acts = el('div', 'psw-actions');
    sh.body.appendChild(acts);
    var bGo = mkBtn(acts, '释 放', 'primary', release, '释放小车沿斜面下滑');
    var bReset = mkBtn(acts, '复位', 'ghost', function () { reset(); }, '复位到斜面顶端');
    sh.body.appendChild(el('div', 'psw-note', '摩擦矢量沿斜面向上；当 μ ≥ tanθ 时小车被静摩擦锁定。'));

    var lastAlert = '';

    var stage = makeStage(sh.stage, function (c2, dt, time, w, h) {
      var c = calc();

      if (MOTION && st.moving) {
        st.v += c.a * dt;
        st.s += st.v * dt;
        if (st.s >= L) {
          st.s = L;
          st.v = Math.sqrt(Math.max(0, 2 * c.a * L));
          st.moving = false;
          st.done = true;
        }
      }

      setTight(sh, h);
      backdrop(c2, w, h, th);

      var u = clamp(Math.min(w, h) / 360, 0.78, 1.4);
      var groundY = h - clamp(h * 0.13, 26, 48);
      var padTop = clamp(h * 0.12, 24, 58);
      var padX = clamp(w * 0.10, 26, 80);
      // 右侧为读数卡预留空间，避免斜面顶端被卡片遮挡
      var hudReserve = clamp(w * 0.36, 200, 280);
      var maxW = Math.max(80, w - padX - hudReserve);
      var maxH = Math.max(40, groundY - padTop);
      var Lpx = Math.min(maxW / c.cos, maxH / c.sin);
      Lpx = Math.max(Lpx, 50);
      var baseW = Lpx * c.cos;
      var baseH = Lpx * c.sin;
      var baseX = padX + (maxW - baseW) * 0.36;
      var apexX = baseX + baseW;
      var apexY = groundY - baseH;

      /* 背景细网格 */
      c2.save();
      c2.strokeStyle = 'rgba(148,163,184,.055)';
      c2.lineWidth = 1;
      for (var bgx = 0; bgx < w; bgx += 42) {
        c2.beginPath(); c2.moveTo(bgx, 0); c2.lineTo(bgx, groundY); c2.stroke();
      }
      for (var bgy = groundY; bgy > 0; bgy -= 42) {
        c2.beginPath(); c2.moveTo(0, bgy); c2.lineTo(w, bgy); c2.stroke();
      }
      c2.restore();

      /* 地面 */
      var gd = c2.createLinearGradient(0, groundY, 0, h);
      gd.addColorStop(0, 'rgba(148,163,184,.14)');
      gd.addColorStop(1, 'rgba(2,6,23,.05)');
      c2.fillStyle = gd;
      c2.fillRect(0, groundY, w, h - groundY);
      hatch(c2, 0, groundY, w, Math.min(16, h - groundY), 13, 'rgba(148,163,184,.14)');
      line(c2, 0, groundY, w, groundY, { color: 'rgba(148,163,184,.45)', width: 1.4 });

      /* 斜面 */
      c2.save();
      var tg = c2.createLinearGradient(baseX, apexY, apexX, groundY);
      tg.addColorStop(0, 'rgba(148,163,184,.22)');
      tg.addColorStop(1, 'rgba(30,41,59,.55)');
      c2.beginPath();
      c2.moveTo(baseX, groundY);
      c2.lineTo(apexX, apexY);
      c2.lineTo(apexX, groundY);
      c2.closePath();
      c2.fillStyle = tg;
      c2.fill();
      c2.strokeStyle = 'rgba(148,163,184,.42)';
      c2.lineWidth = 1.4;
      c2.stroke();
      c2.clip();
      c2.strokeStyle = 'rgba(148,163,184,.12)';
      c2.lineWidth = 1;
      for (var hd = -baseH; hd < baseW + baseH; hd += 13) {
        c2.beginPath();
        c2.moveTo(baseX + hd, groundY);
        c2.lineTo(baseX + hd + baseH, groundY - baseH);
        c2.stroke();
      }
      c2.restore();
      line(c2, baseX, groundY, apexX, apexY, { color: rgba(th.accent, 0.5), width: 2.4 });

      /* 斜面刻度（每 1 m） */
      for (var mm = 1; mm < L; mm++) {
        var q = mm / L;
        var mx = baseX + baseW * q;
        var my = groundY - baseH * q;
        line(c2, mx, my, mx - c.sin * 7 * u, my - c.cos * 7 * u, { color: 'rgba(226,232,240,.20)', width: 1 });
      }

      /* 角弧与标注 */
      var arcR = clamp(Math.min(w, h) * 0.10, 22, 44);
      c2.save();
      c2.strokeStyle = rgba(th.accent, 0.7);
      c2.lineWidth = 1.4;
      c2.beginPath();
      c2.arc(baseX, groundY, arcR, -c.rad, 0);
      c2.stroke();
      c2.restore();
      txt(c2, 'θ ' + fmt(p.theta, 0) + '°', baseX + arcR * 0.78, groundY - arcR * 0.3, { size: 10, color: th.accent });
      txt(c2, 'h = ' + fmt(L * c.sin, 1) + ' m', apexX - 7, (groundY + apexY) / 2, { size: 9.5, color: '#94a3b8', align: 'right' });

      var midx = (baseX + apexX) / 2, midy = (groundY + apexY) / 2;
      txt(c2, 'L = 6.0 m', midx - c.sin * 17 * u, midy - c.cos * 17 * u, { size: 9.5, color: '#94a3b8', align: 'center' });

      /* 已下滑距离高亮 */
      var dpx = (st.s / L) * Lpx;
      if (dpx > 1) {
        var pxs = apexX - dpx * c.cos, pys = apexY + dpx * c.sin;
        line(c2, apexX, apexY, pxs, pys, { color: rgba(th.accent, 0.45), width: 4 });
      }

      /* 小车 */
      var cx = apexX - dpx * c.cos;
      var cy = apexY + dpx * c.sin;
      var cw = 46 * u, chh = 20 * u, rw = 6 * u;
      c2.save();
      c2.translate(cx, cy);
      c2.rotate(-c.rad);
      c2.fillStyle = 'rgba(0,0,0,.35)';
      c2.beginPath();
      c2.ellipse(0, 2 * u, cw * 0.5, 4 * u, 0, 0, Math.PI * 2);
      c2.fill();
      [-cw * 0.28, cw * 0.28].forEach(function (wx) {
        c2.beginPath();
        c2.arc(wx, -rw, rw, 0, Math.PI * 2);
        c2.fillStyle = '#1e293b';
        c2.fill();
        c2.lineWidth = 1.7;
        c2.strokeStyle = '#94a3b8';
        c2.stroke();
        dot(c2, wx, -rw, rw * 0.32, '#94a3b8', 0);
      });
      var bodyGrad = c2.createLinearGradient(0, -chh - 2 * rw, 0, -2 * rw);
      bodyGrad.addColorStop(0, '#f1f5f9');
      bodyGrad.addColorStop(0.55, '#cbd5e1');
      bodyGrad.addColorStop(1, '#94a3b8');
      roundRect(c2, -cw / 2, -chh - 2 * rw, cw, chh, 4 * u);
      c2.fillStyle = bodyGrad;
      c2.fill();
      c2.strokeStyle = 'rgba(15,23,42,.5)';
      c2.lineWidth = 1;
      c2.stroke();
      roundRect(c2, -cw * 0.28, -chh - 2 * rw + 4 * u, cw * 0.56, chh * 0.44, 2.4 * u);
      c2.fillStyle = 'rgba(56,189,248,.32)';
      c2.fill();
      c2.restore();

      /* 受力矢量（同一比例尺） */
      var C = {
        x: cx - c.sin * (chh * 0.5 + 2 * rw),
        y: cy - c.cos * (chh * 0.5 + 2 * rw)
      };
      var fMax = clamp(Math.min(w, h) * 0.17, 42, 112);
      var kF = fMax / Math.max(1e-6, c.G);
      var Gpx = c.G * kF;
      var Npx = c.N * kF;
      var fpx = c.f * kF;
      var upx = c.cos, upy = -c.sin;   // 沿斜面向上（屏幕方向）
      var npx = -c.sin, npy = -c.cos;  // 垂直斜面向外

      // 重力沿斜面/垂直斜面的虚线分量
      arrow(c2, C.x, C.y, C.x - upx * Gpx * c.sin, C.y - upy * Gpx * c.sin,
        { color: 'rgba(248,113,113,.42)', width: 1.2, head: 5, dash: [4, 4] });
      arrow(c2, C.x, C.y, C.x - npx * Gpx * c.cos, C.y - npy * Gpx * c.cos,
        { color: 'rgba(248,113,113,.30)', width: 1.2, head: 5, dash: [4, 4] });

      arrow(c2, C.x, C.y, C.x, C.y + Gpx, { color: '#f87171', width: 2.1, head: 8, glow: 4 });
      arrow(c2, C.x, C.y, C.x + npx * Npx, C.y + npy * Npx, { color: '#34d399', width: 2.1, head: 8, glow: 4 });
      if (fpx > 3) {
        arrow(c2, C.x, C.y, C.x + upx * fpx, C.y + upy * fpx, { color: '#f59e0b', width: 2.1, head: 8, glow: 4 });
      }

      function tag(str, x, y, color, align) {
        txt(c2, str, clamp(x, 4, w - 4), clamp(y, 12, h - 5), { size: 9, color: color, align: align || 'left' });
      }
      tag('G = ' + fmt(c.G, 1) + ' N', C.x + 6, C.y + Gpx + 12, '#f87171');
      tag('N = ' + fmt(c.N, 1) + ' N', C.x + npx * Npx + 4, C.y + npy * Npx - 6, '#34d399',
        npx >= 0 ? 'left' : 'right');
      if (fpx > 3) {
        tag('f = ' + fmt(c.f, 1) + ' N', C.x + upx * fpx + 4, C.y + upy * fpx - 6, '#f59e0b',
          upx >= 0 ? 'left' : 'right');
      }

      // 速度矢量
      if (st.v > 0.03) {
        var vmax = Math.sqrt(Math.max(0.1, 2 * GRAV * L));
        var kv = clamp(fMax * 0.92 / vmax, 1, 12);
        var vsx = C.x - upx * 16 * u, vsy = C.y - upy * 16 * u;
        arrow(c2, vsx, vsy, vsx - upx * st.v * kv, vsy - upy * st.v * kv,
          { color: th.accent, width: 2, head: 7, glow: 5 });
        tag('v = ' + fmt(st.v, 1) + ' m/s', vsx - upx * st.v * kv, vsy - upy * st.v * kv + 14, th.accent);
      }

      /* 状态提示 */
      var btext, bkind;
      if (c.isStatic) { btext = '静摩擦平衡 · 小车保持静止'; bkind = 'warn'; }
      else if (st.moving) { btext = '下滑中 · a = ' + fmt(c.a, 2) + ' m/s²'; bkind = 'ok'; }
      else if (st.done) { btext = '到达底端 · v = ' + fmt(st.v, 1) + ' m/s'; bkind = 'info'; }
      else if (c.a < 0.12) { btext = '临界附近 · 下滑极其缓慢'; bkind = 'warn'; }
      else { btext = '就绪 · 点击「释放」'; bkind = 'info'; }
      badge.set(btext, bkind);

      if (c.isStatic) {
        var msg = '静摩擦平衡：μ = ' + fmt(p.mu, 2) + ' ≥ tan' + fmt(p.theta, 0) + '° = ' +
          fmt(c.tan, 2) + '，小车保持静止。';
        if (msg !== lastAlert) { alertEl.textContent = msg; lastAlert = msg; }
        alertEl.classList.add('show');
      } else {
        alertEl.classList.remove('show');
      }

      var pxPerM = Lpx / L;
      hud.set([
        ['加速度 a', fmt(c.a, 2) + ' m/s²', c.isStatic ? 'warn' : 'acc'],
        ['速度 v', fmt(st.v, 2) + ' m/s'],
        ['位移 s', fmt(st.s, 2) + ' / 6.00 m'],
        ['支持力 N', fmt(c.N, 1) + ' N'],
        ['摩擦力 f', fmt(c.f, 1) + ' N'],
        ['重力 G', fmt(c.G, 1) + ' N'],
        ['μ / tanθ', fmt(p.mu, 2) + ' / ' + fmt(c.tan, 2), c.isStatic ? 'warn' : '']
      ], '斜面长 6.0 m · 1 m = ' + fmt(pxPerM, 1) + ' px');
    });

    function applyParams(np) {
      if (!np) return;
      if (np.angle != null || np.theta != null) {
        p.theta = clamp(num(np.angle != null ? np.angle : np.theta, p.theta), 10, 60);
        sTheta.set(p.theta);
      }
      if (np.mu != null) { p.mu = clamp(num(np.mu, p.mu), 0, 0.8); sMu.set(p.mu); }
      if (np.mass != null || np.m != null) {
        p.m = clamp(num(np.mass != null ? np.mass : np.m, p.m), 0.5, 5);
        sMass.set(p.m);
      }
      reset();
    }

    return {
      destroy: function () {
        stage.destroy();
        clear(root);
      },
      resize: function () {},
      setParams: applyParams
    };
  }

  /* ======================================================================
   * 4. 凸透镜成像
   * ==================================================================== */

  function mountLens(root, params, ctx) {
    params = params || {};
    var th = themeOf(ctx);
    var MOTION = !(ctx && ctx.motion === false);
    var sh = makeShell(root, th, {
      title: '凸透镜成像',
      sub: '三条特殊光线作图 · 1/f = 1/u + 1/v',
      formula: '<b>成像公式</b> 1/f = 1/u + 1/v · <b>放大率</b> |m| = |v/u| = h′/h<br>' +
        'u &gt; 2f 倒立缩小实像 · f &lt; u &lt; 2f 倒立放大实像 · u &lt; f 正立放大虚像'
    });
    var hud = hudCtl(sh.stage);
    var badge = badgeCtl(sh.stage);

    var p = {
      f: clamp(num(params.f, 10), 5, 20),
      u: clamp(num(params.u, 30), 2, 60),
      h: clamp(num(params.h, 3), 1, 5)
    };
    var e = { f: p.f, u: p.u, h: p.h };

    var sF = mkSlider(sh.body, {
      label: '焦距 f', min: 5, max: 20, step: 0.5, value: p.f, unit: 'cm', digits: 1,
      onInput: function (v) { p.f = v; chips.clear(); }
    });
    var sU = mkSlider(sh.body, {
      label: '物距 u', min: 2, max: 60, step: 0.5, value: p.u, unit: 'cm', digits: 1,
      onInput: function (v) { p.u = v; chips.clear(); }
    });
    var sH = mkSlider(sh.body, {
      label: '物高 h', min: 1, max: 5, step: 0.1, value: p.h, unit: 'cm', digits: 1,
      onInput: function (v) { p.h = v; }
    });

    var chips = mkChips(sh.body, [
      { label: 'u < f', k: 0.6 },
      { label: 'u = f', k: 1 },
      { label: 'f < u < 2f', k: 1.5 },
      { label: 'u = 2f', k: 2 },
      { label: 'u > 2f', k: 3 }
    ], function (it) {
      var val = clamp(Math.round(it.k * p.f * 2) / 2, 2, 60);
      p.u = val;
      sU.set(val);
    });
    sh.body.appendChild(el('div', 'psw-note', '实线表示实像，虚线表示虚像；拖动滑块观察光线实时变化。'));

    var stage = makeStage(sh.stage, function (c2, dt, time, w, h) {
      if (MOTION) {
        var k = clamp(dt * 12, 0, 1);
        e.f += (p.f - e.f) * k;
        e.u += (p.u - e.u) * k;
        e.h += (p.h - e.h) * k;
        if (Math.abs(p.f - e.f) < 0.002) e.f = p.f;
        if (Math.abs(p.u - e.u) < 0.002) e.u = p.u;
        if (Math.abs(p.h - e.h) < 0.002) e.h = p.h;
      } else {
        e.f = p.f; e.u = p.u; e.h = p.h;
      }

      var f = e.f, udis = e.u, oh = e.h;
      var noImage = Math.abs(udis - f) < 0.06;
      var v = noImage ? Infinity : (udis * f) / (udis - f);
      var hImg = noImage ? 0 : -oh * (v / udis);
      var mag = noImage ? 0 : Math.abs(v / udis);

      var kindText;
      if (noImage) kindText = 'u = f，不成像';
      else if (v > 0) {
        if (Math.abs(udis - 2 * f) < 0.12) kindText = '倒立等大实像';
        else if (udis > 2 * f) kindText = '倒立缩小实像';
        else kindText = '倒立放大实像';
      } else kindText = '正立放大虚像';

      setTight(sh, h);
      backdrop(c2, w, h, th);

      var bottomBar = clamp(h * 0.15, 50, 64);
      var drawH = h - bottomBar;
      var axisY = drawH * 0.64;
      var lensHalf = clamp(drawH * 0.28, 40, 220);
      var marginX = clamp(w * 0.055, 14, 56);

      var leftNeed = Math.max(udis, 2 * f, v < 0 ? Math.min(-v, 8 * f) : 0) * 1.14 + 1.5;
      var rightNeed = Math.max(2 * f * 1.18, v > 0 ? Math.min(v, 8 * f) * 1.10 : 0, 3) + 1.5;
      var availW = Math.max(60, w - marginX * 2);
      var scale = availW / (leftNeed + rightNeed);
      var topRoom = Math.max(30, axisY - 22);
      var bottomRoom = Math.max(30, drawH - axisY - 8);
      var tall = Math.max(oh, Math.min(Math.abs(hImg), oh * 3.2)) * scale;
      var limit = Math.min(topRoom, bottomRoom) * 0.94;
      if (tall > limit && tall > 0.001) scale *= limit / tall;
      if (!isFinite(scale) || scale <= 0.01) scale = 1;
      var lensX = marginX + leftNeed * scale + Math.max(0, (availW - (leftNeed + rightNeed) * scale) / 2);

      var ox = lensX - udis * scale;
      var oTipY = axisY - oh * scale;
      var fx = f * scale;
      var ix = noImage ? lensX : lensX + v * scale;
      var iy = noImage ? axisY : axisY - hImg * scale;

      /* 光学元件与光线 */
      c2.save();
      c2.beginPath();
      c2.rect(0, 0, w, drawH + 1);
      c2.clip();

      line(c2, 6, axisY, w - 6, axisY, { color: 'rgba(148,163,184,.42)', width: 1.1, dash: [7, 5] });
      txt(c2, '主光轴', w - 10, axisY - 7, { size: 8.5, color: '#64748b', align: 'right' });

      function focalMark(kk, label) {
        var x = lensX + kk * fx;
        if (x < 10 || x > w - 10) return;
        line(c2, x, axisY - 5 * Math.max(0.8, scale / 6), x, axisY + 5 * Math.max(0.8, scale / 6),
          { color: 'rgba(226,232,240,.5)', width: 1.1 });
        dot(c2, x, axisY, 2.2, 'rgba(226,232,240,.65)', 0);
        txt(c2, label, x, axisY + 15, { size: 9, color: '#94a3b8', align: 'center' });
      }
      focalMark(-2, '2F');
      focalMark(-1, 'F');
      focalMark(1, 'F′');
      focalMark(2, '2F′');

      // 光线 1：平行主光轴 → 过焦点 F′
      line(c2, ox, oTipY, lensX, oTipY, { color: '#fbbf24', width: 1.5 });
      var dx1 = Math.max(1e-6, fx);
      var dy1 = axisY - oTipY;
      var k1 = (w + 26 - lensX) / dx1;
      line(c2, lensX, oTipY, lensX + dx1 * k1, oTipY + dy1 * k1, { color: '#fbbf24', width: 1.5 });

      // 光线 2：过光心，方向不变
      var dx2 = Math.max(1e-6, udis * scale);
      var dy2 = axisY - oTipY;
      var k2 = (w + 26 - lensX) / dx2;
      line(c2, ox, oTipY, lensX + dx2 * k2, oTipY + dy2 * k2, { color: '#34d399', width: 1.5 });

      // 光线 3：过焦点 F → 出射平行主光轴
      if (Math.abs(udis - f) > 0.14) {
        var ratio = f / (f - udis);
        var yL = axisY + (oTipY - axisY) * ratio;
        line(c2, ox, oTipY, lensX, yL, { color: '#a78bfa', width: 1.5 });
        line(c2, lensX, yL, w + 26, yL, { color: '#a78bfa', width: 1.5 });
        if (v < 0 && isFinite(ix) && isFinite(iy)) {
          line(c2, lensX, yL, ix, iy, { color: 'rgba(167,139,250,.55)', width: 1.1, dash: [5, 5] });
        }
      }

      // 虚像的反向延长线
      if (v < 0 && isFinite(ix) && isFinite(iy)) {
        line(c2, lensX, oTipY, ix, iy, { color: 'rgba(251,191,36,.45)', width: 1.1, dash: [5, 5] });
        line(c2, lensX, axisY, ix, iy, { color: 'rgba(52,211,153,.4)', width: 1.1, dash: [5, 5] });
      }

      // 透镜
      var lg = c2.createLinearGradient(lensX - lensHalf * 0.2, axisY, lensX + lensHalf * 0.2, axisY);
      lg.addColorStop(0, rgba(th.accent, 0.10));
      lg.addColorStop(0.5, rgba(th.accent, 0.30));
      lg.addColorStop(1, rgba(th.accent, 0.10));
      c2.beginPath();
      c2.moveTo(lensX, axisY - lensHalf);
      c2.quadraticCurveTo(lensX + lensHalf * 0.18, axisY, lensX, axisY + lensHalf);
      c2.quadraticCurveTo(lensX - lensHalf * 0.18, axisY, lensX, axisY - lensHalf);
      c2.closePath();
      c2.fillStyle = lg;
      c2.fill();
      c2.strokeStyle = rgba(th.accent, 0.82);
      c2.lineWidth = 1.8;
      c2.stroke();
      c2.beginPath();
      c2.moveTo(lensX, axisY - lensHalf);
      c2.lineTo(lensX, axisY + lensHalf);
      c2.strokeStyle = 'rgba(226,232,240,.18)';
      c2.lineWidth = 1;
      c2.setLineDash([5, 5]);
      c2.stroke();
      c2.setLineDash([]);
      txt(c2, '凸透镜', lensX, axisY + lensHalf + 14, { size: 9, color: '#94a3b8', align: 'center' });

      // 物
      arrow(c2, ox, axisY, ox, oTipY, { color: th.accent, width: 2.4, head: 9, glow: 6 });
      dot(c2, ox, axisY, 2.6, th.accent, 0);
      var labLeft = ox > 62;
      txt(c2, '物 h=' + fmt(oh, 1) + ' cm', labLeft ? ox - 9 : ox + 9, oTipY - 6,
        { size: 9.5, color: th.accent, align: labLeft ? 'right' : 'left' });

      // 像
      if (!noImage && isFinite(ix) && isFinite(iy)) {
        var real = v > 0;
        var col = real ? '#fbbf24' : '#c084fc';
        if (ix > -40 && ix < w + 40) {
          if (real) {
            arrow(c2, ix, axisY, ix, iy, { color: col, width: 2.4, head: 9, glow: 6 });
          } else {
            line(c2, ix, axisY, ix, iy, { color: col, width: 2, dash: [6, 4] });
            var dir = iy < axisY ? 1 : -1;
            c2.save();
            c2.strokeStyle = col;
            c2.lineWidth = 1.6;
            c2.beginPath();
            c2.moveTo(ix, iy);
            c2.lineTo(ix - 5, iy + 9 * dir);
            c2.lineTo(ix + 5, iy + 9 * dir);
            c2.closePath();
            c2.stroke();
            c2.restore();
          }
          dot(c2, ix, axisY, 2.4, col, 0);
          var imgLabLeft = ix > w - 82;
          txt(c2, real ? '实像' : '虚像', imgLabLeft ? ix - 9 : ix + 9, iy + (real ? 12 : -10),
            { size: 9.5, color: col, align: imgLabLeft ? 'right' : 'left' });
          txt(c2, 'h′=' + fmt(Math.abs(hImg), 1) + ' cm', imgLabLeft ? ix - 9 : ix + 9, iy + (real ? 26 : 3),
            { size: 9, color: '#94a3b8', align: imgLabLeft ? 'right' : 'left' });
        }
      }
      c2.restore();

      /* 底部尺寸标注 */
      var barG = c2.createLinearGradient(0, drawH, 0, h);
      barG.addColorStop(0, 'rgba(7,13,24,0)');
      barG.addColorStop(0.3, 'rgba(7,13,24,.92)');
      barG.addColorStop(1, 'rgba(7,13,24,.96)');
      c2.fillStyle = barG;
      c2.fillRect(0, drawH, w, h - drawH);

      function dim(x1, x2, y, color, label) {
        if (!isFinite(x1) || !isFinite(x2)) return;
        if (Math.abs(x2 - x1) < 8) return;
        line(c2, x1, y, x2, y, { color: color, width: 1 });
        arrow(c2, x1, y, x2, y, { color: color, width: 1, head: 5 });
        arrow(c2, x2, y, x1, y, { color: color, width: 1, head: 5 });
        txt(c2, label, (x1 + x2) / 2, y - 5, { size: 9, color: color, align: 'center' });
      }

      var uY = drawH + 18;
      line(c2, ox, axisY, ox, uY, { color: 'rgba(148,163,184,.22)', width: 1, dash: [3, 4] });
      line(c2, lensX, axisY, lensX, uY, { color: 'rgba(148,163,184,.22)', width: 1, dash: [3, 4] });
      dim(ox, lensX, uY, th.accent, 'u = ' + fmt(udis, 1) + ' cm');

      if (!noImage && isFinite(ix)) {
        var vY = uY + 20;
        line(c2, lensX, axisY, lensX, vY, { color: 'rgba(148,163,184,.22)', width: 1, dash: [3, 4] });
        line(c2, ix, axisY, ix, vY, { color: 'rgba(148,163,184,.22)', width: 1, dash: [3, 4] });
        dim(lensX, ix, vY, v > 0 ? '#fbbf24' : '#c084fc',
          'v = ' + fmt(v, 1) + ' cm' + (v < 0 ? '（虚）' : ''));
      }

      /* 状态与读数 */
      var btext, bkind;
      if (noImage) { btext = 'u = f · 出射光平行，不成像'; bkind = 'warn'; }
      else if (v > 0) { btext = kindText + ' · 可被光屏承接'; bkind = 'ok'; }
      else { btext = '正立放大虚像 · 与物同侧'; bkind = 'info'; }
      badge.set(btext, bkind);

      hud.set([
        ['焦距 f', fmt(f, 1) + ' cm'],
        ['物距 u', fmt(udis, 1) + ' cm'],
        ['像距 v', noImage ? '∞' : fmt(v, 1) + ' cm' + (v < 0 ? '（虚）' : ''), v > 0 ? 'acc' : ''],
        ['放大率 |m|', noImage ? '—' : fmt(mag, 2) + ' ×'],
        ['像高 h′', noImage ? '—' : fmt(Math.abs(hImg), 2) + ' cm'],
        ['像的性质', kindText]
      ], '1 cm = ' + fmt(scale, 1) + ' px · 实线 实像 / 虚线 虚像');
    });

    function applyParams(np) {
      if (!np) return;
      if (np.f != null) { p.f = clamp(num(np.f, p.f), 5, 20); sF.set(p.f); }
      if (np.u != null) { p.u = clamp(num(np.u, p.u), 2, 60); sU.set(p.u); }
      if (np.h != null) { p.h = clamp(num(np.h, p.h), 1, 5); sH.set(p.h); }
      chips.clear();
    }

    return {
      destroy: function () {
        stage.destroy();
        clear(root);
      },
      resize: function () {},
      setParams: applyParams
    };
  }

  /* ======================================================================
   * 5. 串并联电路
   * ==================================================================== */

  function mountCircuit(root, params, ctx) {
    params = params || {};
    var th = themeOf(ctx);
    var sh = makeShell(root, th, {
      title: '串并联电路',
      sub: '欧姆定律 · 电流表与电压表示数 · 功率分布',
      formula: '<b>串联</b> R = R₁ + R₂，I = U/R，U = U₁ + U₂<br>' +
        '<b>并联</b> 1/R = 1/R₁ + 1/R₂，U 各支路相等<br>' +
        '<b>功率</b> P = I²R = U²/R'
    });
    var hud = hudCtl(sh.stage);
    var badge = badgeCtl(sh.stage);

    var p = {
      U: clamp(num(params.U, 6), 1.5, 12),
      R1: clamp(num(params.R1, 10), 2, 50),
      R2: clamp(num(params.R2, 20), 2, 50),
      mode: params.mode === 'parallel' ? 'parallel' : 'series'
    };
    var st = { closed: params.closed !== false, phases: [], phaseKey: '' };

    function solve() {
      var R, I = 0, U1 = 0, U2 = 0, I1 = 0, I2 = 0, P1 = 0, P2 = 0, V = 0;
      if (p.mode === 'series') R = p.R1 + p.R2;
      else R = (p.R1 * p.R2) / (p.R1 + p.R2);
      if (st.closed) {
        if (p.mode === 'series') {
          I = p.U / R;
          U1 = I * p.R1;
          U2 = I * p.R2;
          I1 = I2 = I;
          P1 = I * I * p.R1;
          P2 = I * I * p.R2;
          V = U1;
        } else {
          I = p.U / R;
          I1 = p.U / p.R1;
          I2 = p.U / p.R2;
          U1 = U2 = p.U;
          P1 = p.U * I1;
          P2 = p.U * I2;
          V = p.U;
        }
      }
      return { R: R, I: I, U1: U1, U2: U2, I1: I1, I2: I2, P1: P1, P2: P2, V: V };
    }

    var sMode = mkSeg(sh.body, {
      label: '连接方式', aria: '连接方式',
      value: p.mode,
      options: [{ label: '串联', value: 'series' }, { label: '并联', value: 'parallel' }],
      onChange: function (v) { p.mode = v; st.phaseKey = ''; }
    });
    var sU = mkSlider(sh.body, {
      label: '电源电压 U', min: 1.5, max: 12, step: 0.1, value: p.U, unit: 'V', digits: 1,
      onInput: function (v) { p.U = v; }
    });
    var sR1 = mkSlider(sh.body, {
      label: '电阻 R₁', min: 2, max: 50, step: 1, value: p.R1, unit: 'Ω', digits: 0,
      onInput: function (v) { p.R1 = v; }
    });
    var sR2 = mkSlider(sh.body, {
      label: '电阻 R₂', min: 2, max: 50, step: 1, value: p.R2, unit: 'Ω', digits: 0,
      onInput: function (v) { p.R2 = v; }
    });

    var acts = el('div', 'psw-actions');
    sh.body.appendChild(acts);
    var bSw = mkBtn(acts, '开关：闭合', 'ghost toggle-on', function () {
      st.closed = !st.closed;
      bSw.textContent = st.closed ? '开关：闭合' : '开关：断开';
      bSw.classList.toggle('toggle-on', st.closed);
      bSw.setAttribute('aria-pressed', String(st.closed));
    }, '切换电路开关');
    bSw.classList.add('wide');
    bSw.setAttribute('aria-pressed', 'true');
    sh.body.appendChild(el('div', 'psw-note', '采用理想电表（电流表内阻为 0，电压表内阻为 ∞）。'));

    var stage = makeStage(sh.stage, function (c2, dt, time, w, h) {
      var vals = solve();
      setTight(sh, h);
      backdrop(c2, w, h, th);

      var compact = w < 340;
      var hudReserve = compact ? 0 : (w > 720 ? Math.min(250, w * 0.23) : Math.min(200, w * 0.31));
      var bx0 = clamp(w * 0.05, 10, 70);
      var bx1 = Math.max(bx0 + 120, w - hudReserve - (compact ? 10 : 14));
      var by0 = h * 0.15;
      var by1 = h * 0.90;
      var bw = bx1 - bx0;
      var bh = Math.min(by1 - by0, bw * 0.62);
      var midY = (by0 + by1) / 2;
      by0 = midY - bh / 2;
      by1 = midY + bh / 2;

      var u = clamp(Math.min(bw, bh * 1.3) / 260, 0.7, 1.6);
      var fs = clamp(bh * 0.062, 8.5, 12);
      var rHalf = 24 * u;
      var mr = 13 * u;
      var midYc = (by0 + by1) / 2;

      var segs = [];
      var xR1 = 0, xR2 = 0, xA = 0, xBat = 0, xSw = 0, vY = 0;
      var xB1 = 0, xB2 = 0, xV = 0, swY = midYc;

      if (p.mode === 'series') {
        xR1 = bx0 + bw * 0.24;
        xA = bx0 + bw * 0.50;
        xR2 = bx0 + bw * 0.76;
        xBat = bx0 + bw * 0.44;
        xSw = bx0 + bw * 0.14;
        vY = by0 + Math.min(bh * 0.38, 82 * u);
        segs = [
          { x1: xBat + 6 * u, y1: by1, x2: bx1, y2: by1, I: vals.I },
          { x1: bx1, y1: by1, x2: bx1, y2: by0, I: vals.I },
          { x1: bx1, y1: by0, x2: bx0, y2: by0, I: vals.I },
          { x1: bx0, y1: by0, x2: bx0, y2: by1, I: vals.I },
          { x1: bx0, y1: by1, x2: xBat - 6 * u, y2: by1, I: vals.I }
        ];
      } else {
        xB1 = bx0 + bw * 0.42;
        xB2 = bx1;
        xV = bx0 + bw * 0.76;
        xBat = bx0 + bw * 0.14;
        xA = bx0 + bw * 0.27;
        segs = [
          { x1: xBat + 6 * u, y1: by1, x2: xB1, y2: by1, I: vals.I },
          { x1: xB1, y1: by1, x2: bx1, y2: by1, I: vals.I2 },
          { x1: bx1, y1: by1, x2: bx1, y2: by0, I: vals.I2 },
          { x1: bx1, y1: by0, x2: xB1, y2: by0, I: vals.I2 },
          { x1: xB1, y1: by0, x2: bx0, y2: by0, I: vals.I },
          { x1: bx0, y1: by0, x2: bx0, y2: by1, I: vals.I },
          { x1: bx0, y1: by1, x2: xBat - 6 * u, y2: by1, I: vals.I },
          { x1: xB1, y1: by1, x2: xB1, y2: by0, I: vals.I1 }
        ];
      }

      /* 导线 */
      c2.save();
      c2.lineJoin = 'round';
      c2.lineCap = 'round';
      if (vals.I > 0.001) { c2.shadowColor = rgba(th.accent, 0.55); c2.shadowBlur = 9; }
      c2.strokeStyle = 'rgba(148,163,184,.92)';
      c2.lineWidth = 2;
      roundRect(c2, bx0, by0, bw, bh, Math.min(12 * u, bw * 0.05));
      c2.stroke();
      if (p.mode === 'parallel') {
        c2.beginPath();
        c2.moveTo(xB1, by0);
        c2.lineTo(xB1, by1);
        c2.moveTo(xV, by0);
        c2.lineTo(xV, by1);
        c2.stroke();
      } else {
        c2.beginPath();
        c2.moveTo(xR1 - rHalf, by0);
        c2.lineTo(xR1 - rHalf, vY);
        c2.lineTo(xR1 - mr, vY);
        c2.moveTo(xR1 + rHalf, by0);
        c2.lineTo(xR1 + rHalf, vY);
        c2.lineTo(xR1 + mr, vY);
        c2.stroke();
      }
      c2.restore();

      /* 电流小圆点 */
      var key = p.mode + (st.closed ? '-on' : '-off') + segs.length;
      if (st.phaseKey !== key || !st.phases || st.phases.length !== segs.length) {
        st.phaseKey = key;
        st.phases = [];
        for (var z = 0; z < segs.length; z++) st.phases.push(z * 7);
      }
      var spacing = 22 * u;
      for (var si = 0; si < segs.length; si++) {
        var sg = segs[si];
        if (!(sg.I > 1e-4)) { st.phases[si] = 0; continue; }
        var len = Math.sqrt((sg.x2 - sg.x1) * (sg.x2 - sg.x1) + (sg.y2 - sg.y1) * (sg.y2 - sg.y1));
        if (len < 2) continue;
        var speed = clamp(10 + 30 * Math.min(sg.I, 6), 10, 150);
        var ph = (st.phases[si] + speed * dt) % spacing;
        st.phases[si] = ph;
        var ux = (sg.x2 - sg.x1) / len;
        var uy = (sg.y2 - sg.y1) / len;
        for (var dd = ph; dd < len; dd += spacing) {
          var px = sg.x1 + ux * dd;
          var py = sg.y1 + uy * dd;
          c2.fillStyle = rgba(th.accent, 0.20);
          c2.beginPath();
          c2.arc(px, py, 5.2 * u, 0, Math.PI * 2);
          c2.fill();
          c2.fillStyle = '#bae6fd';
          c2.beginPath();
          c2.arc(px, py, 2.0 * u, 0, Math.PI * 2);
          c2.fill();
        }
      }

      /* 元件绘制 */
      function dotAt(x, y) { dot(c2, x, y, 2.4 * u, '#cbd5e1', 0); }

      function resistor(cx, cy, horizontal) {
        var hw = rHalf, ht = 7 * u;
        if (horizontal) {
          roundRect(c2, cx - hw, cy - ht, hw * 2, ht * 2, 3 * u);
        } else {
          roundRect(c2, cx - ht, cy - hw, ht * 2, hw * 2, 3 * u);
        }
        c2.fillStyle = '#0b1526';
        c2.fill();
        c2.strokeStyle = '#cbd5e1';
        c2.lineWidth = 1.6;
        c2.stroke();
        if (horizontal) {
          dotAt(cx - hw, cy);
          dotAt(cx + hw, cy);
        } else {
          dotAt(cx, cy - hw);
          dotAt(cx, cy + hw);
        }
      }

      function meter(cx, cy, letter) {
        c2.beginPath();
        c2.arc(cx, cy, mr, 0, Math.PI * 2);
        c2.fillStyle = '#081120';
        c2.fill();
        c2.strokeStyle = '#cbd5e1';
        c2.lineWidth = 1.7;
        c2.stroke();
        c2.beginPath();
        c2.arc(cx, cy, mr * 0.74, 0, Math.PI * 2);
        c2.strokeStyle = 'rgba(148,163,184,.20)';
        c2.lineWidth = 1;
        c2.stroke();
        txt(c2, letter, cx, cy + mr * 0.32, { size: mr * 0.86, align: 'center', weight: 600, color: '#f1f5f9' });
      }

      function battery(cx, cy) {
        c2.save();
        c2.strokeStyle = '#e2e8f0';
        c2.lineWidth = 2;
        c2.beginPath();
        c2.moveTo(cx - 5 * u, cy - 8 * u);
        c2.lineTo(cx - 5 * u, cy + 8 * u);
        c2.stroke();
        c2.lineWidth = 2.6;
        c2.beginPath();
        c2.moveTo(cx + 5 * u, cy - 14 * u);
        c2.lineTo(cx + 5 * u, cy + 14 * u);
        c2.stroke();
        txt(c2, '+', cx + 8 * u, cy - 12 * u, { size: 7.5 * u, color: '#94a3b8' });
        txt(c2, '−', cx - 8 * u, cy - 12 * u, { size: 7.5 * u, color: '#94a3b8', align: 'right' });
        c2.restore();
      }

      function switchSym(cx, cy, horizontal) {
        var L = 15 * u;
        var ax, ay, bx, by;
        if (horizontal) { ax = cx - L; ay = cy; bx = cx + L; by = cy; }
        else { ax = cx; ay = cy - L; bx = cx; by = cy + L; }
        c2.save();
        c2.strokeStyle = st.closed ? '#e2e8f0' : '#f87171';
        c2.lineWidth = 2;
        c2.lineCap = 'round';
        dotAt(ax, ay);
        dotAt(bx, by);
        c2.beginPath();
        c2.moveTo(ax, ay);
        if (st.closed) c2.lineTo(bx, by);
        else if (horizontal) c2.lineTo(cx + L * 0.55, cy - L * 0.8);
        else c2.lineTo(cx + L * 0.8, cy - L * 0.55);
        c2.stroke();
        c2.restore();
      }

      function clabel(str, x, y, color, align) {
        txt(c2, str, clamp(x, 4, w - 4), y, { size: fs, color: color, align: align || 'left' });
      }

      if (p.mode === 'series') {
        resistor(xR1, by0, true);
        resistor(xR2, by0, true);
        meter(xA, by0, 'A');
        meter(xR1, vY, 'V');
        battery(xBat, by1);
        switchSym(xSw, by1, true);
        dotAt(bx0, by1);
        dotAt(bx1, by1);

        clabel('R₁ ' + fmt(p.R1, 0) + ' Ω', xR1, by0 - 15 * u, '#f1f5f9', 'center');
        clabel('R₂ ' + fmt(p.R2, 0) + ' Ω', xR2, by0 - 15 * u, '#f1f5f9', 'center');
        clabel(fmt(vals.I, 2) + ' A', xA, by0 - 15 * u, '#f59e0b', 'center');
        clabel(fmt(vals.V, 2) + ' V', xR1, vY + mr + 7 * u, '#f59e0b', 'center');
        clabel('U = ' + fmt(p.U, 1) + ' V', xBat, by1 + 20 * u, '#cbd5e1', 'center');
        clabel('S', xSw, by1 + 20 * u, '#cbd5e1', 'center');
      } else {
        resistor(xB1, midYc, false);
        resistor(xB2, midYc, false);
        meter(xV, midYc, 'V');
        meter(xA, by1, 'A');
        battery(xBat, by1);
        switchSym(bx0, swY, false);
        dotAt(xB1, by0);
        dotAt(xB1, by1);
        dotAt(bx0, by0);
        dotAt(bx1, by0);

        clabel('R₁ ' + fmt(p.R1, 0) + ' Ω', xB1, midYc - rHalf - 9 * u, '#f1f5f9', 'center');
        clabel('R₂ ' + fmt(p.R2, 0) + ' Ω', xB2, midYc - rHalf - 9 * u, '#f1f5f9', 'right');
        clabel('V  ' + fmt(vals.V, 2) + ' V', xV, midYc + mr + 11 * u, '#f59e0b', 'center');
        clabel(fmt(vals.I, 2) + ' A', xA, by1 - 18 * u, '#f59e0b', 'center');
        clabel('U = ' + fmt(p.U, 1) + ' V', xBat, by1 + 20 * u, '#cbd5e1', 'center');
        clabel('S', bx0 + 14 * u, swY - 22 * u, '#cbd5e1', 'left');
      }

      /* 状态与读数 */
      var btext, bkind;
      if (!st.closed) { btext = '开关断开 · 断路，I = 0'; bkind = 'warn'; }
      else if (p.mode === 'series') { btext = '串联通路 · I = ' + fmt(vals.I, 2) + ' A'; bkind = 'ok'; }
      else { btext = '并联通路 · I总 = ' + fmt(vals.I, 2) + ' A'; bkind = 'ok'; }
      badge.set(btext, bkind);

      var rows;
      if (p.mode === 'series') {
        rows = [
          ['总电阻 R', fmt(vals.R, 2) + ' Ω'],
          ['电流表 A', fmt(vals.I, 2) + ' A', 'acc'],
          ['电压表 V', fmt(vals.V, 2) + ' V', 'acc'],
          ['R₁ 电压', fmt(vals.U1, 2) + ' V'],
          ['R₂ 电压', fmt(vals.U2, 2) + ' V'],
          ['R₁ 功率', fmt(vals.P1, 2) + ' W'],
          ['R₂ 功率', fmt(vals.P2, 2) + ' W'],
          ['总功率 P', fmt(vals.P1 + vals.P2, 2) + ' W']
        ];
      } else {
        rows = [
          ['总电阻 R', fmt(vals.R, 2) + ' Ω'],
          ['电流表 A', fmt(vals.I, 2) + ' A', 'acc'],
          ['电压表 V', fmt(vals.V, 2) + ' V', 'acc'],
          ['I₁ 支路', fmt(vals.I1, 2) + ' A'],
          ['I₂ 支路', fmt(vals.I2, 2) + ' A'],
          ['R₁ 功率', fmt(vals.P1, 2) + ' W'],
          ['R₂ 功率', fmt(vals.P2, 2) + ' W'],
          ['总功率 P', fmt(vals.P1 + vals.P2, 2) + ' W']
        ];
      }
      hud.set(rows, p.mode === 'series'
        ? 'R = R₁ + R₂ · I 处处相等'
        : '1/R = 1/R₁ + 1/R₂');
    });

    function applyParams(np) {
      if (!np) return;
      if (np.U != null) { p.U = clamp(num(np.U, p.U), 1.5, 12); sU.set(p.U); }
      if (np.R1 != null) { p.R1 = clamp(num(np.R1, p.R1), 2, 50); sR1.set(p.R1); }
      if (np.R2 != null) { p.R2 = clamp(num(np.R2, p.R2), 2, 50); sR2.set(p.R2); }
      if (np.mode === 'series' || np.mode === 'parallel') { p.mode = np.mode; sMode.set(p.mode); }
      if (np.closed != null) {
        st.closed = !!np.closed;
        bSw.textContent = st.closed ? '开关：闭合' : '开关：断开';
        bSw.classList.toggle('toggle-on', st.closed);
        bSw.setAttribute('aria-pressed', String(st.closed));
      }
      st.phaseKey = '';
    }

    return {
      destroy: function () {
        stage.destroy();
        clear(root);
      },
      resize: function () {},
      setParams: applyParams
    };
  }

  /* ======================================================================
   * 注册
   * ==================================================================== */

  PS.projectile = {
    title: '斜抛运动',
    defaults: { v0: 20, angle: 45 },
    mount: mountProjectile
  };
  PS.incline = {
    title: '斜面摩擦',
    defaults: { angle: 30, mu: 0.2, mass: 2 },
    mount: mountIncline
  };
  PS.pulley = {
    title: '滑轮组',
    defaults: { n: 2, G: 100, F: 60 },
    mount: mountPulley
  };
  PS.lens = {
    title: '凸透镜成像',
    defaults: { f: 10, u: 30, h: 3 },
    mount: mountLens
  };
  PS.circuit = {
    title: '串并联电路',
    defaults: { U: 6, R1: 10, R2: 20, mode: 'series' },
    mount: mountCircuit
  };
})();