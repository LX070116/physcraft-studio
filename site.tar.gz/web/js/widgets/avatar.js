/* 数字人教师：SVG 形象 + 中文语音 + 口型/眨眼/手势联动
 * 契约：PSWidgets.avatar = { title, defaults, mount(root, params, ctx) }
 */
(function () {
  var PS = (window.PSWidgets = window.PSWidgets || {});
  var FONT = '"Microsoft YaHei","PingFang SC",system-ui,sans-serif';

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  var CSS = [
    '.psw-a{position:relative;width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;overflow:hidden;font-family:' + FONT + ';background:radial-gradient(120% 90% at 50% 8%,rgba(56,189,248,.16),rgba(8,14,24,0) 70%)}',
    '.psw-a-stage{position:absolute;inset:0;display:flex;align-items:center;justify-content:center}',
    '.psw-a-svg{width:100%;height:100%;display:block}',
    '.psw-a-name{position:absolute;left:12px;top:10px;display:flex;align-items:center;gap:7px;padding:4px 9px;border-radius:999px;background:rgba(6,12,20,.6);border:1px solid rgba(255,255,255,.09);font-size:10.5px;color:#dbeafe;backdrop-filter:blur(6px);z-index:3}',
    '.psw-a-dot{width:5px;height:5px;border-radius:50%;background:#34d399;box-shadow:0 0 8px #34d399}',
    '.psw-a-name b{font-size:11px}',
    '.psw-a-name span{color:#8fa3bf;font-size:9.5px}',
    '.psw-a-sub{position:absolute;left:12px;right:12px;bottom:44px;max-height:96px;overflow:hidden;padding:9px 12px;border-radius:12px;background:rgba(8,14,24,.78);border:1px solid rgba(255,255,255,.1);font-size:11.5px;line-height:1.62;color:#dbe7f5;backdrop-filter:blur(8px);opacity:0;transform:translateY(6px);transition:opacity .25s,transform .25s;z-index:3}',
    '.psw-a-sub.on{opacity:1;transform:none}',
    '.psw-a-sub .hl{color:#7dd3fc;font-weight:700}',
    '.psw-a-ctl{position:absolute;right:10px;bottom:8px;display:flex;gap:6px;z-index:4}',
    '.psw-a-btn{border:1px solid rgba(255,255,255,.14);background:rgba(10,17,28,.7);color:#cbd9ea;border-radius:8px;padding:4px 9px;font-size:10.5px;cursor:pointer;font-family:inherit;display:flex;align-items:center;gap:4px}',
    '.psw-a-btn:hover{border-color:rgba(56,189,248,.5);color:#eaf6ff}',
    '.psw-a-btn.off{opacity:.5}',
    '.psw-a-btn svg{width:12px;height:12px}',
    '.psw-a-eye{transform-box:fill-box;transform-origin:center}',
    '.psw-a-mouth{transform-box:fill-box;transform-origin:center}',
  ].join('\n');

  function injectStyle() {
    if (document.querySelector('style[data-psw-style="avatar"]')) return;
    var s = document.createElement('style');
    s.setAttribute('data-psw-style', 'avatar');
    s.textContent = CSS;
    document.head.appendChild(s);
  }

  var MOUTH = {
    closed: 'M132 262 Q160 272 188 262',
  };

  function svgMarkup(accent) {
    var a = accent || '#38bdf8';
    return (
      '<svg class="psw-a-svg" viewBox="0 0 320 430" preserveAspectRatio="xMidYMax meet" aria-label="数字人教师">' +
      '<defs>' +
      '<radialGradient id="pswA_halo" cx="50%" cy="34%" r="62%">' +
      '<stop offset="0%" stop-color="' + a + '" stop-opacity=".26"/><stop offset="60%" stop-color="' + a + '" stop-opacity=".05"/><stop offset="100%" stop-color="' + a + '" stop-opacity="0"/>' +
      '</radialGradient>' +
      '<linearGradient id="pswA_skin" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0%" stop-color="#ffe6d2"/><stop offset="60%" stop-color="#f6d2b6"/><stop offset="100%" stop-color="#e9bd9f"/>' +
      '</linearGradient>' +
      '<linearGradient id="pswA_hair" x1="0" y1="0" x2="0.4" y2="1">' +
      '<stop offset="0%" stop-color="#3b2a26"/><stop offset="55%" stop-color="#2a1d1a"/><stop offset="100%" stop-color="#1b1210"/>' +
      '</linearGradient>' +
      '<linearGradient id="pswA_coat" x1="0" y1="0" x2="0.7" y2="1">' +
      '<stop offset="0%" stop-color="#22456b"/><stop offset="55%" stop-color="#1a3554"/><stop offset="100%" stop-color="#12263d"/>' +
      '</linearGradient>' +
      '<linearGradient id="pswA_shirt" x1="0" y1="0" x2="0" y2="1">' +
      '<stop offset="0%" stop-color="#ffffff"/><stop offset="100%" stop-color="#dbe7f3"/>' +
      '</linearGradient>' +
      '<linearGradient id="pswA_tie" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0%" stop-color="' + a + '"/><stop offset="100%" stop-color="#7c3aed"/>' +
      '</linearGradient>' +
      '<filter id="pswA_soft" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="7"/></filter>' +
      '</defs>' +

      /* 背景光晕 */
      '<rect x="0" y="0" width="320" height="430" fill="url(#pswA_halo)"/>' +
      '<circle cx="160" cy="150" r="92" fill="none" stroke="' + a + '" stroke-opacity=".18" stroke-width="1"/>' +
      '<circle cx="160" cy="150" r="120" fill="none" stroke="' + a + '" stroke-opacity=".08" stroke-width="1" stroke-dasharray="3 7"/>' +

      /* 身体（呼吸） */
      '<g data-g="body">' +
      '<ellipse cx="160" cy="418" rx="104" ry="14" fill="#000" opacity=".35" filter="url(#pswA_soft)"/>' +
      '<path d="M74 430 C74 356 104 322 160 322 C216 322 246 356 246 430 Z" fill="url(#pswA_coat)"/>' +
      '<path d="M74 430 C74 372 96 340 132 326 L146 344 L160 366 L174 344 L188 326 C224 340 246 372 246 430 Z" fill="url(#pswA_coat)" opacity=".55"/>' +
      /* 衬衫 */
      '<path d="M128 330 L160 372 L192 330 L178 322 L160 340 L142 322 Z" fill="url(#pswA_shirt)"/>' +
      /* 领带 */
      '<path d="M160 344 L150 356 L157 398 L160 410 L163 398 L170 356 Z" fill="url(#pswA_tie)"/>' +
      /* 西装翻领 */
      '<path d="M128 330 L146 344 L160 372 L126 372 L112 340 Z" fill="#16304c" opacity=".9"/>' +
      '<path d="M192 330 L174 344 L160 372 L194 372 L208 340 Z" fill="#16304c" opacity=".9"/>' +
      /* 口袋与铭牌 */
      '<rect x="190" y="392" width="34" height="18" rx="3" fill="#0d1b2b" stroke="#2b4a6b"/>' +
      '<rect x="194" y="396" width="26" height="3" rx="1.5" fill="' + a + '" opacity=".85"/>' +
      '<rect x="194" y="401" width="18" height="2.4" rx="1.2" fill="#7dd3fc" opacity=".55"/>' +
      '</g>' +

      /* 脖子与头 */
      '<g data-g="head">' +
      '<path d="M140 296 L140 322 Q160 336 180 322 L180 296 Z" fill="#e7b795"/>' +
      '<ellipse cx="160" cy="214" rx="56" ry="64" fill="url(#pswA_skin)"/>' +
      /* 耳朵 */
      '<ellipse cx="104" cy="216" rx="8" ry="12" fill="#f0c3a4"/><ellipse cx="216" cy="216" rx="8" ry="12" fill="#f0c3a4"/>' +
      /* 头发 */
      '<path d="M104 208 C100 148 124 126 160 124 C198 122 222 150 216 210 C214 186 202 166 182 160 C170 176 146 180 128 170 C116 178 108 192 104 208 Z" fill="url(#pswA_hair)"/>' +
      '<path d="M118 176 C126 150 144 138 168 138 C150 146 136 160 130 182 Z" fill="#4a3530" opacity=".55"/>' +
      /* 眉 */
      '<path d="M124 196 Q136 190 148 195" stroke="#3b2a26" stroke-width="3.4" stroke-linecap="round" fill="none"/>' +
      '<path d="M172 195 Q184 190 196 196" stroke="#3b2a26" stroke-width="3.4" stroke-linecap="round" fill="none"/>' +
      /* 眼 */
      '<g>' +
      '<ellipse cx="136" cy="214" rx="12" ry="8" fill="#fff"/>' +
      '<ellipse cx="184" cy="214" rx="12" ry="8" fill="#fff"/>' +
      '<circle cx="138" cy="214" r="5.4" fill="#3b2a26"/><circle cx="186" cy="214" r="5.4" fill="#3b2a26"/>' +
      '<circle cx="136" cy="212" r="1.8" fill="#fff"/><circle cx="184" cy="212" r="1.8" fill="#fff"/>' +
      '</g>' +
      /* 眼镜 */
      '<g fill="none" stroke="#8aa4bf" stroke-width="1.8" opacity=".95">' +
      '<rect x="118" y="202" width="36" height="24" rx="9"/>' +
      '<rect x="166" y="202" width="36" height="24" rx="9"/>' +
      '<path d="M154 212 Q160 209 166 212"/><path d="M118 210 L104 206"/><path d="M202 210 L216 206"/>' +
      '</g>' +
      /* 眼睑（眨眼） */
      '<g>' +
      '<rect class="pswA-eye" x="124" y="204" width="24" height="12" rx="4" opacity="0"/>' +
      '<rect class="pswA-eye" x="172" y="204" width="24" height="12" rx="4" opacity="0"/>' +
      '</g>' +
      /* 鼻 */
      '<path d="M160 220 Q158 232 154 236 Q160 239 166 236" stroke="#d9a07c" stroke-width="2.2" fill="none" stroke-linecap="round"/>' +
      /* 腮红 */
      '<ellipse cx="120" cy="238" rx="10" ry="5" fill="#f2a3a3" opacity=".22"/>' +
      '<ellipse cx="200" cy="238" rx="10" ry="5" fill="#f2a3a3" opacity=".22"/>' +
      /* 嘴 */
      '<g data-g="mouth">' +
      '<path data-mouth="lipU" d="M142 258 Q160 251 178 258" stroke="#b4534a" stroke-width="2.6" fill="none" stroke-linecap="round"/>' +
      '<ellipse data-mouth="in" cx="160" cy="261" rx="13" ry="3" fill="#7f2d2d"/>' +
      '<path data-mouth="lip" d="M143 260 Q160 272 177 260" stroke="#b4534a" stroke-width="2.4" fill="none" stroke-linecap="round"/>' +
      '</g>' +
      '</g>' +

      /* 左臂（自然下垂） */
      '<path d="M84 356 C70 386 72 412 82 428" stroke="#1a3554" stroke-width="26" stroke-linecap="round" fill="none"/>' +
      /* 右臂（可抬手示意） */
      '<g data-g="arm">' +
      '<path d="M236 356 C250 380 248 402 238 420" stroke="#1a3554" stroke-width="26" stroke-linecap="round" fill="none"/>' +
      '<circle cx="238" cy="422" r="13" fill="#f6d2b6"/>' +
      /* 教鞭 */
      '<path d="M244 414 L286 372" stroke="#cbd5e1" stroke-width="3.4" stroke-linecap="round" opacity=".85"/>' +
      '</g>' +
      '</svg>'
    );
  }

  function splitSentences(text) {
    var parts = String(text || "").match(/[^。！？；!?;\n]+[。！？；!?;\n]?/g);
    return (parts || [text || ""]).map(function (s) { return s.trim(); }).filter(Boolean);
  }

  function scoreVoice(v) {
    var n = (v.name || "").toLowerCase();
    var s = 0;
    if (/zh|cmn|chinese|中文/.test((v.lang || "") + n)) s += 20; else s -= 30;
    if (/xiaoxiao|晓晓|xiaoyi|晓伊|xiaohan|晓涵|huihui|慧慧|yaoyao|瑶瑶/.test(n)) s += 8;
    if (/google/.test(n)) s += 4;
    if (/female|女|xiaoxiao|xiaoyi|huihui|yaoyao|晓/.test((v.name || "") + "") && /男/.test(v.name || "") === false) s += 2;
    if (v.localService) s += 2;
    if (/en-us|en-gb/.test(v.lang || "")) s -= 25;
    return s;
  }

  function mount(root, params, ctx) {
    injectStyle();
    var accent = (ctx && ctx.theme && ctx.theme.accent) || params.accent || '#38bdf8';
    var motion = !(ctx && ctx.motion === false);
    var voice = Object.assign({ name: '', rate: 1, pitch: 0, volume: 1 }, params.voice || {});
    var name = params.name || '李老师';
    var role = params.role || '物理 · 智能助教';
    var lines = params.lines || [];
    var lineIdx = 0;
    var speaking = false;
    var muted = false;
    var token = 0;
    var timers = [];
    var blinkTimer = 0;
    var raf = 0;
    var mood = params.mood || 'neutral';
    var lastProgress = -1;

    root.innerHTML = '';
    var ui = el('div', 'psw-a');
    ui.innerHTML =
      '<div class="psw-a-stage">' + svgMarkup(accent) + '</div>' +
      '<div class="psw-a-name"><i class="psw-a-dot"></i><b>' + escapeHtml(name) + '</b><span>' + escapeHtml(role) + '</span></div>' +
      '<div class="psw-a-sub"></div>' +
      '<div class="psw-a-ctl">' +
      '<button class="psw-a-btn" id="pswA-say" title="朗读讲稿">' + iconMic() + '<span>朗读</span></button>' +
      '<button class="psw-a-btn" id="pswA-mute" title="静音">' + iconSound() + '</button>' +
      '</div>';
    root.appendChild(ui);

    var svg = ui.querySelector('svg');
    var body = svg.querySelector('[data-g="body"]');
    var head = svg.querySelector('[data-g="head"]');
    var lids = ui.querySelectorAll('.pswA-eye');
    var mouthG = svg.querySelector('[data-g="mouth"]');
    var mouthIn = svg.querySelector('[data-mouth="in"]');
    var lipL = svg.querySelector('[data-mouth="lip"]');
    var arm = svg.querySelector('[data-g="arm"]');
    var sub = ui.querySelector('.psw-a-sub');
    var sayBtn = ui.querySelector('#pswA-say');
    var muteBtn = ui.querySelector('#pswA-mute');

    function escapeHtml(s) {
      return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
      });
    }
    function iconMic() {
      return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M12 4a3 3 0 0 1 3 3v5a3 3 0 0 1-6 0V7a3 3 0 0 1 3-3z"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6"/></svg>';
    }
    function iconSound() {
      return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/></svg>';
    }
    function iconMute() {
      return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M11 5 6 9H3v6h3l5 4z"/><path d="m16 9 5 6M21 9l-5 6"/></svg>';
    }

    function pickVoice() {
      if (!('speechSynthesis' in window)) return null;
      var list = window.speechSynthesis.getVoices() || [];
      if (voice.name) {
        var exact = list.find(function (v) { return v.name === voice.name; });
        if (exact) return exact;
      }
      var zh = list.filter(function (v) { return /zh|cmn|chinese/i.test((v.lang || '') + ' ' + (v.name || '')); });
      var pool = zh.length ? zh : list;
      if (!pool.length) return null;
      return pool.slice().sort(function (a, b) { return scoreVoice(b) - scoreVoice(a); })[0];
    }

    function setSubtitle(index) {
      if (!sub._raw) return;
      if (index === lastProgress) return;
      lastProgress = index;
      var t = sub._raw;
      sub.innerHTML = '<span>' + escapeHtml(t.slice(0, index)) + '</span><span class="hl">' + escapeHtml(t.slice(index, index + 2)) + '</span><span>' + escapeHtml(t.slice(index + 2)) + '</span>';
    }

    function mouthOpen(amount) {
      var a = Math.max(0, Math.min(1, amount));
      mouthIn.setAttribute('ry', String(2.5 + a * 6.5));
      lipL.setAttribute('d', 'M143 260 Q160 ' + (268 + a * 8) + ' 177 260');
      mouthG.setAttribute('transform', 'translate(0 ' + (a * 2.2) + ')');
    }

    function setMouthLevel(a) {
      mouthOpen(a);
    }

    function startIdle() {
      if (raf) cancelAnimationFrame(raf);
      var t0 = performance.now();
      function frame(ts) {
        if (!ui.isConnected) return;
        var t = (ts - t0) / 1000;
        if (motion) {
          if (body) body.setAttribute('transform', 'translate(0 ' + Math.sin(t * 1.6) * 1.2 + ')');
          if (head) head.setAttribute('transform', 'translate(0 ' + Math.sin(t * 1.1) * 1.6 + ') rotate(' + Math.sin(t * 0.7) * 1.1 + ' 160 250)');
          if (arm) arm.setAttribute('transform', 'rotate(' + (Math.sin(t * 0.9) * 1.2) + ' 236 360)');
          if (!speaking) mouthOpen(0.06 + 0.05 * Math.sin(t * 2.2));
        }
        raf = requestAnimationFrame(frame);
      }
      raf = requestAnimationFrame(frame);
    }

    function blink() {
      if (!motion) return;
      lids.forEach(function (l) { l.setAttribute('opacity', '1'); });
      setTimeout(function () { lids.forEach(function (l) { l.setAttribute('opacity', '0'); }); }, 130);
      blinkTimer = setTimeout(blink, 2800 + Math.random() * 3200);
    }

    function speakLoop() {
      if (!speaking) return;
      var t = performance.now() / 260;
      var open = 0.18 + Math.abs(Math.sin(t) * Math.cos(t * 0.7)) * 0.72;
      mouthOpen(open);
      timers.push(setTimeout(speakLoop, 70));
    }

    function clearTimers() {
      timers.forEach(function (x) { clearTimeout(x); });
      timers = [];
    }

    function stop() {
      token++;
      speaking = false;
      clearTimers();
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
      mouthOpen(0.06);
      sub.classList.remove('on');
      sayBtn.innerHTML = iconMic() + '<span>朗读</span>';
      sayBtn.classList.remove('off');
    }

    function say(text) {
      text = String(text || '').trim();
      if (!text) return;
      stop();
      var my = ++token;
      speaking = true;
      sub._raw = text;
      lastProgress = -1;
      sub.classList.add('on');
      sub.textContent = text;
      sayBtn.innerHTML = iconMic() + '<span>停止</span>';
      sayBtn.classList.add('off');
      speakLoop();

      var chunks = splitSentences(text);
      var offset = 0;
      var i = 0;

      function fallback(start) {
        if (my !== token) return;
        var full = text;
        var pos = start;
        var step = function () {
          if (my !== token || pos >= full.length) {
            finish();
            return;
          }
          pos += 1;
          setSubtitle(pos);
          if (ctx && ctx.onProgress) ctx.onProgress(pos);
          timers.push(setTimeout(step, 165));
        };
        step();
      }

      function finish() {
        if (my !== token) return;
        speaking = false;
        clearTimers();
        mouthOpen(0.06);
        sayBtn.innerHTML = iconMic() + '<span>朗读</span>';
        sayBtn.classList.remove('off');
        setTimeout(function () { if (my === token) sub.classList.remove('on'); }, 2600);
        if (ctx && ctx.onProgress) ctx.onProgress(text.length);
      }

      function next() {
        if (my !== token) return;
        if (i >= chunks.length) { finish(); return; }
        var chunk = chunks[i];
        var start = offset;
        offset += chunk.length;
        i++;
        if (!('speechSynthesis' in window) || muted) {
          fallback(start);
          return;
        }
        var u = new SpeechSynthesisUtterance(chunk);
        var v = pickVoice();
        if (v) u.voice = v;
        u.lang = (v && v.lang) || 'zh-CN';
        u.rate = Number(voice.rate) || 1;
        u.pitch = Number(voice.pitch) || 0;
        u.volume = Number(voice.volume) == null ? 1 : Number(voice.volume);
        u.onboundary = function (e) {
          if (my !== token) return;
          var idx = start + (e.charIndex || 0);
          setSubtitle(idx);
          if (ctx && ctx.onProgress) ctx.onProgress(idx);
        };
        u.onend = function () { if (my === token) next(); };
        u.onerror = function () { if (my === token) fallback(start); };
        try {
          window.speechSynthesis.speak(u);
        } catch (e) {
          fallback(start);
        }
      }

      if (!('speechSynthesis' in window)) {
        fallback(0);
      } else {
        next();
      }
    }

    function setVoice(v) {
      var wasSpeaking = speaking;
      var last = sub._raw || '';
      voice = Object.assign({}, voice, v || {});
      if (wasSpeaking) {
        stop();
        if (last) say(last);
      }
    }

    function setMood(m) {
      mood = m || 'neutral';
      if (mood === 'happy') {
        mouthOpen(0.14);
      } else if (mood === 'thinking') {
        if (head) head.setAttribute('transform', 'rotate(-3 160 250)');
      } else {
        mouthOpen(0.06);
      }
    }

    sayBtn.onclick = function () {
      if (speaking) {
        stop();
        return;
      }
      var text = lines[lineIdx % Math.max(1, lines.length)] || '同学们好，我是李老师。我们开始上课。';
      lineIdx++;
      say(text);
    };
    muteBtn.onclick = function () {
      muted = !muted;
      muteBtn.classList.toggle('off', muted);
      muteBtn.innerHTML = muted ? iconMute() : iconSound();
      if (muted && 'speechSynthesis' in window) window.speechSynthesis.cancel();
    };

    startIdle();
    blink();

    if (params.autoSay && params.lines && params.lines.length) say(params.lines[0]);

    return {
      say: say,
      stop: stop,
      setMood: setMood,
      setVoice: setVoice,
      setParams: function (p) {
        if (!p) return;
        if (p.name) ui.querySelector('.psw-a-name b').textContent = p.name;
        if (p.voice) setVoice(p.voice);
      },
      resize: function () {},
      destroy: function () {
        token++;
        speaking = false;
        clearTimers();
        if (raf) cancelAnimationFrame(raf);
        clearTimeout(blinkTimer);
        if ('speechSynthesis' in window) window.speechSynthesis.cancel();
        if (ui.parentNode) ui.parentNode.removeChild(ui);
      },
    };
  }

  PS.avatar = {
    title: '数字人教师',
    defaults: { name: '李老师', role: '物理 · 智能助教', lines: [], mood: 'neutral' },
    mount: mount,
  };
})();