/* ═══════════════════════════════════════════════════════════════════════════
 * 悟理智课 · 扩展交互控件集  sims-extra.js
 * 控件：buoyancy（浮力浮沉）/ wave（机械波）/ vector（力的合成）/ thermal（分子热运动）
 * 零依赖：ES2017 + Canvas 2D，不使用 import/export、外部字体、图片、CDN。
 * 契约见 docs/CONTRACT.md：窗口对象 PSWidgets[key] = { title, defaults, mount }
 * ═══════════════════════════════════════════════════════════════════════════ */
(function (global) {
  "use strict";

  var PSW = (global.PSWidgets = global.PSWidgets || {});
  var FONT = '"Microsoft YaHei","PingFang SC",system-ui,sans-serif';
  var ACCENT_DEF = "#38bdf8";
  var GRAV = 9.8;          // 重力加速度 m/s²
  var R_GAS = 8.314;       // 气体常量 J/(mol·K)
  var K_B = 1.380649e-23;  // 玻尔兹曼常量 J/K

  /* ────────────────────────────── 小工具 ────────────────────────────── */

  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function num(v, def, a, b) {
    v = parseFloat(v);
    if (!isFinite(v)) v = def;
    return clamp(v, a, b);
  }
  function fx(v, d) {
    d = d == null ? 1 : d;
    if (!isFinite(v)) return "—";
    return Math.abs(v) < 1e-9 ? (0).toFixed(d) : v.toFixed(d);
  }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function hexRgb(h) {
    h = String(h).replace("#", "");
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var n = parseInt(h, 16);
    if (!isFinite(n)) return [56, 189, 248];
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function toHex(r, g, b) {
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }
  function mixHex(c1, c2, t) {
    var a = hexRgb(c1), b = hexRgb(c2);
    return toHex(
      Math.round(lerp(a[0], b[0], t)),
      Math.round(lerp(a[1], b[1], t)),
      Math.round(lerp(a[2], b[2], t))
    );
  }
  function rgba(c, a) {
    if (typeof c !== "string" || c.charAt(0) !== "#") return c; // 非 hex（如 rgb()）原样返回
    var r = hexRgb(c);
    return "rgba(" + r[0] + "," + r[1] + "," + r[2] + "," + a + ")";
  }
  var SUP = { "-": "⁻", "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴", "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹" };
  function sup(n) {
    return String(n).split("").map(function (c) { return SUP[c] || c; }).join("");
  }
  function sci(v) {
    if (!isFinite(v) || v === 0) return "0";
    var e = Math.floor(Math.log10(Math.abs(v)));
    var m = v / Math.pow(10, e);
    return fx(m, 2) + "×10" + sup(e);
  }
  function themeOf(ctx) {
    var t = (ctx && ctx.theme) || {};
    return {
      accent: t.accent || ACCENT_DEF,
      fg: t.fg || "#e2e8f0",
      muted: t.muted || "#94a3b8",
      grid: t.grid || "rgba(148,163,184,.16)"
    };
  }

  /* ────────────────────────────── 样式（只注入一次） ────────────────────────────── */

  var CSS = [
    '.psw-x{position:absolute;top:0;right:0;bottom:0;left:0;overflow:hidden;background:#0b1220;',
    'color:#e2e8f0;font-family:' + FONT + ';font-size:12px;line-height:1.4;-webkit-font-smoothing:antialiased;',
    '--psw-x-accent:#38bdf8;--psw-x-a06:rgba(56,189,248,.06);--psw-x-a10:rgba(56,189,248,.10);',
    '--psw-x-a18:rgba(56,189,248,.18);--psw-x-a35:rgba(56,189,248,.35);}',

    '.psw-x *{box-sizing:border-box;}',
    '.psw-x-stage{position:absolute;top:0;right:0;bottom:0;left:0;display:flex;flex-direction:row-reverse;gap:10px;padding:10px;}',

    '.psw-x-cw{position:relative;flex:1 1 auto;min-width:0;min-height:0;border-radius:16px;overflow:hidden;',
    'background:radial-gradient(130% 115% at 26% -14%,#13223c 0%,#0b1220 58%,#070c16 100%);',
    'box-shadow:inset 0 0 0 1px rgba(255,255,255,.05),0 12px 34px rgba(0,0,0,.28);}',
    '.psw-x-cv{display:block;position:absolute;left:0;top:0;}',

    '.psw-x-card{position:absolute;left:10px;top:10px;z-index:3;padding:9px 11px;border-radius:12px;',
    'background:rgba(12,19,33,.66);border:1px solid rgba(255,255,255,.08);',
    '-webkit-backdrop-filter:blur(10px) saturate(130%);backdrop-filter:blur(10px) saturate(130%);',
    'box-shadow:0 10px 26px rgba(0,0,0,.30);max-width:calc(100% - 20px);pointer-events:none;}',
    '.psw-x-kv{display:flex;align-items:baseline;justify-content:space-between;gap:14px;',
    'font-size:11.5px;line-height:1.62;white-space:nowrap;}',
    '.psw-x-k{color:#94a3b8;font-size:11px;letter-spacing:.2px;}',
    '.psw-x-v{color:#e2e8f0;font-weight:600;font-variant-numeric:tabular-nums;letter-spacing:.2px;}',
    '.psw-x-badge{padding:1px 8px;border-radius:999px;font-size:10.5px;font-weight:700;}',
    '.psw-x-note{margin-top:5px;padding-top:5px;border-top:1px solid rgba(255,255,255,.07);',
    'color:#94a3b8;font-size:10px;line-height:1.5;white-space:normal;max-width:236px;}',

    '.psw-x-panel{flex:0 0 232px;display:flex;flex-direction:column;gap:9px;padding:12px;border-radius:16px;',
    'background:linear-gradient(180deg,rgba(24,37,60,.86),rgba(10,17,30,.94));',
    'box-shadow:inset 0 0 0 1px rgba(255,255,255,.06);overflow-y:auto;overflow-x:hidden;}',
    '.psw-x-panel::-webkit-scrollbar{width:6px;}',
    '.psw-x-panel::-webkit-scrollbar-thumb{background:rgba(148,163,184,.28);border-radius:3px;}',

    '.psw-x-row{display:flex;flex-direction:column;gap:2px;min-width:0;}',
    '.psw-x-head{display:flex;align-items:baseline;justify-content:space-between;gap:6px;min-width:0;}',
    '.psw-x-name{color:#cbd5e1;font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
    '.psw-x-num{color:#f1f5f9;font-size:11.5px;font-weight:600;white-space:nowrap;font-variant-numeric:tabular-nums;}',
    '.psw-x-num i{font-style:normal;font-size:9.5px;font-weight:400;color:#94a3b8;margin-left:2px;}',

    '.psw-x-range{-webkit-appearance:none;appearance:none;width:100%;height:15px;background:transparent;',
    'margin:0;padding:0;cursor:pointer;display:block;}',
    '.psw-x-range::-webkit-slider-runnable-track{height:4px;border-radius:2px;background:rgba(148,163,184,.24);}',
    '.psw-x-range::-webkit-slider-thumb{-webkit-appearance:none;width:12px;height:12px;border-radius:50%;',
    'background:var(--psw-x-accent,#38bdf8);border:2px solid #0b1220;margin-top:-4.5px;',
    'box-shadow:0 0 0 1px var(--psw-x-a35,rgba(56,189,248,.35));}',
    '.psw-x-range::-moz-range-track{height:4px;border-radius:2px;background:rgba(148,163,184,.24);}',
    '.psw-x-range::-moz-range-thumb{width:10px;height:10px;border-radius:50%;border:2px solid #0b1220;',
    'background:var(--psw-x-accent,#38bdf8);}',
    '.psw-x-range:focus{outline:none;}',
    '.psw-x-range:focus-visible::-webkit-slider-thumb{box-shadow:0 0 0 4px var(--psw-x-a35,rgba(56,189,248,.35));}',

    '.psw-x-btns{display:flex;gap:6px;}',
    '.psw-x-btn{flex:1 1 0;min-width:0;font-family:inherit;font-size:11px;font-weight:600;color:#dbe4f0;',
    'background:rgba(148,163,184,.12);border:1px solid rgba(148,163,184,.22);border-radius:9px;',
    'padding:6px 4px;cursor:pointer;letter-spacing:.2px;transition:background .15s,border-color .15s,color .15s;}',
    '.psw-x-btn:hover{background:rgba(148,163,184,.22);}',
    '.psw-x-btn:active{transform:translateY(1px);}',
    '.psw-x-btn.is-active{background:var(--psw-x-accent,#38bdf8);border-color:transparent;color:#06101c;}',
    '.psw-x-btn:focus-visible{outline:2px solid var(--psw-x-accent,#38bdf8);outline-offset:2px;}',

    '.psw-x-chips{display:flex;gap:5px;}',
    '.psw-x-chip{flex:1 1 0;min-width:0;font-family:inherit;font-size:10.5px;color:#cbd5e1;',
    'background:var(--psw-x-a10,rgba(56,189,248,.10));border:1px solid var(--psw-x-a35,rgba(56,189,248,.35));',
    'border-radius:8px;padding:4px 2px;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;',
    'transition:background .15s;}',
    '.psw-x-chip:hover{background:var(--psw-x-a18,rgba(56,189,248,.18));}',
    '.psw-x-chip:active{transform:translateY(1px);}',
    '.psw-x-chip:focus-visible{outline:2px solid var(--psw-x-accent,#38bdf8);outline-offset:2px;}',

    '.psw-x-hint{font-size:10.5px;line-height:1.55;color:#cbd5e1;background:var(--psw-x-a10,rgba(56,189,248,.10));',
    'border-left:2px solid var(--psw-x-accent,#38bdf8);border-radius:6px;padding:6px 8px;}',
    '.psw-x-hint b{color:#f1f5f9;font-weight:600;}',

    /* ── 紧凑布局：窄容器时面板下移、两/三列 ── */
    '.psw-x.psw-x-compact .psw-x-stage{flex-direction:column;gap:8px;padding:8px;}',
    '.psw-x.psw-x-compact .psw-x-panel{flex:0 0 auto;display:grid;',
    'grid-template-columns:repeat(auto-fit,minmax(142px,1fr));align-items:start;gap:4px 12px;',
    'padding:8px 10px;border-radius:12px;max-height:54%;}',
    '.psw-x.psw-x-compact .psw-x-span{grid-column:1/-1;}',
    '.psw-x.psw-x-compact .psw-x-card{padding:6px 8px;border-radius:10px;}',
    '.psw-x.psw-x-compact .psw-x-cbody{display:grid;grid-template-columns:auto auto;',
    'column-gap:14px;row-gap:0;}',
    '.psw-x.psw-x-compact .psw-x-kv{display:flex;justify-content:flex-start;gap:5px;font-size:10.5px;line-height:1.42;}',
    '.psw-x.psw-x-compact .psw-x-k{font-size:9.5px;}',
    '.psw-x.psw-x-compact .psw-x-v{font-size:10.5px;}',
    '.psw-x.psw-x-compact .psw-x-note{grid-column:1/-1;font-size:9px;max-width:none;margin-top:3px;padding-top:3px;}',
    '.psw-x.psw-x-compact .psw-x-name,.psw-x.psw-x-compact .psw-x-num{font-size:10.5px;}',
    '.psw-x.psw-x-compact .psw-x-btn{padding:5px 4px;font-size:10.5px;}',
    '.psw-x.psw-x-compact .psw-x-hint{font-size:9.5px;padding:4px 7px;}'
  ].join("");

  function ensureStyle() {
    if (typeof document === "undefined") return;
    if (document.querySelector('style[data-psw-style="sims-extra"]')) return;
    var s = document.createElement("style");
    s.setAttribute("data-psw-style", "sims-extra");
    s.appendChild(document.createTextNode(CSS));
    (document.head || document.documentElement).appendChild(s);
  }

  /* ────────────────────────────── Canvas 绘制原语 ────────────────────────────── */

  function pathRound(g, x, y, w, h, r) {
    var tl, tr, br, bl;
    if (typeof r === "number") { tl = tr = br = bl = r; }
    else { tl = r[0] || 0; tr = r[1] || 0; br = r[2] || 0; bl = r[3] || 0; }
    var m = Math.min(Math.abs(w), Math.abs(h)) / 2;
    tl = Math.min(tl, m); tr = Math.min(tr, m); br = Math.min(br, m); bl = Math.min(bl, m);
    g.beginPath();
    g.moveTo(x + tl, y);
    g.lineTo(x + w - tr, y);
    if (tr) g.arcTo(x + w, y, x + w, y + tr, tr);
    g.lineTo(x + w, y + h - br);
    if (br) g.arcTo(x + w, y + h, x + w - br, y + h, br);
    g.lineTo(x + bl, y + h);
    if (bl) g.arcTo(x, y + h, x, y + h - bl, bl);
    g.lineTo(x, y + tl);
    if (tl) g.arcTo(x, y, x + tl, y, tl);
    g.closePath();
  }

  function fillRound(g, x, y, w, h, r, color) {
    pathRound(g, x, y, w, h, r);
    g.fillStyle = color;
    g.fill();
  }

  /* 带文字的胶囊标签（自带半透明底，保证压在图形上也清晰） */
  function tag(g, text, x, y, o) {
    o = o || {};
    var size = o.size || 11;
    g.font = (o.bold === false ? "" : "600 ") + size + "px " + FONT;
    g.textAlign = o.align || "left";
    g.textBaseline = "middle";
    var w = g.measureText(text).width;
    var bx = g.textAlign === "center" ? x - w / 2 : (g.textAlign === "right" ? x - w : x);
    if (o.bg !== false) {
      fillRound(g, bx - 4.5, y - size * 0.5 - 3, w + 9, size + 6, 4, o.bg || "rgba(8,14,26,.78)");
    }
    g.fillStyle = o.color || "#e2e8f0";
    g.fillText(text, x, y);
    return w;
  }

  function arrow(g, x1, y1, x2, y2, color, w, head) {
    var dx = x2 - x1, dy = y2 - y1;
    var len = Math.sqrt(dx * dx + dy * dy);
    if (!(len > 0.8)) return 0;
    var ux = dx / len, uy = dy / len;
    head = head || Math.min(13, Math.max(6.5, len * 0.3));
    head = Math.min(head, len * 0.92);
    var bx = x2 - ux * head, by = y2 - uy * head;
    g.strokeStyle = color;
    g.lineWidth = w || 2.4;
    g.lineCap = "round";
    g.beginPath();
    g.moveTo(x1, y1);
    g.lineTo(bx, by);
    g.stroke();
    var hw = head * 0.52;
    g.beginPath();
    g.moveTo(x2, y2);
    g.lineTo(bx - uy * hw, by + ux * hw);
    g.lineTo(bx + uy * hw, by - ux * hw);
    g.closePath();
    g.fillStyle = color;
    g.fill();
    return len;
  }

  /* 双向箭头（用于 λ、Δh 之类的标注） */
  function dimArrow(g, x1, y1, x2, y2, color, w) {
    arrow(g, x1, y1, x2, y2, color, w, 7);
    arrow(g, x2, y2, x1, y1, color, w, 7);
  }

  /* ────────────────────────────── 舞台（DOM + 画布 + 循环） ────────────────────────────── */

  function createStage(root, theme, opts) {
    ensureStyle();
    opts = opts || {};

    root.classList.add("psw-x");
    root.innerHTML = "";
    root.style.setProperty("--psw-x-accent", theme.accent);
    if (typeof theme.accent === "string" && theme.accent.charAt(0) === "#") {
      root.style.setProperty("--psw-x-a06", rgba(theme.accent, 0.06));
      root.style.setProperty("--psw-x-a10", rgba(theme.accent, 0.10));
      root.style.setProperty("--psw-x-a18", rgba(theme.accent, 0.18));
      root.style.setProperty("--psw-x-a35", rgba(theme.accent, 0.35));
    }

    var stageEl = el("div", "psw-x-stage");
    var wrap = el("div", "psw-x-cw");
    var canvas = el("canvas", "psw-x-cv");
    canvas.setAttribute("role", "img");
    canvas.setAttribute("aria-label", opts.label || "物理演示画布");
    wrap.appendChild(canvas);

    var cardEl = el("div", "psw-x-card");
    var cardBody = el("div", "psw-x-cbody");
    cardEl.appendChild(cardBody);
    wrap.appendChild(cardEl);

    var panel = el("div", "psw-x-panel");
    stageEl.appendChild(wrap);
    stageEl.appendChild(panel);
    root.appendChild(stageEl);

    var g = canvas.getContext("2d");
    var st = {
      root: root, wrap: wrap, canvas: canvas, g: g, panel: panel,
      theme: theme, W: 0, H: 0, dpr: 1, compact: false,
      cardW: 0, cardH: 0,
      draw: null, frame: null,
      _rows: [], _raf: 0, _last: 0, _dead: false, _ro: null
    };

    /* ---- 读数卡片 ---- */
    st.card = function (defs) {
      cardBody.innerHTML = "";
      st._rows = [];
      for (var i = 0; i < defs.length; i++) {
        var d = defs[i];
        if (d.note != null) {
          var n = el("div", "psw-x-note", d.note);
          cardBody.appendChild(n);
          st._rows.push({ note: n });
          continue;
        }
        var row = el("div", "psw-x-kv");
        var k = el("span", "psw-x-k", d.k);
        var v = el("span", "psw-x-v" + (d.badge ? " psw-x-badge" : ""), d.v == null ? "—" : d.v);
        row.appendChild(k);
        row.appendChild(v);
        cardBody.appendChild(row);
        st._rows.push({ v: v });
      }
    };
    st.setRow = function (i, text, color, bg) {
      var r = st._rows[i];
      if (!r || !r.v) return;
      if (r.v.textContent !== text) r.v.textContent = text;
      if (color) r.v.style.color = color;
      if (bg) r.v.style.background = bg;
    };
    st.setNote = function (text) {
      for (var i = 0; i < st._rows.length; i++) {
        if (st._rows[i].note) {
          if (st._rows[i].note.textContent !== text) st._rows[i].note.textContent = text;
          return;
        }
      }
    };

    /* ---- 滑块 ---- */
    st.slider = function (cfg) {
      var row = el("div", "psw-x-row");
      var head = el("div", "psw-x-head");
      var name = el("span", "psw-x-name", cfg.name);
      var val = el("span", "psw-x-num");
      var vnum = el("span", null, "");
      val.appendChild(vnum);
      if (cfg.unit) val.appendChild(el("i", null, cfg.unit));
      head.appendChild(name);
      head.appendChild(val);

      var input = el("input", "psw-x-range");
      input.type = "range";
      input.min = cfg.min;
      input.max = cfg.max;
      input.step = cfg.step;
      input.value = cfg.value;
      input.setAttribute("aria-label", cfg.name + (cfg.unit ? "（" + cfg.unit + "）" : ""));

      var digits = cfg.digits == null ? 1 : cfg.digits;
      function fmtv(v) {
        if (cfg.format) return cfg.format(v);
        return fx(v, digits);
      }
      function sync() {
        var v = parseFloat(input.value);
        var txt = fmtv(v);
        vnum.textContent = txt;
        input.setAttribute("aria-valuetext", txt + (cfg.unit || ""));
      }
      input.addEventListener("input", function () {
        sync();
        cfg.onInput(parseFloat(input.value));
      });
      row.appendChild(head);
      row.appendChild(input);
      panel.appendChild(row);
      sync();
      return {
        row: row,
        input: input,
        set: function (v) { input.value = v; sync(); },
        value: function () { return parseFloat(input.value); }
      };
    };

    /* ---- 按钮组 ---- */
    st.buttons = function (items) {
      var box = el("div", "psw-x-btns psw-x-span");
      var refs = [];
      items.forEach(function (it) {
        var b = el("button", "psw-x-btn" + (it.active ? " is-active" : ""), it.label);
        b.type = "button";
        b.setAttribute("aria-label", it.aria || it.label);
        b.addEventListener("click", function () { it.onClick(b); });
        box.appendChild(b);
        refs.push(b);
      });
      panel.appendChild(box);
      return refs;
    };

    /* ---- 快捷按钮 ---- */
    st.chips = function (items) {
      var box = el("div", "psw-x-chips psw-x-span");
      items.forEach(function (it) {
        var b = el("button", "psw-x-chip", it.label);
        b.type = "button";
        b.setAttribute("aria-label", it.aria || it.label);
        b.addEventListener("click", function () { it.onClick(b); });
        box.appendChild(b);
      });
      panel.appendChild(box);
      return box;
    };

    /* ---- 提示条 ---- */
    st.hint = function (html) {
      var h = el("div", "psw-x-hint psw-x-span");
      h.innerHTML = html;
      panel.appendChild(h);
      return h;
    };

    /* ---- 尺寸 / DPR ---- */
    function measure() {
      var cw = root.clientWidth || 0;
      var compact = cw > 0 && cw < 760;
      if (compact !== st.compact) {
        st.compact = compact;
        root.classList.toggle("psw-x-compact", compact);
      }
      var w = wrap.clientWidth, h = wrap.clientHeight;
      if (w < 2 || h < 2) return false;
      var dpr = Math.min(3, global.devicePixelRatio || 1);
      var changed = w !== st.W || h !== st.H || dpr !== st.dpr;
      st.W = w; st.H = h; st.dpr = dpr;
      if (changed) {
        canvas.width = Math.max(1, Math.round(w * dpr));
        canvas.height = Math.max(1, Math.round(h * dpr));
        canvas.style.width = w + "px";
        canvas.style.height = h + "px";
      }
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      st.cardW = cardEl.offsetWidth || 0;
      st.cardH = cardEl.offsetHeight || 0;
      return changed;
    }
    st.measure = measure;

    /* ---- 按需渲染循环 ---- */
    function tick(ts) {
      st._raf = 0;
      if (st._dead) return;
      var dt = st._last ? Math.min(0.05, (ts - st._last) / 1000) : 0.016;
      st._last = ts;
      var again = false;
      try {
        if (st.frame) again = st.frame(dt);
      } catch (e) { again = false; }
      try {
        if (st.draw) st.draw();
      } catch (e2) { /* 极端参数下静默，绝不抛给宿主 */ }
      if (again && !st._dead) st.invalidate();
      else st._last = 0;
    }
    st.invalidate = function () {
      if (st._raf || st._dead || !st.draw) return;
      st._raf = global.requestAnimationFrame(tick);
    };

    st.start = function () {
      measure();
      st.invalidate();
    };

    st.destroy = function () {
      st._dead = true;
      if (st._raf) global.cancelAnimationFrame(st._raf);
      st._raf = 0;
      if (st._ro) st._ro.disconnect();
      global.removeEventListener("resize", onResize);
      root.classList.remove("psw-x-compact");
      root.classList.remove("psw-x");
      root.innerHTML = "";
    };

    function onResize() {
      measure();
      st.invalidate();
    }

    if (global.ResizeObserver) {
      st._ro = new global.ResizeObserver(function () {
        measure();
        st.invalidate();
      });
      st._ro.observe(wrap);
      st._ro.observe(root);
    }
    global.addEventListener("resize", onResize);

    return st;
  }

  /* ═══════════════════════════════════════════════════════════════════════
   *  1. buoyancy —— 浮力与浮沉
   * ═══════════════════════════════════════════════════════════════════════ */
  var BUOY = {
    // 容器（真实尺度，单位 cm）：内宽 20、内高 26、纵深 12 → 底面积 240 cm²
    WC: 20, HC: 26, DEPTH: 12, H0: 12, AREA: 240
  };

  PSW.buoyancy = {
    title: "浮力与浮沉",
    defaults: { rhoObj: 0.6, rhoLiq: 1.0, V: 400 },
    mount: function (root, params, ctx) {
      var theme = themeOf(ctx);
      var st = createStage(root, theme, { label: "浮力演示：物体在液体中的浮沉" });
      var p = params || {};
      var S = {
        rhoObj: num(p.rhoObj, 0.6, 0.2, 3.0),
        rhoLiq: num(p.rhoLiq, 1.0, 0.6, 1.8),
        V: num(p.V, 400, 100, 1000)
      };

      st.card([
        { k: "状态", v: "—", badge: true },
        { k: "重力 G = mg", v: "—" },
        { k: "F浮 = ρ液gV排", v: "—" },
        { k: "V排 / 浸入比例", v: "—" },
        { k: "液面高度", v: "—" },
        { note: "—" }
      ]);

      /* 物理量推导 —— 全部使用真实公式与单位 */
      function derive() {
        var rhoO = S.rhoObj, rhoL = S.rhoLiq, V = S.V;
        var m = (rhoO * V) / 1000;              // g/cm³·cm³ = g → kg
        var G = m * GRAV;                        // N
        var sub, state, color;
        if (Math.abs(rhoO - rhoL) < 1e-9) { sub = 1; state = "悬浮"; color = "#fbbf24"; }
        else if (rhoO < rhoL) { sub = rhoO / rhoL; state = "漂浮"; color = "#34d399"; }
        else { sub = 1; state = "下沉"; color = "#fb7185"; }
        var Vdisp = V * sub;                                    // cm³
        var Fb = rhoL * 1000 * GRAV * (Vdisp * 1e-6);           // kg/m³·m/s²·m³ = N
        var level = BUOY.H0 + Vdisp / BUOY.AREA;                // cm
        return {
          m: m, G: G, Fb: Fb, sub: sub, Vdisp: Vdisp,
          state: state, color: color, level: level, side: Math.cbrt(V)
        };
      }

      function materialColor(rho) {
        var stops = [
          [0.20, "#e9c99b"], [0.45, "#d99f5f"], [0.95, "#cbe9f7"],
          [1.05, "#bcdff1"], [2.00, "#a9bccd"], [3.00, "#8da0b4"]
        ];
        var t = clamp(rho, 0.2, 3.0);
        for (var i = 0; i < stops.length - 1; i++) {
          if (t <= stops[i + 1][0]) {
            var a = stops[i][0], b = stops[i + 1][0];
            return mixHex(stops[i][1], stops[i + 1][1], (t - a) / Math.max(1e-6, b - a));
          }
        }
        return stops[stops.length - 1][1];
      }

      /* 左侧空白区：密度对比小图（判据可视化，同时平衡版面） */
      function drawDensityCompare(g, left0) {
        var H = st.H;
        var colTop = (st.cardH || 0) + 12, colBot = H - 14;
        var w = Math.min(left0 - 36, 320);
        var h = 70;
        if (w < 170 || colBot - colTop < h + 8) return;
        var x = 18, y = colTop + (colBot - colTop - h) / 2;
        var accent = theme.accent;

        fillRound(g, x, y, w, h, 10, "rgba(20,31,50,.74)");
        pathRound(g, x, y, w, h, 10);
        g.strokeStyle = "rgba(148,163,184,.20)";
        g.lineWidth = 1;
        g.stroke();

        var px = x + 12;
        g.textBaseline = "middle";
        g.textAlign = "left";
        g.font = "600 10px " + FONT;
        g.fillStyle = "#cbd5e1";
        g.fillText("密度对比", px, y + 12);
        g.font = "9px " + FONT;
        g.fillStyle = "#94a3b8";
        g.textAlign = "right";
        g.fillText("g/cm³", x + w - 12, y + 12);

        var MAXR = 3.0;
        var tx = px + 30, tw = w - 24 - 30 - 38;
        if (tw < 40) return;
        var rows = [
          { name: "ρ物", v: S.rhoObj, c: materialColor(S.rhoObj) },
          { name: "ρ液", v: S.rhoLiq, c: accent }
        ];
        var ry = y + 29;
        for (var i = 0; i < rows.length; i++) {
          var r = rows[i], cy = ry + i * 17;
          g.textAlign = "left";
          g.font = "9.5px " + FONT;
          g.fillStyle = "#94a3b8";
          g.fillText(r.name, px, cy);

          fillRound(g, tx, cy - 3, tw, 6, 3, "rgba(148,163,184,.18)");
          var ww = clamp(r.v / MAXR, 0, 1) * tw;
          if (ww > 3) fillRound(g, tx, cy - 3, ww, 6, 3, rgba(r.c, 0.9));
          g.beginPath();
          g.arc(tx + ww, cy, 3.6, 0, Math.PI * 2);
          g.fillStyle = r.c;
          g.fill();
          g.strokeStyle = "rgba(11,18,32,.92)";
          g.lineWidth = 1.2;
          g.stroke();

          g.textAlign = "right";
          g.font = "600 9.5px " + FONT;
          g.fillStyle = "#e2e8f0";
          g.fillText(fx(r.v, 2), x + w - 12, cy);
        }

        /* 刻度：0 / 1 / 2 / 3 g·cm⁻³ */
        g.textAlign = "center";
        g.font = "8.5px " + FONT;
        g.fillStyle = "rgba(148,163,184,.6)";
        for (var k = 0; k <= 3; k++) {
          var gx = tx + (k / MAXR) * tw;
          g.strokeStyle = "rgba(148,163,184,.26)";
          g.lineWidth = 1;
          g.beginPath();
          g.moveTo(gx, ry + 21);
          g.lineTo(gx, ry + 24);
          g.stroke();
          g.fillText(String(k), gx, y + h - 8);
        }
      }

      function draw() {
        var g = st.g, W = st.W, H = st.H;
        g.clearRect(0, 0, W, H);
        if (W < 60 || H < 60) return;
        var d = derive();
        var accent = theme.accent;

        /* 版面：读数卡片在左上，容器居中于其右侧的空白区 */
        var padB = Math.max(16, H * 0.07);
        var reserve = Math.min(st.cardW, W * 0.52);
        var left0 = reserve > 0 ? reserve + 16 : 18;
        var availW = Math.max(90, W - left0 - 18);
        var availH = H - padB - 12;
        var s = Math.min(availW / (BUOY.WC + 1.0), availH / (BUOY.HC + 1.2));

        var bW = BUOY.WC * s, bH = BUOY.HC * s;
        var cx = left0 + (availW - bW) / 2 + bW / 2;
        var yB = H - padB, yT = yB - bH;
        var xL = cx - bW / 2, xR = cx + bW / 2;
        var levelY = yB - d.level * s;

        /* 台面 */
        var bench = g.createLinearGradient(xL - 26, 0, xR + 26, 0);
        bench.addColorStop(0, "rgba(148,163,184,0)");
        bench.addColorStop(0.5, "rgba(148,163,184,.28)");
        bench.addColorStop(1, "rgba(148,163,184,0)");
        g.fillStyle = bench;
        g.fillRect(xL - 26, yB + 1, bW + 52, 1.5);

        /* 玻璃杯体（裁剪后画液体） */
        g.save();
        pathRound(g, xL, yT, bW, bH, [0, 0, 9, 9]);
        g.clip();
        var glass = g.createLinearGradient(xL, 0, xR, 0);
        glass.addColorStop(0, "rgba(148,163,184,.10)");
        glass.addColorStop(0.45, "rgba(148,163,184,.035)");
        glass.addColorStop(1, "rgba(148,163,184,.09)");
        g.fillStyle = glass;
        g.fillRect(xL, yT, bW, bH);

        /* 液体 */
        var lg = g.createLinearGradient(0, levelY, 0, yB);
        lg.addColorStop(0, rgba(accent, 0.34));
        lg.addColorStop(1, rgba(accent, 0.12));
        g.fillStyle = lg;
        g.fillRect(xL, levelY, bW, yB - levelY);
        g.restore();

        /* 物体几何 */
        var sidePx = d.side * s;
        var objBottom, objTop;
        if (d.state === "下沉") {
          objBottom = yB - 2;
        } else if (d.state === "悬浮") {
          var ccy = (levelY + yB) / 2;
          objBottom = Math.min(yB - 2, ccy + sidePx / 2);
        } else {
          objBottom = Math.min(yB - 2, levelY + d.side * d.sub * s);
        }
        objTop = objBottom - sidePx;
        if (objTop < yT + 3) { objTop = yT + 3; objBottom = objTop + sidePx; }
        var oy = (objTop + objBottom) / 2;

        /* 原液面（虚线参考，用来显示排水导致的水位上升） */
        var h0y = yB - BUOY.H0 * s;
        g.save();
        g.setLineDash([4, 4]);
        g.strokeStyle = "rgba(148,163,184,.42)";
        g.lineWidth = 1;
        g.beginPath();
        g.moveTo(xL + 2, h0y);
        g.lineTo(xR - 2, h0y);
        g.stroke();
        g.restore();
        if (levelY < h0y - 6) {
          tag(g, "原液面", xR - 4, h0y - 7, { size: 9, color: "rgba(148,163,184,.85)", align: "right", bg: false });
        }

        /* 物体 */
        var oc = materialColor(S.rhoObj);
        var og = g.createLinearGradient(xL, objTop, xR, objBottom);
        og.addColorStop(0, mixHex(oc, "#ffffff", 0.30));
        og.addColorStop(0.55, oc);
        og.addColorStop(1, mixHex(oc, "#000000", 0.28));
        fillRound(g, cx - sidePx / 2, objTop, sidePx, sidePx, Math.min(4, sidePx * 0.12), og);
        g.strokeStyle = "rgba(255,255,255,.30)";
        g.lineWidth = 1;
        pathRound(g, cx - sidePx / 2 + 0.5, objTop + 0.5, sidePx - 1, sidePx - 1, Math.min(4, sidePx * 0.12));
        g.stroke();

        /* 浸入部分着色（水面以下的体积） */
        var subTop = Math.max(objTop, levelY);
        if (objBottom > subTop) {
          g.save();
          g.beginPath();
          g.rect(cx - sidePx / 2, subTop, sidePx, objBottom - subTop);
          g.clip();
          g.fillStyle = rgba(accent, 0.28);
          g.fillRect(cx - sidePx / 2, objTop, sidePx, sidePx);
          g.restore();
        }

        /* 液面（画在物体之上，形成水线） */
        g.strokeStyle = rgba(accent, 0.92);
        g.lineWidth = 1.8;
        g.beginPath();
        g.moveTo(xL, levelY);
        g.lineTo(xR, levelY);
        g.stroke();
        var surf = g.createLinearGradient(xL, levelY - 8, xL, levelY);
        surf.addColorStop(0, rgba(accent, 0));
        surf.addColorStop(1, rgba(accent, 0.16));
        g.fillStyle = surf;
        g.fillRect(xL, levelY - 8, bW, 8);

        /* 杯壁 */
        g.strokeStyle = "rgba(148,163,184,.55)";
        g.lineWidth = 2;
        g.beginPath();
        g.moveTo(xL, yT);
        g.lineTo(xL, yB - 9);
        g.quadraticCurveTo(xL, yB, xL + 9, yB);
        g.lineTo(xR - 9, yB);
        g.quadraticCurveTo(xR, yB, xR, yB - 9);
        g.lineTo(xR, yT);
        g.stroke();
        g.strokeStyle = "rgba(255,255,255,.10)";
        g.lineWidth = 1;
        g.beginPath();
        g.moveTo(xL + 3.5, yT + 2);
        g.lineTo(xL + 3.5, yB - 12);
        g.stroke();

        /* 刻度（每 2 cm 一格，每 10 cm 标数） */
        var tickStep = 2;
        g.font = "9px " + FONT;
        g.textAlign = "left";
        g.textBaseline = "middle";
        for (var cmv = tickStep; cmv < BUOY.HC; cmv += tickStep) {
          var ty = yB - cmv * s;
          if (ty < yT + 3) break;
          var major = cmv % 10 === 0;
          g.strokeStyle = "rgba(148,163,184," + (major ? 0.5 : 0.26) + ")";
          g.lineWidth = 1;
          g.beginPath();
          g.moveTo(xR - (major ? 6 : 3.5), ty);
          g.lineTo(xR - 1, ty);
          g.stroke();
          if (major) {
            g.fillStyle = "rgba(148,163,184,.68)";
            g.fillText(String(cmv), xR + 5, ty);
          }
        }
        g.fillStyle = "rgba(148,163,184,.55)";
        g.font = "9px " + FONT;
        g.fillText("cm", xR + 5, yB - BUOY.HC * s + 8);

        /* 受力矢量：G 与 F浮 同起点（物体质心），长度按统一比例 */
        var maxArrow = clamp(H * 0.23, 34, 92);
        var fmax = Math.max(d.G, d.Fb, 0.4);
        var scaleF = maxArrow / fmax;
        var lgG = clamp(d.G * scaleF, 15, Math.max(15, yB - 6 - oy));
        var lgF = clamp(d.Fb * scaleF, 15, Math.max(15, oy - yT - 6));

        var gc = "#fb7185", fc = accent;
        arrow(g, cx, oy, cx, oy + lgG, gc, 2.6);
        arrow(g, cx, oy, cx, oy - lgF, fc, 2.6);

        var labY1 = oy + lgG + 11;
        var labY2 = oy - lgF - 11;
        if (labY1 > H - 8) labY1 = oy + lgG - 12;
        if (labY2 < 10) labY2 = oy - lgF + 12;
        tag(g, "G = " + fx(d.G, 2) + " N", cx + 8, labY1, { size: 10.5, color: gc });
        tag(g, "F浮 = " + fx(d.Fb, 2) + " N", cx + 8, labY2, { size: 10.5, color: fc });

        /* 左侧：密度对比 */
        drawDensityCompare(g, left0);

        /* 读数卡片 */
        st.setRow(0, d.state, d.color, rgba(d.color, 0.16));
        st.setRow(1, fx(d.G, 2) + " N", "#e2e8f0");
        st.setRow(2, fx(d.Fb, 2) + " N", "#e2e8f0");
        st.setRow(3, fx(d.Vdisp, 0) + " cm³ · " + fx(d.sub * 100, 0) + "%", "#e2e8f0");
        st.setRow(4, fx(d.level, 1) + " cm (+" + fx(d.level - BUOY.H0, 1) + ")", "#e2e8f0");
        if (d.state === "漂浮") {
          st.setNote("ρ物 < ρ液 → 漂浮：F浮 = G，浸入比例 = ρ物/ρ液 = " + fx(d.sub, 2));
        } else if (d.state === "悬浮") {
          st.setNote("ρ物 = ρ液 → 悬浮：F浮 = G，V排 = V，可停在液体内任意深度");
        } else {
          st.setNote("ρ物 > ρ液 → 下沉：F浮 < G，底部支持力 N = G − F浮 = " +
            fx(Math.max(0, d.G - d.Fb), 2) + " N");
        }
      }

      st.draw = draw;
      st.frame = function () { return false; };

      var sRhoO = st.slider({
        name: "物体密度 ρ物", unit: "g/cm³", min: 0.2, max: 3.0, step: 0.05,
        value: S.rhoObj, digits: 2,
        onInput: function (v) { S.rhoObj = v; st.invalidate(); }
      });
      var sRhoL = st.slider({
        name: "液体密度 ρ液", unit: "g/cm³", min: 0.6, max: 1.8, step: 0.05,
        value: S.rhoLiq, digits: 2,
        onInput: function (v) { S.rhoLiq = v; st.invalidate(); }
      });
      var sV = st.slider({
        name: "物体体积 V", unit: "cm³", min: 100, max: 1000, step: 10,
        value: S.V, digits: 0,
        onInput: function (v) { S.V = v; st.invalidate(); }
      });

      function speak(txt) {
        if (ctx && typeof ctx.speak === "function") {
          try { ctx.speak(txt); } catch (e) { /* 忽略 */ }
        }
      }
      st.chips([
        { label: "水 1.00", aria: "液体设为水，密度 1.00 克每立方厘米",
          onClick: function () { S.rhoLiq = 1.0; sRhoL.set(1.0); st.invalidate(); speak("液体是水，密度一点零克每立方厘米"); } },
        { label: "酒精 0.80", aria: "液体设为酒精，密度 0.80 克每立方厘米",
          onClick: function () { S.rhoLiq = 0.8; sRhoL.set(0.8); st.invalidate(); speak("液体是酒精，密度零点八克每立方厘米"); } },
        { label: "盐水 1.20", aria: "液体设为盐水，密度 1.20 克每立方厘米",
          onClick: function () { S.rhoLiq = 1.2; sRhoL.set(1.2); st.invalidate(); speak("液体是盐水，密度一点二克每立方厘米"); } }
      ]);

      st.start();

      return {
        destroy: st.destroy,
        resize: function () { st.measure(); st.invalidate(); },
        setParams: function (np) {
          if (!np) return;
          if (np.rhoObj != null) { S.rhoObj = num(np.rhoObj, S.rhoObj, 0.2, 3.0); sRhoO.set(S.rhoObj); }
          if (np.rhoLiq != null) { S.rhoLiq = num(np.rhoLiq, S.rhoLiq, 0.6, 1.8); sRhoL.set(S.rhoLiq); }
          if (np.V != null) { S.V = num(np.V, S.V, 100, 1000); sV.set(S.V); }
          st.invalidate();
        }
      };
    }
  };

  /* ═══════════════════════════════════════════════════════════════════════
   *  2. wave —— 横波（波的形成与传播）
   * ═══════════════════════════════════════════════════════════════════════ */
  PSW.wave = {
    title: "机械波（横波）",
    defaults: { A: 1.0, f: 1.5, v: 8.0 },
    mount: function (root, params, ctx) {
      var theme = themeOf(ctx);
      var st = createStage(root, theme, { label: "横波演示：波形传播与质点振动" });
      var p = params || {};
      var S = {
        A: num(p.A, 1.0, 0.2, 2.0),
        f: num(p.f, 1.5, 0.5, 5),
        v: num(p.v, 8.0, 2, 20),
        t: 0,
        playing: !(ctx && ctx.motion === false)
      };

      st.card([
        { k: "波长 λ = v/f", v: "—" },
        { k: "周期 T = 1/f", v: "—" },
        { k: "时间 t", v: "—" },
        { k: "质点 P 相位 φ", v: "—" },
        { note: "y = A·sin[2π(f·t − x/λ)]，波形沿 +x 方向传播" }
      ]);

      function lambda() { return S.v / S.f; }

      function draw() {
        var g = st.g, W = st.W, H = st.H;
        g.clearRect(0, 0, W, H);
        if (W < 80 || H < 80) return;
        var accent = theme.accent;
        var lam = lambda();
        var T = 1 / S.f;

        var top = Math.max(H * 0.11, (st.cardH || 90) + 12);
        var bottom = H - 16;
        if (bottom - top < 70) { top = 14; bottom = H - 12; }
        var mid = top + (bottom - top) * 0.54;
        var ampMax = (bottom - top) * 0.44;
        var amp = ampMax * (S.A / 2);
        var x0 = 26, x1 = W - 22;
        var plotW = Math.max(40, x1 - x0);

        var WIN = 2.6;                     // 屏幕横向显示 2.6 个波长
        var winM = WIN * lam;              // 屏宽对应的实际长度（m）

        function waveY(x) {
          var xm = (x - x0) / plotW * winM;
          return mid - amp * Math.sin(2 * Math.PI * (S.f * S.t - xm / lam));
        }

        /* 横向参考轴 */
        g.strokeStyle = "rgba(148,163,184,.30)";
        g.lineWidth = 1;
        g.beginPath();
        g.moveTo(x0 - 8, mid);
        g.lineTo(x1 + 4, mid);
        g.stroke();
        g.fillStyle = "rgba(148,163,184,.55)";
        g.font = "9.5px " + FONT;
        g.textAlign = "left";
        g.textBaseline = "middle";
        g.fillText("x / m", x0 + 2, H - 9);

        /* 波形下的淡填充 + 曲线（发光两遍） */
        g.save();
        g.beginPath();
        g.moveTo(x0, mid);
        for (var x = x0; x <= x1; x += 2) g.lineTo(x, waveY(x));
        g.lineTo(x1, mid);
        g.closePath();
        var area = g.createLinearGradient(0, mid - ampMax, 0, mid + ampMax);
        area.addColorStop(0, rgba(accent, 0.12));
        area.addColorStop(1, rgba(accent, 0.02));
        g.fillStyle = area;
        g.fill();
        g.restore();

        g.save();
        g.lineJoin = "round";
        g.shadowColor = rgba(accent, 0.55);
        g.shadowBlur = 10;
        g.strokeStyle = accent;
        g.lineWidth = 2.6;
        g.beginPath();
        g.moveTo(x0, waveY(x0));
        for (x = x0 + 2; x <= x1; x += 2) g.lineTo(x, waveY(x));
        g.lineTo(x1, waveY(x1));
        g.stroke();
        g.restore();

        /* 传播方向箭头 */
        var ay = Math.max(top - 22, 16);
        var ax2 = x1 - 6, ax1 = Math.max(ax2 - 118, x0 + 90);
        arrow(g, ax1, ay, ax2, ay, rgba(accent, 0.85), 2, 8);
        tag(g, "传播方向  v = " + fx(S.v, 1) + " m/s", ax1 - 6, ay, {
          size: 10, align: "right", color: rgba(accent, 0.95), bg: false
        });

        /* 波长标注：找两个相邻波峰 */
        var us = [];
        for (var k = -12; k <= 12; k++) {
          var u = (S.f * S.t - 0.25 - k) / WIN;
          if (u > 0.06 && u < 0.94) us.push(u);
        }
        us.sort(function (a, b) { return a - b; });
        if (us.length >= 2) {
          var ua = us[0], ub = us[1];
          if (ub - ua > 0.12) {
            var xa = x0 + ua * plotW, xb = x0 + ub * plotW;
            var by = Math.max(top + 4, mid - amp - 16);
            g.save();
            g.setLineDash([3, 3]);
            g.strokeStyle = "rgba(148,163,184,.45)";
            g.lineWidth = 1;
            g.beginPath();
            g.moveTo(xa, by + 5);
            g.lineTo(xa, mid - amp * Math.sin(2 * Math.PI * (S.f * S.t - ua * WIN)));
            g.moveTo(xb, by + 5);
            g.lineTo(xb, mid - amp * Math.sin(2 * Math.PI * (S.f * S.t - ub * WIN)));
            g.stroke();
            g.restore();
            dimArrow(g, xa, by, xb, by, "rgba(226,232,240,.8)", 1.4);
            tag(g, "λ = " + fx(lam, 2) + " m", (xa + xb) / 2, by - 11, {
              size: 10.5, align: "center", color: "#e2e8f0"
            });
          }
        }

        /* 红色质点：横坐标固定，只沿竖直方向振动 */
        var fracs = [0.10, 0.30, 0.50, 0.70, 0.90];
        for (var i = 0; i < fracs.length; i++) {
          var px = x0 + fracs[i] * plotW;
          var py = waveY(px);
          g.save();
          g.setLineDash([3, 3]);
          g.strokeStyle = "rgba(248,113,113,.42)";
          g.lineWidth = 1;
          g.beginPath();
          g.moveTo(px, mid);
          g.lineTo(px, py);
          g.stroke();
          g.restore();
          g.strokeStyle = "rgba(248,113,113,.55)";
          g.lineWidth = 1;
          g.beginPath();
          g.arc(px, mid, 2.6, 0, Math.PI * 2);
          g.stroke();
          g.save();
          g.shadowColor = "rgba(248,113,113,.85)";
          g.shadowBlur = 8;
          g.fillStyle = "#f87171";
          g.beginPath();
          g.arc(px, py, 3.6, 0, Math.PI * 2);
          g.fill();
          g.restore();
        }
        tag(g, "质点 P（仅上下振动）", x0 + 0.5 * plotW + 9, mid + 16, {
          size: 9.5, color: "rgba(248,113,113,.95)", bg: "rgba(8,14,26,.6)"
        });

        /* 读数 */
        var phase = (S.f * S.t - 0.5 * WIN) % 1;
        if (phase < 0) phase += 1;
        st.setRow(0, fx(lam, 2) + " m", "#e2e8f0");
        st.setRow(1, fx(T, 3) + " s", "#e2e8f0");
        st.setRow(2, fx(S.t, 2) + " s", "#e2e8f0");
        st.setRow(3, fx(phase * 360, 0) + "°", "#e2e8f0");
        st.setNote("y = A·sin[2π(f·t − x/λ)]，A = " + fx(S.A, 2) +
          " m，屏宽显示 2.6λ = " + fx(winM, 2) + " m");
      }

      var btnPlay;

      st.draw = draw;
      st.frame = function (dt) {
        if (!S.playing) return false;
        S.t += dt;
        if (S.t > 3600) S.t -= 3600;
        return true;
      };

      var sA = st.slider({
        name: "振幅 A", unit: "m", min: 0.2, max: 2, step: 0.05, value: S.A, digits: 2,
        onInput: function (v) { S.A = v; st.invalidate(); }
      });
      var sF = st.slider({
        name: "频率 f", unit: "Hz", min: 0.5, max: 5, step: 0.1, value: S.f, digits: 1,
        onInput: function (v) { S.f = v; st.invalidate(); }
      });
      var sV = st.slider({
        name: "波速 v", unit: "m/s", min: 2, max: 20, step: 0.5, value: S.v, digits: 1,
        onInput: function (v) { S.v = v; st.invalidate(); }
      });

      function syncPlay() {
        if (!btnPlay) return;
        btnPlay.textContent = S.playing ? "暂停" : "播放";
        btnPlay.classList.toggle("is-active", S.playing);
        btnPlay.setAttribute("aria-label", S.playing ? "暂停波形动画" : "播放波形动画");
        btnPlay.setAttribute("aria-pressed", S.playing ? "true" : "false");
      }

      var btns = st.buttons([
        {
          label: "播放", aria: "播放波形动画",
          onClick: function () { S.playing = !S.playing; syncPlay(); st.invalidate(); }
        },
        {
          label: "单步", aria: "单步推进八分之一个周期",
          onClick: function () {
            S.playing = false;
            S.t += (1 / S.f) / 8;
            syncPlay();
            st.invalidate();
          }
        },
        {
          label: "重置", aria: "时间归零",
          onClick: function () { S.t = 0; st.invalidate(); }
        }
      ]);
      btnPlay = btns[0];
      syncPlay();

      st.start();

      return {
        destroy: st.destroy,
        resize: function () { st.measure(); st.invalidate(); },
        setParams: function (np) {
          if (!np) return;
          if (np.A != null) { S.A = num(np.A, S.A, 0.2, 2); sA.set(S.A); }
          if (np.f != null) { S.f = num(np.f, S.f, 0.5, 5); sF.set(S.f); }
          if (np.v != null) { S.v = num(np.v, S.v, 2, 20); sV.set(S.v); }
          if (np.playing != null) { S.playing = !!np.playing; syncPlay(); }
          st.invalidate();
        },
        play: function () { S.playing = true; syncPlay(); st.invalidate(); },
        pause: function () { S.playing = false; syncPlay(); st.invalidate(); }
      };
    }
  };

  /* ═══════════════════════════════════════════════════════════════════════
   *  3. vector —— 力的合成
   * ═══════════════════════════════════════════════════════════════════════ */
  PSW.vector = {
    title: "力的合成",
    defaults: { F1: 6, F2: 8, theta: 60, view: "para" },
    mount: function (root, params, ctx) {
      var theme = themeOf(ctx);
      var st = createStage(root, theme, { label: "力的合成：平行四边形与三角形法则" });
      var p = params || {};
      var S = {
        F1: num(p.F1, 6, 1, 10),
        F2: num(p.F2, 8, 1, 10),
        theta: num(p.theta, 60, 0, 180),
        view: p.view === "tri" ? "tri" : "para"
      };

      st.card([
        { k: "合力 F", v: "—" },
        { k: "方向 α（与 F₁ 夹角）", v: "—" },
        { k: "图示实测", v: "—" },
        { k: "分力夹角 θ", v: "—" },
        { note: "F = √(F₁²+F₂²+2F₁F₂cosθ)，α = arctan[F₂sinθ ⁄ (F₁+F₂cosθ)]" }
      ]);

      function calc() {
        var th = S.theta * Math.PI / 180;
        var c = Math.cos(th), sn = Math.sin(th);
        var rx = S.F1 + S.F2 * c, ry = S.F2 * sn;
        var R = Math.sqrt(rx * rx + ry * ry);
        var alpha = R > 1e-9 ? Math.atan2(ry, rx) * 180 / Math.PI : 0;
        return { th: th, c: c, s: sn, rx: rx, ry: ry, R: R, alpha: alpha };
      }

      function draw() {
        var g = st.g, W = st.W, H = st.H;
        g.clearRect(0, 0, W, H);
        if (W < 90 || H < 90) return;
        var d = calc();
        var accent = theme.accent;
        var cardW = Math.min(st.cardW || 0, W * 0.55);
        var cardH = st.cardH || 90;

        /* 力空间中的四个顶点（y 轴向上） */
        var minX = Math.min(0, S.F2 * d.c), maxX = Math.max(S.F1, d.rx);
        var minY = 0, maxY = Math.max(S.F2 * d.s, d.ry);
        var spanX = Math.max(maxX - minX, 1e-6);
        var spanY = Math.max(maxY - minY, 1e-6);

        /* 候选绘图区：卡片右侧 或 卡片下方，取能画得更大的一处 */
        var rects = [
          { x: cardW + 14, y: 10, w: W - cardW - 28, h: H - 22 },
          { x: 10, y: cardH + 12, w: W - 20, h: H - cardH - 24 }
        ];
        var best = null;
        for (var i = 0; i < rects.length; i++) {
          var r = rects[i];
          if (r.w < 90 || r.h < 70) continue;
          var pad = clamp(Math.min(r.w, r.h) * 0.10, 14, 30);
          var aw = r.w - pad * 2, ah = r.h - pad * 2;
          if (aw < 50 || ah < 44) continue;
          var sc = Math.min(aw / spanX, ah / spanY);
          if (!best || sc > best.sc) best = { r: r, pad: pad, aw: aw, ah: ah, sc: sc };
        }
        if (!best) return;
        var scale = best.sc;
        var Ox = best.r.x + best.pad + (best.aw - spanX * scale) / 2 - minX * scale;
        var Oy = best.r.y + best.pad + (best.ah - spanY * scale) / 2 + maxY * scale;

        function P(fx, fy) { return { x: Ox + fx * scale, y: Oy - fy * scale }; }

        var O = P(0, 0), A = P(S.F1, 0);
        var B = P(S.F2 * d.c, S.F2 * d.s);
        var C = P(d.rx, d.ry);

        /* 构造线 */
        g.save();
        g.setLineDash([5, 5]);
        g.strokeStyle = "rgba(148,163,184,.42)";
        g.lineWidth = 1.2;
        if (S.view === "para") {
          g.beginPath();
          g.moveTo(A.x, A.y);
          g.lineTo(C.x, C.y);
          g.moveTo(B.x, B.y);
          g.lineTo(C.x, C.y);
          g.stroke();
          g.restore();
          g.save();
          g.beginPath();
          g.moveTo(O.x, O.y);
          g.lineTo(A.x, A.y);
          g.lineTo(C.x, C.y);
          g.lineTo(B.x, B.y);
          g.closePath();
          g.fillStyle = rgba(accent, 0.055);
          g.fill();
        } else {
          g.beginPath();
          g.moveTo(O.x, O.y);
          g.lineTo(B.x, B.y);
          g.stroke();
        }
        g.restore();

        /* 合力（对角线） */
        arrow(g, O.x, O.y, C.x, C.y, accent, 3);
        /* 两个分力 */
        arrow(g, O.x, O.y, A.x, A.y, "#a78bfa", 2.6);
        var f2x = S.view === "tri" ? A.x : O.x, f2y = S.view === "tri" ? A.y : O.y;
        arrow(g, f2x, f2y, C.x, C.y, "#fb923c", 2.6);

        /* 夹角圆弧（原点处，从 +x 转到 F₂ 方向） */
        var arcR = Math.min(0.36 * Math.min(S.F1, S.F2) * scale, 46);
        if (arcR > 12) {
          g.strokeStyle = "rgba(251,146,60,.75)";
          g.lineWidth = 1.4;
          g.beginPath();
          g.arc(Ox, Oy, arcR, 0, -d.th, true);
          g.stroke();
          var am = -d.th / 2;
          var lx = Ox + Math.cos(am) * (arcR + 16);
          var ly = Oy + Math.sin(am) * (arcR + 16);
          tag(g, "θ = " + fx(S.theta, 0) + "°", lx, ly, {
            size: 10, align: "center", color: "#fb923c"
          });
        }

        /* 矢量标签（放在箭头中点的法向侧） */
        function midTag(pA, pB, text, color, side) {
          var mx = (pA.x + pB.x) / 2, my = (pA.y + pB.y) / 2;
          var dx = pB.x - pA.x, dy = pB.y - pA.y;
          var L = Math.sqrt(dx * dx + dy * dy) || 1;
          var nx = -dy / L, ny = dx / L;
          if (side) { nx = -nx; ny = -ny; }
          return tag(g, text, mx + nx * 15, my + ny * 15, {
            size: 10.5, align: "center", color: color
          });
        }
        midTag(O, A, "F₁ = " + fx(S.F1, 1) + " N", "#c4b5fd", false);
        midTag(O, C, "F = " + fx(d.R, 2) + " N", accent, true);
        if (S.view === "tri") midTag(A, C, "F₂ = " + fx(S.F2, 1) + " N", "#fdba74", false);
        else midTag(O, B, "F₂ = " + fx(S.F2, 1) + " N", "#fdba74", true);

        /* 比例尺：让“看图测力”有依据 */
        var nice = [0.5, 1, 2, 5, 10];
        var unitN = nice[0];
        for (i = 0; i < nice.length; i++) {
          if (nice[i] * scale >= 46) { unitN = nice[i]; break; }
          unitN = nice[i];
        }
        while (unitN * scale > 130 && unitN > 0.5) unitN /= 2;
        var barN = Math.max(unitN, 1);
        var barPx = barN * scale;
        var bx = 16, by = H - 16;
        g.strokeStyle = "rgba(148,163,184,.7)";
        g.lineWidth = 1.4;
        g.beginPath();
        g.moveTo(bx, by);
        g.lineTo(bx + barPx, by);
        g.moveTo(bx, by - 3);
        g.lineTo(bx, by + 3);
        g.moveTo(bx + barPx, by - 3);
        g.lineTo(bx + barPx, by + 3);
        g.stroke();
        tag(g, "标尺 " + fx(barN, barN < 1 ? 1 : 0) + " N", bx + barPx + 6, by, {
          size: 9.5, color: "rgba(148,163,184,.9)", bg: false
        });

        /* 图示实测：从像素长度反推，检验与公式值一致 */
        var dxp = C.x - O.x, dyp = C.y - O.y;
        var measF = Math.sqrt(dxp * dxp + dyp * dyp) / scale;
        var measA = Math.atan2(-dyp, dxp) * 180 / Math.PI;
        if (measA < -0.5) measA += 360;

        st.setRow(0, fx(d.R, 2) + " N", "#e2e8f0");
        var tiny = d.R < 0.05;
        st.setRow(1, tiny ? "—" : fx(d.alpha, 1) + "°", "#e2e8f0");
        st.setRow(2, tiny ? "合力为零" : fx(measF, 2) + " N / " + fx(measA, 1) + "°", "#94a3b8");
        st.setRow(3, fx(S.theta, 0) + "°", "#e2e8f0");
        if (tiny) {
          st.setNote("θ = 180° 且 F₁ = F₂：合力为零，二力平衡");
        } else if (S.theta === 0) {
          st.setNote("θ = 0°：F = F₁ + F₂ = " + fx(d.R, 2) + " N（同向共线）");
        } else if (S.theta === 180) {
          st.setNote("θ = 180°：F = |F₁ − F₂| = " + fx(d.R, 2) + " N（反向共线）");
        } else {
          st.setNote("F = √(" + fx(S.F1, 1) + "² + " + fx(S.F2, 1) + "² + 2×" +
            fx(S.F1, 1) + "×" + fx(S.F2, 1) + "×cos" + fx(S.theta, 0) + "°) = " +
            fx(d.R, 2) + " N");
        }
      }

      st.draw = draw;
      st.frame = function () { return false; };

      var sF1 = st.slider({
        name: "分力 F₁", unit: "N", min: 1, max: 10, step: 0.1, value: S.F1, digits: 1,
        onInput: function (v) { S.F1 = v; st.invalidate(); }
      });
      var sF2 = st.slider({
        name: "分力 F₂", unit: "N", min: 1, max: 10, step: 0.1, value: S.F2, digits: 1,
        onInput: function (v) { S.F2 = v; st.invalidate(); }
      });
      var sTh = st.slider({
        name: "夹角 θ", unit: "°", min: 0, max: 180, step: 1, value: S.theta, digits: 0,
        onInput: function (v) { S.theta = v; st.invalidate(); }
      });

      function setView(v) {
        S.view = v;
        btnPara.classList.toggle("is-active", v === "para");
        btnTri.classList.toggle("is-active", v === "tri");
        btnPara.setAttribute("aria-pressed", v === "para" ? "true" : "false");
        btnTri.setAttribute("aria-pressed", v === "tri" ? "true" : "false");
        st.invalidate();
      }
      var btns = st.buttons([
        {
          label: "平行四边形", aria: "平行四边形法则视图", active: S.view === "para",
          onClick: function () { setView("para"); }
        },
        {
          label: "三角形", aria: "三角形法则视图", active: S.view === "tri",
          onClick: function () { setView("tri"); }
        }
      ]);
      var btnPara = btns[0], btnTri = btns[1];
      setView(S.view);

      st.start();

      return {
        destroy: st.destroy,
        resize: function () { st.measure(); st.invalidate(); },
        setParams: function (np) {
          if (!np) return;
          if (np.F1 != null) { S.F1 = num(np.F1, S.F1, 1, 10); sF1.set(S.F1); }
          if (np.F2 != null) { S.F2 = num(np.F2, S.F2, 1, 10); sF2.set(S.F2); }
          if (np.theta != null) { S.theta = num(np.theta, S.theta, 0, 180); sTh.set(S.theta); }
          if (np.view) setView(np.view === "tri" ? "tri" : "para");
          st.invalidate();
        }
      };
    }
  };

  /* ═══════════════════════════════════════════════════════════════════════
   *  4. thermal —— 分子热运动
   * ═══════════════════════════════════════════════════════════════════════ */
  PSW.thermal = {
    title: "分子热运动",
    defaults: { T: 300 },
    mount: function (root, params, ctx) {
      var theme = themeOf(ctx);
      var st = createStage(root, theme, { label: "分子热运动：温度与速率分布" });
      var p = params || {};

      var N = 120;                  // 分子数
      var M = 0.028;                // 氮气摩尔质量 kg/mol
      var VMAX = 1300;              // 速率分布横轴 m/s
      var BINS = 22;
      var KPF = 0.34;               // 像素/（m/s）：动画速率换算
      var S = { T: num(p.T, 300, 100, 600) };

      var mols = [];
      var hit = { l: 0, r: 0, t: 0, b: 0 };
      var cardClock = 0;

      function gauss() {
        var u = 0, v = 0;
        while (u === 0) u = Math.random();
        while (v === 0) v = Math.random();
        return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
      }
      function sigma(T) { return Math.sqrt(R_GAS * T / M); }
      function vRms(T) { return Math.sqrt(3 * R_GAS * T / M); }
      function vMean(T) { return Math.sqrt(8 * R_GAS * T / (Math.PI * M)); }

      function seedMol() {
        var sg = sigma(S.T);
        mols.length = 0;
        for (var i = 0; i < N; i++) {
          mols.push({
            x: 0.02 + Math.random() * 0.96,
            y: 0.02 + Math.random() * 0.96,
            vx: gauss() * sg,
            vy: gauss() * sg,
            vz: gauss() * sg
          });
        }
      }
      seedMol();

      /* 温度变化：理想气体分子速率 ∝ √T —— 直接按 √(T'/T) 等比缩放，分布形状保持 */
      function setT(T) {
        T = clamp(T, 100, 600);
        if (Math.abs(T - S.T) < 1e-9) return;
        var k = Math.sqrt(T / S.T);
        S.T = T;
        for (var i = 0; i < mols.length; i++) {
          mols[i].vx *= k;
          mols[i].vy *= k;
          mols[i].vz *= k;
        }
      }

      function speedOf(m) {
        return Math.sqrt(m.vx * m.vx + m.vy * m.vy + m.vz * m.vz);
      }

      /* 温度 → 颜色：低温蓝 → 高温橙（中段降低饱和度，避免刺眼的荧光绿） */
      function tempColor(T) {
        var t = clamp((T - 100) / 500, 0, 1);
        var bend = Math.sin(Math.PI * t);
        var h = 205 - 178 * t;
        var sat = 80 - 20 * bend;
        var li = 61 + 3 * bend;
        return "hsl(" + h.toFixed(1) + "," + sat.toFixed(0) + "%," + li.toFixed(0) + "%)";
      }

      st.card([
        { k: "温度 T", v: "—" },
        { k: "方均根速率 v_rms", v: "—" },
        { k: "平均速率 v̄（实测/理论）", v: "—" },
        { k: "分子平均动能 Ēk = 3/2·kT", v: "—" },
        { note: "v_rms = √(3RT/M)，N₂ 的 M = 28 g/mol；温度是分子平均动能的标志" }
      ]);

      /* 容器与直方图的版面（绘制与运动学共用，保证分子贴壁不越界） */
      function layout() {
        var W = st.W, H = st.H;
        var top = Math.max(18, (st.cardH || 76) + 12);
        var bot = H - 14;
        if (bot - top < 70) { top = 14; bot = H - 12; }
        var gap = 14;
        var boxX = 14, boxW = Math.max(120, (W - 42) * 0.56);
        var boxY = top, boxH = Math.max(46, bot - top);
        var histX = boxX + boxW + gap;
        var histW = Math.max(90, W - histX - 14);
        return {
          boxX: boxX, boxY: boxY, boxW: boxW, boxH: boxH,
          histX: histX, histY: top, histW: histW, histH: boxH
        };
      }
      function molR(boxW, boxH) {
        return clamp(Math.min(boxW, boxH) / 46, 2.2, 4.4);
      }

      function draw() {
        var g = st.g, W = st.W, H = st.H;
        g.clearRect(0, 0, W, H);
        if (W < 80 || H < 80) return;

        var col = tempColor(S.T);
        var L = layout();
        var boxX = L.boxX, boxY = L.boxY, boxW = L.boxW, boxH = L.boxH;
        var histX = L.histX, histY = L.histY, histW = L.histW, histH = L.histH;

        /* 读数（限流刷新，避免每帧改 DOM 造成抖动） */
        if (cardClock <= 0) {
          cardClock = 0.14;
          var sumV = 0;
          for (var q = 0; q < mols.length; q++) sumV += speedOf(mols[q]);
          st.setRow(0, fx(S.T, 0) + " K", col);
          st.setRow(1, fx(vRms(S.T), 0) + " m/s", "#e2e8f0");
          st.setRow(2, fx(sumV / mols.length, 0) + " / " + fx(vMean(S.T), 0) + " m/s", "#e2e8f0");
          st.setRow(3, sci(1.5 * K_B * S.T) + " J", "#e2e8f0");
        }

        /* ── 容器 ── */
        fillRound(g, boxX, boxY, boxW, boxH, 12, "rgba(10,17,30,.55)");
        var innerGlow = g.createRadialGradient(
          boxX + boxW / 2, boxY + boxH / 2, 10,
          boxX + boxW / 2, boxY + boxH / 2, Math.max(boxW, boxH) * 0.72
        );
        innerGlow.addColorStop(0, rgba(theme.accent, 0.05));
        innerGlow.addColorStop(1, "rgba(0,0,0,0)");
        g.save();
        pathRound(g, boxX, boxY, boxW, boxH, 12);
        g.clip();
        g.fillStyle = innerGlow;
        g.fillRect(boxX, boxY, boxW, boxH);
        g.restore();

        /* 分子 */
        var r = molR(boxW, boxH);
        g.save();
        pathRound(g, boxX + 1, boxY + 1, boxW - 2, boxH - 2, 11);
        g.clip();
        g.fillStyle = col;
        g.globalAlpha = 0.92;
        g.beginPath();
        for (var i = 0; i < mols.length; i++) {
          var mx = boxX + mols[i].x * boxW;
          var my = boxY + mols[i].y * boxH;
          g.moveTo(mx + r, my);
          g.arc(mx, my, r, 0, Math.PI * 2);
        }
        g.fill();
        g.globalAlpha = 1;
        g.restore();

        /* 器壁（碰撞侧发光） */
        var base = "rgba(148,163,184,.42)";
        var hi = "rgba(255,255,255,.85)";
        function wall(x1, y1, x2, y2, heat) {
          g.strokeStyle = heat > 0.02 ? mixHex("#94a3b8", "#ffffff", Math.min(1, heat)) : base;
          g.lineWidth = 1.6 + heat * 1.4;
          g.beginPath();
          g.moveTo(x1, y1);
          g.lineTo(x2, y2);
          g.stroke();
        }
        g.save();
        pathRound(g, boxX, boxY, boxW, boxH, 12);
        g.clip();
        wall(boxX + 1, boxY, boxX + 1, boxY + boxH, hit.l);
        wall(boxX + boxW - 1, boxY, boxX + boxW - 1, boxY + boxH, hit.r);
        wall(boxX, boxY + 1, boxX + boxW, boxY + 1, hit.t);
        wall(boxX, boxY + boxH - 1, boxX + boxW, boxY + boxH - 1, hit.b);
        g.restore();
        pathRound(g, boxX, boxY, boxW, boxH, 12);
        g.strokeStyle = "rgba(148,163,184,.28)";
        g.lineWidth = 1;
        g.stroke();

        tag(g, "N = " + N + " 个 N₂ 分子", boxX + 9, boxY + 13, {
          size: 9.5, color: "rgba(203,213,225,.85)", bg: false
        });

        /* ── 速率分布 ── */
        fillRound(g, histX, histY, histW, histH, 12, "rgba(10,17,30,.5)");
        pathRound(g, histX, histY, histW, histH, 12);
        g.strokeStyle = "rgba(148,163,184,.20)";
        g.lineWidth = 1;
        g.stroke();

        var padL = 10, padR = 10, padT = 24, padB = 22;
        var plotX = histX + padL, plotY = histY + padT;
        var plotW = histW - padL - padR, plotH = histH - padT - padB;

        if (plotW > 40 && plotH > 30) {
          var counts = new Array(BINS);
          for (var ci = 0; ci < BINS; ci++) counts[ci] = 0;
          for (i = 0; i < mols.length; i++) {
            var v = speedOf(mols[i]);
            var bi = Math.floor(v / VMAX * BINS);
            if (bi >= BINS) bi = BINS - 1;
            if (bi < 0) bi = 0;
            counts[bi]++;
          }
          var coef = 4 * Math.PI * Math.pow(M / (2 * Math.PI * R_GAS * S.T), 1.5);
          var bw = VMAX / BINS;
          var theory = [];
          var maxY = 1;
          for (i = 0; i < BINS; i++) {
            var vc = (i + 0.5) * bw;
            var fv = coef * vc * vc * Math.exp(-M * vc * vc / (2 * R_GAS * S.T));
            var ct = fv * N * bw;
            theory.push(ct);
            if (ct > maxY) maxY = ct;
            if (counts[i] > maxY) maxY = counts[i];
          }
          maxY = maxY * 1.12 + 0.5;

          /* 基线 */
          g.strokeStyle = "rgba(148,163,184,.28)";
          g.lineWidth = 1;
          g.beginPath();
          g.moveTo(plotX, plotY + plotH);
          g.lineTo(plotX + plotW, plotY + plotH);
          g.stroke();

          var bwPx = plotW / BINS;
          g.save();
          for (i = 0; i < BINS; i++) {
            var hh = counts[i] / maxY * plotH;
            if (hh < 0.4) continue;
            var bx0 = plotX + i * bwPx;
            var grd = g.createLinearGradient(0, plotY + plotH - hh, 0, plotY + plotH);
            grd.addColorStop(0, rgba(theme.accent, 0.75));
            grd.addColorStop(1, rgba(theme.accent, 0.14));
            g.fillStyle = grd;
            g.fillRect(bx0 + 0.8, plotY + plotH - hh, Math.max(1, bwPx - 1.6), hh);
          }
          g.restore();

          /* 理论曲线 */
          g.strokeStyle = col;
          g.lineWidth = 2;
          g.lineJoin = "round";
          g.beginPath();
          for (i = 0; i < BINS; i++) {
            var cx0 = plotX + (i + 0.5) * bwPx;
            var cy0 = plotY + plotH - theory[i] / maxY * plotH;
            if (i === 0) g.moveTo(cx0, cy0); else g.lineTo(cx0, cy0);
          }
          g.stroke();

          /* v_rms 标线 */
          var vr = vRms(S.T);
          var vx = plotX + clamp(vr / VMAX, 0, 1) * plotW;
          g.save();
          g.setLineDash([3, 3]);
          g.strokeStyle = rgba(theme.accent, 0.75);
          g.lineWidth = 1;
          g.beginPath();
          g.moveTo(vx, plotY + 2);
          g.lineTo(vx, plotY + plotH);
          g.stroke();
          g.restore();
          tag(g, "v_rms", vx, plotY - 4, {
            size: 9, align: "center", color: rgba(theme.accent, 0.95), bg: false
          });

          /* 轴刻度 */
          g.fillStyle = "rgba(148,163,184,.7)";
          g.font = "9px " + FONT;
          g.textAlign = "center";
          g.textBaseline = "top";
          for (var tk = 0; tk <= VMAX; tk += 400) {
            var txx = plotX + (tk / VMAX) * plotW;
            g.strokeStyle = "rgba(148,163,184,.22)";
            g.beginPath();
            g.moveTo(txx, plotY + plotH);
            g.lineTo(txx, plotY + plotH + 3);
            g.stroke();
            if (txx < plotX + plotW - 6) g.fillText(String(tk), txx, plotY + plotH + 5);
          }
          g.textAlign = "left";
          g.textBaseline = "middle";
          g.fillStyle = "rgba(148,163,184,.75)";
          g.fillText("速率分布", histX + 10, histY + 12);
          g.textAlign = "right";
          g.fillText("v / (m·s⁻¹)", histX + histW - 10, histY + 12);
        }
      }

      st.draw = draw;
      st.frame = function (dt) {
        var L = layout();
        var boxW = L.boxW, boxH = L.boxH;
        var r = molR(boxW, boxH);
        var mx = r / boxW, my = r / boxH;

        for (var i = 0; i < mols.length; i++) {
          var m = mols[i];
          m.x += (m.vx * KPF / boxW) * dt;
          m.y += (m.vy * KPF / boxH) * dt;
          if (m.x < mx) { m.x = mx + (mx - m.x); m.vx = Math.abs(m.vx); hit.l = 1; }
          else if (m.x > 1 - mx) { m.x = 2 - mx - m.x; m.vx = -Math.abs(m.vx); hit.r = 1; }
          if (m.y < my) { m.y = my + (my - m.y); m.vy = Math.abs(m.vy); hit.t = 1; }
          else if (m.y > 1 - my) { m.y = 2 - my - m.y; m.vy = -Math.abs(m.vy); hit.b = 1; }
        }
        var dk = Math.min(1, dt * 4);
        hit.l = Math.max(0, hit.l - dk);
        hit.r = Math.max(0, hit.r - dk);
        hit.t = Math.max(0, hit.t - dk);
        hit.b = Math.max(0, hit.b - dk);
        cardClock -= dt;
        return true;
      };

      var sT = st.slider({
        name: "温度 T", unit: "K", min: 100, max: 600, step: 5, value: S.T, digits: 0,
        onInput: function (v) { setT(v); st.invalidate(); }
      });

      st.buttons([
        {
          label: "重新排布", aria: "重新随机生成分子位置与速度",
          onClick: function () { seedMol(); st.invalidate(); }
        }
      ]);

      st.hint("温度是分子平均动能的标志：<b>Ēk = 3/2·kT</b>，T 升高则分子平均动能与速率都增大，速率分布整体右移。");

      st.start();

      return {
        destroy: st.destroy,
        resize: function () { st.measure(); st.invalidate(); },
        setParams: function (np) {
          if (!np) return;
          if (np.T != null) { setT(num(np.T, S.T, 100, 600)); sT.set(S.T); }
          st.invalidate();
        }
      };
    }
  };

})(typeof window !== "undefined" ? window : this);