/*!
 * 悟理智课 · 360° 环视实验室（vr）
 * 零依赖 Canvas 伪 3D 全景控件：球面投影 + 拖拽惯性 + 指南针 + 小地图 + 热点说明卡
 */
(function () {
  "use strict";

  window.PSWidgets = window.PSWidgets || {};

  var DEG = Math.PI / 180;
  var TAU = Math.PI * 2;
  var FOV = 75;            // 垂直视场角（可缩放）
  var TARGET_FOV = 75;
  var NEAR = 0.05;         // 近裁剪（相机空间 z）
  var FOCUS = 6;           // 准星命中角（度）
  var PITCH_MIN = -62;
  var PITCH_MAX = 62;
  var FONT = "system-ui,-apple-system,'Segoe UI','PingFang SC','Microsoft YaHei',sans-serif";

  /* ------------------------------------------------------------------ *
   * 通用小工具
   * ------------------------------------------------------------------ */
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }

  function wrap180(a) {
    a = (a + 180) % 360;
    if (a < 0) a += 360;
    return a - 180;
  }

  function parseHex(c) {
    if (typeof c !== "string" || c.charAt(0) !== "#") return null;
    var h = c.slice(1);
    if (h.length === 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
    var n = parseInt(h, 16);
    if (!isFinite(n)) return null;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  function withAlpha(c, a) {
    var p = parseHex(c);
    if (!p) return c;
    return "rgba(" + p[0] + "," + p[1] + "," + p[2] + "," + a + ")";
  }

  function mixHex(a, b, t) {
    var A = parseHex(a), B = parseHex(b);
    if (!A || !B) return a;
    return "rgb(" + Math.round(A[0] + (B[0] - A[0]) * t) + "," +
      Math.round(A[1] + (B[1] - A[1]) * t) + "," +
      Math.round(A[2] + (B[2] - A[2]) * t) + ")";
  }

  /* ------------------------------------------------------------------ *
   * 场景数据构件
   * ------------------------------------------------------------------ */
  function band(y0, y1, top, bottom, color) {
    return { y0: y0, y1: y1, top: top, bottom: bottom, color: color };
  }

  /* 起伏山脊：yaw 全周，按 step 切分为一组带（周期函数，接缝连续） */
  function ridge(baseTop, amp, step, bottom, color, phase) {
    var out = [], y, t, top;
    for (y = -180; y < 180; y += step) {
      t = y * DEG;
      top = baseTop + amp * (
        Math.sin(t * 2 + phase) * 0.55 +
        Math.sin(t * 5 + phase * 1.7) * 0.3 +
        Math.sin(t * 11 + phase * 2.3) * 0.15
      );
      out.push(band(y, y + step, top, bottom, color));
    }
    return out;
  }

  /* 磁场线：以 (cx,cy) 为中心的闭合椭圆采样点（yaw,pitch 单位度） */
  function fieldLoop(cx, cy, a, b, n) {
    n = n || 44;
    var pts = [], i, t;
    for (i = 0; i <= n; i++) {
      t = (i / n) * TAU;
      pts.push([cx + a * Math.cos(t), cy + b * Math.sin(t)]);
    }
    return pts;
  }

  function makeStars(count, seed) {
    var out = [], i, s = seed || 7, u, v;
    for (i = 0; i < count; i++) {
      s = (s * 16807) % 2147483647; u = s / 2147483647;
      s = (s * 16807) % 2147483647; v = s / 2147483647;
      out.push({
        yaw: u * 360 - 180,
        pitch: 2 + v * 46,
        r: 0.1 + (i % 4) * 0.045,
        a: 0.25 + ((i * 41) % 62) / 100
      });
    }
    return out;
  }

  /* ------------------------------------------------------------------ *
   * 四个预设场景
   * ------------------------------------------------------------------ */
  function buildMechanics() {
    var bands = [], props = [], y;

    bands.push(band(-180, 180, -1.5, -8.6, "#4a3348"));                 // 远处地面 / 薄雾
    bands = bands.concat(ridge(2.0, 1.7, 8, -2.3, "#3a2a46", 0.6));     // 远山
    bands = bands.concat(ridge(4.3, 1.15, 8, -1.5, "#4d3753", 2.1));    // 近山
    bands.push(band(-180, 180, -4.0, -3.4, "#2e2233"));                 // 围栏上横杆
    bands.push(band(-180, 180, -6.4, -5.8, "#2e2233"));                 // 围栏下横杆
    for (y = -180; y < 180; y += 12) bands.push(band(y, y + 1.2, -7.5, -3.4, "#352641"));

    props.push(
      // 夕阳
      { k: "glow", yaw: 18, pitch: 6.5, r: 11, color: "#ffb066", a: 0.42 },
      { k: "disc", yaw: 18, pitch: 6.5, r: 3.6, fill: "#ffe3b4" },
      // 晚霞
      { k: "poly", pts: [[-48, 17], [-26, 21], [-8, 18], [-22, 13.5]], fill: "rgba(255,168,140,0.14)" },
      { k: "poly", pts: [[32, 23], [56, 25], [66, 20.5], [44, 18.5]], fill: "rgba(255,150,150,0.11)" },
      // 斜面（楔形）
      { k: "poly", pts: [[20, -13.4], [68, -13.4], [68, -2.4]], fill: "#4b3b46",
        stroke: "rgba(255,196,150,0.35)", lw: 1.2 },
      { k: "line", pts: [[20, -13.4], [68, -2.4]], color: "rgba(255,206,160,0.85)", lw: 2 },
      // 小车
      { k: "panel", y0: 34, y1: 42, top: -7.9, bottom: -9.2, fill: "#e0663f" },
      { k: "line", pts: [[34.4, -8.25], [41.6, -8.6]], color: "rgba(255,235,200,0.55)", lw: 1 },
      { k: "disc", yaw: 35.6, pitch: -9.35, r: 0.55, fill: "#2a2230", stroke: "rgba(255,196,150,0.7)" },
      { k: "disc", yaw: 40.4, pitch: -9.35, r: 0.55, fill: "#2a2230", stroke: "rgba(255,196,150,0.7)" },
      // 打点计时器
      { k: "panel", y0: 56.5, y1: 63.5, top: -2.6, bottom: -4.1, fill: "#3a4a63",
        stroke: "rgba(160,215,255,0.45)" },
      { k: "disc", yaw: 60, pitch: -3.35, r: 0.8, fill: "#16212f", stroke: "#9fd8ff" },
      { k: "disc", yaw: 60, pitch: -3.35, r: 0.24, fill: "#d9f0ff" },
      // 纸带
      { k: "line", pts: [[58.8, -3.9], [50, -5.8], [41.6, -7.9]], color: "rgba(245,235,205,0.8)",
        lw: 3, dash: [3, 3] },
      // 刻度尺
      { k: "panel", y0: 71, y1: 83, top: -12.9, bottom: -12.1, fill: "#e8d7a6",
        stroke: "rgba(110,80,40,0.7)" }
    );

    return {
      name: "力学 · 操场斜面",
      startYaw: 34,
      startPitch: -7,
      sky: ["#2a1c3e", "#7b4062", "#f7a866"],
      ground: ["#3d2e3a", "#201a24"],
      grid: { color: "#ffb878", alpha: 0.26, step: 2, xmax: 16, zmax: 46 },
      eye: 1.6,
      haze: "#ffb98a",
      hazeA: 0.16,
      vignette: 0.52,
      rings: [
        { r: 9.5, color: "rgba(210,120,88,0.30)", w: 2 },
        { r: 11.2, color: "rgba(210,120,88,0.24)", w: 2 },
        { r: 12.8, color: "rgba(226,150,110,0.18)", w: 1.5 }
      ],
      bands: bands,
      props: props,
      objects: [
        { yaw: 38, pitch: -8.2, label: "小车", kind: "cart",
          desc: "小车在斜面上加速下滑；忽略摩擦时，下滑加速度 a = g·sinθ 与质量无关。" },
        { yaw: 25, pitch: -12.6, label: "斜面", kind: "incline",
          desc: "倾角 θ 越大，重力沿斜面的分力越大，加速度 a = g(sinθ − μcosθ) 越大。" },
        { yaw: 52, pitch: -6.0, label: "纸带", kind: "tape",
          desc: "纸带上相邻点距逐渐变大，说明小车做加速直线运动。" },
        { yaw: 61.5, pitch: -3.5, label: "打点计时器", kind: "timer",
          desc: "电磁打点计时器接 50 Hz 交流电源，每隔 0.02 s 在纸带上打一个点。" },
        { yaw: 77, pitch: -12.4, label: "刻度尺", kind: "ruler",
          desc: "测出相邻相等时间内的位移差 Δx，可由 Δx = aT² 求出加速度。" }
      ]
    };
  }

  function buildCircuit() {
    var bands = [], props = [], y;

    // 顶部由天空渐变承担（避免极端俯仰下整条穹顶带被近裁剪面裁掉）
    bands.push(band(-180, 180, 34, 20, "#13273b"));
    bands.push(band(-180, 180, 20, 5, "#20364c"));
    bands.push(band(-180, 180, 5, -16, "#1a2c40"));
    for (y = -180; y < 180; y += 30) bands.push(band(y, y + 0.6, -16, 5, "#162536"));

    props.push(
      // 窗（冷色日光）
      { k: "panel", y0: -62, y1: -42, top: 15, bottom: -2, c1: "#7fb3d8", c2: "#dcecf7" },
      { k: "line", pts: [[-52, 15], [-52, -2]], color: "rgba(20,40,60,0.55)", lw: 2 },
      { k: "line", pts: [[-62, 7], [-42, 7]], color: "rgba(20,40,60,0.55)", lw: 2 },
      { k: "line", pts: [[-62, 15], [-42, 15]], color: "rgba(160,200,230,0.6)", lw: 2 },
      { k: "glow", yaw: -52, pitch: 7, r: 20, color: "#cfe9ff", a: 0.28 },
      // 天花板日光灯
      { k: "panel", y0: -34, y1: -12, top: 30.5, bottom: 29.2, fill: "#e8f8ff" },
      { k: "panel", y0: 8, y1: 30, top: 30.5, bottom: 29.2, fill: "#e8f8ff" },
      { k: "glow", yaw: -23, pitch: 29.8, r: 13, color: "#bfe9ff", a: 0.40 },
      { k: "glow", yaw: 19, pitch: 29.8, r: 13, color: "#bfe9ff", a: 0.40 },
      // 墙上挂钟
      { k: "disc", yaw: 44, pitch: 12, r: 2.4, fill: "#e2e8f0", stroke: "#94a3b8" },
      { k: "line", pts: [[44, 12], [44, 13.4]], color: "#334155", lw: 1.2 },
      { k: "line", pts: [[44, 12], [45, 12]], color: "#334155", lw: 1.2 },
      // 实验台
      { k: "panel", y0: -36, y1: 36, top: -12.7, bottom: -25.2, c1: "#3d322d", c2: "#241c1e" },
      { k: "panel", y0: -36, y1: 36, top: -12.1, bottom: -12.7, fill: "#6f5848" },
      { k: "line", pts: [[-36, -12.55], [36, -12.55]], color: "rgba(255,215,170,0.35)", lw: 1.4 },
      // 电源
      { k: "panel", y0: -21, y1: -14, top: -9.4, bottom: -12.5, fill: "#2b3a4d",
        stroke: "rgba(150,190,230,0.4)" },
      { k: "panel", y0: -20.4, y1: -14.6, top: -9.9, bottom: -11.3, fill: "#1a2634" },
      { k: "line", pts: [[-20.6, -11.6], [-14.4, -11.6]], color: "rgba(125,211,252,0.5)", lw: 1 },
      { k: "disc", yaw: -19.4, pitch: -11.9, r: 0.28, fill: "#ef4444" },
      { k: "disc", yaw: -15.6, pitch: -11.9, r: 0.28, fill: "#0f172a", stroke: "#94a3b8" },
      // 小灯泡
      { k: "panel", y0: -8.6, y1: -4.4, top: -11.3, bottom: -12.5, fill: "#3a4a5c" },
      { k: "disc", yaw: -6.5, pitch: -10.2, r: 1.5, fill: "rgba(255,236,170,0.85)",
        stroke: "rgba(255,245,200,0.9)" },
      { k: "glow", yaw: -6.5, pitch: -10.2, r: 7, color: "#ffe9a8", a: 0.55 },
      { k: "line", pts: [[-7.2, -10.9], [-5.9, -10.0]], color: "rgba(255,120,60,0.9)", lw: 1.2 },
      // 开关
      { k: "panel", y0: 1.5, y1: 6.5, top: -11.9, bottom: -12.5, fill: "#1e2a38",
        stroke: "rgba(148,163,184,0.4)" },
      { k: "line", pts: [[3.2, -12.1], [5.2, -11.2]], color: "#cbd5e1", lw: 2 },
      // 电流表
      { k: "panel", y0: 10, y1: 17, top: -9.6, bottom: -12.5, fill: "#22303f",
        stroke: "rgba(125,211,252,0.4)" },
      { k: "panel", y0: 10.6, y1: 16.4, top: -10.0, bottom: -11.9, fill: "#dbe7f2" },
      { k: "line", pts: [[13.5, -11.85], [12.2, -10.6]], color: "#e11d48", lw: 1.4 },
      // 导线
      { k: "line", pts: [[-19.4, -11.7], [-16, -10.0], [-11, -9.6], [-8.4, -10.4]],
        color: "#e05a4a", lw: 2 },
      { k: "line", pts: [[-15.6, -11.7], [-12, -11.4], [-9.4, -11.6], [-8.2, -12.0]],
        color: "#334155", lw: 2 },
      { k: "line", pts: [[-4.8, -11.9], [-1.5, -12.1], [1.6, -12.2]], color: "#e05a4a", lw: 2 },
      { k: "line", pts: [[6.4, -12.2], [8.6, -12.3], [10.2, -12.4]], color: "#e05a4a", lw: 2 },
      { k: "line", pts: [[16.8, -11.9], [22, -12.6], [26.5, -13.4]], color: "#334155", lw: 2 }
    );

    return {
      name: "电路 · 实验室台面",
      startYaw: 0,
      startPitch: -6,
      sky: ["#0a1422", "#0f1e2e", "#1a2f45"],
      ground: ["#152534", "#0b1520"],
      grid: { color: "#7dd3fc", alpha: 0.15, step: 0.8, xmax: 12, zmax: 12 },
      eye: 1.6,
      haze: "#9fd0ea",
      hazeA: 0.06,
      vignette: 0.55,
      bands: bands,
      props: props,
      objects: [
        { yaw: -17, pitch: -10.6, label: "电源", kind: "power",
          desc: "电源为电路提供恒定电压 U，是持续推动电荷定向移动、维持电流的装置。" },
        { yaw: -6.5, pitch: -10.2, label: "小灯泡", kind: "bulb",
          desc: "电流通过灯丝时电能转化为内能和光能，实际功率 P = UI。" },
        { yaw: 4.2, pitch: -11.2, label: "开关", kind: "switch",
          desc: "开关闭合使电路形成通路；断开时电路断路，电流为零。" },
        { yaw: 13.4, pitch: -10.6, label: "电流表", kind: "ammeter",
          desc: "电流表必须串联接入电路，所选量程要大于电路中的最大电流。" },
        { yaw: 24, pitch: -13.2, label: "导线", kind: "wire",
          desc: "导线中自由电子在电压作用下定向移动形成电流，电流方向规定为正电荷移动的方向。" },
        { yaw: 19, pitch: 29.8, label: "日光灯", kind: "lamp",
          desc: "日光灯把电能主要转化为光能，发光效率高、发热少，属于冷光源。" }
      ]
    };
  }

  function buildOptics() {
    var bands = [], props = [], i, y;

    // 顶部由天空渐变承担（暗室顶棚）
    bands.push(band(-180, 180, 28, 6, "#241443"));
    bands.push(band(-180, 180, 6, -16, "#1c1030"));
    for (y = -180; y < 180; y += 40) bands.push(band(y, y + 1, -16, 6, "#170e28"));

    props.push(
      // 两侧遮光帘
      { k: "panel", y0: -95, y1: -45, top: 20, bottom: -12, c1: "#2c1b48", c2: "#130c24" },
      { k: "panel", y0: 45, y1: 95, top: 20, bottom: -12, c1: "#2c1b48", c2: "#130c24" },
      // 光具座
      { k: "panel", y0: -40, y1: 40, top: -12.6, bottom: -13.9, fill: "#2b2440" },
      { k: "line", pts: [[-40, -12.6], [40, -12.6]], color: "#8b7bc0", lw: 1.5 },
      // 光源（烛焰）
      { k: "panel", y0: -26, y1: -22.6, top: -11.4, bottom: -12.7, fill: "#3a2f52" },
      { k: "line", pts: [[-24.3, -11.4], [-24.3, -10.4]], color: "#c4b5fd", lw: 1.2 },
      { k: "disc", yaw: -24.3, pitch: -9.9, r: 1.0, fill: "#ffd7a0", stroke: "rgba(255,220,160,0.8)" },
      { k: "glow", yaw: -24.3, pitch: -9.9, r: 8, color: "#ffcf99", a: 0.5 },
      // 会聚光束（物 → 透镜 → 像）
      { k: "poly", pts: [[-24.0, -9.9], [-1.5, -6.35], [-1.5, -12.35]], fill: "rgba(255,205,150,0.09)" },
      { k: "poly", pts: [[-1.5, -6.35], [21.2, -8.9], [-1.5, -12.35]], fill: "rgba(255,225,180,0.075)" },
      // 凸透镜
      { k: "disc", yaw: 0, pitch: -9.35, rx: 1.5, ry: 3.0, fill: "rgba(167,139,250,0.16)",
        stroke: "#c4b5fd", lw: 2 },
      { k: "panel", y0: -0.9, y1: 0.9, top: -12.0, bottom: -12.6, fill: "#4b3f6b" },
      // 光屏
      { k: "panel", y0: 19.5, y1: 23.5, top: -2.6, bottom: -15.4, fill: "#c8d3e2",
        stroke: "rgba(226,232,240,0.5)" },
      { k: "line", pts: [[21.5, -15.4], [21.5, -16.8]], color: "#64748b", lw: 2 },
      { k: "glow", yaw: 21.3, pitch: -8.9, r: 2.2, color: "#ffe6b0", a: 0.7 },
      { k: "disc", yaw: 21.3, pitch: -8.9, r: 0.7, fill: "#fff3d0" },
      // 焦点
      { k: "disc", yaw: -6, pitch: -12.95, r: 0.3, fill: "#f0abfc" },
      { k: "disc", yaw: 6, pitch: -12.95, r: 0.3, fill: "#f0abfc" },
      { k: "text", yaw: -6, pitch: -14.6, text: "F", color: "#f0abfc", size: 10 },
      { k: "text", yaw: 6, pitch: -14.6, text: "F", color: "#f0abfc", size: 10 },
      // 顶部微弱聚光
      { k: "glow", yaw: 0, pitch: 30, r: 18, color: "#7c5cff", a: 0.22 }
    );

    // 光具座刻度
    for (i = -38; i <= 38; i += 4) {
      props.push({ k: "line", pts: [[i, -13.6], [i, -12.95]], color: "rgba(160,150,220,0.32)", lw: 1 });
    }

    return {
      name: "光学 · 暗室光具座",
      startYaw: 0,
      startPitch: -5,
      sky: ["#0e0919", "#160e28", "#1f1436"],
      ground: ["#150d28", "#090613"],
      grid: { color: "#a78bfa", alpha: 0.12, step: 0.6, xmax: 13, zmax: 11 },
      eye: 1.5,
      haze: "#4c3a7a",
      hazeA: 0.07,
      vignette: 0.46,
      bands: bands,
      props: props,
      objects: [
        { yaw: -8.5, pitch: -13.2, label: "光具座", kind: "bench",
          desc: "光具座使光源、凸透镜和光屏共轴，便于直接读出物距 u 与像距 v。" },
        { yaw: 0, pitch: -9.35, label: "凸透镜", kind: "lens",
          desc: "凸透镜对光有会聚作用，成像位置满足 1/f = 1/u + 1/v。" },
        { yaw: -24.3, pitch: -9.9, label: "光源", kind: "candle",
          desc: "物距 u > 2f 时，凸透镜成倒立、缩小的实像。" },
        { yaw: 21.5, pitch: -5.5, label: "光屏", kind: "screen",
          desc: "实像能被光屏承接；虚像不能，只能透过透镜观察。" },
        { yaw: 6, pitch: -13.2, label: "焦点 F", kind: "focus",
          desc: "平行于主光轴的光线经凸透镜后会聚于焦点，焦点到光心的距离就是焦距 f。" },
        { yaw: 8.5, pitch: -6.0, label: "会聚光束", kind: "ray",
          desc: "凸透镜使通过它的光线向主光轴偏折，用三条特殊光线即可确定像的位置。" }
      ]
    };
  }

  function buildField() {
    var bands = [], props = [], i, cfg, pts;
    var cx = -20.5, cy = -4.2;

    // 顶部由天空渐变承担（深空）
    bands.push(band(-180, 180, 30, 4, "#081b30"));
    bands.push(band(-180, 180, 4, -4, "#0a2036"));

    // 铁芯
    props.push(
      { k: "panel", y0: -30, y1: -11, top: -1.0, bottom: -7.4, fill: "#132538",
        stroke: "rgba(125,211,252,0.35)" }
    );
    // 线圈
    for (i = 0; i < 8; i++) {
      props.push({
        k: "disc", yaw: -29 + i * 2.45, pitch: cy, rx: 0.75, ry: 3.0,
        fill: "rgba(125,211,252,0.10)", stroke: "#7dd3fc", lw: 2
      });
    }
    // 磁感线 + 流动光点
    cfg = [[13, 7.6], [18, 10.6], [23, 13.6], [8.4, 4.9]];
    for (i = 0; i < cfg.length; i++) {
      pts = fieldLoop(cx, cy, cfg[i][0], cfg[i][1]);
      props.push({ k: "line", pts: pts, color: "rgba(103,232,249,0.55)", lw: 1.5, glow: true });
      props.push({ k: "pulse", pts: pts, color: "#a5f3fc", n: 3, speed: 0.11, off: i * 0.17 });
    }
    // 导线与电流
    props.push(
      { k: "line", pts: [[-42, -20], [-35, -11], [-29.5, -5.6]],
        color: "rgba(250,204,21,0.75)", lw: 2.4, glow: true },
      { k: "line", pts: [[-11, -4.0], [-6, 1.5], [-2.5, 6.5]],
        color: "rgba(250,204,21,0.75)", lw: 2.4, glow: true },
      { k: "text", yaw: -3.2, pitch: 8.4, text: "I", color: "#facc15", size: 13, bold: true },
      // 小磁针
      { k: "disc", yaw: 18, pitch: -5.9, r: 0.55, fill: "#0b1220", stroke: "#94a3b8" },
      { k: "line", pts: [[18, -5.9], [19.4, -4.5]], color: "#fb7185", lw: 2.6 },
      { k: "line", pts: [[18, -5.9], [16.6, -7.3]], color: "#e2e8f0", lw: 2.6 },
      { k: "text", yaw: 20.4, pitch: -3.9, text: "N", color: "#fb7185", size: 10, bold: true }
    );

    return {
      name: "磁场 · 通电螺线管",
      startYaw: -8,
      startPitch: -2,
      sky: ["#030a16", "#051222", "#091a2c"],
      ground: ["#06182b", "#030b16"],
      grid: { color: "#22d3ee", alpha: 0.28, step: 1.2, xmax: 14, zmax: 26 },
      eye: 1.7,
      haze: "#1f6f8b",
      hazeA: 0.10,
      vignette: 0.58,
      rings: [
        { r: 3.2, color: "rgba(34,211,238,0.16)", w: 1.5 },
        { r: 4.6, color: "rgba(34,211,238,0.12)", w: 1.5 },
        { r: 6.2, color: "rgba(34,211,238,0.08)", w: 1.5 }
      ],
      bands: bands,
      props: props,
      stars: makeStars(46, 9931),
      objects: [
        { yaw: -20.5, pitch: 3.4, label: "磁感线", kind: "fieldline",
          desc: "磁感线从 N 极出发、回到 S 极，线的疏密表示磁场的强弱。" },
        { yaw: -20.5, pitch: -4.2, label: "通电螺线管", kind: "coil",
          desc: "通电螺线管外部的磁场与条形磁体相似，内部磁场方向由 S 极指向 N 极。" },
        { yaw: -33, pitch: 7, label: "右手螺旋定则", kind: "rule",
          desc: "右手握住螺线管，四指指向电流环绕方向，拇指所指的一端就是 N 极。" },
        { yaw: 18, pitch: -5.9, label: "小磁针", kind: "needle",
          desc: "小磁针静止时 N 极所指的方向，就是该点磁场的方向。" },
        { yaw: -14, pitch: -1, label: "铁芯", kind: "core",
          desc: "插入铁芯后螺线管的磁性显著增强，这就是电磁铁的工作原理。" },
        { yaw: -4.5, pitch: 3.5, label: "电流方向", kind: "current",
          desc: "改变电流方向，螺线管的 N、S 极随之对调，磁场方向反向。" }
      ]
    };
  }

  var BUILDERS = {
    mechanics: buildMechanics,
    circuit: buildCircuit,
    optics: buildOptics,
    field: buildField
  };
  var SCENE_CACHE = {};

  function getScene(key) {
    if (!BUILDERS[key]) key = "mechanics";
    if (!SCENE_CACHE[key]) {
      var s = BUILDERS[key]();
      var i, b;
      for (i = 0; i < s.bands.length; i++) {
        b = s.bands[i];
        b.n = Math.max(1, Math.ceil((b.y1 - b.y0) / 8));
      }
      SCENE_CACHE[key] = s;
    }
    return SCENE_CACHE[key];
  }

  var KIND_COLOR = {
    incline: "#fbbf24", cart: "#fb923c", timer: "#93c5fd", tape: "#fcd34d", ruler: "#a3e635",
    power: "#f87171", bulb: "#fde68a", switch: "#94a3b8", wire: "#fca5a5", ammeter: "#67e8f9",
    lamp: "#bae6fd",
    bench: "#c4b5fd", lens: "#a78bfa", screen: "#e2e8f0", candle: "#fdba74", ray: "#c4b5fd",
    focus: "#f0abfc",
    coil: "#7dd3fc", fieldline: "#22d3ee", needle: "#fb7185", core: "#94a3b8", current: "#facc15",
    rule: "#a5b4fc",
    mark: "#38bdf8"
  };

  var KIND_BADGE = {
    incline: "实验装置", cart: "实验装置", timer: "测量仪器", tape: "实验记录", ruler: "测量仪器",
    power: "电源设备", bulb: "用电器", switch: "控制元件", wire: "连接导线", ammeter: "测量仪器",
    lamp: "环境光源", bench: "实验装置", lens: "光学元件", screen: "实验器材", candle: "光源",
    ray: "光现象", focus: "概念标记", coil: "磁场装置", fieldline: "磁场模型", needle: "检测工具",
    core: "磁场装置", current: "电流方向", rule: "物理规律", mark: "场景热点"
  };

  /* ------------------------------------------------------------------ *
   * 样式（注入一次，psw- 前缀）
   * ------------------------------------------------------------------ */
  var STYLE_TEXT = [
    '.psw-vr{position:absolute;inset:0;overflow:hidden;background:#0b1220;color:#e2e8f0;',
    'font-family:system-ui,-apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;',
    'user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent;',
    'touch-action:none;outline:none}',
    '.psw-vr *{box-sizing:border-box}',
    '.psw-vr:focus-visible{outline:2px solid var(--psw-accent);outline-offset:-2px}',
    '.psw-vr canvas{display:block}',
    '.psw-vr-canvas{position:absolute;left:0;top:0;width:100%;height:100%;cursor:grab;touch-action:none}',

    '.psw-vr-title{position:absolute;left:12px;top:10px;max-width:44%;z-index:3;pointer-events:none}',
    '.psw-vr-name{display:flex;align-items:center;gap:6px;font-size:13px;font-weight:600;',
    'letter-spacing:.02em;line-height:1.3;text-shadow:0 2px 10px rgba(0,0,0,.7)}',
    '.psw-vr-dot{width:6px;height:6px;border-radius:50%;background:var(--psw-accent);',
    'box-shadow:0 0 9px var(--psw-accent);flex:0 0 auto}',
    '.psw-vr-hint{margin-top:4px;font-size:11px;line-height:1.55;color:#94a3b8;',
    'text-shadow:0 1px 8px rgba(0,0,0,.85)}',

    '.psw-vr-compass{position:absolute;left:50%;top:10px;transform:translateX(-50%);',
    'height:26px;border-radius:999px;background:rgba(11,18,32,.55);',
    'border:1px solid rgba(148,163,184,.24);backdrop-filter:blur(8px);',
    '-webkit-backdrop-filter:blur(8px);z-index:3;pointer-events:none;',
    'box-shadow:0 6px 18px rgba(0,0,0,.28)}',

    '.psw-vr-reset{position:absolute;right:12px;top:10px;z-index:5;display:inline-flex;',
    '.psw-vr-zoom{position:absolute;right:12px;top:46px;z-index:5;display:flex;flex-direction:column;gap:5px}',
    '.psw-vr-zbtn{width:30px;height:30px;border-radius:8px;border:1px solid rgba(255,255,255,.18);',
    'background:rgba(10,17,28,.72);color:#dbe7f5;font-size:16px;line-height:1;cursor:pointer;display:flex;align-items:center;justify-content:center}',
    '.psw-vr-zbtn:hover{border-color:var(--psw-accent);color:#fff}',
    'align-items:center;gap:5px;padding:6px 10px;border-radius:999px;cursor:pointer;',
    'border:1px solid rgba(148,163,184,.28);background:rgba(15,23,42,.66);color:#e2e8f0;',
    'font:600 11.5px/1 system-ui,-apple-system,"PingFang SC",sans-serif;',
    'backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);',
    'transition:border-color .16s,color .16s,box-shadow .16s,transform .16s}',
    '.psw-vr-reset:hover{border-color:var(--psw-accent);color:#fff;transform:translateY(-1px)}',
    '.psw-vr-reset:focus-visible{outline:none;border-color:var(--psw-accent);',
    'box-shadow:0 0 0 2px rgba(56,189,248,.28)}',
    '.psw-vr-reset-i{font-size:13px;line-height:1;color:var(--psw-accent)}',

    '.psw-vr-map{position:absolute;right:12px;bottom:12px;border-radius:50%;z-index:3;',
    'pointer-events:none;filter:drop-shadow(0 6px 16px rgba(0,0,0,.45))}',

    '.psw-vr-reticle{position:absolute;left:50%;top:50%;width:20px;height:20px;',
    'margin:-10px 0 0 -10px;border-radius:50%;border:1px solid rgba(226,232,240,.5);',
    'z-index:4;pointer-events:none;transition:width .16s,height .16s,margin .16s,',
    'border-color .16s,box-shadow .16s}',
    '.psw-vr-reticle-d{position:absolute;left:50%;top:50%;width:2px;height:2px;margin:-1px;',
    'border-radius:50%;background:rgba(226,232,240,.85)}',
    '.psw-vr-reticle.is-hot{width:30px;height:30px;margin:-15px 0 0 -15px;',
    'border-color:var(--psw-accent);box-shadow:0 0 14px rgba(56,189,248,.55),',
    'inset 0 0 8px rgba(56,189,248,.22)}',
    '.psw-vr-reticle.is-hot .psw-vr-reticle-d{background:var(--psw-accent)}',

    '.psw-vr-keyhint{position:absolute;left:50%;top:calc(50% + 30px);transform:translate(-50%,4px);',
    'z-index:4;padding:4px 10px;border-radius:999px;background:rgba(11,18,32,.72);',
    'border:1px solid rgba(56,189,248,.45);color:#e2e8f0;font-size:11px;letter-spacing:.02em;',
    'white-space:nowrap;pointer-events:none;opacity:0;transition:opacity .16s,transform .16s}',
    '.psw-vr-keyhint.is-on{opacity:1;transform:translate(-50%,0)}',

    '.psw-vr-read{position:absolute;left:12px;bottom:12px;z-index:3;pointer-events:none;',
    'font:500 10.5px/1 ui-monospace,SFMono-Regular,Consolas,monospace;color:#94a3b8;',
    'letter-spacing:.04em;text-shadow:0 1px 6px rgba(0,0,0,.8)}',

    '.psw-vr-card{position:absolute;left:50%;top:50%;width:min(330px,86%);max-height:72%;',
    'overflow:auto;z-index:6;padding:15px 15px 12px;border-radius:16px;',
    'transform:translate(-50%,-50%) scale(.94);opacity:0;visibility:hidden;pointer-events:none;',
    'transition:opacity .18s ease,transform .18s ease,visibility .18s;',
    'background:linear-gradient(180deg,rgba(17,28,46,.88),rgba(12,20,34,.82));',
    'border:1px solid rgba(148,163,184,.26);',
    'backdrop-filter:blur(14px) saturate(1.25);-webkit-backdrop-filter:blur(14px) saturate(1.25);',
    'box-shadow:0 18px 48px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,255,255,.06)}',
    '.psw-vr-card.is-on{opacity:1;visibility:visible;pointer-events:auto;',
    'transform:translate(-50%,-50%) scale(1)}',
    '.psw-vr-card-top{display:flex;align-items:center;justify-content:space-between;gap:8px}',
    '.psw-vr-kind{font-size:10px;font-weight:700;letter-spacing:.14em;color:var(--psw-accent)}',
    '.psw-vr-x{width:26px;height:26px;display:grid;place-items:center;flex:0 0 auto;',
    'border-radius:9px;border:1px solid rgba(148,163,184,.25);background:rgba(255,255,255,.04);',
    'color:#cbd5e1;font-size:12px;line-height:1;cursor:pointer;transition:all .15s}',
    '.psw-vr-x:hover{border-color:var(--psw-accent);color:#fff;background:rgba(56,189,248,.12)}',
    '.psw-vr-x:focus-visible{outline:none;border-color:var(--psw-accent);',
    'box-shadow:0 0 0 2px rgba(56,189,248,.28)}',
    '.psw-vr-card-h{margin-top:7px;font-size:16px;font-weight:700;letter-spacing:.01em;',
    'line-height:1.35}',
    '.psw-vr-card-d{margin-top:8px;font-size:12.5px;line-height:1.7;color:#cbd5e1}',
    '.psw-vr-card-f{margin-top:11px;font-size:10.5px;color:#64748b}',

    '.psw-vr.is-narrow .psw-vr-hint{display:none}',
    '.psw-vr.is-narrow .psw-vr-compass{top:36px;height:22px}',
    '.psw-vr.is-narrow .psw-vr-name{font-size:12px}',
    '.psw-vr.is-narrow .psw-vr-reset{padding:5px 8px;font-size:11px}'
  ].join("\n");

  function ensureStyle() {
    if (document.querySelector('style[data-psw-style="vr"]')) return;
    var st = document.createElement("style");
    st.setAttribute("data-psw-style", "vr");
    st.appendChild(document.createTextNode(STYLE_TEXT));
    (document.head || document.documentElement).appendChild(st);
  }

  /* ------------------------------------------------------------------ *
   * 控件
   * ------------------------------------------------------------------ */
  function mount(root, params, api) {
    ensureStyle();
    params = params || {};
    api = api || {};

    var accent = (api.theme && api.theme.accent) || "#38bdf8";
    var motionOff = api.motion === false;

    /* ---------------- DOM ---------------- */
    var wrap = document.createElement("div");
    wrap.className = "psw-vr";
    wrap.tabIndex = 0;
    wrap.setAttribute("role", "region");
    wrap.setAttribute("aria-label",
      "360° 环视实验室：拖拽或方向键旋转视角，准星对准热点按空格查看说明");
    wrap.style.setProperty("--psw-accent", accent);
    wrap.innerHTML =
      '<canvas class="psw-vr-canvas" aria-hidden="true"></canvas>' +
      '<div class="psw-vr-title">' +
        '<div class="psw-vr-name"><i class="psw-vr-dot"></i><span class="psw-vr-scene"></span></div>' +
        '<div class="psw-vr-hint">拖拽环视 · 滚轮缩放 · 双击/靠近观察</div>' +
      '</div>' +
      '<canvas class="psw-vr-compass" aria-hidden="true"></canvas>' +
      '<button class="psw-vr-reset" type="button" aria-label="重置视角，快捷键 R">' +
        '<span class="psw-vr-reset-i">↺</span><span>重置视角</span>' +
      '</button>' +
      '<div class="psw-vr-zoom">' +
        '<button class="psw-vr-zbtn" type="button" data-z="in" aria-label="放大，快捷键 + 或滚轮">＋</button>' +
        '<button class="psw-vr-zbtn" type="button" data-z="out" aria-label="缩小，快捷键 − 或滚轮">−</button>' +
        '<button class="psw-vr-zbtn" type="button" data-z="near" aria-label="靠近观察：飞向最近的热点" style="font-size:11px">靠近</button>' +
      '</div>' +
      '<canvas class="psw-vr-map" aria-hidden="true"></canvas>' +
      '<div class="psw-vr-reticle" aria-hidden="true"><span class="psw-vr-reticle-d"></span></div>' +
      '<div class="psw-vr-keyhint" aria-hidden="true">按空格查看</div>' +
      '<div class="psw-vr-read" aria-hidden="true"></div>' +
      '<div class="psw-vr-card" role="dialog" aria-modal="false" aria-live="polite" ' +
        'aria-hidden="true" aria-label="热点说明">' +
        '<div class="psw-vr-card-top">' +
          '<span class="psw-vr-kind"></span>' +
          '<button class="psw-vr-x" type="button" aria-label="关闭说明">✕</button>' +
        '</div>' +
        '<div class="psw-vr-card-h"></div>' +
        '<div class="psw-vr-card-d"></div>' +
        '<div class="psw-vr-card-f">空格 或 Esc 关闭</div>' +
      '</div>';
    root.appendChild(wrap);

    var main = wrap.querySelector(".psw-vr-canvas");
    var compass = wrap.querySelector(".psw-vr-compass");
    var mapEl = wrap.querySelector(".psw-vr-map");
    var sceneLabel = wrap.querySelector(".psw-vr-scene");
    var resetBtn = wrap.querySelector(".psw-vr-reset");
    var reticle = wrap.querySelector(".psw-vr-reticle");
    var keyhint = wrap.querySelector(".psw-vr-keyhint");
    var readout = wrap.querySelector(".psw-vr-read");
    var card = wrap.querySelector(".psw-vr-card");
    var cardKind = wrap.querySelector(".psw-vr-kind");
    var cardTitle = wrap.querySelector(".psw-vr-card-h");
    var cardDesc = wrap.querySelector(".psw-vr-card-d");
    var closeBtn = wrap.querySelector(".psw-vr-x");

    var g2d = main.getContext("2d");
    var hudCtx = compass.getContext("2d");
    var mapCtx = mapEl.getContext("2d");

    /* ---------------- 状态 ---------------- */
    var W = 1, H = 1, CX = 0.5, CY = 0.5, FOCAL = 1, dpr = 1;
    var halfH = 54;                 // 水平半视场角（由宽高比决定）
    var CW = 200, CH = 26, MS = 92;
    var COSP = 1, SINP = 0;         // 相机 pitch 的三角函数
    var camYaw = 0, camPitch = 0;
    var zoomBtns = wrap.querySelectorAll(".psw-vr-zbtn");
    var flyTo = null;
    var velYaw = 0, velPitch = 0;
    var S = null, sceneKey = "";
    var hotspots = [];
    var focusedIndex = -1;
    var cardOpen = false;
    var running = true;
    var raf = 0, lastTs = 0;
    var vignette = null;

    var dragging = false, dragId = -1, dragX = 0, dragY = 0;
    var movedPx = 0, lastMoveT = 0;
    var keys = { l: 0, r: 0, u: 0, d: 0 };

    var glowCache = {};

    /* ---------------- 投影 ---------------- */
    // 输入：相对相机 yaw 的偏角 a（度）、世界 pitch（度）
    // 输出：_px/_py 屏幕坐标（CSS px）；返回 false 表示在近裁剪面之后
    var _px = 0, _py = 0;
    function projRel(aDeg, pDeg) {
      var a = aDeg * DEG, p = pDeg * DEG;
      var cp = Math.cos(p);
      var x1 = Math.sin(a) * cp;
      var y1 = Math.sin(p);
      var z1 = Math.cos(a) * cp;
      var y2 = y1 * COSP - z1 * SINP;
      var z2 = y1 * SINP + z1 * COSP;
      if (z2 < NEAR) return false;
      _px = CX + FOCAL * x1 / z2;
      _py = CY - FOCAL * y2 / z2;
      return true;
    }

    function projAbs(yawDeg, pitchDeg) {
      return projRel(wrap180(yawDeg - camYaw), pitchDeg);
    }

    // 地面点 (X,Z)（米，相机为原点）→ 屏幕
    function groundPoint(X, Z, eye) {
      var d = Math.sqrt(X * X + Z * Z);
      var yaw = Math.atan2(X, Z) / DEG;
      var pitch = -Math.atan2(eye, d) / DEG;
      return projRel(wrap180(yaw - camYaw), pitch);
    }

    function angDist(yawDeg, pitchDeg) {
      var cp = Math.cos(camPitch * DEG), sp = Math.sin(camPitch * DEG);
      var hp = Math.cos(pitchDeg * DEG), hq = Math.sin(pitchDeg * DEG);
      var d = sp * hq + cp * hp * Math.cos(wrap180(yawDeg - camYaw) * DEG);
      return Math.acos(clamp(d, -1, 1)) / DEG;
    }

    /* ---------------- 尺寸 ---------------- */
    function measure() {
      W = Math.max(1, Math.round(wrap.clientWidth || 1));
      H = Math.max(1, Math.round(wrap.clientHeight || 1));
      var rs = Math.min(1, 900 / Math.max(W, 1));
      dpr = clamp(window.devicePixelRatio || 1, 1, 2) * rs;

      main.width = Math.round(W * dpr);
      main.height = Math.round(H * dpr);
      main.style.width = W + "px";
      main.style.height = H + "px";
      g2d.setTransform(dpr, 0, 0, dpr, 0, 0);

      CX = W / 2;
      CY = H / 2;
      FOCAL = (H / 2) / Math.tan(FOV * DEG / 2);
      halfH = Math.atan((W / 2) / FOCAL) / DEG;

      var narrow = W < 560;
      wrap.classList.toggle("is-narrow", narrow);
      CW = Math.round(clamp(narrow ? W * 0.54 : W * 0.44, 132, 340));
      CH = narrow ? 22 : 26;
      compass.style.width = CW + "px";
      compass.style.height = CH + "px";
      compass.width = Math.round(CW * dpr);
      compass.height = Math.round(CH * dpr);
      hudCtx.setTransform(dpr, 0, 0, dpr, 0, 0);

      MS = narrow ? 74 : 92;
      mapEl.style.width = MS + "px";
      mapEl.style.height = MS + "px";
      mapEl.width = Math.round(MS * dpr);
      mapEl.height = Math.round(MS * dpr);
      mapCtx.setTransform(dpr, 0, 0, dpr, 0, 0);

      vignette = g2d.createRadialGradient(CX, CY, Math.min(W, H) * 0.16,
        CX, CY, Math.max(W, H) * 0.76);
      vignette.addColorStop(0, "rgba(2,6,14,0)");
      vignette.addColorStop(0.62, "rgba(2,6,14,0.20)");
      vignette.addColorStop(1, "rgba(2,6,14,0.62)");
    }

    /* ---------------- 场景 / 热点 ---------------- */
    function normalizeObjects(list) {
      var out = [], i, o, yaw, pitch;
      if (!list || !list.length) return out;
      for (i = 0; i < list.length; i++) {
        o = list[i];
        if (!o) continue;
        yaw = Number(o.yaw);
        pitch = Number(o.pitch);
        if (!isFinite(yaw) || !isFinite(pitch)) continue;
        out.push({
          yaw: wrap180(yaw),
          pitch: clamp(pitch, -85, 85),
          label: o.label == null ? "热点" : String(o.label),
          desc: o.desc == null ? "" : String(o.desc),
          kind: o.kind == null ? "mark" : String(o.kind),
          _x: -999, _y: -999, _ok: false, _f: false, _d: 180
        });
      }
      return out;
    }

    function loadScene(key) {
      sceneKey = BUILDERS[key] ? key : "mechanics";
      S = getScene(sceneKey);
      sceneLabel.textContent = S.name;
      var custom = params.objects;
      hotspots = normalizeObjects(custom && custom.length ? custom : S.objects);
      focusedIndex = -1;
      closeCard();
      resetView();
    }

    function setFov(v) { TARGET_FOV = clamp(v, 32, 92); }

    function resetView() {
      TARGET_FOV = 75;
      camYaw = wrap180(S.startYaw || 0);
      camPitch = clamp(S.startPitch || 0, PITCH_MIN, PITCH_MAX);
      velYaw = 0;
      velPitch = 0;
    }

    /* ---------------- 发光精灵（离屏缓存） ---------------- */
    function glowSprite(color) {
      if (glowCache[color]) return glowCache[color];
      var c = document.createElement("canvas");
      c.width = 64;
      c.height = 64;
      var g = c.getContext("2d");
      var grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
      grd.addColorStop(0, withAlpha(color, 0.9));
      grd.addColorStop(0.32, withAlpha(color, 0.34));
      grd.addColorStop(0.65, withAlpha(color, 0.09));
      grd.addColorStop(1, withAlpha(color, 0));
      g.fillStyle = grd;
      g.fillRect(0, 0, 64, 64);
      glowCache[color] = c;
      return c;
    }

    function drawSprite(color, x, y, size, alpha) {
      if (!(size > 0) || !(alpha > 0)) return;
      var img = glowSprite(color);
      var a0 = g2d.globalAlpha;
      g2d.globalAlpha = alpha;
      g2d.globalCompositeOperation = "lighter";
      g2d.drawImage(img, x - size / 2, y - size / 2, size, size);
      g2d.globalCompositeOperation = "source-over";
      g2d.globalAlpha = a0;
    }

    /* ---------------- 天空 / 地面 ---------------- */
    function drawSky(horizon) {
      var hgt = clamp(horizon + 1, 0, H);
      if (hgt <= 0) return;
      // 按仰角映射渐变：抬头 / 低头时天空层次保持一致
      var top = horizon - FOCAL * Math.tan(72 * DEG);
      var span = Math.max(1, horizon - top);
      var g = g2d.createLinearGradient(0, top, 0, horizon);
      var stops = [
        [72, S.sky[0]],
        [38, mixHex(S.sky[1], S.sky[0], 0.70)],
        [20, mixHex(S.sky[1], S.sky[0], 0.16)],
        [9, mixHex(S.sky[2], S.sky[1], 0.55)],
        [0, S.sky[2]]
      ];
      for (var i = 0; i < stops.length; i++) {
        var y = horizon - FOCAL * Math.tan(stops[i][0] * DEG);
        g.addColorStop(clamp((y - top) / span, 0, 1), stops[i][1]);
      }
      g2d.fillStyle = g;
      g2d.fillRect(0, 0, W, hgt);
    }

    function drawFloor(horizon) {
      if (horizon >= H - 1) return;
      var y0 = Math.max(0, horizon);
      var g = g2d.createLinearGradient(0, horizon, 0, horizon + Math.max(1, H - horizon));
      g.addColorStop(0, S.ground[0]);
      g.addColorStop(1, S.ground[1]);
      g2d.fillStyle = g;
      g2d.fillRect(0, y0, W, H - y0);

      // 透视地面网格：地面点按 atan 反算 pitch，线条自然符合 tan 投影
      var gr = S.grid, eye = S.eye || 1.6;
      var lg = g2d.createLinearGradient(0, horizon, 0, horizon + Math.max(48, H * 0.82));
      lg.addColorStop(0, withAlpha(gr.color, 0));
      lg.addColorStop(0.16, withAlpha(gr.color, gr.alpha * 0.38));
      lg.addColorStop(1, withAlpha(gr.color, gr.alpha));
      g2d.strokeStyle = lg;
      g2d.lineWidth = 1;

      var k, i, X, Z, pen;
      for (k = -gr.xmax; k <= gr.xmax; k++) {
        X = k * gr.step;
        g2d.beginPath();
        pen = false;
        for (i = 0; i <= 9; i++) {
          Z = 0.7 * Math.pow(gr.zmax / 0.7, i / 9);
          if (!groundPoint(X, Z, eye)) { pen = false; continue; }
          if (pen) g2d.lineTo(_px, _py); else { g2d.moveTo(_px, _py); pen = true; }
        }
        g2d.stroke();
      }
      for (k = 1; k <= Math.round(gr.zmax / gr.step); k++) {
        Z = k * gr.step;
        g2d.beginPath();
        pen = false;
        for (i = -gr.xmax; i <= gr.xmax; i += 2) {
          X = i * gr.step;
          if (!groundPoint(X, Z, eye)) { pen = false; continue; }
          if (pen) g2d.lineTo(_px, _py); else { g2d.moveTo(_px, _py); pen = true; }
        }
        g2d.stroke();
      }

      // 地面环（跑道 / 场域圆环）
      if (S.rings) {
        for (k = 0; k < S.rings.length; k++) {
          var ring = S.rings[k];
          g2d.beginPath();
          pen = false;
          for (i = 0; i <= 72; i++) {
            var ang = (i / 72) * TAU;
            if (!groundPoint(Math.cos(ang) * ring.r, Math.sin(ang) * ring.r, eye)) {
              pen = false;
              continue;
            }
            if (pen) g2d.lineTo(_px, _py); else { g2d.moveTo(_px, _py); pen = true; }
          }
          g2d.strokeStyle = ring.color;
          g2d.lineWidth = ring.w || 2;
          g2d.stroke();
        }
      }
    }

    /* ---------------- 全景（墙 / 山 / 围栏） ---------------- */
    function drawBand(b) {
      var span = b.y1 - b.y0;
      if (span <= 0) return;
      var n = b.n || Math.max(1, Math.ceil(span / 8));
      var step = span / n;
      var lim = halfH + step + 6;
      var s, shift, rel0, j0, j1, j, a0, a1;
      var x0, y0, x1, y1, x2, y2, x3, y3, any = false;

      g2d.beginPath();
      for (s = 0; s < 3; s++) {
        shift = s === 1 ? 360 : (s === 2 ? -360 : 0);
        rel0 = wrap180(b.y0 - camYaw) + shift;
        j0 = Math.floor((-lim - rel0) / step);
        j1 = Math.ceil((lim - rel0) / step);
        if (j0 < 0) j0 = 0;
        if (j1 > n) j1 = n;
        for (j = j0; j < j1; j++) {
          a0 = rel0 + j * step;
          a1 = a0 + step + 0.25;
          if (!projRel(a0, b.top)) continue;
          x0 = _px; y0 = _py;
          if (!projRel(a1, b.top)) continue;
          x1 = _px; y1 = _py;
          if (!projRel(a1, b.bottom)) continue;
          x2 = _px; y2 = _py;
          if (!projRel(a0, b.bottom)) continue;
          x3 = _px; y3 = _py;
          g2d.moveTo(x0, y0);
          g2d.lineTo(x1, y1);
          g2d.lineTo(x2, y2);
          g2d.lineTo(x3, y3);
          g2d.closePath();
          any = true;
        }
      }
      if (any) {
        g2d.fillStyle = b.color;
        g2d.fill();
      }
    }

    function drawBands() {
      var i;
      for (i = 0; i < S.bands.length; i++) drawBand(S.bands[i]);
    }

    /* ---------------- 道具 ---------------- */
    function quad(a0, a1, pTop, pBot) {
      var x0, y0, x1, y1, x2, y2, x3, y3;
      if (!projRel(a0, pTop)) return false;
      x0 = _px; y0 = _py;
      if (!projRel(a1, pTop)) return false;
      x1 = _px; y1 = _py;
      if (!projRel(a1, pBot)) return false;
      x2 = _px; y2 = _py;
      if (!projRel(a0, pBot)) return false;
      x3 = _px; y3 = _py;
      g2d.moveTo(x0, y0);
      g2d.lineTo(x1, y1);
      g2d.lineTo(x2, y2);
      g2d.lineTo(x3, y3);
      g2d.closePath();
      return true;
    }

    function drawPanel(p) {
      var span = p.y1 - p.y0;
      if (span <= 0) return;
      var n = Math.max(1, Math.ceil(span / 6));
      var step = span / n;
      var rel0 = wrap180(p.y0 - camYaw);
      var i, a0, yTop = 0, yBot = 0;
      var grad = null;

      if (p.c1) {
        var mid = (p.y0 + p.y1) / 2;
        if (projAbs(mid, p.top)) {
          yTop = _py;
          if (projAbs(mid, p.bottom)) {
            yBot = _py;
            if (Math.abs(yBot - yTop) > 1) {
              grad = g2d.createLinearGradient(0, yTop, 0, yBot);
              grad.addColorStop(0, p.c1);
              grad.addColorStop(1, p.c2);
            }
          }
        }
      }

      g2d.beginPath();
      var any = false;
      for (i = 0; i < n; i++) {
        a0 = rel0 + i * step;
        if (quad(a0, a0 + step + 0.25, p.top, p.bottom)) any = true;
      }
      if (!any) return;
      g2d.fillStyle = grad || p.fill || p.c2 || p.c1 || "#334155";
      g2d.fill();
      if (p.stroke) {
        g2d.strokeStyle = p.stroke;
        g2d.lineWidth = p.lw || 1;
        g2d.stroke();
      }
    }

    function drawPoly(p) {
      var pts = p.pts, i, first = true, any = false;
      g2d.beginPath();
      for (i = 0; i < pts.length; i++) {
        if (!projAbs(pts[i][0], pts[i][1])) { first = true; continue; }
        if (first) { g2d.moveTo(_px, _py); first = false; } else { g2d.lineTo(_px, _py); }
        any = true;
      }
      if (!any) return;
      g2d.closePath();
      if (p.fill) {
        g2d.fillStyle = p.fill;
        g2d.fill();
      }
      if (p.stroke) {
        g2d.strokeStyle = p.stroke;
        g2d.lineWidth = p.lw || 1;
        g2d.stroke();
      }
    }

    function drawLineProp(p) {
      var pts = p.pts, i, pen = false, any = false;
      g2d.beginPath();
      for (i = 0; i < pts.length; i++) {
        if (!projAbs(pts[i][0], pts[i][1])) { pen = false; continue; }
        if (pen) g2d.lineTo(_px, _py); else { g2d.moveTo(_px, _py); pen = true; }
        any = true;
      }
      if (!any) return;
      if (p.dash) g2d.setLineDash(p.dash);
      if (p.glow) {
        g2d.globalAlpha = 0.16;
        g2d.lineWidth = (p.lw || 1) * 5;
        g2d.strokeStyle = p.color;
        g2d.stroke();
        g2d.globalAlpha = 1;
      }
      g2d.lineWidth = p.lw || 1;
      g2d.strokeStyle = p.color;
      g2d.stroke();
      if (p.dash) g2d.setLineDash([]);
    }

    function drawDisc(p) {
      if (!projAbs(p.yaw, p.pitch)) return;
      var x = _px, y = _py;
      var rx = FOCAL * Math.tan((p.rx || p.r || 0.5) * DEG);
      var ry = FOCAL * Math.tan((p.ry || p.rx || p.r || 0.5) * DEG);
      if (!(rx > 0.2) || !(ry > 0.2)) return;
      g2d.beginPath();
      if (g2d.ellipse) g2d.ellipse(x, y, rx, ry, 0, 0, TAU);
      else g2d.arc(x, y, Math.max(rx, ry), 0, TAU);
      if (p.fill) {
        g2d.fillStyle = p.fill;
        g2d.fill();
      }
      if (p.stroke) {
        g2d.lineWidth = p.lw || 1.5;
        g2d.strokeStyle = p.stroke;
        g2d.stroke();
      }
    }

    function drawTextProp(p) {
      if (!projAbs(p.yaw, p.pitch)) return;
      g2d.font = (p.bold ? "700 " : "500 ") + (p.size || 11) + "px " + FONT;
      g2d.fillStyle = p.color || "#e2e8f0";
      g2d.textAlign = "center";
      g2d.textBaseline = "middle";
      g2d.fillText(p.text, _px, _py);
    }

    function drawPulse(p, ts) {
      var n = p.pts.length;
      if (n < 2) return;
      var base = ts * 0.001 * (p.speed || 0.12) + (p.off || 0);
      for (var d = 0; d < p.n; d++) {
        var u = (base + d / p.n) % 1;
        var f = u * (n - 1);
        var i0 = Math.floor(f), fr = f - i0, i1 = Math.min(n - 1, i0 + 1);
        var yaw = p.pts[i0][0] + (p.pts[i1][0] - p.pts[i0][0]) * fr;
        var pit = p.pts[i0][1] + (p.pts[i1][1] - p.pts[i0][1]) * fr;
        if (!projAbs(yaw, pit)) continue;
        drawSprite(p.color, _px, _py, 13, 0.8);
        g2d.beginPath();
        g2d.arc(_px, _py, 1.5, 0, TAU);
        g2d.fillStyle = "#e6feff";
        g2d.fill();
      }
    }

    function drawStars(ts) {
      var i, o, x, y, r, pulse;
      for (i = 0; i < S.stars.length; i++) {
        o = S.stars[i];
        if (!projAbs(o.yaw, o.pitch)) continue;
        x = _px; y = _py;
        if (x < -20 || x > W + 20 || y < -20 || y > H + 20) continue;
        r = clamp(FOCAL * Math.tan(o.r * DEG), 0.8, 2.2);
        pulse = motionOff ? 0.6 : 0.62 + 0.38 * Math.sin(ts * 0.0016 + i);
        g2d.globalAlpha = o.a * pulse;
        g2d.beginPath();
        g2d.arc(x, y, r, 0, TAU);
        g2d.fillStyle = "#dff6ff";
        g2d.fill();
        g2d.globalAlpha = 1;
      }
    }

    function drawProps(ts) {
      var i, p;
      for (i = 0; i < S.props.length; i++) {
        p = S.props[i];
        switch (p.k) {
          case "panel": drawPanel(p); break;
          case "poly": drawPoly(p); break;
          case "line": drawLineProp(p); break;
          case "disc": drawDisc(p); break;
          case "glow":
            if (projAbs(p.yaw, p.pitch)) {
              drawSprite(p.color, _px, _py, FOCAL * Math.tan((p.r || 8) * DEG) * 2,
                p.a == null ? 0.7 : p.a);
            }
            break;
          case "text": drawTextProp(p); break;
          case "pulse": drawPulse(p, motionOff ? 0 : ts); break;
          default: break;
        }
      }
    }

    /* ---------------- 热点 ---------------- */
    function drawHotspots(ts) {
      var i, o, d, f, color, rr, x, y, lw, label, ly, pad;
      var pulse = motionOff ? 0.5 : 0.5 + 0.5 * Math.sin(ts * 0.0035);
      var best = -1, bestD = 1e9;

      for (i = 0; i < hotspots.length; i++) {
        o = hotspots[i];
        o._ok = false;
        if (!projAbs(o.yaw, o.pitch)) continue;
        o._x = _px;
        o._y = _py;
        if (o._x < -80 || o._x > W + 80 || o._y < -80 || o._y > H + 80) continue;
        o._ok = true;
        o._d = d = angDist(o.yaw, o.pitch);
        if (d < bestD) { bestD = d; best = i; }
      }

      focusedIndex = bestD <= FOCUS ? best : -1;

      for (i = 0; i < hotspots.length; i++) {
        o = hotspots[i];
        if (!o._ok) continue;
        f = o._d <= FOCUS;
        o._f = f;
        color = KIND_COLOR[o.kind] || accent;
        x = o._x;
        y = o._y;
        rr = (f ? 1.5 : 1) * (11 + pulse * 3);

        drawSprite(color, x, y, rr * 5.2, f ? 0.85 : 0.55);

        g2d.beginPath();
        g2d.arc(x, y, f ? 8.5 : 6, 0, TAU);
        g2d.fillStyle = "rgba(11,18,32,0.88)";
        g2d.fill();
        g2d.lineWidth = f ? 2.4 : 1.8;
        g2d.strokeStyle = color;
        g2d.stroke();

        g2d.beginPath();
        g2d.arc(x, y, f ? 3.4 : 2.3, 0, TAU);
        g2d.fillStyle = color;
        g2d.fill();

        // 标签
        label = o.label;
        g2d.font = f ? "600 13px " + FONT : "500 11.5px " + FONT;
        lw = g2d.measureText(label).width;
        pad = f ? 8 : 6;
        ly = y + (f ? 14 : 11);
        var bx = x - lw / 2 - pad, bw = lw + pad * 2, bh = f ? 20 : 18;
        var br = bh / 2, bxx = bx + bw, byh = ly + bh;
        g2d.beginPath();
        g2d.moveTo(bx + br, ly);
        g2d.arcTo(bxx, ly, bxx, byh, br);
        g2d.arcTo(bxx, byh, bx, byh, br);
        g2d.arcTo(bx, byh, bx, ly, br);
        g2d.arcTo(bx, ly, bxx, ly, br);
        g2d.closePath();
        g2d.fillStyle = f ? "rgba(11,18,32,0.82)" : "rgba(11,18,32,0.62)";
        g2d.fill();
        if (f) {
          g2d.lineWidth = 1;
          g2d.strokeStyle = withAlpha(color, 0.55);
          g2d.stroke();
        }
        g2d.fillStyle = f ? "#ffffff" : "#dbe4f0";
        g2d.textAlign = "center";
        g2d.textBaseline = "middle";
        g2d.fillText(label, x, ly + bh / 2 + 0.5);
      }
    }

    /* ---------------- HUD ---------------- */
    function drawCompass() {
      var w = CW, h = CH, mid = w / 2, span = 58;
      hudCtx.clearRect(0, 0, w, h);
      hudCtx.textAlign = "center";
      hudCtx.textBaseline = "middle";

      for (var hdg = -180; hdg < 180; hdg += 15) {
        var rel = wrap180(hdg - camYaw);
        if (Math.abs(rel) > span) continue;
        var x = mid + (rel / span) * (w / 2 - 8);
        var major = hdg % 90 === 0;
        var half = hdg % 45 === 0;
        hudCtx.globalAlpha = clamp(1 - Math.abs(rel) / span * 0.82, 0.14, 1);
        hudCtx.strokeStyle = major ? accent : "#94a3b8";
        hudCtx.lineWidth = major ? 1.6 : 1;
        var th = major ? 8 : (half ? 6 : 4);
        hudCtx.beginPath();
        hudCtx.moveTo(x, h - 3);
        hudCtx.lineTo(x, h - 3 - th);
        hudCtx.stroke();
        if (major) {
          var names = { "-180": "S", "-90": "W", "0": "N", "90": "E" };
          hudCtx.fillStyle = hdg === 0 ? accent : "#cbd5e1";
          hudCtx.font = "700 11px " + FONT;
          hudCtx.fillText(names[String(hdg)] || "", x, 7.5);
        }
      }
      hudCtx.globalAlpha = 1;

      // 中央指针
      hudCtx.beginPath();
      hudCtx.moveTo(mid, h - 0.5);
      hudCtx.lineTo(mid - 4.5, h - 8);
      hudCtx.lineTo(mid + 4.5, h - 8);
      hudCtx.closePath();
      hudCtx.fillStyle = accent;
      hudCtx.fill();
    }

    function drawMinimap() {
      var s = MS, mid = s / 2, R = s / 2 - 3;
      var i, o, x, y;

      mapCtx.clearRect(0, 0, s, s);
      mapCtx.beginPath();
      mapCtx.arc(mid, mid, R, 0, TAU);
      mapCtx.fillStyle = "rgba(8,14,26,0.74)";
      mapCtx.fill();
      mapCtx.lineWidth = 1;
      mapCtx.strokeStyle = "rgba(148,163,184,0.30)";
      mapCtx.stroke();

      mapCtx.beginPath();
      mapCtx.arc(mid, mid, R * 0.8, 0, TAU);
      mapCtx.strokeStyle = "rgba(148,163,184,0.12)";
      mapCtx.stroke();

      // 视野扇形（yaw → canvas 角度：-90°）
      var a0 = (camYaw - halfH - 90) * DEG;
      var a1 = (camYaw + halfH - 90) * DEG;
      mapCtx.beginPath();
      mapCtx.moveTo(mid, mid);
      mapCtx.arc(mid, mid, R - 1, a0, a1);
      mapCtx.closePath();
      mapCtx.fillStyle = withAlpha(accent, 0.16);
      mapCtx.fill();
      mapCtx.lineWidth = 1;
      mapCtx.strokeStyle = withAlpha(accent, 0.45);
      mapCtx.stroke();

      // 热点方位
      for (i = 0; i < hotspots.length; i++) {
        o = hotspots[i];
        x = mid + Math.sin(o.yaw * DEG) * R * 0.8;
        y = mid - Math.cos(o.yaw * DEG) * R * 0.8;
        mapCtx.beginPath();
        mapCtx.arc(x, y, o._f ? 3.4 : 2.3, 0, TAU);
        mapCtx.fillStyle = KIND_COLOR[o.kind] || accent;
        mapCtx.fill();
        if (o._f) {
          mapCtx.beginPath();
          mapCtx.arc(x, y, 5.6, 0, TAU);
          mapCtx.strokeStyle = withAlpha(KIND_COLOR[o.kind] || accent, 0.6);
          mapCtx.lineWidth = 1;
          mapCtx.stroke();
        }
      }

      // 相机朝向
      var hx = Math.sin(camYaw * DEG), hy = -Math.cos(camYaw * DEG);
      mapCtx.beginPath();
      mapCtx.moveTo(mid + hx * 9, mid + hy * 9);
      mapCtx.lineTo(mid + hy * 3.4, mid - hx * 3.4);
      mapCtx.lineTo(mid - hy * 3.4, mid + hx * 3.4);
      mapCtx.closePath();
      mapCtx.fillStyle = accent;
      mapCtx.fill();

      mapCtx.beginPath();
      mapCtx.arc(mid, mid, 1.6, 0, TAU);
      mapCtx.fillStyle = "#e2e8f0";
      mapCtx.fill();

      mapCtx.font = "700 9px " + FONT;
      mapCtx.textAlign = "center";
      mapCtx.textBaseline = "middle";
      mapCtx.fillStyle = "rgba(148,163,184,0.9)";
      mapCtx.fillText("N", mid, 9);
    }

    var lastRead = "";
    function updateReadout() {
      var head = Math.round((camYaw + 360) % 360) % 360;
      var pit = Math.round(camPitch);
      var sign = pit < 0 ? "−" : "+";
      var ap = Math.abs(pit);
      var txt = "方位 " + (head < 10 ? "00" : head < 100 ? "0" : "") + head + "°" +
        " · 俯仰 " + sign + (ap < 10 ? "0" : "") + ap + "°" +
        " · FOV " + Math.round(FOV) + "°";
      if (txt !== lastRead) {
        lastRead = txt;
        readout.textContent = txt;
      }
    }

    var lastHot = false, lastHint = false;
    function updateHintDom() {
      var hot = focusedIndex >= 0 && !cardOpen;
      if (hot !== lastHot) {
        lastHot = hot;
        if (hot) reticle.classList.add("is-hot");
        else reticle.classList.remove("is-hot");
      }
      if (hot !== lastHint) {
        lastHint = hot;
        if (hot) keyhint.classList.add("is-on");
        else keyhint.classList.remove("is-on");
      }
    }

    /* ---------------- 渲染主循环 ---------------- */
    function render(ts) {
      if (W < 2 || H < 2) return;
      if (Math.abs(TARGET_FOV - FOV) > 0.05) {
        FOV += (TARGET_FOV - FOV) * 0.55;
        FOCAL = (H / 2) / Math.tan(FOV * DEG / 2);
        halfH = Math.atan((W / 2) / FOCAL) / DEG;
      } else if (FOV !== TARGET_FOV) {
        FOV = TARGET_FOV;
        FOCAL = (H / 2) / Math.tan(FOV * DEG / 2);
        halfH = Math.atan((W / 2) / FOCAL) / DEG;
      }
      if (flyTo) {
        var dy = wrap180(flyTo.yaw - camYaw);
        camYaw = wrap180(camYaw + dy * 0.45);
        camPitch += (flyTo.pitch - camPitch) * 0.45;
        setFov(flyTo.fov);
        if (Math.abs(dy) < 0.3 && Math.abs(flyTo.pitch - camPitch) < 0.3) flyTo = null;
      }
      COSP = Math.cos(camPitch * DEG);
      SINP = Math.sin(camPitch * DEG);
      var horizon = CY + FOCAL * Math.tan(camPitch * DEG);

      g2d.setTransform(dpr, 0, 0, dpr, 0, 0);
      g2d.clearRect(0, 0, W, H);

      drawSky(horizon);
      drawFloor(horizon);
      drawBands();

      if (S.haze) {
        var hz = g2d.createLinearGradient(0, horizon - H * 0.14, 0, horizon + H * 0.12);
        hz.addColorStop(0, withAlpha(S.haze, 0));
        hz.addColorStop(0.5, withAlpha(S.haze, S.hazeA == null ? 0.16 : S.hazeA));
        hz.addColorStop(1, withAlpha(S.haze, 0));
        g2d.fillStyle = hz;
        g2d.fillRect(0, horizon - H * 0.14, W, H * 0.26);
      }

      if (S.stars) drawStars(ts);
      drawProps(ts);
      drawHotspots(ts);

      if (vignette) {
        g2d.globalAlpha = S.vignette == null ? 0.5 : S.vignette;
        g2d.fillStyle = vignette;
        g2d.fillRect(0, 0, W, H);
        g2d.globalAlpha = 1;
      }

      drawCompass();
      drawMinimap();
      updateReadout();
      updateHintDom();
    }

    /* ---------------- 运动 ---------------- */
    function update(dt) {
      var spd = 1.15 * dt;
      var keyed = false;
      if (keys.l) { camYaw = wrap180(camYaw - spd); keyed = true; }
      if (keys.r) { camYaw = wrap180(camYaw + spd); keyed = true; }
      if (keys.u) { camPitch = clamp(camPitch + spd * 0.8, PITCH_MIN, PITCH_MAX); keyed = true; }
      if (keys.d) { camPitch = clamp(camPitch - spd * 0.8, PITCH_MIN, PITCH_MAX); keyed = true; }
      if (keyed) { velYaw = 0; velPitch = 0; return; }

      if (dragging || motionOff) return;
      if (Math.abs(velYaw) > 0.02 || Math.abs(velPitch) > 0.02) {
        camYaw = wrap180(camYaw + velYaw * dt);
        camPitch = clamp(camPitch + velPitch * dt, PITCH_MIN, PITCH_MAX);
        var damp = Math.pow(0.90, dt);
        velYaw *= damp;
        velPitch *= damp;
      } else {
        velYaw = 0;
        velPitch = 0;
      }
    }

    var sizeTick = 0;
    function frame(ts) {
      if (!running) return;
      raf = requestAnimationFrame(frame);
      var dt = lastTs ? clamp((ts - lastTs) / 16.667, 0.1, 3) : 1;
      lastTs = ts;

      // 兜底巡检：个别宿主/隐藏标签页下 ResizeObserver 回调可能被节流
      if (++sizeTick >= 18) {
        sizeTick = 0;
        var cw = Math.round(wrap.clientWidth || 1);
        var ch = Math.round(wrap.clientHeight || 1);
        var dd = clamp(window.devicePixelRatio || 1, 1, 2);
        if (cw !== W || ch !== H || Math.abs(dd - dpr) > 0.01) measure();
      }

      update(dt);
      render(ts);
    }

    /* ---------------- 卡片 ---------------- */
    function openCard(i) {
      var o = hotspots[i];
      if (!o) return;
      cardOpen = true;
      cardKind.textContent = KIND_BADGE[o.kind] || "场景热点";
      cardTitle.textContent = o.label;
      cardDesc.textContent = o.desc || "（暂无说明）";
      card.classList.add("is-on");
      card.setAttribute("aria-hidden", "false");
      if (typeof api.speak === "function") {
        try { api.speak(o.desc ? o.desc : o.label); } catch (err) { /* 朗读失败不影响交互 */ }
      }
    }

    function closeCard() {
      if (!cardOpen) return;
      cardOpen = false;
      card.classList.remove("is-on");
      card.setAttribute("aria-hidden", "true");
    }

    function openFocused() {
      if (focusedIndex >= 0) openCard(focusedIndex);
    }

    /* ---------------- 交互 ---------------- */
    function hitTest(clientX, clientY) {
      var r = main.getBoundingClientRect();
      var x = clientX - r.left, y = clientY - r.top;
      var best = -1, bestD = 26 * 26, i, o, dx, dy, d2;
      for (i = 0; i < hotspots.length; i++) {
        o = hotspots[i];
        if (!o._ok) continue;
        dx = o._x - x;
        dy = o._y - y;
        d2 = dx * dx + dy * dy;
        if (d2 < bestD) { bestD = d2; best = i; }
      }
      return best;
    }

    function onPointerDown(e) {
      if (e.pointerType === "mouse" && e.button !== 0) return;
      if (cardOpen) closeCard();
      try { wrap.focus({ preventScroll: true }); } catch (err) { wrap.focus(); }
      dragging = true;
      dragId = e.pointerId;
      dragX = e.clientX;
      dragY = e.clientY;
      movedPx = 0;
      lastMoveT = performance.now();
      velYaw = 0;
      velPitch = 0;
      main.style.cursor = "grabbing";
      if (main.setPointerCapture) {
        try { main.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      }
      e.preventDefault();
    }

    function onPointerMove(e) {
      if (!dragging || e.pointerId !== dragId) {
        if (!dragging) {
          var hi = hitTest(e.clientX, e.clientY);
          main.style.cursor = hi >= 0 ? "pointer" : "grab";
        }
        return;
      }
      var now = performance.now();
      var dtm = Math.max(8, now - lastMoveT);
      lastMoveT = now;
      var dx = e.clientX - dragX;
      var dy = e.clientY - dragY;
      dragX = e.clientX;
      dragY = e.clientY;
      movedPx += Math.abs(dx) + Math.abs(dy);

      var k = 0.14;
      camYaw = wrap180(camYaw - dx * k);
      camPitch = clamp(camPitch + dy * k, PITCH_MIN, PITCH_MAX);

      if (!motionOff) {
        var f = 16.667 / dtm;
        velYaw = clamp(velYaw * 0.55 + (-dx * k * f) * 0.45, -14, 14);
        velPitch = clamp(velPitch * 0.55 + (dy * k * f) * 0.45, -14, 14);
      }
      e.preventDefault();
    }

    function onPointerUp(e) {
      if (!dragging || e.pointerId !== dragId) return;
      dragging = false;
      dragId = -1;
      main.style.cursor = "grab";
      if (performance.now() - lastMoveT > 90) { velYaw = 0; velPitch = 0; }
      if (motionOff) { velYaw = 0; velPitch = 0; }
      if (movedPx < 6) {
        var hit = hitTest(e.clientX, e.clientY);
        if (hit >= 0) {
          openCard(hit);
          velYaw = 0;
          velPitch = 0;
        }
      }
      if (main.releasePointerCapture) {
        try { main.releasePointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      }
      e.preventDefault();
    }

    function onKeyDown(e) {
      if (e.key === "+" || e.key === "=") { e.preventDefault(); setFov(TARGET_FOV * 0.85); return; }
      if (e.key === "-" || e.key === "_") { e.preventDefault(); setFov(TARGET_FOV * 1.18); return; }
      if (e.key === "0") { e.preventDefault(); setFov(75); return; }
      var k = e.key;
      if (k === "ArrowLeft" || k === "a" || k === "A") { keys.l = 1; e.preventDefault(); e.stopPropagation(); }
      else if (k === "ArrowRight" || k === "d" || k === "D") { keys.r = 1; e.preventDefault(); e.stopPropagation(); }
      else if (k === "ArrowUp" || k === "w" || k === "W") { keys.u = 1; e.preventDefault(); e.stopPropagation(); }
      else if (k === "ArrowDown" || k === "s" || k === "S") { keys.d = 1; e.preventDefault(); e.stopPropagation(); }
      else if (k === " " || k === "Spacebar") {
        if (e.target && e.target.tagName === "BUTTON") return;
        e.preventDefault();
        e.stopPropagation();
        if (cardOpen) closeCard();
        else openFocused();
      } else if (k === "Escape" || k === "Esc") {
        if (cardOpen) { closeCard(); e.preventDefault(); }
      } else if (k === "r" || k === "R") {
        resetView();
        e.preventDefault();
        e.stopPropagation();
      }
    }

    function onKeyUp(e) {
      var k = e.key;
      if (k === "ArrowLeft" || k === "a" || k === "A") keys.l = 0;
      else if (k === "ArrowRight" || k === "d" || k === "D") keys.r = 0;
      else if (k === "ArrowUp" || k === "w" || k === "W") keys.u = 0;
      else if (k === "ArrowDown" || k === "s" || k === "S") keys.d = 0;
    }

    function onBlur() {
      keys.l = keys.r = keys.u = keys.d = 0;
    }

    main.addEventListener("pointerdown", onPointerDown);
    main.addEventListener("pointermove", onPointerMove);
    main.addEventListener("pointerup", onPointerUp);
    main.addEventListener("pointercancel", onPointerUp);
    wrap.addEventListener("keydown", onKeyDown);
    wrap.addEventListener("keyup", onKeyUp);
    wrap.addEventListener("blur", onBlur);
    resetBtn.addEventListener("click", resetView);
    function onWheel(e) {
      e.preventDefault();
      setFov(TARGET_FOV + e.deltaY * 0.03);
    }
    main.addEventListener("wheel", onWheel, { passive: false });
    zoomBtns.forEach(function (b) {
      b.addEventListener("click", function (e) {
        e.stopPropagation();
        var act = b.getAttribute("data-z");
        if (act === "near") {
          var best = -1, bestD = 999;
          for (var i = 0; i < hotspots.length; i++) {
            var d = angDist(hotspots[i].yaw, hotspots[i].pitch);
            if (d < bestD) { bestD = d; best = i; }
          }
          if (best >= 0) {
            flyTo = { yaw: hotspots[best].yaw, pitch: hotspots[best].pitch, fov: 44 };
            FOV = Math.min(FOV, 58);
          } else { TARGET_FOV = 44; FOV = Math.min(FOV, 58); }
          return;
        }
        setFov(act === "in" ? TARGET_FOV * 0.84 : TARGET_FOV * 1.19);
      });
    });
    main.addEventListener("dblclick", function (e) {
      if (cardOpen) return;
      if (focusedIndex >= 0 && hotspots[focusedIndex]) {
        var hp = hotspots[focusedIndex];
        flyTo = { yaw: hp.yaw, pitch: hp.pitch, fov: 46 };
      } else {
        setFov(Math.max(32, TARGET_FOV * 0.8));
      }
    });
    closeBtn.addEventListener("click", closeCard);

    /* ---------------- 观察器 ---------------- */
    var ro = null;
    if (typeof ResizeObserver !== "undefined") {
      ro = new ResizeObserver(function () { measure(); });
      ro.observe(wrap);
    }
    function onWinResize() { measure(); }
    window.addEventListener("resize", onWinResize);
    window.addEventListener("orientationchange", onWinResize);

    /* ---------------- 启动 ---------------- */
    loadScene(params.scene || "mechanics");
    measure();
    raf = requestAnimationFrame(frame);

    /* ---------------- 对外接口 ---------------- */
    function destroy() {
      running = false;
      if (raf) { cancelAnimationFrame(raf); raf = 0; }
      if (ro) { ro.disconnect(); ro = null; }
      window.removeEventListener("resize", onWinResize);
      window.removeEventListener("orientationchange", onWinResize);
      main.removeEventListener("pointerdown", onPointerDown);
      main.removeEventListener("pointermove", onPointerMove);
      main.removeEventListener("pointerup", onPointerUp);
      main.removeEventListener("pointercancel", onPointerUp);
      wrap.removeEventListener("keydown", onKeyDown);
      wrap.removeEventListener("keyup", onKeyUp);
      wrap.removeEventListener("blur", onBlur);
      resetBtn.removeEventListener("click", resetView);
    main.removeEventListener("wheel", onWheel);
      closeBtn.removeEventListener("click", closeCard);
      hotspots = [];
      glowCache = {};
      if (wrap.parentNode) wrap.parentNode.removeChild(wrap);
    }

    function setParams(p) {
      p = p || {};
      var needScene = p.scene && p.scene !== sceneKey;
      params = p;
      if (needScene) {
        loadScene(p.scene);
      } else {
        var custom = p.objects;
        hotspots = normalizeObjects(custom && custom.length ? custom : S.objects);
        focusedIndex = -1;
        closeCard();
      }
    }

    return {
      destroy: destroy,
      resize: function () { measure(); },
      setParams: setParams
    };
  }

  PSWidgets["vr"] = {
    title: "360° 环视实验室",
    defaults: { scene: "mechanics" },
    mount: mount
  };
})();