/* 轻量 API 客户端 */
window.PS = window.PS || {};
PS.views = PS.views || {};

PS.api = (function () {
  async function json(url, opts) {
    const res = await fetch(url, opts);
    const ct = res.headers.get("content-type") || "";
    const data = ct.includes("application/json") ? await res.json() : await res.text();
    if (!res.ok) {
      const msg = (data && data.error) || (typeof data === "string" ? data : "") || `请求失败（${res.status}）`;
      throw new Error(msg);
    }
    return data;
  }
  return {
    get: (url) => json(url),
    post: (url, body) =>
      json(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) }),
    async upload(url, file, filename, extra) {
      const name = filename || (file && file.name) || "upload.bin";
      const res = await fetch(url, {
        method: "POST",
        headers: Object.assign(
          { "X-Filename": encodeURIComponent(name), "Content-Type": "application/octet-stream" },
          extra || {}
        ),
        body: file,
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || `上传失败（${res.status}）`);
      return data;
    },
    async download(url, fallbackName) {
      const res = await fetch(url);
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.error || `下载失败（${res.status}）`);
      }
      const blob = await res.blob();
      let name = fallbackName;
      const cd = res.headers.get("content-disposition") || "";
      const m = /filename\*?=(?:UTF-8'')?"?([^\";]+)"?/i.exec(cd);
      if (m) name = decodeURIComponent(m[1]);
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = name || "download";
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        URL.revokeObjectURL(a.href);
        a.remove();
      }, 1200);
    },
  };
})();