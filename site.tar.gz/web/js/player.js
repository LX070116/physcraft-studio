/* 课堂播放器 · 自包含运行时（应用内与离线导出共用） */
window.PSPlayer = (function () {
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const TYPE_LABEL = {
    cover: "封面", objectives: "学习目标", hook: "情境导入", concept: "核心概念", formula: "规律公式",
    simulation: "交互仿真", vr: "VR 实验", game: "物理闯关", avatar: "数字人", book3d: "立体课本", example: "例题精讲",
    quiz: "随堂检测", summary: "课堂小结", homework: "分层作业", report: "优化说明",
  };
  const I = {
    prev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg>',
    next: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
    play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>',
    stop: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>',
    sound: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/></svg>',
    mute: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M11 5 6 9H3v6h3l5 4z"/><path d="m16 9 5 6M21 9l-5 6"/></svg>',
    full: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>',
    voice: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M12 4a3 3 0 0 1 3 3v5a3 3 0 0 1-6 0V7a3 3 0 0 1 3-3z"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6"/></svg>',
    exit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4M10 8l-4 4 4 4M6 12h9"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="m5 13 4 4L19 7"/></svg>',
  };

  function sceneHtml(sc) {
    const t = sc.type || "concept";
    const kicker = sc.kicker ? `<div class="kicker">${esc(sc.kicker)}</div>` : "";
    switch (t) {
      case "cover":
        return `<div class="scene scene-cover">
          <div style="max-width:900px">
            ${kicker}
            <h1>${esc(sc.title || "")}</h1>
            <div class="lead">${esc(sc.subtitle || "")}</div>
            <div class="chips-row">${(sc.chips || []).map((c) => `<span class="pill pill-accent">${esc(c)}</span>`).join("")}</div>
          </div>
          <div class="cover-orbit" aria-hidden="true">
            <div class="ring r1"></div><div class="ring r2"></div><div class="core">Φ</div>
            <i class="sat s1"></i><i class="sat s2"></i><i class="sat s3"></i>
          </div>
        </div>`;
      case "objectives":
        return `<div class="scene">
          <div class="kicker">${esc(sc.kicker || "OBJECTIVES")}</div>
          <h2>${esc(sc.title || "学习目标")}</h2>
          <div class="scene-body obj-grid">
            ${(sc.items || []).map((o, i) => `<div class="obj-item"><div class="obj-num">${i + 1}</div><div><div class="obj-dim">${esc(o.dim)}</div><div style="font-size:clamp(13px,1.4vw,16px);line-height:1.7">${esc(o.text)}</div></div></div>`).join("")}
          </div>
        </div>`;
      case "hook":
        return `<div class="scene">
          <div class="kicker">${esc(sc.kicker || "")}</div>
          <h2>${esc(sc.title || "情境导入")}</h2>
          <div class="scene-body hook-grid">
            <div class="hook-context">${esc(sc.context || "")}</div>
            <div>${(sc.questions || []).map((q) => `<div class="q-item"><div class="q-mark">?</div><div style="font-size:clamp(13px,1.4vw,16px);line-height:1.65">${esc(q)}</div></div>`).join("")}</div>
          </div>
        </div>`;
      case "concept":
        return `<div class="scene">
          <div class="kicker">${esc(sc.kicker || "核心概念")}</div>
          <h2>${esc(sc.title || "")}</h2>
          <div class="scene-body concept-grid">
            <ul class="bullets concept-bullets">${(sc.bullets || []).map((b) => `<li>${esc(b)}</li>`).join("")}</ul>
            <div>
              ${sc.formula ? `<div class="formula-card">${esc(sc.formula)}</div>` : ""}
              <div class="card-flat" style="margin-top:14px;font-size:12px;color:var(--muted)">
                <b style="color:var(--fg)">课堂提示</b><br>先让学生用自己的话复述结论，再回到公式表达。
              </div>
            </div>
          </div>
        </div>`;
      case "formula":
        return `<div class="scene">
          <div class="kicker">${esc(sc.kicker || "规律与公式")}</div>
          <h2>${esc(sc.title || "")}</h2>
          <div class="scene-body" style="display:grid;gap:14px;grid-template-columns:1.25fr 1fr">
            <div style="display:flex;flex-direction:column;gap:12px">
              ${(sc.formulas || []).map((f) => `<div class="formula-card" style="text-align:left;padding:18px 22px">${esc(f)}</div>`).join("")}
            </div>
            <div class="card-flat"><b style="font-size:12px;color:var(--accent)">式中各量的意义</b>
              <ul class="bullets" style="margin-top:10px">${(sc.bullets || []).map((b) => `<li>${esc(b)}</li>`).join("")}</ul>
            </div>
          </div>
        </div>`;
      case "simulation":
        return `<div class="scene scene-sim">
          <div class="sim-head">
            <div class="row-between">
              <div>
                <div class="kicker">${esc(sc.kicker || "交互仿真")}</div>
                <h2 style="font-size:clamp(18px,2vw,26px)">${esc(sc.title || "")}</h2>
              </div>
              <div class="row" style="gap:8px">
                <span class="pill pill-accent" style="font-size:10px">可调参数 · 实时读数</span>
                <button class="btn btn-sm btn-ghost" id="sim-task-toggle">任务单</button>
              </div>
            </div>
          </div>
          <div class="widget-host" data-widget="${esc(sc.widget || "")}"></div>
          <div class="sim-toast" id="sim-toast"></div>
          ${
            (sc.tasks || []).length
              ? `<div class="scene-tasks collapsed" id="sim-tasks">
                  <div class="task-head"><h4>探究任务</h4><span class="dim" style="font-size:10px">逐条勾选</span></div>
                  ${(sc.tasks || []).map((t, i) => `<label class="task-check"><input type="checkbox" data-task="${i}" /><span>${esc(t)}</span></label>`).join("")}
                </div>`
              : ""
          }
          <div class="sim-table" id="sim-table" hidden></div>
          <div class="sim-toolbar">
            <button class="btn btn-sm btn-primary" data-sim="record">＋ 记录数据</button>
            <button class="btn btn-sm" data-sim="table">数据表 <b id="sim-count">0</b></button>
            <button class="btn btn-sm" data-sim="reset">重置实验</button>
            <button class="btn btn-sm" data-sim="full">全屏</button>
            <button class="btn btn-sm" data-sim="csv">导出 CSV</button>
            <span class="sim-hint">改变条件 → 观察读数 → 记录一组数据</span>
          </div>
        </div>`;
      case "vr":
        return `<div class="scene scene-sim">
          <div class="sim-head">
            <div class="kicker">${esc(sc.kicker || "VR 实验")}</div>
            <h2 style="font-size:clamp(18px,2vw,26px)">${esc(sc.title || "")}</h2>
          </div>
          <div class="widget-host" data-widget="vr"></div>
          ${(sc.tasks || []).length ? `<div class="scene-tasks"><h4>观察任务</h4><ol style="margin:0;padding-left:16px">${(sc.tasks || []).map((t) => `<li>${esc(t)}</li>`).join("")}</ol></div>` : ""}
        </div>`;
      case "game":
        return `<div class="scene scene-sim">
          <div class="sim-head">
            <div class="kicker">${esc(sc.kicker || "知识游戏")}</div>
            <h2 style="font-size:clamp(18px,2vw,26px)">${esc(sc.title || "物理闯关")}</h2>
          </div>
          <div class="widget-host" data-widget="game"></div>
          ${(sc.tasks || []).length ? `<div class="scene-tasks"><h4>闯关要求</h4><ol style="margin:0;padding-left:16px">${(sc.tasks || []).map((t) => `<li>${esc(t)}</li>`).join("")}</ol></div>` : ""}
        </div>`;
      case "book3d":
        return `<div class="scene scene-sim">
          <div class="sim-head"><div class="kicker">${esc(sc.kicker || "立体课本")}</div><h2 style="font-size:clamp(18px,2vw,26px)">${esc(sc.title || "")}</h2></div>
          <div class="widget-host" data-widget="book3d"></div>
        </div>`;
      case "avatar":
        return `<div class="scene">
          <div class="kicker">${esc(sc.kicker || "数字人讲解")}</div>
          <h2>${esc(sc.title || "")}</h2>
          <div class="scene-body" style="display:grid;grid-template-columns:300px 1fr;gap:26px">
            <div data-widget="avatar" style="height:330px;border-radius:16px;overflow:hidden;border:1px solid var(--line);background:radial-gradient(circle at 50% 20%, rgba(56,189,248,.14), transparent 65%)"></div>
            <div>
              <div class="pill pill-amber">本节难点</div>
              <div style="font-size:clamp(17px,1.9vw,24px);font-weight:700;margin:10px 0 14px;line-height:1.45">${esc(sc.focus || "")}</div>
              <ul class="bullets">${(sc.points || []).map((p) => `<li style="font-size:13.5px;margin-bottom:9px">${esc(p)}</li>`).join("")}</ul>
              ${sc.misconception ? `<div class="issue" style="margin-top:16px"><b>常见误区</b><p style="font-size:12.5px;color:#e9d5b8">${esc(sc.misconception)}</p></div>` : ""}
            </div>
          </div>
        </div>`;
      case "example":
        return `<div class="scene">
          <div class="kicker">${esc(sc.kicker || "例题精讲")}</div>
          <h2>${esc(sc.title || "")}</h2>
          <div class="scene-body" style="display:grid;grid-template-columns:1.35fr 1fr;gap:20px">
            <div class="card" style="background:rgba(255,255,255,.03)">
              <div class="pill pill-accent" style="margin-bottom:10px">题目</div>
              <div style="font-size:clamp(13px,1.4vw,16px);line-height:1.85">${esc(sc.stem || "")}</div>
              <div id="ex-steps" style="margin-top:16px;display:flex;flex-direction:column;gap:8px"></div>
              <button class="btn btn-sm" id="ex-next" style="margin-top:14px">显示下一步</button>
            </div>
            <div class="card" style="background:rgba(52,211,153,.06);border-color:rgba(52,211,153,.3)" id="ex-answer">
              <div class="pill pill-green" style="margin-bottom:10px">答案</div>
              <div style="font-size:clamp(15px,1.6vw,20px);font-weight:700;filter:blur(5px);transition:filter .35s" id="ex-answer-text">${esc(sc.answer || "")}</div>
              <div class="dim" style="font-size:11px;margin-top:12px">先独立完成，再点击显示答案</div>
            </div>
          </div>
        </div>`;
      case "quiz":
        return `<div class="scene">
          <div class="kicker">${esc(sc.kicker || "随堂检测")}</div>
          <h2>${esc(sc.title || "")}</h2>
          <div class="scene-body" id="quiz-list">
            ${(sc.items || []).map((q, i) => `<div class="quiz-card" data-q="${i}">
              <div class="row" style="gap:8px;margin-bottom:6px"><span class="pill pill-accent">${q.type === "judge" ? "判断" : q.type === "calc" ? "计算" : q.type === "mcq" ? "选择" : "简答"}</span><span class="dim" style="font-size:11px">第 ${i + 1} 题</span></div>
              <div style="font-size:13.5px;line-height:1.7">${esc(q.stem)}</div>
              ${(q.options || []).length ? `<div class="quiz-opts">${q.options.map((o) => `<button class="quiz-opt" data-opt="${esc(o)}">${esc(o)}</button>`).join("")}</div>` : `<div class="quiz-opts"><button class="quiz-opt" data-reveal="1">查看答案</button></div>`}
              <div class="quiz-exp" style="display:none"></div>
            </div>`).join("")}
          </div>
        </div>`;
      case "summary":
        return `<div class="scene">
          <div class="kicker">${esc(sc.kicker || "课堂小结")}</div>
          <h2>${esc(sc.title || "")}</h2>
          <div class="scene-body">
            <div class="board-cols">${(sc.branches || []).map((b, i) => `<div class="board-col"><h4 style="color:${["var(--accent)", "var(--accent-2)", "var(--amber)"][i] || "var(--accent)"}">${esc(b.label)}</h4><ul class="bullets">${(b.items || []).map((x) => `<li style="font-size:12.5px">${esc(x)}</li>`).join("")}</ul></div>`).join("")}</div>
            <div class="card" style="margin-top:16px;border-color:rgba(56,189,248,.3);background:rgba(56,189,248,.05)">
              <div class="row" style="gap:10px"><span class="pill pill-accent">出门条</span><span style="font-size:13px">${esc(sc.exitTicket || "")}</span></div>
            </div>
          </div>
        </div>`;
      case "homework":
        return `<div class="scene">
          <div class="kicker">${esc(sc.kicker || "分层作业")}</div>
          <h2>${esc(sc.title || "")}</h2>
          <div class="scene-body" style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px">
            ${(sc.tiers || []).map((t, i) => `<div class="tier" style="border-color:${["rgba(52,211,153,.3)", "rgba(56,189,248,.3)", "rgba(167,139,250,.3)"][i]}">
              <div class="row-between"><h4 style="color:${["var(--green)", "var(--accent)", "var(--accent-2)"][i]}">${esc(t.level)}</h4><span class="pill" style="font-size:10px">${esc(t.tag)}</span></div>
              <ul class="bullets" style="margin-top:8px">${(t.items || []).map((x) => `<li style="font-size:12px">${esc(x)}</li>`).join("")}</ul>
            </div>`).join("")}
          </div>
        </div>`;
      case "report":
        return `<div class="scene">
          <div class="kicker">${esc(sc.kicker || "优化说明")}</div>
          <h2>${esc(sc.title || "")}</h2>
          <div class="scene-body" style="display:grid;grid-template-columns:220px 220px 1fr;gap:16px">
            <div class="card-flat" style="text-align:center"><div class="dim" style="font-size:11px">优化前</div><div class="diag-score" style="color:var(--amber)">${esc(sc.before)}</div></div>
            <div class="card-flat" style="text-align:center"><div class="dim" style="font-size:11px">优化后</div><div class="diag-score" style="color:var(--green)">${esc(sc.after)}</div></div>
            <div class="card-flat"><b style="font-size:12px;color:var(--accent)">主要改动</b><ul class="bullets" style="margin-top:8px">${(sc.changes || []).map((c) => `<li style="font-size:12px">${esc(c)}</li>`).join("")}</ul></div>
          </div>
          <div class="scene-body" style="margin-top:14px"><b style="font-size:12px;color:var(--accent-2)">诊断结论</b>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">${(sc.issues || []).map((i) => `<div class="issue sev-${esc(i.level)}" style="margin:0"><b>${esc(i.title)}</b><p>${esc(i.evidence)}</p></div>`).join("")}</div>
          </div>
        </div>`;
      default:
        return `<div class="scene"><div class="kicker">${esc(sc.kicker || "")}</div><h2>${esc(sc.title || "")}</h2><div class="scene-body"><ul class="bullets">${(sc.bullets || []).map((b) => `<li>${esc(b)}</li>`).join("")}</ul></div></div>`;
    }
  }

  function mountWidget(host, type, params, ctx) {
    const w = (window.PSWidgets || {})[type];
    if (!host) return null;
    host.innerHTML = "";
    if (!w) {
      host.innerHTML = `<div class="empty">未加载控件「${esc(type)}」</div>`;
      return null;
    }
    try {
      return w.mount(host, Object.assign({}, w.defaults || {}, params || {}), ctx || {});
    } catch (e) {
      console.error(e);
      host.innerHTML = `<div class="empty">控件加载失败：${esc(e.message)}</div>`;
      return null;
    }
  }

  function mount(container, deck, opts) {
    opts = opts || {};
    const root = typeof container === "string" ? document.querySelector(container) : container;
    if (!root) throw new Error("播放器容器不存在");
    const scenes = deck.scenes || [];
    let idx = opts.startIndex || 0;
    let autoSpeak = opts.autoSpeak !== false;
    let avatar = null;
    let widgetHandle = null;
    let speaking = false;
    let sceneAvatar = null;
    let simRows = [];
    let voiceSettings = loadVoice();

    function loadVoice() {
      try {
        const v = JSON.parse(localStorage.getItem("ps.voice") || "null");
        return Object.assign({ name: "", rate: 1, pitch: 0 }, v || {});
      } catch (e) {
        return { name: "", rate: 1, pitch: 0 };
      }
    }

    function toastAt(el, msg, kind) {
      if (!el) return;
      el.textContent = msg;
      el.className = "sim-toast on " + (kind || "");
      clearTimeout(el._tm);
      el._tm = setTimeout(() => (el.className = "sim-toast " + (kind || "")), 1900);
    }

    function captureRows(host) {
      const rows = [];
      const push = (k, v) => {
        k = (k || "").trim();
        v = (v || "").trim();
        if (k && v && !rows.some((r) => r[0] === k)) rows.push([k, v]);
      };
      host.querySelectorAll(".psw-hud-row").forEach((r) => {
        push(r.querySelector(".psw-hud-k")?.innerText, r.querySelector(".psw-hud-v")?.innerText);
      });
      if (!rows.length) {
        host.querySelectorAll(".psw-x-kv").forEach((r) => {
          push(r.querySelector(".psw-x-k")?.innerText, r.querySelector(".psw-x-v")?.innerText);
        });
      }
      if (!rows.length) {
        host.innerText.split("\n").forEach((line) => {
          const m = line.match(/^(.{1,14}?)\s*[:：]?\s*([-+]?\d[\d.,]*\s*[\w%°℃/²³·]*)$/);
          if (m) push(m[1], m[2]);
        });
      }
      return rows;
    }

    function csvOf(rows) {
      const keys = [];
      rows.forEach((r) => r.cells.forEach(([k]) => { if (!keys.includes(k)) keys.push(k); }));
      const head = ["序号", "时间", ...keys];
      const body = rows.map((r, i) => [i + 1, r.t, ...keys.map((k) => (r.cells.find(([kk]) => kk === k) || ["", ""])[1])]);
      const q = (x) => `"${String(x).replace(/"/g, '""')}"`;
      return "\ufeff" + [head, ...body].map((line) => line.map(q).join(",")).join("\r\n");
    }

    root.classList.add("player");
    root.innerHTML = `
      <div class="player-top">
        <button class="btn btn-sm btn-ghost" id="pp-exit" title="退出课堂">${I.exit}</button>
        <div class="grow" style="min-width:0">
          <div style="font-size:13.5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(deck.meta?.title || "课堂")}</div>
          <div class="dim" style="font-size:10.5px">${esc((deck.meta?.textbook || "") + " · " + (deck.meta?.chapter || ""))}</div>
        </div>
        <span class="pill pill-accent" id="pp-type">封面</span>
        <button class="btn btn-sm btn-ghost" id="pp-sound" title="语音讲解">${I.sound}<span id="pp-sound-t">朗读</span></button>
        <button class="btn btn-sm btn-ghost" id="pp-voice" title="数字人声音">${I.voice}<span>声音</span></button>
        <button class="btn btn-sm btn-ghost" id="pp-full" title="全屏">${I.full}</button>
      </div>
      <div class="voice-pop" id="voice-pop" hidden>
        <h4>数字人声音</h4>
        <label>音色<select class="select" id="voice-select"></select></label>
        <label>语速 <span id="voice-rate-val">1.00×</span><input type="range" id="voice-rate" min="0.8" max="1.3" step="0.05" value="1" /></label>
        <label>音调 <span id="voice-pitch-val">0.0</span><input type="range" id="voice-pitch" min="-2" max="2" step="0.1" value="0" /></label>
        <div class="row" style="margin-top:4px"><button class="btn btn-sm" id="voice-test">试听</button><button class="btn btn-sm btn-primary" id="voice-apply">应用</button></div>
        <div class="dim" style="font-size:10px;margin-top:8px;line-height:1.6">音色来自系统语音库，不同电脑可选项不同；无中文音色时会自动降级。</div>
      </div>
      <div class="player-body">
        <div class="stage-wrap">
          <div class="stage"><div class="stage-inner" id="pp-stage"></div></div>
          <div class="row" style="font-size:11px;color:var(--dim)">
            <span id="pp-hint">← → 切换场景 · 空格朗读</span>
            <span class="grow"></span>
            <span id="pp-progress">1 / ${scenes.length}</span>
          </div>
        </div>
        <aside class="player-side">
          <div class="side-avatar" id="pp-avatar"></div>
          <div class="side-scroll">
            <div class="row-between" style="margin-bottom:8px"><span class="dim" style="font-size:10px;letter-spacing:1.4px">讲稿 / NARRATION</span><span id="pp-speaking" class="pill" style="font-size:9.5px">待机</span></div>
            <div class="narration" id="pp-narration"></div>
            <div class="hr"></div>
            <div class="dim" style="font-size:10.5px;line-height:1.7">提示：朗读使用系统语音（zh-CN），可在浏览器设置中更换音色；无语音时按文本节奏驱动数字人口型。</div>
          </div>
        </aside>
      </div>
      <div class="player-bottom">
        <button class="btn btn-sm" id="pp-prev">${I.prev} 上一页</button>
        <div class="dots-nav" id="pp-dots"></div>
        <button class="btn btn-sm btn-primary" id="pp-next">下一页 ${I.next}</button>
      </div>`;

    const $ = (s) => root.querySelector(s);
    const stage = $("#pp-stage");
    const dots = $("#pp-dots");

    dots.innerHTML = scenes.map((s, i) => `<button class="dot-btn" data-i="${i}" title="${esc(TYPE_LABEL[s.type] || s.type)}"></button>`).join("");
    dots.querySelectorAll(".dot-btn").forEach((b) => (b.onclick = () => go(+b.dataset.i)));

    // 数字人（侧栏常驻）
    const avatarHost = $("#pp-avatar");
    if ((window.PSWidgets || {}).avatar) {
      avatar = PSWidgets.avatar.mount(
        avatarHost,
        { name: "李老师", role: "物理 · 智能助教", voice: voiceSettings },
        { speak: () => {}, onProgress: highlightNarration }
      );
    } else {
      avatarHost.innerHTML = `<div class="empty" style="padding:40px 10px">数字人控件未加载</div>`;
    }

    function highlightNarration(i) {
      const el = $("#pp-narration");
      if (!el || !el._raw) return;
      const txt = el._raw;
      const n = Math.max(0, Math.min(txt.length, i | 0));
      el.innerHTML = `<span>${esc(txt.slice(0, n))}</span><span class="hl">${esc(txt.slice(n, n + 2))}</span><span>${esc(txt.slice(n + 2))}</span>`;
    }

    function destroyWidget() {
      if (widgetHandle && typeof widgetHandle.destroy === "function") {
        try { widgetHandle.destroy(); } catch (e) {}
      }
      widgetHandle = null;
    }

    function speak(text) {
      if (!autoSpeak || !avatar || !text) return;
      try {
        avatar.say(text);
        speaking = true;
        $("#pp-speaking").textContent = "讲解中";
        $("#pp-speaking").className = "pill pill-green";
      } catch (e) {
        console.warn(e);
      }
    }

    function bindSimTools(sc, host) {
      const toastEl = stage.querySelector("#sim-toast");
      const tableEl = stage.querySelector("#sim-table");
      const countEl = stage.querySelector("#sim-count");
      const toggle = stage.querySelector("#sim-task-toggle");
      const tasks = stage.querySelector("#sim-tasks");

      if (toggle && tasks) {
        toggle.onclick = () => {
          tasks.classList.toggle("collapsed");
          toggle.textContent = tasks.classList.contains("collapsed") ? "任务单" : "收起";
        };
        tasks.querySelectorAll(".task-check input").forEach((cb) => {
          cb.onchange = () => cb.closest(".task-check").classList.toggle("done", cb.checked);
        });
      }

      function updateCount() {
        if (countEl) countEl.textContent = String(simRows.length);
      }

      function exportCSV() {
        if (!simRows.length) {
          toastAt(toastEl, "还没有记录数据", "err");
          return;
        }
        const blob = new Blob([csvOf(simRows)], { type: "text/csv;charset=utf-8" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = `${deck.meta?.title || "实验"}-${sc.title || "数据"}.csv`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 1500);
        toastAt(toastEl, "CSV 已导出", "ok");
      }

      function drawTable() {
        if (!tableEl) return;
        const keys = [];
        simRows.forEach((r) => r.cells.forEach(([k]) => { if (!keys.includes(k)) keys.push(k); }));
        tableEl.innerHTML = `<div class="sim-table-head"><b>实验记录</b><span>${simRows.length} 组</span>
          <button data-sim2="csv">导出</button><button data-sim2="clear">清空</button><button data-sim2="close">收起</button></div>
          <div class="sim-table-scroll"><table><thead><tr><th>#</th><th>时间</th>${keys.map((k) => `<th>${esc(k)}</th>`).join("")}</tr></thead>
          <tbody>${simRows
            .map(
              (r, i) =>
                `<tr><td>${i + 1}</td><td>${esc(r.t)}</td>${keys
                  .map((k) => {
                    const c = r.cells.find(([kk]) => kk === k);
                    return `<td>${esc(c ? c[1] : "")}</td>`;
                  })
                  .join("")}</tr>`
            )
            .join("")}</tbody></table></div>`;
        tableEl.querySelectorAll("[data-sim2]").forEach((b) => {
          b.onclick = () => {
            const a = b.dataset.sim2;
            if (a === "clear") {
              simRows = [];
              drawTable();
              updateCount();
              toastAt(toastEl, "已清空记录");
            } else if (a === "close") {
              tableEl.hidden = true;
            } else if (a === "csv") {
              exportCSV();
            }
          };
        });
      }

      stage.querySelectorAll("[data-sim]").forEach((b) => {
        b.onclick = () => {
          const act = b.dataset.sim;
          if (act === "record") {
            const cells = captureRows(stage.querySelector(".widget-host"));
            if (!cells.length) {
              toastAt(toastEl, "未读到参数，先操作一次实验", "err");
              return;
            }
            simRows.push({ t: new Date().toLocaleTimeString("zh-CN", { hour12: false }), cells });
            updateCount();
            drawTable();
            toastAt(toastEl, `已记录第 ${simRows.length} 组数据`, "ok");
          } else if (act === "table") {
            tableEl.hidden = false;
            drawTable();
            if (!simRows.length) toastAt(toastEl, "记录后这里会出现数据表");
          } else if (act === "reset") {
            destroyWidget();
            widgetHandle = mountWidget(stage.querySelector(".widget-host"), sc.widget, sc.params || {}, { speak, motion: true });
            toastAt(toastEl, "实验已重置");
          } else if (act === "full") {
            const st = stage.parentElement;
            if (st && st.requestFullscreen) st.requestFullscreen();
          } else if (act === "csv") {
            exportCSV();
          }
        };
      });
      updateCount();
    }

    function render() {
      const sc = scenes[idx];
      if (!sc) return;
      destroyWidget();
      sceneAvatar = null;
      simRows = [];
      stage.innerHTML = sceneHtml(sc);
      $("#pp-type").textContent = TYPE_LABEL[sc.type] || sc.type;
      $("#pp-progress").textContent = `${idx + 1} / ${scenes.length}`;
      const nar = $("#pp-narration");
      nar._raw = sc.narration || "（本页无讲稿）";
      nar.textContent = nar._raw;
      dots.querySelectorAll(".dot-btn").forEach((b, i) => b.classList.toggle("on", i === idx));

      // 挂载控件
      const host = stage.querySelector("[data-widget]");
      if (host) {
        const type = host.dataset.widget;
        if (type === "vr") {
          widgetHandle = mountWidget(host, "vr", { scene: sc.vr || "mechanics" }, { speak, motion: true });
        } else if (type === "book3d") {
          widgetHandle = mountWidget(host, "book3d", { book: sc.book }, { speak, motion: true });
        } else if (type === "avatar") {
          sceneAvatar = mountWidget(host, "avatar", { name: "李老师", role: "物理 · 智能助教", voice: voiceSettings, lines: [sc.narration || ""] }, { speak, motion: true, onProgress: highlightNarration });
          widgetHandle = sceneAvatar;
        } else {
          widgetHandle = mountWidget(host, type, sc.params || {}, { speak, motion: true });
        }
      }
      if (sc.type === "simulation") bindSimTools(sc, host);

      // 例题逐步
      const exNext = stage.querySelector("#ex-next");
      if (exNext) {
        let k = 0;
        const steps = sc.steps || [];
        exNext.onclick = () => {
          if (k < steps.length) {
            const d = document.createElement("div");
            d.className = "list-item";
            d.innerHTML = `<span class="idx">${String(k + 1).padStart(2, "0")}</span><span>${esc(steps[k])}</span>`;
            stage.querySelector("#ex-steps").appendChild(d);
            k++;
            if (k >= steps.length) {
              exNext.textContent = "已展示完整解答";
              exNext.disabled = true;
              const at = stage.querySelector("#ex-answer-text");
              if (at) at.style.filter = "none";
            }
          }
        };
      }

      // 选择题交互
      stage.querySelectorAll(".quiz-card").forEach((card) => {
        const qi = +card.dataset.q;
        const q = (sc.items || [])[qi] || {};
        card.querySelectorAll(".quiz-opt").forEach((btn) => {
          btn.onclick = () => {
            if (!q.options || !q.options.length) {
              const exp = card.querySelector(".quiz-exp");
              exp.style.display = "block";
              exp.textContent = "参考答案：" + (q.answer || "") + (q.explain ? "　解析：" + q.explain : "");
              return;
            }
            const val = btn.dataset.opt;
            const ok = String(q.answer || "").includes(val);
            btn.classList.add(ok ? "ok" : "bad");
            card.querySelectorAll(".quiz-opt").forEach((b2) => (b2.disabled = true));
            const exp = card.querySelector(".quiz-exp");
            exp.style.display = "block";
            exp.innerHTML = `<b style="color:${ok ? "var(--green)" : "var(--red)"}">${ok ? "回答正确" : "再想一想"}</b>　参考答案：${esc(q.answer || "")}<br>${esc(q.explain || "")}`;
          };
        });
      });

      if (autoSpeak) speak(sc.narration);
      if (window.__PS_ON_SCENE) window.__PS_ON_SCENE(idx, sc);
    }

    function go(i) {
      if (i < 0 || i >= scenes.length) return;
      idx = i;
      render();
      stage.scrollTop = 0;
    }

    $("#pp-prev").onclick = () => go(idx - 1);
    $("#pp-next").onclick = () => go(idx + 1);
    $("#pp-sound").onclick = () => {
      autoSpeak = !autoSpeak;
      $("#pp-sound-t").textContent = autoSpeak ? "朗读" : "静音";
      $("#pp-sound").classList.toggle("btn-primary", autoSpeak);
      if (!autoSpeak && avatar && avatar.stop) avatar.stop();
      if (autoSpeak) speak(scenes[idx].narration);
    };
    $("#pp-full").onclick = () => {
      if (!document.fullscreenElement) root.requestFullscreen && root.requestFullscreen();
      else document.exitFullscreen && document.exitFullscreen();
    };

    // ---------- 数字人声音面板 ----------
    const vp = $("#voice-pop");
    const vSel = $("#voice-select");
    const vRate = $("#voice-rate");
    const vPitch = $("#voice-pitch");

    function voiceList() {
      if (!("speechSynthesis" in window)) return [];
      const all = speechSynthesis.getVoices() || [];
      const zh = all.filter((v) => /zh|cmn|chinese|中文/i.test((v.lang || "") + " " + (v.name || "")));
      return zh.length ? zh : all;
    }

    function syncVoiceUI() {
      if (!vp) return;
      vRate.value = String(voiceSettings.rate);
      vPitch.value = String(voiceSettings.pitch);
      $("#voice-rate-val").textContent = Number(voiceSettings.rate).toFixed(2) + "×";
      $("#voice-pitch-val").textContent = Number(voiceSettings.pitch).toFixed(1);
    }

    function populateVoiceSelect() {
      if (!vSel) return;
      const list = voiceList();
      const cur = voiceSettings.name;
      vSel.innerHTML =
        `<option value="">自动（优先中文女声）</option>` +
        list.map((v) => `<option value="${esc(v.name)}">${esc(v.name)} · ${esc(v.lang)}</option>`).join("");
      vSel.value = cur && [...vSel.options].some((o) => o.value === cur) ? cur : "";
    }

    function applyVoice() {
      voiceSettings = { name: vSel ? vSel.value : "", rate: Number(vRate.value), pitch: Number(vPitch.value) };
      try {
        localStorage.setItem("ps.voice", JSON.stringify(voiceSettings));
      } catch (e) {}
      [avatar, sceneAvatar].forEach((a) => {
        if (a && a.setVoice) {
          try { a.setVoice(voiceSettings); } catch (e) {}
        }
      });
      if (vp) vp.hidden = true;
      toastAt(stage.querySelector(".sim-toast"), "声音已更新", "ok");
    }

    function previewVoice() {
      if (!("speechSynthesis" in window)) {
        toastAt(stage.querySelector(".sim-toast"), "当前浏览器不支持语音合成", "err");
        return;
      }
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance("同学们好，我是李老师，今天我们学习凸透镜成像的规律。");
      const list = voiceList();
      const pick = list.find((v) => v.name === vSel.value);
      if (pick) u.voice = pick;
      u.lang = (pick && pick.lang) || "zh-CN";
      u.rate = Number(vRate.value);
      u.pitch = Number(vPitch.value);
      speechSynthesis.speak(u);
    }

    if ($("#pp-voice")) {
      populateVoiceSelect();
      syncVoiceUI();
      $("#pp-voice").onclick = (e) => {
        e.stopPropagation();
        vp.hidden = !vp.hidden;
        if (!vp.hidden) {
          populateVoiceSelect();
          syncVoiceUI();
        }
      };
      vRate.oninput = () => ($("#voice-rate-val").textContent = Number(vRate.value).toFixed(2) + "×");
      vPitch.oninput = () => ($("#voice-pitch-val").textContent = Number(vPitch.value).toFixed(1));
      $("#voice-test").onclick = previewVoice;
      $("#voice-apply").onclick = applyVoice;
      if ("speechSynthesis" in window) speechSynthesis.onvoiceschanged = () => { if (!vp.hidden) populateVoiceSelect(); };
      document.addEventListener("click", (e) => {
        if (vp && !vp.hidden && !vp.contains(e.target) && e.target.id !== "pp-voice") vp.hidden = true;
      });
    }
    const exit = $("#pp-exit");
    if (opts.offline) exit.style.display = "none";
    exit.onclick = () => { if (opts.onExit) opts.onExit(); else location.hash = "#/library"; };

    root.addEventListener("keydown", (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      if (e.key === "ArrowRight") { e.preventDefault(); go(idx + 1); }
      if (e.key === "ArrowLeft") { e.preventDefault(); go(idx - 1); }
      if (e.code === "Space" && e.target === document.body) { e.preventDefault(); speak(scenes[idx].narration); }
    });
    root.tabIndex = 0;

    render();
    return { go, next: () => go(idx + 1), prev: () => go(idx - 1), destroy: destroyWidget, scenes, get index() { return idx; } };
  }

  return { mount };
})();