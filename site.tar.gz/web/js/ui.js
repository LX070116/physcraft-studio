/* UI 基础件：图标、提示、抽屉、加载态 */
window.PS = window.PS || {};

PS.ui = (function () {
  const ICONS = {
    book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z"/><path d="M4 5.5v15"/><path d="M8 7h8M8 11h6"/>',
    doc: '<path d="M7 3h10a2 2 0 0 1 2 2v16l-7-4-7 4V5a2 2 0 0 1 2-2z"/><path d="M9 8h6M9 12h4"/>',
    slides: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M12 16v4M8 20h8"/><path d="m7 12 3-4 2.5 3L15 8l2 4"/>',
    spark: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8"/><circle cx="12" cy="12" r="3"/>',
    play: '<path d="M8 5v14l11-7z"/>',
    upload: '<path d="M12 16V4M6 10l6-6 6 6"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/>',
    download: '<path d="M12 4v12M6 10l6 6 6-6"/><path d="M4 18v2h16v-2"/>',
    check: '<path d="m5 13 4 4L19 7"/>',
    x: '<path d="M6 6l12 12M18 6 6 18"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    vr: '<path d="M3 8.5A2.5 2.5 0 0 1 5.5 6h13A2.5 2.5 0 0 1 21 8.5v7a2.5 2.5 0 0 1-2.5 2.5c-1.6 0-2.4-1-3.2-2.2-.6-.9-1.1-1.3-2.3-1.3s-1.7.4-2.3 1.3C9.9 17 9.1 18 7.5 18A2.5 2.5 0 0 1 5 15.5z"/><circle cx="8" cy="11" r="1.4"/><circle cx="16" cy="11" r="1.4"/>',
    cube: '<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9z"/><path d="m4 7.5 8 4.5 8-4.5M12 12v9"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/>',
    wand: '<path d="m4 20 10-10M14 6l4 4M16 3v2M21 8h-2M18.5 4.5 17 6M13 4l-1-1"/>',
    chart: '<path d="M4 20V6M4 20h16"/><path d="M8 17v-4M12 17V9M16 17v-6M20 17v-9"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    target: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/>',
    layers: '<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>',
    warn: '<path d="M12 4 3 20h18z"/><path d="M12 10v4M12 17h.01"/>',
    refresh: '<path d="M4 12a8 8 0 0 1 13.7-5.7L20 8"/><path d="M20 4v4h-4"/><path d="M20 12a8 8 0 0 1-13.7 5.7L4 16"/><path d="M4 20v-4h4"/>',
    eye: '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6z"/><circle cx="12" cy="12" r="3"/>',
    save: '<path d="M5 3h11l3 3v15H5z"/><path d="M8 3v6h8V3M8 21v-7h8v7"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  };

  function icon(name, size) {
    const p = ICONS[name] || ICONS.spark;
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"${size ? ` style="width:${size}px;height:${size}px"` : ""}>${p}</svg>`;
  }

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function toast(msg, kind) {
    const wrap = document.getElementById("toasts");
    if (!wrap) return;
    const el = document.createElement("div");
    el.className = "toast " + (kind || "");
    el.innerHTML = (kind === "err" ? icon("warn", 14) : kind === "ok" ? icon("check", 14) : "") + `<span>${esc(msg)}</span>`;
    wrap.appendChild(el);
    setTimeout(() => {
      el.style.transition = "opacity .3s, transform .3s";
      el.style.opacity = "0";
      el.style.transform = "translateY(8px)";
      setTimeout(() => el.remove(), 320);
    }, kind === "err" ? 4200 : 2600);
  }

  function drawer(title, subtitle, bodyHtml, footHtml) {
    const mask = document.getElementById("drawer-mask");
    const drawer = document.getElementById("drawer");
    document.getElementById("drawer-head").innerHTML = `
      <div class="grow">
        <div class="eyebrow" style="margin-bottom:4px">${esc(subtitle || "详情")}</div>
        <h2>${esc(title)}</h2>
      </div>
      <button class="btn btn-sm btn-ghost drawer-close" id="drawer-close">${icon("x", 15)}</button>`;
    document.getElementById("drawer-body").innerHTML = bodyHtml + (footHtml ? `<div style="margin-top:24px">${footHtml}</div>` : "");
    mask.classList.add("show");
    drawer.classList.add("show");
    const close = () => {
      mask.classList.remove("show");
      drawer.classList.remove("show");
    };
    document.getElementById("drawer-close").onclick = close;
    mask.onclick = close;
    return { close };
  }

  function spinner(text) {
    return `<div class="row" style="padding:26px;justify-content:center;color:var(--muted);font-size:12.5px"><span class="spinner"></span>${esc(text || "处理中…")}</div>`;
  }

  function scoreColor(n) {
    if (n >= 85) return "var(--green)";
    if (n >= 70) return "var(--accent)";
    if (n >= 55) return "var(--amber)";
    return "var(--red)";
  }

  function dots(n, max, cls) {
    let s = `<span class="dots ${cls || ""}">`;
    for (let i = 1; i <= (max || 3); i++) s += `<i class="${i <= n ? "on" : ""}"></i>`;
    return s + "</span>";
  }

  function mountWidget(host, type, params, ctx) {
    const w = (window.PSWidgets || {})[type];
    if (!host) return null;
    host.innerHTML = "";
    if (!w) {
      host.innerHTML = `<div class="empty">${icon("warn")}<div>未加载控件「${esc(type)}」</div><div class="dim" style="font-size:11px;margin-top:6px">请检查 web/js/widgets/ 下的脚本</div></div>`;
      return null;
    }
    try {
      return w.mount(host, Object.assign({}, w.defaults || {}, params || {}), ctx || {});
    } catch (e) {
      console.error(e);
      host.innerHTML = `<div class="empty">${icon("warn")}<div>控件加载失败：${esc(e.message)}</div></div>`;
      return null;
    }
  }

  return { icon, esc, toast, drawer, spinner, scoreColor, dots, mountWidget };
})();