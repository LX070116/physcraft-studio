/* 架构与说明 */
PS.views.about = {
  title: "架构与说明",
  render() {
    return `
      <div class="page-head">
        <div>
          <div class="eyebrow">Architecture</div>
          <h1>二次开发说明</h1>
          <div class="lead">本平台以 THU-MAIC/OpenMAIC 的场景化课堂范式为基础，面向“中学物理教材知识库 → 教案 → 课件 → 课堂”的教师工作流做了垂直化重构。</div>
        </div>
        <a class="btn btn-sm" href="https://github.com/THU-MAIC/OpenMAIC" target="_blank" rel="noopener">OpenMAIC 仓库 ↗</a>
      </div>

      <div class="grid g-2-1" style="align-items:start">
        <div class="card">
          <h2 style="margin-bottom:12px">与 OpenMAIC 的对应关系</h2>
          <table class="about-table">
            <thead><tr><th style="width:30%">OpenMAIC 概念</th><th>本平台实现</th></tr></thead>
            <tbody>
              <tr><td>两阶段生成（Outline → Scenes）</td><td>教案解析 → 场景序列（14 类教学场景），由 <code>core/generation.py</code> 编排</td></tr>
              <tr><td>场景 DSL（@openmaic/dsl）</td><td>轻量 JSON 场景契约：<code>cover / objectives / hook / concept / formula / simulation / vr / avatar / book3d / example / quiz / summary / homework / report</code></td></tr>
              <tr><td>Interactive scene（3D / 仿真 / 游戏）</td><td>9 个零依赖 Canvas 物理仿真 + 4 个 360° VR 场景 + 3 个知识闯关游戏，注册于 <code>PSWidgets</code></td></tr>
              <tr><td>多智能体教师 / TTS 讲解</td><td>SVG 数字人教师 + 浏览器语音合成（zh-CN）+ 逐字讲稿高亮</td></tr>
              <tr><td>PPTX / HTML 导出</td><td><code>core/pptx_export.py</code> 生成可编辑 PPT（含矢量图示与讲稿备注）；<code>core/html_export.py</code> 导出单文件交互课件</td></tr>
              <tr><td>知识库（v1.3）</td><td>中学物理教材知识库：全学段知识点 / 重难点 / 误区 / 实验 / 仿真映射，<code>core/kb_*.json</code>；另含 66 个实验库与题库</td></tr>
              <tr><td>PPTX 导入</td><td><code>core/textparse.py</code> 逐页解析文字、字号、图片与备注，用于诊断与结构重排</td></tr>
            </tbody>
          </table>
        </div>

        <div class="col">
          <div class="card">
            <h3 style="margin-bottom:10px">技术栈</h3>
            <dl class="kv">
              <dt>后端</dt><dd>Python 3.12 标准库 HTTP 服务（无外部框架）</dd>
              <dt>文档</dt><dd>python-pptx / python-docx / 自研 PDF 文本提取</dd>
              <dt>前端</dt><dd>原生 ES2020 + Canvas / SVG / CSS 3D，无构建步骤</dd>
              <dt>存储</dt><dd>本地文件 <code>data/out/&lt;id&gt;/</code></dd>
              <dt>运行</dt><dd><code>python run.py</code> → http://127.0.0.1:8770</dd>
            </dl>
          </div>
          <div class="card">
            <h3 style="margin-bottom:8px">数据流</h3>
            <div class="code" style="font-size:11px;line-height:1.9">教案(docx/txt) ─┐
                 ├─ 解析重难点/学情 ─→ 场景DSL ─→ 课堂播放器
知识库(JSON) ─────┘                        ├─→ PPTX
                                          ├─→ 单文件HTML
                                          └─→ 诊断报告</div>
          </div>
        </div>
      </div>

      <div class="grid g3" style="margin-top:18px">
        <div class="card">
          <h3 style="margin-bottom:8px">能力边界</h3>
          <ul class="bullets">
            <li>离线可用：知识库与生成规则内置于仓库，无需任何 API Key</li>
            <li>不依赖大模型：生成结果可复现、可审计；如需润色可接 LLM 适配层</li>
            <li>PPTX 中的互动页为“入口页”，真正交互在配套 HTML / 平台课堂中运行</li>
            <li>语音使用系统 TTS 音色，不同机器音色不同</li>
          </ul>
        </div>
        <div class="card">
          <h3 style="margin-bottom:8px">可扩展点</h3>
          <ul class="bullets">
            <li><code>core/kb_*.json</code>：扩充教材版本与知识点</li>
            <li><code>web/js/widgets/</code>：按契约新增仿真 / VR 场景</li>
            <li><code>core/generation.py</code>：调整场景序列与讲稿策略</li>
            <li><code>core/llm.py</code>：接入 OpenAI 兼容模型做文本润色</li>
          </ul>
        </div>
        <div class="card">
          <h3 style="margin-bottom:8px">接口一览</h3>
          <div class="code" style="font-size:10.5px;line-height:1.8">GET  /api/kb
GET  /api/kb/point/:id
POST /api/lesson/generate
POST /api/lesson/optimize
POST /api/deck/generate
POST /api/deck/optimize
GET  /api/deck/:id/pptx
GET  /api/deck/:id/html</div>
        </div>
      </div>

      <div class="card" style="margin-top:18px" id="net-card">
        <div class="row-between" style="margin-bottom:8px"><h3>其他设备访问（局域网）</h3><span class="pill">检测中…</span></div>
        <div class="dim" style="font-size:12px">正在读取本机地址…</div>
      </div>

      <div class="card" style="margin-top:18px">
        <h3 style="margin-bottom:8px">致谢与许可</h3>
        <p style="font-size:12.5px;color:var(--muted);line-height:1.8">
          架构与交互范式参考 <a href="https://github.com/THU-MAIC/OpenMAIC" target="_blank" rel="noopener">THU-MAIC/OpenMAIC</a>（MIT License，清华大学 MAIC 团队）。
          本仓库为面向中学物理的独立二次开发实现，未包含上游源码；如需与上游部署联调，可在 <code>core/</code> 中增加 OpenMAIC API 适配器。
        </p>
      </div>`;
  },
  async after() {
    const card = document.getElementById("net-card");
    if (!card) return;
    try {
      const n = await PS.api.get("/api/network");
      card.innerHTML = `
        <div class="row-between" style="margin-bottom:10px"><h3>其他设备访问（局域网）</h3><span class="pill pill-accent">端口 ${n.port}</span></div>
        <div class="col" style="gap:8px">
          ${n.urls.map((u) => `<div class="list-item" style="align-items:center"><code style="font-size:12px">${PS.ui.esc(u)}</code><span class="grow"></span><button class="btn btn-sm" data-copy="${PS.ui.esc(u)}">复制</button></div>`).join("")}
          <div class="dim" style="font-size:11.5px">本机页面：${PS.ui.esc(n.loopback)}</div>
        </div>
        <div class="hr"></div>
        <div class="issue" style="border-left-color:var(--amber)"><b>为什么“同一个 Wi-Fi”还是打不开？</b><p>${PS.ui.esc(n.sameLan)}</p></div>
        <div style="font-size:12px;color:var(--muted);line-height:1.8;margin-top:10px">
          ${n.tips.map((t) => "· " + PS.ui.esc(t)).join("<br>")}
        </div>
        <div class="hr"></div>
        <div class="row-between" style="margin-bottom:6px"><b style="font-size:12px">防火墙放行命令（管理员 PowerShell）</b><button class="btn btn-sm" data-copy="${PS.ui.esc(n.firewallCommand)}">复制</button></div>
        <div class="code" style="font-size:11px">${PS.ui.esc(n.firewallCommand)}</div>
        <div class="dim" style="font-size:11px;margin-top:6px">也可以双击项目根目录的“开放局域网访问.bat”，按提示允许管理员权限。</div>`;
      card.querySelectorAll("[data-copy]").forEach((b) => {
        b.onclick = async () => {
          try {
            await navigator.clipboard.writeText(b.dataset.copy);
            PS.ui.toast("已复制", "ok");
          } catch (e) {
            PS.ui.toast("复制失败，请手动选择", "err");
          }
        };
      });
    } catch (e) {
      card.innerHTML = `<h3>其他设备访问</h3><div class="empty">${PS.ui.esc(e.message)}</div>`;
    }
  },
};