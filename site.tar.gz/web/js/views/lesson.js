/* 教案工坊 */
PS.views.lesson = {
  title: "教案工坊",
  render(r) {
    const tab = r.params.tab === "optimize" ? "optimize" : "generate";
    PS._lesson = { tab, points: [], result: null, optResult: null, file: null };
    return `
      <div class="page-head">
        <div>
          <div class="eyebrow">Lesson Design</div>
          <h1>教案工坊</h1>
          <div class="lead">从教材知识点出发生成六环节教案；或上传旧教案，先诊断再优化，保留你的原始判断。</div>
        </div>
        <div class="seg" id="ls-tabs">
          <button data-tab="generate" class="${tab === "generate" ? "active" : ""}">生成教案</button>
          <button data-tab="optimize" class="${tab === "optimize" ? "active" : ""}">优化教案</button>
        </div>
      </div>
      <div id="ls-body"></div>`;
  },
  async after(r) {
    const S = PS._lesson;
    const $ = (id) => document.getElementById(id);

    document.querySelectorAll("#ls-tabs button").forEach((b) => {
      b.onclick = () => {
        document.querySelectorAll("#ls-tabs button").forEach((x) => x.classList.toggle("active", x === b));
        S.tab = b.dataset.tab;
        paint();
      };
    });

    async function addPoint(pid) {
      if (!pid || S.points.find((p) => p.id === pid)) return;
      try {
        const p = await PS.api.get(`/api/kb/point/${pid}`);
        if (S.points.find((x) => x.id === p.id)) return;
        S.points.push({ id: p.id, title: p.title });
      } catch (e) {
        PS.ui.toast(e.message, "err");
      }
      paintGen();
    }

    function genForm() {
      return `
        <div class="grid g-64" style="align-items:start">
          <div class="card">
            <h2 style="margin-bottom:14px">① 选择知识点</h2>
            <div style="position:relative">
              <input class="input" id="pt-search" placeholder="搜索知识点，如“凸透镜成像”“欧姆定律”“平抛运动”" autocomplete="off" />
              <div id="pt-sug" class="card" style="display:none;position:absolute;z-index:20;left:0;right:0;top:44px;padding:6px;max-height:280px;overflow-y:auto"></div>
            </div>
            <div class="chips" id="pt-selected" style="margin-top:10px"></div>

            <div class="hr"></div>
            <h2 style="margin-bottom:14px">② 学情画像</h2>
            <div class="grid g2">
              <label class="field"><span class="field-label"><b>班级层次</b></span>
                <div class="chips" id="lv-chips">
                  ${["薄弱", "中等", "优秀"].map((x) => `<span class="chip ${x === "中等" ? "on" : ""}" data-lv="${x}">${x}</span>`).join("")}
                </div>
              </label>
              <label class="field"><span class="field-label"><b>前测均分</b><span class="dim">可选</span></span>
                <input class="input" id="pre-score" type="number" min="0" max="100" placeholder="如 62" />
              </label>
              <label class="field"><span class="field-label"><b>课时长度</b></span>
                <select class="select" id="duration"><option value="40">40 分钟</option><option value="45" selected>45 分钟</option><option value="90">90 分钟（两课时）</option></select>
              </label>
              <label class="field"><span class="field-label"><b>课型 / 风格</b></span>
                <select class="select" id="style"><option value="探究式" selected>探究式</option><option value="讲授式">讲授式</option><option value="复习课">复习课</option></select>
              </label>
            </div>
            <label class="field"><span class="field-label"><b>已有基础 / 备注</b><span class="dim">可选</span></span>
              <textarea class="textarea" id="prior" placeholder="如：学生已掌握速度公式，但单位换算易错；班级有 6 名学生基础薄弱。"></textarea>
            </label>
            <div class="row" style="margin-top:4px">
              <button class="btn btn-primary btn-lg" id="ls-gen">生成教案</button>
              <span class="dim" style="font-size:11.5px">约 2 秒 · 本地知识库驱动，无需联网</span>
            </div>
          </div>
          <div class="card" style="position:sticky;top:0">
            <div class="eyebrow">教学结构</div>
            <h3 style="margin-bottom:10px">六环节 · 45 分钟</h3>
            <div class="list">
              ${[
                ["情境导入", "5′", "生活现象 → 问题链"],
                ["概念建构", "14′", "观察 → 证据 → 结论"],
                ["模型深化", "9′", "公式推导 + 例题示范"],
                ["仿真 / VR", "9′", "改变条件，观察响应"],
                ["分层训练", "5′", "基础 / 提高 / 拓展"],
                ["小结作业", "3′", "概念图 + 分层作业"],
              ]
                .map(([a, b, c]) => `<div class="list-item"><span class="idx">${b}</span><div><b style="font-size:12.5px">${a}</b><div class="dim" style="font-size:11px">${c}</div></div></div>`)
                .join("")}
            </div>
            <div class="hr"></div>
            <div class="dim" style="font-size:11.5px;line-height:1.7">生成结果包含：目标（可观测动词）、重难点、学情对策、师生活动与设计意图、板书、分层作业、评价量规、数字人讲稿。</div>
          </div>
        </div>
        <div id="ls-result" style="margin-top:18px"></div>`;
    }

    function optForm() {
      return `
        <div class="grid g2" style="align-items:start">
          <div class="card">
            <h2 style="margin-bottom:6px">上传原教案</h2>
            <div class="lead" style="margin-bottom:14px">支持 .docx / .txt / .md。系统会识别目标、重难点、学情、过程、板书、作业等段落。</div>
            <div class="drop" id="ls-drop">
              <div class="drop-icon">${PS.ui.icon("upload")}</div>
              <b>点击选择或拖拽教案文件</b>
              <small>.docx / .pdf / .txt / .md，建议 1–5 MB</small>
              <input type="file" id="ls-file" accept=".docx,.pdf,.txt,.md,.markdown" style="display:none" />
            </div>
            <div id="ls-file-name" style="margin-top:10px"></div>
            <div class="row" style="margin-top:14px;gap:8px">
              <button class="btn btn-primary" id="ls-opt" disabled>诊断并优化</button>
              <button class="btn btn-ghost btn-sm" id="ls-demo">载入示例教案</button>
              <button class="btn btn-ghost btn-sm" id="ls-demo-pdf">载入示例 PDF</button>
            </div>
          </div>
          <div class="card">
            <div class="eyebrow">诊断维度</div>
            <h3 style="margin-bottom:10px">8 项教学一致性检查</h3>
            <ul class="bullets">
              <li>目标是否可观测、可评价（行为动词）</li>
              <li>重难点是否显性并与教材一致</li>
              <li>学情是否有数据支撑（前测 / 错误率）</li>
              <li>环节时间是否落在课时内</li>
              <li>是否有探究 / 实验活动</li>
              <li>是否分层作业、总量是否合理</li>
              <li>是否有课堂评价与反馈设计</li>
              <li>是否有结构化板书</li>
            </ul>
            <div class="hr"></div>
            <div class="dim" style="font-size:11.5px;line-height:1.7">优化不会覆盖你的原始判断：已有目标、重难点会被保留并条目化，缺失部分按知识库补齐，并给出逐项改动说明。</div>
          </div>
        </div>
        <div id="ls-result" style="margin-top:18px"></div>`;
    }

    function paint() {
      $("ls-body").innerHTML = S.tab === "generate" ? genForm() : optForm();
      if (S.tab === "generate") {
        paintGen();
        if (S.result) renderPlan(S.result.plan, S.result.id);
      } else {
        paintOpt();
        if (S.optResult) renderOpt(S.optResult);
      }
    }

    /* ---------- 生成 ---------- */
    function paintGen() {
      const sel = $("pt-selected");
      if (!sel) return;
      sel.innerHTML = S.points.length
        ? S.points.map((p) => `<span class="chip on" data-rm="${p.id}">${PS.ui.esc(p.title)} ✕</span>`).join("")
        : `<span class="dim" style="font-size:12px">尚未选择知识点</span>`;
      sel.querySelectorAll("[data-rm]").forEach((c) => {
        c.onclick = () => {
          S.points = S.points.filter((p) => p.id !== c.dataset.rm);
          paintGen();
        };
      });
    }

    function bindGen() {
      const input = $("pt-search");
      const sug = $("pt-sug");
      let timer = null;
      input.addEventListener("input", () => {
        clearTimeout(timer);
        const q = input.value.trim();
        if (!q) { sug.style.display = "none"; return; }
        timer = setTimeout(async () => {
          try {
            const res = await PS.api.get(`/api/kb/search?q=${encodeURIComponent(q)}`);
            sug.innerHTML = res.results.length
              ? res.results.slice(0, 8).map((p) => `<div class="mini-slide" style="margin-bottom:4px" data-p="${p.id}"><div class="t">${PS.ui.esc(p.title)}</div><div class="x">${PS.ui.esc(p.chapterTitle || "")} · ${PS.ui.esc(p.textbookName || "")}</div></div>`).join("")
              : `<div class="empty" style="padding:14px">没有匹配结果</div>`;
            sug.style.display = "block";
            sug.querySelectorAll("[data-p]").forEach((el) => {
              el.onclick = () => { addPoint(el.dataset.p); input.value = ""; sug.style.display = "none"; };
            });
          } catch (e) {
            sug.style.display = "none";
          }
        }, 220);
      });
      document.addEventListener("click", (e) => {
        if (sug && !sug.contains(e.target) && e.target !== input) sug.style.display = "none";
      });

      document.querySelectorAll("#lv-chips .chip").forEach((c) => {
        c.onclick = () => {
          document.querySelectorAll("#lv-chips .chip").forEach((x) => x.classList.toggle("on", x === c));
          S.level = c.dataset.lv;
        };
      });

      $("ls-gen").onclick = async () => {
        if (!S.points.length) { PS.ui.toast("请先选择至少一个知识点", "err"); return; }
        const btn = $("ls-gen");
        btn.disabled = true;
        btn.innerHTML = `<span class="spinner"></span> 生成中`;
        try {
          const res = await PS.api.post("/api/lesson/generate", {
            pointIds: S.points.map((p) => p.id),
            profile: {
              classLevel: S.level || "中等",
              preScore: $("pre-score").value ? +$("pre-score").value : null,
              prior: $("prior").value.trim(),
              duration: +$("duration").value,
            },
            duration: +$("duration").value,
            style: $("style").value,
          });
          S.result = res;
          renderPlan(res.plan, res.id);
          PS.app.loadLibrary();
          PS.ui.toast("教案已生成", "ok");
        } catch (e) {
          PS.ui.toast(e.message, "err");
        } finally {
          btn.disabled = false;
          btn.textContent = "生成教案";
        }
      };

      }

    function renderPlan(plan, id) {
      const box = $("ls-result");
      if (!box) return;
      const m = plan.meta || {};
      box.innerHTML = `
        <div class="card">
          <div class="row-between" style="margin-bottom:14px">
            <div>
              <div class="eyebrow">${PS.ui.esc(m.textbook || "")} · ${PS.ui.esc(m.chapter || "")}</div>
              <h2>${PS.ui.esc(plan.title)}</h2>
              <div class="row wrap" style="gap:6px;margin-top:8px">
                <span class="pill pill-accent">${PS.ui.esc(m.classLevel || "中等")}班</span>
                <span class="pill">${m.duration} 分钟</span>
                <span class="pill">${PS.ui.esc(m.style || "")}</span>
                <span class="pill pill-violet">${plan.pointIds.length} 个知识点</span>
              </div>
            </div>
            <div class="row wrap" style="gap:8px">
              <button class="btn btn-sm" id="ls-docx">${PS.ui.icon("download", 14)} 导出 DOCX</button>
              <button class="btn btn-sm btn-primary" id="ls-todeck">${PS.ui.icon("slides", 14)} 生成课件</button>
            </div>
          </div>
          <div class="grid g2" style="gap:14px">
            <div>
              <div class="pill pill-accent" style="margin-bottom:8px">教学目标</div>
              ${plan.objectives.map((o) => `<div class="list-item"><b style="font-size:11.5px;color:var(--accent-2);min-width:64px">${PS.ui.esc(o.dim)}</b><span style="font-size:12px">${PS.ui.esc(o.text)}</span></div>`).join("")}
              <div class="pill pill-green" style="margin:14px 0 8px">教学重点</div>
              <ul class="bullets">${plan.keyPoints.map((k) => `<li style="font-size:12.5px">${PS.ui.esc(k)}</li>`).join("")}</ul>
              <div class="pill pill-amber" style="margin:14px 0 8px">教学难点</div>
              <ul class="bullets">${plan.hardPoints.map((k) => `<li style="font-size:12.5px">${PS.ui.esc(k)}</li>`).join("")}</ul>
            </div>
            <div>
              <div class="pill" style="margin-bottom:8px">学情分析与对策</div>
              <div class="card-flat" style="font-size:12px;color:var(--muted);line-height:1.7">
                ${plan.studentAnalysis.gaps.map((g) => "· " + PS.ui.esc(g)).join("<br>") || "· 无明显前概念障碍"}
                <div class="hr"></div>
                ${plan.studentAnalysis.strategies.map((s) => "→ " + PS.ui.esc(s)).join("<br>")}
              </div>
              <div class="pill" style="margin:14px 0 8px">板书设计</div>
              <div class="card-flat" style="font-size:11.5px;line-height:1.75;font-family:var(--mono)">
                <b style="color:var(--accent)">${PS.ui.esc(plan.board.title)}</b><br>
                ${plan.board.blocks.map((b) => `<span style="color:var(--accent-2)">【${PS.ui.esc(b.label)}】</span> ${b.lines.filter(Boolean).map((l) => PS.ui.esc(l)).join("；")}`).join("<br>")}
              </div>
            </div>
          </div>

          <div class="hr"></div>
          <h3 style="margin-bottom:10px">教学过程</h3>
          <div class="list">
            ${plan.process.map((p, i) => `<div class="list-item" style="align-items:flex-start">
              <span class="idx" style="min-width:52px">${String(i + 1).padStart(2, "0")} · ${p.minutes}′</span>
              <div class="grow"><b style="font-size:12.5px">${PS.ui.esc(p.name)}</b>
                <div style="font-size:11.5px;color:var(--muted);margin-top:5px;line-height:1.65"><b style="color:#cbd9ea">教师</b> ${PS.ui.esc(p.teacher)}</div>
                <div style="font-size:11.5px;color:var(--muted);margin-top:3px;line-height:1.65"><b style="color:#cbd9ea">学生</b> ${PS.ui.esc(p.student)}</div>
                <div style="font-size:11px;color:var(--dim);margin-top:3px">意图：${PS.ui.esc(p.intent)}</div>
              </div></div>`).join("")}
          </div>

          <div class="hr"></div>
          <div class="grid g3">
            ${[["基础层 · 必做", plan.homework.basic, "var(--green)"], ["提高层 · 选做", plan.homework.improve, "var(--accent)"], ["拓展层 · 挑战", plan.homework.extend, "var(--accent-2)"]]
              .map(([t, items, c]) => `<div class="tier" style="border-color:${c}33"><h4 style="color:${c}">${t}</h4><ul class="bullets">${items.map((x) => `<li style="font-size:11.5px">${PS.ui.esc(x)}</li>`).join("")}</ul></div>`)
              .join("")}
          </div>

          <div class="hr"></div>
          <div class="grid g2">
            <div><div class="pill pill-violet" style="margin-bottom:8px">教学评价</div>
              <ul class="bullets">${plan.assessment.observations.map((o) => `<li style="font-size:12px">${PS.ui.esc(o)}</li>`).join("")}</ul>
              <div class="dim" style="font-size:11px;margin-top:8px">评分：${plan.assessment.rubric.map((x) => PS.ui.esc(x)).join(" ｜ ")}</div>
            </div>
            <div><div class="pill pill-accent" style="margin-bottom:8px">数字人讲稿</div>
              ${plan.narration.map((n) => `<div style="font-size:11.5px;color:var(--muted);margin-bottom:6px;line-height:1.6"><b style="color:var(--accent)">【${PS.ui.esc(n.scene)}】</b>${PS.ui.esc(n.text)}</div>`).join("")}
            </div>
          </div>
        </div>`;

      $("ls-docx").onclick = () => PS.api.download(`/api/lesson/${id}/docx`, `${plan.title}.docx`).catch((e) => PS.ui.toast(e.message, "err"));
      $("ls-todeck").onclick = async () => {
        try {
          PS.ui.toast("正在生成课件…");
          const res = await PS.api.post("/api/deck/from-lesson", { lessonId: id, classLevel: m.classLevel });
          PS.app.go(`#/deck?open=${res.id}`);
        } catch (e) {
          PS.ui.toast(e.message, "err");
        }
      };
    }

    /* ---------- 优化 ---------- */
    function paintOpt() {
      const drop = $("ls-drop");
      const input = $("ls-file");
      const btn = $("ls-opt");
      function setFile(f) {
        S.file = f;
        $("ls-file-name").innerHTML = f ? `<div class="file-chip">${PS.ui.icon("doc", 15)}<span class="grow">${PS.ui.esc(f.name)}</span><span class="dim">${(f.size / 1024).toFixed(0)} KB</span></div>` : "";
        btn.disabled = !f;
      }
      drop.onclick = () => input.click();
      input.onchange = () => setFile(input.files[0]);
      ["dragover", "dragleave", "drop"].forEach((ev) =>
        drop.addEventListener(ev, (e) => {
          e.preventDefault();
          drop.classList.toggle("over", ev === "dragover");
          if (ev === "drop" && e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]);
        })
      );
      $("ls-demo-pdf").onclick = async () => {
        try {
          const res = await fetch("/api/sample/lesson-pdf");
          if (!res.ok) {
            const d = await res.json().catch(() => ({}));
            throw new Error(d.error || "示例 PDF 不可用");
          }
          const blob = await res.blob();
          setFile(new File([blob], "示例教案-凸透镜成像.pdf", { type: "application/pdf" }));
          PS.ui.toast("已载入示例 PDF", "ok");
        } catch (e) {
          PS.ui.toast(e.message, "err");
        }
      };
      $("ls-demo").onclick = async () => {
        try {
          const res = await fetch("/api/sample/lesson");
          const blob = await res.blob();
          setFile(new File([blob], "示例教案-凸透镜成像.docx", { type: blob.type }));
          PS.ui.toast("已载入示例教案", "ok");
        } catch (e) {
          PS.ui.toast("示例载入失败", "err");
        }
      };
      btn.onclick = async () => {
        if (!S.file) return;
        btn.disabled = true;
        btn.innerHTML = `<span class="spinner"></span> 诊断中`;
        try {
          const res = await PS.api.upload("/api/lesson/optimize", S.file);
          S.optResult = res;
          renderOpt(res);
          PS.app.loadLibrary();
        } catch (e) {
          PS.ui.toast(e.message, "err");
        } finally {
          btn.disabled = false;
          btn.textContent = "诊断并优化";
        }
      };
    }

    function renderOpt(res) {
      const box = $("ls-result");
      if (!box) return;
      const d = res.diagnosis;
      const plan = res.plan;
      box.innerHTML = `
        <div class="grid g-2-1" style="align-items:start">
          <div class="card">
            <div class="row-between" style="margin-bottom:12px">
              <div><div class="eyebrow">Diagnosis</div><h2>诊断结果</h2></div>
              <button class="btn btn-sm" id="opt-docx">${PS.ui.icon("download", 14)} 导出优化教案</button>
            </div>
            <div class="row" style="gap:26px;margin-bottom:16px">
              <div><div class="dim" style="font-size:11px">优化前</div><div class="diag-score" style="color:${PS.ui.scoreColor(d.scoreBefore)}">${d.scoreBefore}</div></div>
              <div style="font-size:22px;color:var(--dim);padding-top:14px">→</div>
              <div><div class="dim" style="font-size:11px">优化后</div><div class="diag-score" style="color:var(--green)">${d.scoreAfter}</div></div>
              <div class="grow" style="align-self:flex-end"><div class="dim" style="font-size:11.5px">共 ${d.issues.length} 条问题 · ${d.diffs.length} 项改动</div></div>
            </div>
            ${d.issues.map((i) => `<div class="issue sev-${PS.ui.esc(i.level)}"><b>[${PS.ui.esc(i.level)}] ${PS.ui.esc(i.title)}</b><p>${PS.ui.esc(i.evidence)}</p><p style="color:#cbd9ea">建议：${PS.ui.esc(i.fix)}</p></div>`).join("") || `<div class="empty">未发现明显问题</div>`}
            <div class="hr"></div>
            <div class="pill pill-accent" style="margin-bottom:8px">改动清单</div>
            ${d.diffs.map((x) => `<div class="list-item" style="align-items:flex-start"><div class="grow"><b style="font-size:12px">${PS.ui.esc(x.field)}</b>
              <div style="font-size:11px;color:var(--dim);margin-top:3px">原：${PS.ui.esc(String(x.before))}</div>
              <div style="font-size:11px;color:#bfe6ff;margin-top:2px">新：${PS.ui.esc(String(x.after))}</div>
              <div style="font-size:10.5px;color:var(--muted);margin-top:3px">理由：${PS.ui.esc(x.reason)}</div></div></div>`).join("")}
          </div>
          <div class="card" style="position:sticky;top:0">
            <div class="eyebrow">Optimized Plan</div>
            <h3 style="margin-bottom:10px">优化后教案</h3>
            <div class="card-flat" style="font-size:12px;line-height:1.8;max-height:520px;overflow-y:auto">
              <b style="color:#dff4ff">${PS.ui.esc(plan.title)}</b>
              <div class="dim" style="font-size:10.5px;margin-bottom:8px">${PS.ui.esc(plan.meta.textbook || "")} · ${PS.ui.esc(plan.meta.chapter || "")}</div>
              ${plan.objectives.map((o) => `<div style="margin-bottom:5px"><span style="color:var(--accent-2);font-size:10.5px">${PS.ui.esc(o.dim)}</span><br>${PS.ui.esc(o.text)}</div>`).join("")}
              <div class="hr"></div>
              ${plan.process.map((p) => `<div style="margin-bottom:6px"><b style="font-size:11.5px">${PS.ui.esc(p.name)} · ${p.minutes}′</b><div style="font-size:11px;color:var(--muted)">${PS.ui.esc(p.teacher)}</div></div>`).join("")}
            </div>
            <button class="btn btn-primary" style="width:100%;margin-top:12px" id="opt-todeck">用优化结果生成课件</button>
          </div>
        </div>`;

      $("opt-docx").onclick = () => PS.api.download(`/api/lesson/${res.id}/docx`, `${plan.title}.docx`).catch((e) => PS.ui.toast(e.message, "err"));
      $("opt-todeck").onclick = async () => {
        try {
          PS.ui.toast("正在生成课件…");
          const rr = await PS.api.post("/api/deck/from-lesson", { lessonId: res.id, classLevel: plan.meta.classLevel });
          PS.app.go(`#/deck?open=${rr.id}`);
        } catch (e) {
          PS.ui.toast(e.message, "err");
        }
      };
    }

    paint();
    if (S.tab === "generate") {
      bindGen();
      if (r.params.point) addPoint(r.params.point);
    }
    if (r.params.open) {
      try {
        const res = await PS.api.get(`/api/lesson/${r.params.open}`);
        S.tab = "generate";
        paint();
        S.result = res;
        renderPlan(res.plan, res.id);
      } catch (e) {}
    }
  },
};