/* 实验库 */
PS.views.labs = {
  title: "实验库",
  render() {
    return `
      <div class="page-head">
        <div>
          <div class="eyebrow">Physics Labs</div>
          <h1>中学物理实验库</h1>
          <div class="lead">覆盖人教版初中与高中教材的测量、探究、演示实验：器材、步骤、记录表、注意事项与常见错误，可直接生成实验课课件。</div>
        </div>
        <div class="row" id="lab-stats"><span class="pill">加载中…</span></div>
      </div>
      <div class="card tight" style="margin-bottom:16px">
        <div class="row wrap" style="gap:10px">
          <div class="seg" id="lab-stage">
            <button class="active" data-s="">全部</button><button data-s="初中">初中</button><button data-s="高中">高中</button>
          </div>
          <div class="chips" id="lab-types"></div>
          <input class="input" id="lab-search" placeholder="搜索：凸透镜、欧姆定律、打点计时器…" style="margin-left:auto;max-width:300px" />
        </div>
      </div>
      <div id="lab-list"></div>`;
  },
  async after() {
    const $ = (id) => document.getElementById(id);
    let all = [];
    const state = { stage: "", type: "", q: "" };
    const TYPE_ORDER = ["分组实验", "探究实验", "测量实验", "演示实验"];

    function pointTitle(pid) {
      const tree = PS.state.tree || [];
      for (const st of tree) {
        for (const tb of st.textbooks || []) {
          for (const ch of tb.chapters || []) {
            const p = (ch.points || []).find((x) => x.id === pid);
            if (p) return p.title;
          }
        }
      }
      return "";
    }

    function paintFilters() {
      const types = [...new Set(all.map((x) => x.type))].sort((a, b) => TYPE_ORDER.indexOf(a) - TYPE_ORDER.indexOf(b));
      $("lab-types").innerHTML =
        `<span class="chip ${state.type === "" ? "on" : ""}" data-t="">全部类型</span>` +
        types.map((t) => `<span class="chip ${state.type === t ? "on" : ""}" data-t="${t}">${PS.ui.esc(t)}</span>`).join("");
      $("lab-types").querySelectorAll("[data-t]").forEach((c) => {
        c.onclick = () => { state.type = c.dataset.t; paintFilters(); paintList(); };
      });
    }

    function filtered() {
      return all.filter(
        (it) =>
          (!state.stage || it.stage === state.stage) &&
          (!state.type || it.type === state.type) &&
          (!state.q || (it.title + it.chapter + (it.purpose || "") + (it.tags || []).join("")).toLowerCase().includes(state.q.toLowerCase()))
      );
    }

    function paintList() {
      const items = filtered();
      $("lab-list").innerHTML = `<div class="grid g3">${items
        .map(
          (it) => `<div class="card card-hover lab-card" data-id="${it.id}">
            <div class="row-between" style="margin-bottom:8px">
              <span class="pill ${it.stage === "高中" ? "pill-violet" : "pill-accent"}" style="font-size:9.5px">${PS.ui.esc(it.stage)}</span>
              <span class="pill" style="font-size:9.5px">${PS.ui.esc(it.type)}</span>
            </div>
            <h3 style="font-size:14px;line-height:1.45">${PS.ui.esc(it.title)}</h3>
            <div style="font-size:11.5px;color:var(--muted);margin-top:4px">${PS.ui.esc(it.chapter || "")}</div>
            <div style="font-size:11.5px;color:var(--muted);margin-top:8px;line-height:1.6;min-height:36px">${PS.ui.esc((it.purpose || "").slice(0, 46))}${(it.purpose || "").length > 46 ? "…" : ""}</div>
            <div class="row wrap" style="gap:5px;margin-top:8px">${(it.tags || []).slice(0, 3).map((t) => `<span class="pill" style="font-size:9.5px">${PS.ui.esc(t)}</span>`).join("")}</div>
            <div class="row" style="gap:8px;margin-top:12px;font-size:11px;color:var(--dim)">
              <span>${(it.apparatus || []).length} 件器材</span><span>·</span><span>${(it.steps || []).length} 步</span>
            </div>
          </div>`
        )
        .join("") || `<div class="empty">没有匹配的实验</div>`}</div>`;
      $("lab-list").querySelectorAll("[data-id]").forEach((c) => (c.onclick = () => open(c.dataset.id)));
    }

    function open(id) {
      const it = all.find((x) => x.id === id);
      if (!it) return;
      const sec = (t, items, cls) =>
        items && items.length
          ? `<div style="margin-bottom:14px"><div class="pill ${cls || ""}" style="font-size:9.5px;margin-bottom:6px">${t}</div>${
              Array.isArray(items) ? `<ul class="bullets">${items.map((x) => `<li style="font-size:12.5px">${PS.ui.esc(x)}</li>`).join("")}</ul>` : items
            }</div>`
          : "";
      const pid = (it.points || [])[0] || "";
      const body = `
        <div class="row wrap" style="gap:6px;margin-bottom:12px">
          <span class="pill pill-accent">${PS.ui.esc(it.stage)}</span>
          <span class="pill">${PS.ui.esc(it.textbook || "")}</span>
          <span class="pill">${PS.ui.esc(it.type)}</span>
        </div>
        <div class="card-flat" style="margin-bottom:14px;font-size:13px;line-height:1.8">${PS.ui.esc(it.purpose || "")}</div>
        ${sec("实验器材", it.apparatus, "pill-green")}
        ${sec("实验步骤", (it.steps || []).map((s, i) => `${i + 1}. ${s}`), "pill-accent")}
        ${sec("记录表", it.data && it.data.length ? `<div class="code">${it.data.map((c) => PS.ui.esc(c)).join(" | ")}</div>` : "", "pill-violet")}
        ${sec("注意事项", it.precautions, "pill-amber")}
        ${sec("常见错误", it.errors, "pill-red")}
        <div class="row wrap" style="gap:8px;margin-top:18px">
          ${pid ? `<button class="btn btn-primary" id="lab-deck">生成实验课课件</button>` : ""}
          ${pid ? `<button class="btn" id="lab-point">查看关联知识点</button>` : ""}
        </div>`;
      const d = PS.ui.drawer(it.title, "实验详情", body);
      if (pid) {
        const b = document.getElementById("lab-deck");
        if (b) b.onclick = () => { d.close(); PS.app.go(`#/deck?point=${pid}`); };
        const p = document.getElementById("lab-point");
        if (p) p.onclick = () => { d.close(); PS.app.go(`#/kb`); };
      }
    }

    try {
      const data = await PS.api.get("/api/labs");
      all = data.items || [];
      const st = data.stats || {};
      $("lab-stats").innerHTML = `<span class="pill pill-accent">${st.total} 个实验</span><span class="pill pill-violet">${(st.byType && st.byType["探究实验"]) || 0} 个探究</span>`;
      paintFilters();
      paintList();
    } catch (e) {
      $("lab-list").innerHTML = `<div class="empty">${PS.ui.esc(e.message)}</div>`;
    }

    document.querySelectorAll("#lab-stage button").forEach((b) => {
      b.onclick = () => {
        state.stage = b.dataset.s;
        document.querySelectorAll("#lab-stage button").forEach((x) => x.classList.toggle("active", x === b));
        paintList();
      };
    });
    $("lab-search").oninput = (e) => { state.q = e.target.value; paintList(); };
  },
};