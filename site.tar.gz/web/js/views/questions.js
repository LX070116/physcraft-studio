/* 题库：浏览、筛选、错题本、AI 讲解、同型练习、导出 */
PS.views.questions = {
  title: "题库",
  render() {
    return `
      <div class="page-head">
        <div>
          <div class="eyebrow">Question Bank</div>
          <h1>中学物理题库</h1>
          <div class="lead">按学段、题型、难度检索试题；查看解析与解题步骤、加入错题本、用同型题举一反三，并导出练习卷。</div>
        </div>
        <div class="row" id="q-stats"><span class="pill">加载中…</span></div>
      </div>
      <div class="card tight" style="margin-bottom:14px">
        <div class="row wrap" style="gap:10px">
          <div class="seg" id="q-tabs">
            <button class="active" data-t="all">题库</button>
            <button data-t="wrong">错题本 <b id="q-wrong-n">0</b></button>
          </div>
          <div class="seg" id="q-stage"><button class="active" data-s="">全部</button><button data-s="初中">初中</button><button data-s="高中">高中</button></div>
          <input class="input" id="q-search" placeholder="搜索题干、章节、标签…" style="max-width:260px" />
        </div>
        <div class="row wrap" style="gap:8px;margin-top:10px">
          <div class="chips" id="q-types"></div>
          <div class="chips" id="q-diffs"></div>
        </div>
      </div>
      <div class="row-between" style="margin-bottom:10px">
        <div class="row" style="gap:8px">
          <button class="btn btn-sm" id="q-selall">全选本页</button>
          <span class="dim" style="font-size:11px" id="q-selinfo">未选择</span>
        </div>
        <div class="row" style="gap:8px">
          <button class="btn btn-sm" id="q-exp-docx">导出选中 DOCX</button>
          <button class="btn btn-sm btn-primary" id="q-exp-pdf">导出选中 PDF</button>
        </div>
      </div>
      <div id="q-list"></div>`;
  },
  async after() {
    const $ = (id) => document.getElementById(id);
    const state = { tab: "all", stage: "", type: "", diff: "", q: "", selected: new Set() };
    let all = [];
    const TYPES = ["选择", "填空", "计算", "实验探究", "简答"];
    const DIFFS = ["1", "2", "3"];

    function wrongBook() {
      try { return JSON.parse(localStorage.getItem("ps.wrong") || "[]"); } catch (e) { return []; }
    }
    function saveWrong(list) {
      localStorage.setItem("ps.wrong", JSON.stringify(list.slice(0, 300)));
      $("q-wrong-n").textContent = String(list.length);
    }
    function toggleWrong(q, add) {
      let list = wrongBook();
      if (add) {
        if (!list.find((x) => x.id === q.id)) list.push(q);
      } else {
        list = list.filter((x) => x.id !== q.id);
      }
      saveWrong(list);
      PS.ui.toast(add ? "已加入错题本" : "已移出错题本", "ok");
    }

    function paintFilters() {
      $("q-types").innerHTML = `<span class="chip ${!state.type ? "on" : ""}" data-ty="">全部题型</span>` + TYPES.map((t) => `<span class="chip ${state.type === t ? "on" : ""}" data-ty="${t}">${t}</span>`).join("");
      $("q-types").querySelectorAll("[data-ty]").forEach((c) => (c.onclick = () => { state.type = c.dataset.ty; paintFilters(); paintList(); }));
      $("q-diffs").innerHTML = `<span class="chip ${!state.diff ? "on" : ""}" data-df="">全部难度</span>` + DIFFS.map((d) => `<span class="chip ${state.diff === d ? "on" : ""}" data-df="${d}">${"★".repeat(+d)}</span>`).join("");
      $("q-diffs").querySelectorAll("[data-df]").forEach((c) => (c.onclick = () => { state.diff = c.dataset.df; paintFilters(); paintList(); }));
    }

    function visible() {
      let items = state.tab === "wrong" ? wrongBook() : all;
      if (state.stage) items = items.filter((q) => q.stage === state.stage);
      if (state.type) items = items.filter((q) => q.type === state.type);
      if (state.diff) items = items.filter((q) => String(q.difficulty) === state.diff);
      if (state.q) {
        const w = state.q.toLowerCase();
        items = items.filter((q) => (q.stem + q.chapter + (q.tags || []).join("")).toLowerCase().includes(w));
      }
      return items;
    }

    function paintList() {
      const items = visible();
      $("q-list").innerHTML = items.length
        ? `<div class="grid g2" style="gap:12px">${items
            .map(
              (q) => `<div class="card tight" data-q="${q.id}" style="cursor:pointer">
                <div class="row-between" style="margin-bottom:6px">
                  <div class="row" style="gap:6px">
                    <input type="checkbox" data-sel="${q.id}" ${state.selected.has(q.id) ? "checked" : ""} style="accent-color:var(--accent)" />
                    <span class="pill ${q.stage === "高中" ? "pill-violet" : "pill-accent"}" style="font-size:9px">${q.stage}</span>
                    <span class="pill" style="font-size:9px">${q.type}</span>
                    <span class="pill pill-amber" style="font-size:9px">${"★".repeat(+q.difficulty || 1)}</span>
                  </div>
                  <span class="dim" style="font-size:10px">${PS.ui.esc(q.chapter || "")}</span>
                </div>
                <div style="font-size:12.5px;line-height:1.6">${PS.ui.esc(q.stem)}</div>
                <div class="row wrap" style="gap:5px;margin-top:8px">${(q.tags || []).slice(0, 3).map((t) => `<span class="pill" style="font-size:9px">${PS.ui.esc(t)}</span>`).join("")}</div>
              </div>`
            )
            .join("")}</div>`
        : `<div class="card"><div class="empty">${state.tab === "wrong" ? "错题本还是空的：在题目详情里点“加入错题本”" : "没有匹配的试题"}</div></div>`;
      $("q-list").querySelectorAll("[data-q]").forEach((card) => {
        card.onclick = (e) => {
          if (e.target.dataset.sel) return;
          openQ(card.dataset.q);
        };
      });
      $("q-list").querySelectorAll("[data-sel]").forEach((cb) => {
        cb.onclick = (e) => {
          e.stopPropagation();
          if (cb.checked) state.selected.add(cb.dataset.sel);
          else state.selected.delete(cb.dataset.sel);
          $("q-selinfo").textContent = state.selected.size ? `已选 ${state.selected.size} 题` : "未选择";
        };
      });
      $("q-selinfo").textContent = state.selected.size ? `已选 ${state.selected.size} 题` : "未选择";
    }

    async function openQ(qid) {
      const q = (state.tab === "wrong" ? wrongBook() : all).find((x) => x.id === qid);
      if (!q) return;
      const isWrong = !!wrongBook().find((x) => x.id === q.id);
      const body = `
        <div class="row wrap" style="gap:6px;margin-bottom:10px">
          <span class="pill pill-accent">${q.stage}</span><span class="pill">${q.type}</span>
          <span class="pill pill-amber">难度 ${"★".repeat(+q.difficulty || 1)}</span>
          <span class="pill">${PS.ui.esc(q.chapter || "")}</span>
        </div>
        <div class="card-flat" style="font-size:13.5px;line-height:1.8;margin-bottom:12px">${PS.ui.esc(q.stem)}</div>
        ${(q.options || []).length ? `<div class="col" style="gap:6px;margin-bottom:12px">${q.options.map((o) => `<div class="list-item" style="font-size:12.5px">${PS.ui.esc(o)}</div>`).join("")}</div>` : ""}
        <div class="row" style="gap:8px;margin-bottom:12px">
          <button class="btn btn-sm" id="q-show">显示答案</button>
          <button class="btn btn-sm" id="q-addwrong">${isWrong ? "移出错题本" : "加入错题本"}</button>
          <button class="btn btn-sm" id="q-say">数字人讲解</button>
        </div>
        <div id="q-answer" class="card-flat" style="display:none;font-size:13px;line-height:1.8"></div>
        <div style="margin-top:14px">
          <div class="row-between" style="margin-bottom:8px"><b style="font-size:12.5px">解析</b></div>
          <div style="font-size:12.5px;line-height:1.8;color:#d3e0f0">${PS.ui.esc((q.analysis || "—").replace(/^解析[:：]\s*/, ""))}</div>
          ${(q.solution || []).length ? `<div style="margin-top:10px;font-size:12px;color:var(--muted)">${q.solution.map((s, i) => `<div style="margin-bottom:5px"><b style="color:var(--accent-2)">${i + 1}.</b> ${PS.ui.esc(s)}</div>`).join("")}</div>` : ""}
        </div>
        <div class="hr"></div>
        <div class="row-between"><b style="font-size:12.5px">举一反三 · 同型练习</b><button class="btn btn-sm" id="q-sim">换一组</button></div>
        <div id="q-sim-list" style="margin-top:10px">${PS.ui.spinner("生成中…")}</div>`;
      const d = PS.ui.drawer("试题详情", q.id, body);
      $("q-show").onclick = () => {
        const box = $("q-answer");
        box.style.display = "block";
        box.innerHTML = `<b style="color:var(--green)">答案：</b>${PS.ui.esc(q.answer || "")}<br><b style="color:var(--accent)">解析：</b>${PS.ui.esc((q.analysis || "").replace(/^解析[:：]\s*/, ""))}`;
      };
      $("q-addwrong").onclick = () => {
        toggleWrong(q, !isWrong);
        d.close();
        paintList();
      };
      $("q-say").onclick = async () => {
        try {
          const ex = await PS.api.get(`/api/questions/${q.id}/explain`);
          speak(ex.script || ex.explanation);
        } catch (e) {
          PS.ui.toast(e.message, "err");
        }
      };
      let n = 0;
      async function loadSim() {
        try {
          const res = await PS.api.get(`/api/questions/${q.id}/similar`);
          $("q-sim-list").innerHTML = res.items
            .map(
              (it, i) => `<div class="list-item" style="align-items:flex-start"><span class="idx">${String(i + 1).padStart(2, "0")}</span>
                <div class="grow"><div style="font-size:12px;line-height:1.6">${PS.ui.esc(it.stem)}</div>
                <div style="font-size:11px;color:var(--muted);margin-top:4px">答案：${PS.ui.esc(it.answer || "")}　<span class="tag">${PS.ui.esc(it.source || "")}</span></div></div></div>`
            )
            .join("") || `<div class="dim" style="font-size:12px">暂无同型题</div>`;
        } catch (e) {
          $("q-sim-list").innerHTML = `<div class="dim" style="font-size:12px">${PS.ui.esc(e.message)}</div>`;
        }
      }
      loadSim();
      $("q-sim").onclick = loadSim;
    }

    function speak(text) {
      if (!("speechSynthesis" in window)) return PS.ui.toast("当前浏览器不支持语音", "err");
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      const vs = speechSynthesis.getVoices().filter((v) => /zh|cmn/i.test(v.lang));
      if (vs.length) u.voice = vs[0];
      u.lang = "zh-CN";
      u.rate = 1.02;
      speechSynthesis.speak(u);
      PS.ui.toast("数字人开始讲解", "ok");
    }

    // 初始化
    $("q-wrong-n").textContent = String(wrongBook().length);
    try {
      const data = await PS.api.get("/api/questions");
      all = data.items || [];
      const st = data.stats || {};
      $("q-stats").innerHTML = `<span class="pill pill-accent">${st.total} 道题</span><span class="pill pill-violet">${(st.byType && st.byType["计算"]) || 0} 道计算</span>`;
    } catch (e) {
      $("q-list").innerHTML = `<div class="empty">${PS.ui.esc(e.message)}</div>`;
    }
    paintFilters();
    paintList();

    $("q-tabs").querySelectorAll("button").forEach((b) => {
      b.onclick = () => {
        state.tab = b.dataset.t;
        $("q-tabs").querySelectorAll("button").forEach((x) => x.classList.toggle("active", x === b));
        paintList();
      };
    });
    $("q-stage").querySelectorAll("button").forEach((b) => {
      b.onclick = () => {
        state.stage = b.dataset.s;
        $("q-stage").querySelectorAll("button").forEach((x) => x.classList.toggle("active", x === b));
        paintList();
      };
    });
    $("q-search").oninput = (e) => { state.q = e.target.value; paintList(); };
    $("q-selall").onclick = () => {
      const items = visible();
      const allSel = items.every((q) => state.selected.has(q.id));
      items.forEach((q) => (allSel ? state.selected.delete(q.id) : state.selected.add(q.id)));
      paintList();
    };
    function exportSel(fmt) {
      const ids = [...state.selected];
      if (!ids.length) return PS.ui.toast("请先勾选试题", "err");
      PS.api.download(`/api/questions/export?ids=${ids.join(",")}&format=${fmt}`, `物理练习.${fmt}`).catch((e) => PS.ui.toast(e.message, "err"));
    }
    $("q-exp-docx").onclick = () => exportSel("docx");
    $("q-exp-pdf").onclick = () => exportSel("pdf");
  },
};