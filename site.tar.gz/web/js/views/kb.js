/* 教材知识库 */
PS.views.kb = {
  title: "教材知识库",
  render() {
    const data = PS.state.kb;
    if (!data) return PS.ui.spinner("正在载入知识库…");
    const tree = data.tree;
    const st = { stage: tree[0]?.stage || "初中", tb: tree[0]?.textbooks?.[0]?.id, chapter: null, q: "" };
    PS._kbState = st;
    return `
      <div class="page-head">
        <div>
          <div class="eyebrow">Knowledge Base</div>
          <h1>中学物理教材知识库</h1>
          <div class="lead">以人教版初中 / 高中教材为骨架，每个知识点标注重要度、难度、核心结论、重难点、常见误区与可用的仿真 / VR 资源。</div>
        </div>
        <div class="row">
          <span class="pill pill-accent">${data.stats.points} 个知识点</span>
          <span class="pill">${data.stats.textbooks} 册教材</span>
          <span class="pill pill-violet">${data.stats.chapters} 章</span>
        </div>
      </div>

      <div class="kb-layout">
        <div class="card tight">
          <div class="seg" id="kb-stage" style="width:100%;margin-bottom:10px">
            ${tree.map((s) => `<button data-stage="${s.stage}" class="${s.stage === st.stage ? "active" : ""}" style="flex:1">${s.stage}</button>`).join("")}
          </div>
          <div class="chips" id="kb-books" style="margin-bottom:10px"></div>
          <input class="input" id="kb-search" placeholder="搜索：浮力、欧姆定律、平抛…" style="margin-bottom:10px" />
          <div class="chapter-list" id="kb-chapters"></div>
        </div>
        <div id="kb-main"></div>
      </div>`;
  },
  async after() {
    const st = PS._kbState;
    const tree = PS.state.kb.tree;
    const $ = (id) => document.getElementById(id);

    function stageData() {
      return tree.find((s) => s.stage === st.stage) || tree[0];
    }
    function bookData() {
      const s = stageData();
      return (s.textbooks || []).find((t) => t.id === st.tb) || s.textbooks[0];
    }

    function paintBooks() {
      const s = stageData();
      $("kb-books").innerHTML = (s.textbooks || [])
        .map((t) => `<span class="chip ${t.id === st.tb ? "on" : ""}" data-tb="${t.id}">${PS.ui.esc(t.name.replace("人教版·", "").replace("人教版（2019）·", ""))}</span>`)
        .join("");
      $("kb-books").querySelectorAll("[data-tb]").forEach((c) => {
        c.onclick = () => {
          st.tb = c.dataset.tb;
          st.chapter = null;
          st.q = "";
          $("kb-search").value = "";
          paintBooks();
          paintChapters();
          paintMain();
        };
      });
    }

    function paintChapters() {
      const b = bookData();
      if (!st.chapter && b.chapters.length) st.chapter = b.chapters[0].id;
      $("kb-chapters").innerHTML = b.chapters
        .map(
          (c) => `<button class="chapter-btn ${c.id === st.chapter ? "active" : ""}" data-ch="${c.id}">
            <span class="no">${String(c.no).padStart(2, "0")}</span>
            <span>${PS.ui.esc(c.title.replace(/^第.+?章\s*/, ""))}<br><span class="dim" style="font-size:10.5px">${PS.ui.esc(c.theme || "")} · ${c.points.length} 个知识点</span></span>
          </button>`
        )
        .join("");
      $("kb-chapters").querySelectorAll("[data-ch]").forEach((btn) => {
        btn.onclick = () => {
          st.chapter = btn.dataset.ch;
          st.q = "";
          $("kb-search").value = "";
          paintChapters();
          paintMain();
        };
      });
    }

    function pointCard(p) {
      return `<div class="point-card" data-pid="${p.id}">
        <div class="row-between" style="margin-bottom:6px">
          <b style="font-size:13.5px">${PS.ui.esc(p.title)}</b>
          <span class="row" style="gap:8px">
            <span class="pill" style="font-size:9.5px">重要 ${PS.ui.dots(p.importance)}</span>
            <span class="pill" style="font-size:9.5px">难度 ${PS.ui.dots(p.difficulty, 3, "amber")}</span>
          </span>
        </div>
        <div style="font-size:12px;color:var(--muted);line-height:1.6">${PS.ui.esc(p.summary || "")}</div>
        <div class="row wrap" style="margin-top:9px;gap:5px">
          ${p.sim ? `<span class="pill pill-accent" style="font-size:9.5px">交互仿真</span>` : ""}
          ${p.vr ? `<span class="pill pill-violet" style="font-size:9.5px">VR 场景</span>` : ""}
          ${p.game ? `<span class="pill pill-amber" style="font-size:9.5px">知识游戏</span>` : ""}
        </div>
      </div>`;
    }

    function paintMain() {
      const b = bookData();
      const q = st.q.trim();
      if (q) {
        const all = [];
        b.chapters.forEach((c) => c.points.forEach((p) => all.push({ ...p, ch: c.title })));
        const hits = all.filter((p) => (p.title + p.summary).toLowerCase().includes(q.toLowerCase()));
        $("kb-main").innerHTML = `<div class="card"><div class="row-between" style="margin-bottom:12px"><h2>搜索“${PS.ui.esc(q)}”</h2><span class="pill">${hits.length} 个结果</span></div>
          <div class="grid g2">${hits.map(pointCard).join("") || `<div class="empty">没有匹配的知识点</div>`}</div></div>`;
      } else {
        const ch = b.chapters.find((c) => c.id === st.chapter) || b.chapters[0];
        if (!ch) {
          $("kb-main").innerHTML = `<div class="empty">该教材暂无章节数据</div>`;
          return;
        }
        $("kb-main").innerHTML = `
          <div class="card" style="margin-bottom:14px">
            <div class="row-between">
              <div>
                <div class="eyebrow">Chapter ${String(ch.no).padStart(2, "0")} · ${PS.ui.esc(b.name)}</div>
                <h1 style="font-size:22px">${PS.ui.esc(ch.title)}</h1>
                <div class="lead" style="margin-top:4px">${PS.ui.esc(ch.theme || "")} ｜ ${ch.points.length} 个知识点</div>
              </div>
              <button class="btn btn-sm" id="ch-plan">整章生成教案</button>
            </div>
          </div>
          <div class="grid g2">${ch.points.map(pointCard).join("")}</div>`;
        const btn = document.getElementById("ch-plan");
        if (btn) btn.onclick = () => PS.app.go(`#/lesson?point=${ch.points[0]?.id || ""}`);
      }
      $("kb-main").querySelectorAll("[data-pid]").forEach((el) => (el.onclick = () => openPoint(el.dataset.pid)));
    }

    async function openPoint(pid) {
      const body = PS.ui.spinner("载入知识点…");
      const d = PS.ui.drawer("知识点详情", "Knowledge Point", body);
      try {
        const p = await PS.api.get(`/api/kb/point/${pid}`);
        const sec = (t, items, cls) =>
          items && items.length
            ? `<div style="margin-bottom:16px"><div class="row" style="gap:6px;margin-bottom:7px"><span class="pill ${cls || ""}" style="font-size:9.5px">${t}</span></div><ul class="bullets">${items.map((x) => `<li style="font-size:12.5px">${PS.ui.esc(x)}</li>`).join("")}</ul></div>`
            : "";
        document.getElementById("drawer-body").innerHTML = `
          <div class="row wrap" style="gap:6px;margin-bottom:12px">
            <span class="pill pill-accent">${PS.ui.esc(p.stage)}</span>
            <span class="pill">${PS.ui.esc(p.textbookName)}</span>
            <span class="pill">${PS.ui.esc(p.chapterTitle)}</span>
            <span class="pill pill-amber">重要度 ${PS.ui.dots(p.importance)}</span>
            <span class="pill pill-violet">难度 ${PS.ui.dots(p.difficulty, 3, "amber")}</span>
          </div>
          <div class="card-flat" style="margin-bottom:16px;font-size:13px;line-height:1.8">${PS.ui.esc(p.summary)}</div>
          ${sec("核心结论", p.core, "pill-accent")}
          ${sec("教学重点", p.key, "pill-green")}
          ${sec("教学难点", p.hard, "pill-amber")}
          ${sec("常见误区", p.misconceptions, "pill-red")}
          ${p.formulas && p.formulas.length ? `<div style="margin-bottom:16px"><span class="pill pill-accent" style="font-size:9.5px">公式</span><div class="code" style="margin-top:8px">${p.formulas.map((f) => PS.ui.esc(f)).join("<br>")}</div></div>` : ""}
          ${sec("实验 / 探究", p.experiments, "pill-violet")}
          <div class="row wrap" style="gap:6px;margin-bottom:16px">
            ${p.sim ? `<span class="pill pill-accent">仿真：${p.sim}</span>` : ""}
            ${p.vr ? `<span class="pill pill-violet">VR：${p.vr}</span>` : ""}
            ${p.game ? `<span class="pill pill-amber">游戏：${p.game}</span>` : ""}
            ${(p.tags || []).map((t) => `<span class="pill">${PS.ui.esc(t)}</span>`).join("")}
          </div>
          ${p.related && p.related.length ? `<div style="margin-bottom:8px"><div class="dim" style="font-size:11px;margin-bottom:6px">相关知识点</div><div class="chips">${p.related.map((r) => `<span class="chip" data-rel="${r.id}">${PS.ui.esc(r.title)}</span>`).join("")}</div></div>` : ""}
          <div class="row" style="margin-top:20px;gap:8px">
            <button class="btn btn-primary" id="p-plan">用此知识点生成教案</button>
            <button class="btn" id="p-deck">直接生成课件</button>
          </div>`;
        document.getElementById("p-plan").onclick = () => { d.close(); PS.app.go(`#/lesson?point=${p.id}`); };
        document.getElementById("p-deck").onclick = () => { d.close(); PS.app.go(`#/deck?point=${p.id}`); };
        document.querySelectorAll("[data-rel]").forEach((c) => (c.onclick = () => { d.close(); setTimeout(() => openPoint(c.dataset.rel), 260); }));
      } catch (e) {
        document.getElementById("drawer-body").innerHTML = `<div class="empty">${PS.ui.esc(e.message)}</div>`;
      }
    }

    document.querySelectorAll("#kb-stage button").forEach((b) => {
      b.onclick = () => {
        st.stage = b.dataset.stage;
        const s = stageData();
        st.tb = s.textbooks[0].id;
        st.chapter = null;
        st.q = "";
        $("kb-search").value = "";
        document.querySelectorAll("#kb-stage button").forEach((x) => x.classList.toggle("active", x === b));
        paintBooks();
        paintChapters();
        paintMain();
      };
    });
    $("kb-search").addEventListener("input", (e) => {
      st.q = e.target.value;
      paintMain();
    });

    paintBooks();
    paintChapters();
    paintMain();
  },
};