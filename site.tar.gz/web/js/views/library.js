/* 我的课堂：生成结果列表 */
PS.views.library = {
  title: "我的课堂",
  render() {
    const lib = PS.state.library || { decks: [], lessons: [] };
    return `
      <div class="page-head">
        <div>
          <div class="eyebrow">Library</div>
          <h1>我的课堂</h1>
          <div class="lead">平台生成的所有教案与课件都保存在本地 data/out，可随时打开、导出或重新优化。</div>
        </div>
        <div class="row"><span class="pill pill-accent">${lib.decks.length} 个课件</span><span class="pill pill-violet">${lib.lessons.length} 份教案</span></div>
      </div>
      <div class="seg" id="lib-tabs" style="margin-bottom:16px">
        <button class="active" data-t="deck">课件</button>
        <button data-t="lesson">教案</button>
      </div>
      <div id="lib-list"></div>`;
  },
  async after() {
    const lib = PS.state.library || { decks: [], lessons: [] };
    let tab = "deck";
    const list = document.getElementById("lib-list");
    function paint() {
      const items = tab === "deck" ? lib.decks : lib.lessons;
      if (!items.length) {
        list.innerHTML = `<div class="card"><div class="empty">${PS.ui.icon("spark")}<div>还没有${tab === "deck" ? "课件" : "教案"}</div><div class="dim" style="font-size:11px;margin-top:6px">去${tab === "deck" ? "课件工坊" : "教案工坊"}生成一个吧</div></div></div>`;
        return;
      }
      list.innerHTML = `<div class="grid g3">${items
        .map(
          (it) => `<div class="card card-hover" data-id="${it.id}">
            <div class="row-between" style="margin-bottom:8px">
              <span class="pill ${tab === "deck" ? "pill-accent" : "pill-violet"}" style="font-size:9.5px">${PS.ui.esc(it.kindLabel || (tab === "deck" ? "课件" : "教案"))}</span>
              <span class="dim" style="font-size:10px">${PS.ui.esc(it.created || "")}</span>
            </div>
            <h3 style="font-size:14px;line-height:1.45">${PS.ui.esc(it.title)}</h3>
            <div style="font-size:11.5px;color:var(--muted);margin-top:5px">${PS.ui.esc(it.subtitle || "")}</div>
            <div class="row wrap" style="gap:5px;margin-top:10px">
              ${(it.tags || []).map((t) => `<span class="pill" style="font-size:9.5px">${PS.ui.esc(t)}</span>`).join("")}
            </div>
            <div class="row" style="gap:8px;margin-top:14px">
              <button class="btn btn-sm btn-primary" data-open="${it.id}">${tab === "deck" ? "打开课堂" : "查看教案"}</button>
              <button class="btn btn-sm" data-dl="${it.id}">${PS.ui.icon("download", 13)} 导出</button>
            </div>
          </div>`
        )
        .join("")}</div>`;

      list.querySelectorAll("[data-open]").forEach((b) => {
        b.onclick = (e) => {
          e.stopPropagation();
          location.hash = tab === "deck" ? `#/play/${b.dataset.open}` : `#/lesson?open=${b.dataset.open}`;
        };
      });
      list.querySelectorAll("[data-dl]").forEach((b) => {
        b.onclick = (e) => {
          e.stopPropagation();
          const url = tab === "deck" ? `/api/deck/${b.dataset.dl}/pptx` : `/api/lesson/${b.dataset.dl}/docx`;
          PS.api.download(url, "export").catch((err) => PS.ui.toast(err.message, "err"));
        };
      });
      list.querySelectorAll("[data-id]").forEach((c) => {
        c.onclick = () => (location.hash = tab === "deck" ? `#/play/${c.dataset.id}` : `#/lesson?open=${c.dataset.id}`);
      });
    }
    document.querySelectorAll("#lib-tabs button").forEach((b) => {
      b.onclick = () => {
        tab = b.dataset.t;
        document.querySelectorAll("#lib-tabs button").forEach((x) => x.classList.toggle("active", x === b));
        paint();
      };
    });
    paint();
  },
};