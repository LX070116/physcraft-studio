/* 课件工坊：生成 / 优化 */
PS.views.deck = {
  title: "课件工坊",
  render(r) {
    const tab = r.params.tab === "optimize" ? "optimize" : r.params.tab === "convert" ? "convert" : "generate";
    PS._deck = { tab, file: null, result: null, optResult: null, point: r.params.point || "" };
    return `
      <div class="page-head">
        <div>
          <div class="eyebrow">Courseware Studio</div>
          <h1>课件工坊</h1>
          <div class="lead">上传教案 → 解析重难点与学情 → 生成含交互仿真、VR 实验、物理闯关、数字人与立体课本的课件；或上传原版 PPT 做结构优化。</div>
        </div>
        <div class="seg" id="dk-tabs">
          <button data-tab="generate" class="${tab === "generate" ? "active" : ""}">生成 PPT</button>
          <button data-tab="optimize" class="${tab === "optimize" ? "active" : ""}">优化 PPT</button>
          <button data-tab="convert" class="${tab === "convert" ? "active" : ""}">PDF 转 DOCX</button>
        </div>
      </div>
      <div id="dk-body"></div>`;
  },
  async after(r) {
    const S = PS._deck;
    const $ = (id) => document.getElementById(id);

    document.querySelectorAll("#dk-tabs button").forEach((b) => {
      b.onclick = () => {
        document.querySelectorAll("#dk-tabs button").forEach((x) => x.classList.toggle("active", x === b));
        S.tab = b.dataset.tab;
        paint();
      };
    });

    function paint() {
      $("dk-body").innerHTML = S.tab === "generate" ? genForm() : S.tab === "optimize" ? optForm() : convertForm();
      if (S.tab === "generate") paintGen();
      else if (S.tab === "optimize") paintOpt();
      else paintConvert();
      if (S.result && S.tab === "generate") renderDeck(S.result);
      if (S.optResult && S.tab === "optimize") renderDeck(S.optResult.deck, S.optResult.diagnosis);
      if (S.convResult && S.tab === "convert") renderConvert(S.convResult);
    }

    function genForm() {
      return `
        <div class="grid g2" style="align-items:start">
          <div class="card">
            <h2 style="margin-bottom:6px">上传教案，生成课件</h2>
            <div class="lead" style="margin-bottom:14px">解析教案中的教学重难点与学情分析，匹配教材知识库，生成与目标一致的课件。</div>
            <div class="drop" id="dk-drop">
              <div class="drop-icon">${PS.ui.icon("upload")}</div>
              <b>点击选择或拖拽教案文件</b>
              <small>.docx / .pdf / .txt / .md</small>
              <input type="file" id="dk-file" accept=".docx,.pdf,.txt,.md,.markdown" style="display:none" />
            </div>
            <div id="dk-file-name" style="margin-top:10px"></div>

            <div class="hr"></div>
            <div class="row wrap" style="gap:8px">
              <button class="btn btn-primary" id="dk-gen" disabled>生成课件</button>
              <button class="btn btn-ghost btn-sm" id="dk-demo">载入示例教案</button>
              <button class="btn btn-ghost btn-sm" id="dk-demo-pdf">载入示例 PDF</button>
            </div>

            <div class="hr"></div>
            <div class="field-label"><b>没有教案？按知识点直接生成</b></div>
            <div class="row" style="gap:8px">
              <input class="input" id="dk-point" placeholder="知识点 ID 或标题" style="flex:1" ${S.point ? `value="${PS.ui.esc(S.point)}"` : ""} />
              <button class="btn btn-sm" id="dk-point-btn">生成</button>
            </div>
            <div class="dim" style="font-size:11px;margin-top:6px">提示：可从知识库详情页点击“直接生成课件”。</div>
          </div>

          <div class="card">
            <div class="eyebrow">生成逻辑</div>
            <h3 style="margin-bottom:12px">从教案到课件的 5 步映射</h3>
            <div class="list">
              ${[
                ["解析教案", "目标 / 重难点 / 学情 / 过程 / 作业"],
                ["匹配知识库", "课题关键词 → 教材知识点 + 课标要求"],
                ["确定主线", "重难点决定页面顺序与讲解密度"],
                ["插入互动", "仿真 / VR / 数字人 / 立体课本按知识点映射"],
                ["导出", "PPTX（含讲稿备注）+ 单文件交互课件"],
              ].map(([a, b], i) => `<div class="list-item"><span class="idx">${String(i + 1).padStart(2, "0")}</span><div><b style="font-size:12.5px">${a}</b><div class="dim" style="font-size:11px">${b}</div></div></div>`).join("")}
            </div>
            <div class="hr"></div>
            <div class="row wrap" style="gap:6px">
              <span class="pill pill-accent">交互仿真</span><span class="pill pill-violet">VR 场景</span>
              <span class="pill pill-green">数字人</span><span class="pill pill-amber">立体课本</span>
            </div>
          </div>
        </div>
        <div id="dk-result" style="margin-top:18px"></div>`;
    }

    function optForm() {
      return `
        <div class="grid g2" style="align-items:start">
          <div class="card">
            <h2 style="margin-bottom:6px">上传原版 PPT</h2>
            <div class="lead" style="margin-bottom:14px">逐页解析文字量、字号、图片与结构，诊断认知负荷与教学闭环，保留原课件要点后重构。</div>
            <div class="drop" id="dk-drop">
              <div class="drop-icon">${PS.ui.icon("upload")}</div>
              <b>点击选择或拖拽 PPT 文件</b>
              <small>.pptx（建议 10–40 页）</small>
              <input type="file" id="dk-file" accept=".pptx" style="display:none" />
            </div>
            <div id="dk-file-name" style="margin-top:10px"></div>
            <div class="row" style="margin-top:14px;gap:8px">
              <button class="btn btn-primary" id="dk-opt" disabled>诊断并优化</button>
              <button class="btn btn-ghost btn-sm" id="dk-demo-ppt">载入示例 PPT</button>
            </div>
          </div>
          <div class="card">
            <div class="eyebrow">诊断规则</div>
            <h3 style="margin-bottom:10px">课件体检 · 8 项</h3>
            <ul class="bullets">
              <li>页数是否支撑一节课的容量</li>
              <li>平均字数 / 单页字数是否过载</li>
              <li>最小字号是否满足后排可读</li>
              <li>是否缺少图示与可视化</li>
              <li>是否有探究 / 实验 / 互动</li>
              <li>目标、重难点是否显性</li>
              <li>例题、检测、小结、作业是否闭环</li>
              <li>页面比例是否符合 16:9</li>
            </ul>
            <div class="hr"></div>
            <div class="dim" style="font-size:11.5px;line-height:1.7">优化不是简单美化：会按“导入—概念—探究—例题—检测—小结”重排结构，并把原页面的要点迁移到对应的概念页。</div>
          </div>
        </div>
        <div id="dk-result" style="margin-top:18px"></div>`;
    }

    function bindUpload(inputId, dropId, fileNameId, btnId, cb) {
      const drop = $(dropId), input = $(inputId), btn = $(btnId);
      function setFile(f) {
        S.file = f;
        $(fileNameId).innerHTML = f ? `<div class="file-chip">${PS.ui.icon("slides", 15)}<span class="grow">${PS.ui.esc(f.name)}</span><span class="dim">${(f.size / 1024 / 1024).toFixed(2)} MB</span></div>` : "";
        btn.disabled = !f;
      }
      drop.onclick = () => input.click();
      input.onchange = () => setFile(input.files[0]);
      ["dragover", "dragleave", "drop"].forEach((ev) =>
        drop.addEventListener(ev, (e) => {
          e.preventDefault();
          drop.classList.toggle("over", ev === "dragover");
          if (ev === "drop" && e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]);
        })
      );
      return setFile;
    }

    function paintGen() {
      const setFile = bindUpload("dk-file", "dk-drop", "dk-file-name", "dk-gen");
      $("dk-demo-pdf").onclick = async () => {
        try {
          const res = await fetch("/api/sample/lesson-pdf");
          if (!res.ok) {
            const d = await res.json().catch(() => ({}));
            throw new Error(d.error || "示例 PDF 不可用");
          }
          const blob = await res.blob();
          setFile(new File([blob], "示例教案-凸透镜成像.pdf", { type: "application/pdf" }));
          PS.ui.toast("已载入示例 PDF", "ok");
        } catch (e) {
          PS.ui.toast(e.message, "err");
        }
      };
      $("dk-demo").onclick = async () => {
        try {
          const res = await fetch("/api/sample/lesson");
          const blob = await res.blob();
          setFile(new File([blob], "示例教案-凸透镜成像.docx", { type: blob.type }));
          PS.ui.toast("已载入示例教案", "ok");
        } catch (e) {
          PS.ui.toast("示例载入失败", "err");
        }
      };
      $("dk-gen").onclick = async () => {
        if (!S.file) return;
        const btn = $("dk-gen");
        btn.disabled = true;
        btn.innerHTML = `<span class="spinner"></span> 解析并生成`;
        try {
          const res = await PS.api.upload("/api/deck/generate", S.file);
          S.result = res;
          renderDeck(res);
          PS.app.loadLibrary();
          PS.ui.toast("课件已生成", "ok");
        } catch (e) {
          PS.ui.toast(e.message, "err");
        } finally {
          btn.disabled = false;
          btn.textContent = "生成课件";
        }
      };
      $("dk-point-btn").onclick = async () => {
        const q = $("dk-point").value.trim();
        if (!q) { PS.ui.toast("请输入知识点", "err"); return; }
        try {
          const res = await PS.api.post("/api/deck/from-point", { q, classLevel: "中等", duration: 45 });
          S.result = res;
          renderDeck(res);
          PS.app.loadLibrary();
        } catch (e) {
          PS.ui.toast(e.message, "err");
        }
      };
    }

    function paintOpt() {
      const setFile = bindUpload("dk-file", "dk-drop", "dk-file-name", "dk-opt");
      $("dk-demo-ppt").onclick = async () => {
        try {
          const res = await fetch("/api/sample/pptx");
          const blob = await res.blob();
          setFile(new File([blob], "示例-凸透镜成像(原版).pptx", { type: blob.type }));
          PS.ui.toast("已载入示例 PPT", "ok");
        } catch (e) {
          PS.ui.toast("示例载入失败", "err");
        }
      };
      $("dk-opt").onclick = async () => {
        if (!S.file) return;
        const btn = $("dk-opt");
        btn.disabled = true;
        btn.innerHTML = `<span class="spinner"></span> 诊断中`;
        try {
          const res = await PS.api.upload("/api/deck/optimize", S.file);
          S.optResult = res;
          renderDeck(res.deck, res.diagnosis);
          PS.app.loadLibrary();
          PS.ui.toast("优化完成", "ok");
        } catch (e) {
          PS.ui.toast(e.message, "err");
        } finally {
          btn.disabled = false;
          btn.textContent = "诊断并优化";
        }
      };
    }

    function convertForm() {
      return `
        <div class="grid g2" style="align-items:start">
          <div class="card">
            <h2 style="margin-bottom:6px">PDF 转 DOCX / 可复制文字 PDF</h2>
            <div class="lead" style="margin-bottom:14px">自动判断“文字版”与“扫描版”。扫描版会调用本机中文 OCR 识别，输出可编辑 DOCX 与可复制文字的 PDF。</div>
            <div class="drop" id="dkc-drop">
              <div class="drop-icon">${PS.ui.icon("upload")}</div>
              <b>点击选择或拖拽 PDF</b>
              <small>支持文字版与扫描版，单文件 ≤ 60 MB</small>
              <input type="file" id="dkc-file" accept=".pdf" style="display:none" />
            </div>
            <div id="dkc-file-name" style="margin-top:10px"></div>
            <div class="row wrap" style="margin-top:14px;gap:8px">
              <button class="btn btn-primary" id="dkc-run" disabled>开始转换</button>
              <button class="btn btn-ghost btn-sm" id="dkc-demo">载入扫描版示例</button>
            </div>
            <div id="dkc-progress" style="margin-top:12px"></div>
          </div>
          <div class="card">
            <div class="eyebrow">Working</div>
            <h3 style="margin-bottom:12px">三步完成</h3>
            <div class="list">
              <div class="list-item"><span class="idx">01</span><div><b style="font-size:12.5px">判断类型</b><div class="dim" style="font-size:11px">能抽出文字 → 文字版；抽不到 → 扫描版</div></div></div>
              <div class="list-item"><span class="idx">02</span><div><b style="font-size:12.5px">OCR / 抽取</b><div class="dim" style="font-size:11px">Windows 中文 OCR 逐页识别，或直接提取</div></div></div>
              <div class="list-item"><span class="idx">03</span><div><b style="font-size:12.5px">生成文件</b><div class="dim" style="font-size:11px">DOCX（可编辑）+ PDF（可复制）+ TXT</div></div></div>
            </div>
            <div class="hr"></div>
            <div class="dim" style="font-size:11.5px;line-height:1.7">提示：OCR 对清晰、端正的扫描件效果最好；低分辨率或倾斜页面可能有少量错字，可在 DOCX 中直接修改。转换结果还能一键生成课件。</div>
          </div>
        </div>
        <div id="dkc-result" style="margin-top:18px"></div>`;
    }

    function paintConvert() {
      const drop = $("dkc-drop"), input = $("dkc-file"), btn = $("dkc-run"), prog = $("dkc-progress");
      let file = null;
      function setFile(f) {
        file = f;
        $("dkc-file-name").innerHTML = f ? `<div class="file-chip">${PS.ui.icon("doc", 15)}<span class="grow">${PS.ui.esc(f.name)}</span><span class="dim">${(f.size / 1024 / 1024).toFixed(2)} MB</span></div>` : "";
        btn.disabled = !f;
      }
      drop.onclick = () => input.click();
      input.onchange = () => setFile(input.files[0]);
      ["dragover", "dragleave", "drop"].forEach((ev) =>
        drop.addEventListener(ev, (e) => {
          e.preventDefault();
          drop.classList.toggle("over", ev === "dragover");
          if (ev === "drop" && e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]);
        })
      );
      $("dkc-demo").onclick = async () => {
        try {
          const res = await fetch("/api/sample/scanned-pdf");
          if (!res.ok) throw new Error("示例不可用");
          const blob = await res.blob();
          setFile(new File([blob], "示例教案-扫描版.pdf", { type: "application/pdf" }));
          PS.ui.toast("已载入扫描版示例", "ok");
        } catch (e) {
          PS.ui.toast(e.message, "err");
        }
      };
      btn.onclick = async () => {
        if (!file) return;
        btn.disabled = true;
        prog.innerHTML = PS.ui.spinner("正在分析页面并识别文字（扫描件约 10~30 秒）…");
        try {
          const res = await PS.api.upload("/api/tools/pdf-convert", file);
          S.convResult = res;
          renderConvert(res);
          prog.innerHTML = "";
          PS.ui.toast(res.mode === "ocr" ? "OCR 完成" : "文字提取完成", "ok");
        } catch (e) {
          prog.innerHTML = `<div class="issue" style="border-left-color:var(--red)"><b>转换失败</b><p>${PS.ui.esc(e.message)}</p></div>`;
        } finally {
          btn.disabled = false;
        }
      };
    }

    function renderConvert(res) {
      const box = $("dkc-result");
      if (!box) return;
      const isOcr = res.mode === "ocr";
      box.innerHTML = `
        <div class="card">
          <div class="row-between wrap" style="gap:12px;margin-bottom:12px">
            <div>
              <div class="eyebrow">Converted</div>
              <h2>${isOcr ? "扫描版 → DOCX（OCR）" : "文字版 → DOCX"}</h2>
            </div>
            <div class="row wrap" style="gap:6px">
              <span class="pill ${isOcr ? "pill-amber" : "pill-green"}">${isOcr ? "扫描版 · OCR" : "文字版 · 直接提取"}</span>
              <span class="pill">${res.pages} 页</span>
              <span class="pill">${res.chars} 字</span>
            </div>
          </div>
          <div class="row wrap" style="gap:8px;margin-bottom:12px">
            <button class="btn btn-sm btn-primary" id="dkc-docx">${PS.ui.icon("download", 14)} 下载 DOCX</button>
            <button class="btn btn-sm" id="dkc-pdf">${PS.ui.icon("download", 14)} 下载可复制 PDF</button>
            <button class="btn btn-sm btn-violet" id="dkc-todeck">用该内容生成课件</button>
            <span class="dim" style="font-size:11px;align-self:center">${isOcr ? "OCR 结果建议校对后再用于正式课件" : "已保留原文结构"}</span>
          </div>
          <div class="code" style="max-height:280px;overflow:auto;white-space:pre-wrap;line-height:1.7">${PS.ui.esc(res.preview || "")}${res.preview && res.preview.length >= 600 ? "…" : ""}</div>
        </div>`;
      $("dkc-docx").onclick = () => PS.api.download(`/api/tools/${res.id}/docx`, "转换结果.docx").catch((e) => PS.ui.toast(e.message, "err"));
      $("dkc-pdf").onclick = () => PS.api.download(`/api/tools/${res.id}/pdf`, "转换结果-可复制.pdf").catch((e) => PS.ui.toast(e.message, "err"));
      $("dkc-todeck").onclick = async () => {
        try {
          PS.ui.toast("正在生成课件…");
          const deck = await PS.api.post("/api/deck/from-tool", { id: res.id });
          PS.app.go(`#/deck?open=${deck.id}`);
        } catch (e) {
          PS.ui.toast(e.message, "err");
        }
      };
    }

    function renderDeck(deck, diagnosis) {
      const box = $("dk-result");
      if (!box) return;
      const m = deck.meta || {};
      const a = deck.analysis || {};
      const scenes = deck.scenes || [];
      const isOpt = !!diagnosis;
      box.innerHTML = `
        <div class="card">
          <div class="row-between wrap" style="gap:14px;margin-bottom:14px">
            <div>
              <div class="eyebrow">${isOpt ? "Optimized Deck" : "Generated Deck"} · ${scenes.length} 页</div>
              <h2>${PS.ui.esc(m.title || "")}</h2>
              <div class="row wrap" style="gap:6px;margin-top:8px">
                <span class="pill pill-accent">${PS.ui.esc(m.textbook || "")}</span>
                <span class="pill">${PS.ui.esc(m.chapter || "")}</span>
                <span class="pill">${m.duration || 45} 分钟</span>
                <span class="pill pill-green">含 ${scenes.filter((s) => ["simulation", "vr", "game", "avatar", "book3d"].includes(s.type)).length} 个互动场景</span>
                ${isOpt ? `<span class="pill pill-amber">诊断 ${diagnosis.score} → 优化版</span>` : ""}
              </div>
            </div>
            <div class="row wrap" style="gap:8px">
              <button class="btn btn-sm btn-primary" id="dk-play">${PS.ui.icon("play", 14)} 打开课堂</button>
              <button class="btn btn-sm" id="dk-pptx">${PS.ui.icon("download", 14)} 导出 PPTX</button>
              <button class="btn btn-sm" id="dk-html">${PS.ui.icon("download", 14)} 交互课件</button>
              ${isOpt ? `<button class="btn btn-sm" id="dk-report">诊断报告</button>` : ""}
            </div>
          </div>

          <div class="grid g3" style="gap:10px;margin-bottom:16px">
            <div class="card-flat"><div class="dim" style="font-size:10.5px">教学重点</div>
              <ul class="bullets" style="margin-top:6px">${(a.keyPoints || []).slice(0, 2).map((x) => `<li style="font-size:11.5px">${PS.ui.esc(x)}</li>`).join("") || `<li class="dim" style="font-size:11.5px">见教案</li>`}</ul></div>
            <div class="card-flat"><div class="dim" style="font-size:10.5px">教学难点</div>
              <ul class="bullets" style="margin-top:6px">${(a.hardPoints || []).slice(0, 2).map((x) => `<li style="font-size:11.5px">${PS.ui.esc(x)}</li>`).join("") || `<li class="dim" style="font-size:11.5px">见教案</li>`}</ul></div>
            <div class="card-flat"><div class="dim" style="font-size:10.5px">学情</div>
              <div style="font-size:11.5px;margin-top:6px;line-height:1.6">${PS.ui.esc((a.student && a.student.level) || m.classLevel || "中等")}班 · ${PS.ui.esc(((a.student && a.student.gaps) || []).length)} 个认知障碍</div></div>
          </div>

          ${isOpt ? `<div class="grid g2" style="margin-bottom:14px">
            <div class="card-flat"><div class="row-between"><b style="font-size:12px">原课件诊断</b><span class="pill pill-amber">${diagnosis.score} 分</span></div>
              <div class="row" style="gap:16px;margin-top:8px;font-size:11px;color:var(--muted)">
                <span>${diagnosis.slideCount} 页</span><span>均 ${diagnosis.avgChars} 字/页</span><span>最小字号 ${diagnosis.minFont || "—"} pt</span><span>图片 ${diagnosis.images}</span>
              </div></div>
            <div class="card-flat"><div class="row-between"><b style="font-size:12px">主要问题</b><span class="pill pill-red">${diagnosis.issues.length} 项</span></div>
              <div style="margin-top:6px;font-size:11px;color:var(--muted);line-height:1.6">${diagnosis.issues.slice(0, 3).map((i) => "· " + PS.ui.esc(i.title)).join("<br>") || "无明显问题"}</div></div>
          </div>` : ""}

          <div class="thumb-list" id="dk-scenes">
            ${scenes.map((s, i) => `
              <div class="mini-slide" data-i="${i}" style="padding:10px">
                <div class="row-between" style="margin-bottom:4px">
                  <span class="pill" style="font-size:9px">${PS.ui.esc(sceneLabel(s.type))}</span>
                  <span class="dim" style="font-size:9.5px;font-family:var(--mono)">${String(i + 1).padStart(2, "0")}</span>
                </div>
                <div class="t" style="font-size:11.5px;line-height:1.4">${PS.ui.esc(s.title || "")}</div>
                <div class="x" style="font-size:10px">${PS.ui.esc((s.narration || "").slice(0, 28))}${(s.narration || "").length > 28 ? "…" : ""}</div>
              </div>`).join("")}
          </div>

          <div class="hr"></div>
          <div class="row-between wrap" style="gap:10px">
            <div class="dim" style="font-size:11px">点击任一页可在课堂中直接跳转；PPTX 的每页备注已写入数字人讲稿。</div>
            <div class="row" style="gap:8px">
              <button class="btn btn-sm btn-ghost" id="dk-regen">${PS.ui.icon("refresh", 13)} 重新生成</button>
              <a class="btn btn-sm btn-ghost" href="#/library">查看我的课堂</a>
            </div>
          </div>
        </div>`;

      $("dk-play").onclick = () => PS.app.go(`#/play/${deck.id}`);
      $("dk-pptx").onclick = () => PS.api.download(`/api/deck/${deck.id}/pptx`, `${m.title || "课件"}.pptx`).catch((e) => PS.ui.toast(e.message, "err"));
      $("dk-html").onclick = () => PS.api.download(`/api/deck/${deck.id}/html`, `${m.title || "课件"}-交互版.html`).catch((e) => PS.ui.toast(e.message, "err"));
      if (isOpt) $("dk-report").onclick = () => PS.api.download(`/api/deck/${deck.id}/report`, `诊断报告-${m.title || ""}.docx`).catch((e) => PS.ui.toast(e.message, "err"));
      $("dk-regen").onclick = () => {
        if (S.tab === "generate" && S.file) $("dk-gen").click();
        else if (S.tab === "optimize" && S.file) $("dk-opt").click();
        else PS.ui.toast("请重新选择文件");
      };
      $("dk-scenes").querySelectorAll("[data-i]").forEach((el) => {
        el.onclick = () => PS.app.go(`#/play/${deck.id}?s=${el.dataset.i}`);
      });
      S.currentDeck = deck;
    }

    function sceneLabel(t) {
      return { cover: "封面", objectives: "目标", hook: "情境", concept: "概念", formula: "公式", simulation: "仿真", vr: "VR", avatar: "数字人", book3d: "课本", example: "例题", quiz: "检测", summary: "小结", homework: "作业", report: "说明" }[t] || t;
    }

    paint();

    if (r.params.open) {
      try {
        const deck = await PS.api.get(`/api/deck/${r.params.open}`);
        S.tab = "generate";
        paint();
        S.result = deck;
        renderDeck(deck);
      } catch (e) {
        PS.ui.toast(e.message, "err");
      }
    } else if (S.point) {
      try {
        const res = await PS.api.post("/api/deck/from-point", { pointId: S.point, classLevel: "中等", duration: 45 });
        S.result = res;
        renderDeck(res);
      } catch (e) {}
    }
  },
};