/* 工作台 */
PS.views.home = {
  title: "工作台",
  render() {
    const st = (PS.state.kb && PS.state.kb.stats) || { points: "—", chapters: "—", simPoints: "—", vrPoints: "—" };
    const lib = PS.state.library || { decks: [], lessons: [] };
    return `
      <div class="hero">
        <div class="eyebrow">Secondary Development · Based on OpenMAIC</div>
        <h1>把一份教案，变成一堂<br>能动手、能环视、能开口的物理课</h1>
        <p class="lead" style="margin-top:12px;max-width:640px;color:var(--muted);font-size:13px">
          以中学物理教材知识库为底座，围绕“教学重难点 × 学情分析”生成或优化教案与课件；
          课件内生成交互仿真、VR 实验场景、物理闯关、数字人讲解与立体课本。
        </p>
        <div class="flow">
          <span class="flow-step">教材知识库</span><span class="flow-arrow">→</span>
          <span class="flow-step">教案（生成 / 优化）</span><span class="flow-arrow">→</span>
          <span class="flow-step">课件（生成 / 优化）</span><span class="flow-arrow">→</span>
          <span class="flow-step">课堂运行与导出</span>
        </div>
        <div class="row wrap" style="margin-top:22px">
          <a class="btn btn-primary btn-lg" href="#/deck">开始生成课件</a>
          <a class="btn btn-lg" href="#/lesson">生成教案</a>
          <a class="btn btn-lg btn-ghost" href="#/kb">浏览知识库</a>
        </div>
      </div>

      <div class="grid g4" style="margin-top:18px">
        <div class="stat a"><div class="n">${st.points}</div><div class="l">教材知识点</div></div>
        <div class="stat b"><div class="n">${st.chapters}</div><div class="l">章节 / 单元</div></div>
        <div class="stat c"><div class="n">${st.simPoints}</div><div class="l">可仿真知识点</div></div>
        <div class="stat d"><div class="n">${st.vrPoints}</div><div class="l">VR 场景映射</div></div>
      </div>

      <div class="grid g4" style="margin-top:18px">
        <div class="action-card" onclick="PS.app.go('#/kb')">
          <div class="ico" style="background:rgba(56,189,248,.12);color:var(--accent)">${PS.ui.icon("book")}</div>
          <h3>教材知识库</h3>
          <p>按学段 / 教材 / 章节检索知识点，查看课标要点、重难点、常见误区与实验建议。</p>
          <div class="go">进入知识库 ${PS.ui.icon("arrow", 13)}</div>
        </div>
        <div class="action-card" onclick="PS.app.go('#/lesson')">
          <div class="ico" style="background:rgba(167,139,250,.12);color:var(--accent-2)">${PS.ui.icon("doc")}</div>
          <h3>教案工坊</h3>
          <p>按知识点 + 学情画像生成六环节教案；上传旧教案做诊断与结构化优化。</p>
          <div class="go">生成 / 优化教案 ${PS.ui.icon("arrow", 13)}</div>
        </div>
        <div class="action-card" onclick="PS.app.go('#/deck')">
          <div class="ico" style="background:rgba(52,211,153,.12);color:var(--green)">${PS.ui.icon("slides")}</div>
          <h3>课件生成</h3>
          <p>上传教案，解析重难点与学情，生成含仿真 / VR / 数字人 / 立体课本的课件。</p>
          <div class="go">生成 PPT ${PS.ui.icon("arrow", 13)}</div>
        </div>
        <div class="action-card" onclick="PS.app.go('#/deck?tab=optimize')">
          <div class="ico" style="background:rgba(245,158,11,.12);color:var(--amber)">${PS.ui.icon("wand")}</div>
          <h3>课件优化</h3>
          <p>上传原版 PPT，做认知负荷与结构诊断，补齐互动场景并保留原有要点。</p>
          <div class="go">优化 PPT ${PS.ui.icon("arrow", 13)}</div>
        </div>
        <div class="action-card" onclick="PS.app.go('#/labs')">
          <div class="ico" style="background:rgba(251,113,133,.12);color:var(--red)">${PS.ui.icon("chart")}</div>
          <h3>实验库</h3>
          <p>中学物理测量 / 探究 / 演示实验：器材、步骤、记录表、注意事项与常见错误。</p>
          <div class="go">浏览实验 ${PS.ui.icon("arrow", 13)}</div>
        </div>
        <div class="action-card" onclick="PS.app.go('#/textbook')">
          <div class="ico" style="background:rgba(56,189,248,.12);color:var(--accent)">${PS.ui.icon("book")}</div>
          <h3>电子教材</h3>
          <p>导入官方教材 PDF 在线阅读并叠加章节重难点；也可下载平台编排的知识读本。</p>
          <div class="go">开始阅读 ${PS.ui.icon("arrow", 13)}</div>
        </div>
        <div class="action-card" onclick="PS.app.go('#/questions')">
          <div class="ico" style="background:rgba(167,139,250,.12);color:var(--accent-2)">${PS.ui.icon("target")}</div>
          <h3>题库</h3>
          <p>按学段 / 题型 / 难度检索试题，查看解析、加入错题本、举一反三并导出练习卷。</p>
          <div class="go">去刷题 ${PS.ui.icon("arrow", 13)}</div>
        </div>
      </div>

      <div class="grid g-2-1" style="margin-top:24px;align-items:start">
        <div class="card">
          <div class="row-between" style="margin-bottom:12px"><h2>课件内生成的四类互动</h2><span class="pill pill-accent">OpenMAIC 场景范式</span></div>
          <div class="grid g2" style="gap:12px">
            ${[
              ["交互仿真", "9 个真实物理引擎控件：抛体、斜面、滑轮、透镜、电路、浮力、波动、力的合成、分子热运动。", "var(--accent)"],
              ["VR 实验场景", "4 个 360° 环视实验室：力学 / 电学 / 光学 / 磁场，热点可朗读、可答题。", "var(--accent-2)"],
              ["数字人教师", "SVG 数字人 + 浏览器语音合成，口型与字幕同步，承担难点微讲解。", "var(--green)"],
              ["立体课本", "CSS 3D 翻页课本，概念卡 / 公式卡 / 实验卡 / 易错卡四类页面。", "var(--amber)"],
              ["物理闯关", "抛体投篮、调焦成像、浮沉判断三个可通关游戏，把规律变成操作目标。", "var(--red)"],
            ]
              .map(
                ([t, d, c]) => `<div class="card-flat">
                  <div class="row" style="gap:8px;margin-bottom:6px"><span style="width:6px;height:6px;border-radius:50%;background:${c};box-shadow:0 0 8px ${c}"></span><b style="font-size:13px">${t}</b></div>
                  <div style="font-size:12px;color:var(--muted);line-height:1.65">${d}</div></div>`
              )
              .join("")}
          </div>
        </div>
        <div class="card">
          <div class="row-between" style="margin-bottom:10px"><h2>最近生成</h2><a class="btn btn-sm btn-ghost" href="#/library">全部</a></div>
          <div id="recent-list">
            ${
              (lib.decks || []).length || (lib.lessons || []).length
                ? [...(lib.decks || []).slice(0, 3).map((d) => ({ ...d, k: "deck" })), ...(lib.lessons || []).slice(0, 3).map((l) => ({ ...l, k: "lesson" }))]
                    .slice(0, 6)
                    .map(
                      (it) => `<div class="mini-slide" style="margin-bottom:8px" onclick="${it.k === "deck" ? `PS.app.go('#/play/${it.id}')` : `PS.app.go('#/lesson?open=${it.id}')`}">
                        <div class="row-between"><span class="t">${PS.ui.esc(it.title)}</span><span class="pill" style="font-size:9.5px">${it.k === "deck" ? "课件" : "教案"}</span></div>
                        <div class="x">${PS.ui.esc(it.subtitle || "")}</div></div>`
                    )
                    .join("")
                : `<div class="empty">${PS.ui.icon("spark")}<div>还没有生成记录</div><div class="dim" style="font-size:11px;margin-top:4px">从“课件工坊”上传一份教案开始</div></div>`
            }
          </div>
        </div>
      </div>`;
  },
};