/* 电子教材：官方教材（导入 PDF 阅读）+ 知识读本（自编） */
PS.views.textbook = {
  title: "电子教材",
  render() {
    return `
      <div class="page-head">
        <div>
          <div class="eyebrow">E-Textbook</div>
          <h1>电子教材</h1>
          <div class="lead">阅读你合法持有的官方教材 PDF（本地导入、逐页浏览、叠加章节重难点），或使用平台编排的知识读本；两者都可下载。</div>
        </div>
        <div class="seg" id="tb-tabs">
          <button class="active" data-m="official">官方教材</button>
          <button data-m="read">知识读本</button>
        </div>
      </div>
      <div id="tb-body"></div>`;
  },
  async after() {
    const $ = (id) => document.getElementById(id);
    let readData = null;
    let official = [];
    const state = { mode: "official", stage: "初中", book: 0, chapter: 0, viewer: null, page: 1, annBook: "", annChapter: 0 };

    document.querySelectorAll("#tb-tabs button").forEach((b) => {
      b.onclick = () => {
        state.mode = b.dataset.m;
        document.querySelectorAll("#tb-tabs button").forEach((x) => x.classList.toggle("active", x === b));
        paint();
      };
    });

    function paint() {
      if (state.mode === "official") {
        $("tb-body").innerHTML = officialHtml();
        bindOfficial();
      } else {
        $("tb-body").innerHTML = readHtml();
        bindRead();
      }
    }

    /* ---------------- 官方教材 ---------------- */
    function textbookOptions() {
      const opts = [];
      const tree = PS.state.tree || [];
      tree.forEach((st) => (st.textbooks || []).forEach((tb) => opts.push({ id: tb.id, name: tb.name, stage: st.stage })));
      return opts;
    }

    function officialHtml() {
      const opts = textbookOptions();
      return `
        <div class="grid g2" style="align-items:start;margin-bottom:16px">
          <div class="card">
            <h2 style="margin-bottom:6px">导入官方教材 PDF</h2>
            <div class="lead" style="margin-bottom:12px">平台不内置教材原文；导入你持有的 PDF 后，可在线阅读、逐页翻页，并在右侧叠加本章重难点与关键知识点。</div>
            <div class="drop" id="off-drop">
              <div class="drop-icon">${PS.ui.icon("upload")}</div>
              <b>选择教材 PDF</b>
              <small>支持任意页数；导入后本地保存，不上传云端</small>
              <input type="file" id="off-file" accept=".pdf" style="display:none" />
            </div>
            <div class="grid g2" style="margin-top:12px">
              <label class="field"><span class="field-label"><b>教材</b></span>
                <select class="select" id="off-book">
                  <option value="">不指定</option>
                  ${opts.map((o) => `<option value="${o.id}" data-stage="${o.stage}">${PS.ui.esc(o.name)}</option>`).join("")}
                </select>
              </label>
              <label class="field"><span class="field-label"><b>显示名称</b></span>
                <input class="input" id="off-title" placeholder="如 人教版八年级上册（我的副本）" />
              </label>
            </div>
            <div id="off-file-name" style="margin-bottom:10px"></div>
            <div class="row"><button class="btn btn-primary" id="off-upload" disabled>导入并建立索引</button><span class="dim" style="font-size:11px;margin-left:8px">导入时会逐页生成预览图，约 5~20 秒</span></div>
          </div>
          <div class="card">
            <div class="eyebrow">Copyright</div>
            <h3 style="margin-bottom:10px">关于教材原文</h3>
            <ul class="bullets">
              <li>平台不附带、不分发受版权保护的教材 PDF。</li>
              <li>请使用你已购买或获授权的电子版教材导入，仅在本机使用。</li>
              <li>导入的文件保存在 <code>data/textbooks/</code>，可随时删除。</li>
              <li>知识读本是平台自编要点整理，可自由下载。</li>
            </ul>
            <div class="hr"></div>
            <div class="dim" style="font-size:11.5px">已导入 <b id="off-count">${official.length}</b> 本教材</div>
          </div>
        </div>
        <div id="off-viewer"></div>
        <div id="off-list" class="grid g3">${official
          .map(
            (b) => `<div class="card card-hover" data-open="${b.id}">
              <div class="row-between" style="margin-bottom:8px"><span class="pill pill-accent" style="font-size:9.5px">${PS.ui.esc(b.stage || "教材")}</span><span class="dim" style="font-size:10px">${b.pages || 0} 页</span></div>
              <h3 style="font-size:14px;line-height:1.45">${PS.ui.esc(b.title)}</h3>
              <div style="font-size:11.5px;color:var(--muted);margin-top:4px">${PS.ui.esc((b.bookId || "").toUpperCase())} · ${(b.size / 1024 / 1024).toFixed(1)} MB</div>
              <div class="row" style="gap:8px;margin-top:12px"><button class="btn btn-sm btn-primary" data-open="${b.id}">阅读</button><button class="btn btn-sm" data-dl="${b.id}">下载</button></div>
            </div>`
          )
          .join("") || `<div class="empty" style="grid-column:1/-1">还没有导入教材</div>`}</div>`;
    }

    function bindOfficial() {
      const drop = $("off-drop"), input = $("off-file"), btn = $("off-upload");
      let file = null;
      function setFile(f) {
        file = f;
        $("off-file-name").innerHTML = f ? `<div class="file-chip">${PS.ui.icon("doc", 15)}<span class="grow">${PS.ui.esc(f.name)}</span><span class="dim">${(f.size / 1024 / 1024).toFixed(1)} MB</span></div>` : "";
        btn.disabled = !f;
        if (f && !$("off-title").value) $("off-title").value = f.name.replace(/\.pdf$/i, "");
      }
      drop.onclick = () => input.click();
      input.onchange = () => setFile(input.files[0]);
      ["dragover", "dragleave", "drop"].forEach((ev) =>
        drop.addEventListener(ev, (e) => {
          e.preventDefault();
          drop.classList.toggle("over", ev === "dragover");
          if (ev === "drop" && e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]);
        })
      );
      $("off-book").onchange = (e) => {
        const opt = e.target.selectedOptions[0];
        if (opt && opt.dataset.stage && !$("off-title").value) $("off-title").value = opt.textContent;
      };
      btn.onclick = async () => {
        if (!file) return;
        btn.disabled = true;
        btn.innerHTML = `<span class="spinner"></span> 导入并渲染页面…`;
        try {
          const bookId = $("off-book").value;
          const res = await PS.api.upload("/api/textbook/upload", file, file.name, {
            "X-Title": encodeURIComponent($("off-title").value || file.name.replace(/\.pdf$/i, "")),
            "X-Book-Id": bookId,
            "X-Stage": encodeURIComponent(($("off-book").selectedOptions[0] || {}).dataset?.stage || ""),
          });
          PS.ui.toast(`已导入：${res.pages} 页`, "ok");
          await loadOfficial();
          paint();
        } catch (e) {
          PS.ui.toast(e.message, "err");
          btn.disabled = false;
          btn.textContent = "导入并建立索引";
        }
      };
      $("off-list").querySelectorAll("[data-open]").forEach((el) => (el.onclick = (e) => { e.stopPropagation(); openViewer(el.dataset.open); }));
      $("off-list").querySelectorAll("[data-dl]").forEach((el) => (el.onclick = (e) => { e.stopPropagation(); PS.api.download(`/api/textbook/file/${el.dataset.dl}`, "教材.pdf").catch((err) => PS.ui.toast(err.message, "err")); }));
    }

    function openViewer(id) {
      const b = official.find((x) => x.id === id);
      if (!b) return;
      state.viewer = b;
      state.page = 1;
      const opts = textbookOptions();
      state.annBook = b.bookId || (opts[0] ? opts[0].id : "");
      state.annChapter = 0;
      renderViewer();
    }

    function renderViewer() {
      const b = state.viewer;
      if (!b) return;
      $("off-viewer").innerHTML = `
        <div class="card" style="margin-bottom:16px" id="off-vcard">
          <div class="row-between wrap" style="gap:10px;margin-bottom:10px">
            <div><div class="eyebrow">Reading</div><h2>${PS.ui.esc(b.title)}</h2></div>
            <div class="row wrap" style="gap:6px">
              <button class="btn btn-sm" id="off-prev">上一页</button>
              <span class="pill" id="off-page">${state.page} / ${b.pages || "?"}</span>
              <button class="btn btn-sm" id="off-next">下一页</button>
              <button class="btn btn-sm" id="off-dl2">下载原版</button>
              <button class="btn btn-sm btn-ghost" id="off-close">关闭</button>
            </div>
          </div>
          <div class="grid" style="grid-template-columns:minmax(0,1fr) 330px;gap:14px;align-items:start">
            <div style="border:1px solid var(--line);border-radius:12px;overflow:hidden;background:#fff;height:70vh">
              <iframe id="off-frame" src="/api/textbook/file/${b.id}#page=${state.page}&zoom=page-width" style="width:100%;height:100%;border:0"></iframe>
            </div>
            <div class="card-flat">
              <div class="field-label"><b>章节重难点</b></div>
              <select class="select" id="off-chapter" style="margin-bottom:10px"></select>
              <div id="off-ann" style="font-size:12px;line-height:1.7"></div>
            </div>
          </div>
        </div>`;
      const pager = (n) => {
        state.page = Math.max(1, Math.min(b.pages || 1, n));
        $("off-frame").src = `/api/textbook/file/${b.id}#page=${state.page}&zoom=page-width`;
        $("off-page").textContent = `${state.page} / ${b.pages || "?"}`;
      };
      $("off-prev").onclick = () => pager(state.page - 1);
      $("off-next").onclick = () => pager(state.page + 1);
      $("off-dl2").onclick = () => PS.api.download(`/api/textbook/file/${b.id}`, `${b.title}.pdf`).catch((e) => PS.ui.toast(e.message, "err"));
      $("off-close").onclick = () => { $("off-viewer").innerHTML = ""; state.viewer = null; };

      // 章节注记
      const book = (textbookOptions().find((x) => x.id === state.annBook) || {}).id;
      const chapters = [];
      (PS.state.tree || []).forEach((st) =>
        (st.textbooks || []).forEach((tb) => {
          if (tb.id !== book) return;
          (tb.chapters || []).forEach((ch) => chapters.push({ id: ch.id, title: ch.title, points: ch.points || [] }));
        })
      );
      const sel = $("off-chapter");
      sel.innerHTML = chapters.length
        ? chapters.map((c, i) => `<option value="${i}">${PS.ui.esc(c.title)}</option>`).join("")
        : `<option value="">（未指定教材）</option>`;
      function paintAnn() {
        const i = +sel.value;
        const ch = chapters[i];
        if (!ch) { $("off-ann").innerHTML = `<div class="dim">导入时选择对应教材，即可显示章节重难点。</div>`; return; }
        const rows = ch.points
          .map((p) => {
            const detail = (PS.state.kbPoints && PS.state.kbPoints[p.id]) || null;
            return `<div class="list-item" style="align-items:flex-start"><div><b style="font-size:12px">${PS.ui.esc(p.title)}</b>
              <div style="font-size:11px;color:var(--muted);margin-top:3px">${PS.ui.esc(p.summary || "")}</div>
              <div style="font-size:10.5px;color:var(--dim);margin-top:3px">重要 ${PS.ui.dots(p.importance)} · 难度 ${PS.ui.dots(p.difficulty, 3, "amber")}</div></div></div>`;
          })
          .join("");
        $("off-ann").innerHTML = `<div style="font-weight:700;margin-bottom:8px">${PS.ui.esc(ch.title)}</div>${rows || `<div class="dim">本章暂无标注</div>`}`;
      }
      sel.onchange = paintAnn;
      paintAnn();
    }

    async function loadOfficial() {
      try {
        const res = await PS.api.get("/api/textbook/library");
        official = res.books || [];
      } catch (e) {
        official = [];
      }
    }

    /* ---------------- 知识读本 ---------------- */
    function stageData() {
      return (readData.stages || []).find((s) => s.stage === state.stage) || { books: [], stats: {} };
    }
    function books() { return stageData().books || []; }
    function curBook() { return books()[state.book] || null; }
    function curChapter() { const b = curBook(); return b ? b.chapters[state.chapter] || null : null; }

    function readHtml() {
      const st = stageData().stats || {};
      return `
        <div class="row wrap" style="gap:10px;margin-bottom:16px">
          <div class="seg" id="tb-stage"><button class="${state.stage === "初中" ? "active" : ""}" data-s="初中">初中</button><button class="${state.stage === "高中" ? "active" : ""}" data-s="高中">高中</button></div>
          <span class="pill">${st.books || 0} 册 · ${st.chapters || 0} 章 · ${st.points || 0} 个知识点</span>
          <span class="pill pill-violet">${st.experiments || 0} 个实验已关联</span>
          <div class="row" style="margin-left:auto;gap:8px"><button class="btn btn-sm" id="tb-docx">下载 DOCX</button><button class="btn btn-sm btn-primary" id="tb-pdf">下载 PDF</button></div>
        </div>
        <div class="kb-layout" style="grid-template-columns:280px minmax(0,1fr)">
          <div class="card tight"><div class="dim" style="font-size:10.5px;letter-spacing:1.4px;margin-bottom:8px">目录 / CONTENTS</div><div class="chapter-list" id="tb-toc" style="max-height:calc(100vh - 280px)"></div></div>
          <div id="tb-reader"></div>
        </div>`;
    }

    function bindRead() {
      $("tb-toc").innerHTML = books()
        .map(
          (b, bi) =>
            `<div style="font-size:10.5px;color:var(--dim);padding:8px 10px 4px">${PS.ui.esc(b.name)}</div>` +
            b.chapters.map((c, ci) => `<button class="chapter-btn ${bi === state.book && ci === state.chapter ? "active" : ""}" data-b="${bi}" data-c="${ci}"><span class="no">${String(c.no).padStart(2, "0")}</span><span>${PS.ui.esc(c.title.replace(/^第.+?章\s*/, ""))}<br><span class="dim" style="font-size:10px">${c.points.length} 个知识点</span></span></button>`).join("")
        )
        .join("");
      $("tb-toc").querySelectorAll("[data-b]").forEach((btn) => {
        btn.onclick = () => { state.book = +btn.dataset.b; state.chapter = +btn.dataset.c; paint(); };
      });
      paintReader();
      $("tb-docx").onclick = () => PS.api.download(`/api/textbook/${state.stage}/docx`, `${state.stage}物理-电子教材.docx`).catch((e) => PS.ui.toast(e.message, "err"));
      $("tb-pdf").onclick = () => PS.api.download(`/api/textbook/${state.stage}/pdf`, `${state.stage}物理-电子教材.pdf`).catch((e) => PS.ui.toast(e.message, "err"));
      document.querySelectorAll("#tb-stage button").forEach((btn) => {
        btn.onclick = () => { state.stage = btn.dataset.s; state.book = 0; state.chapter = 0; paint(); };
      });
    }

    function paintReader() {
      const b = curBook(), c = curChapter();
      if (!b || !c) { $("tb-reader").innerHTML = `<div class="empty">暂无内容</div>`; return; }
      $("tb-reader").innerHTML = `
        <div class="card" style="margin-bottom:12px"><div class="row-between wrap" style="gap:10px"><div><div class="eyebrow">${PS.ui.esc(b.name)}</div><h1 style="font-size:24px">${PS.ui.esc(c.title)}</h1><div class="lead" style="margin-top:4px">${PS.ui.esc(c.theme || "")} ｜ ${c.points.length} 个知识点</div></div><div class="row" style="gap:6px"><button class="btn btn-sm" id="tb-prev">上一章</button><button class="btn btn-sm" id="tb-next">下一章</button></div></div></div>
        ${c.points
          .map(
            (p) => `<div class="card" style="margin-bottom:12px">
              <div class="row-between" style="margin-bottom:6px"><h3 style="font-size:15px">${PS.ui.esc(p.title)}</h3><span class="row" style="gap:6px"><span class="pill" style="font-size:9.5px">重要 ${PS.ui.dots(p.importance)}</span><span class="pill" style="font-size:9.5px">难度 ${PS.ui.dots(p.difficulty, 3, "amber")}</span></span></div>
              <div style="font-size:12.5px;color:var(--muted);line-height:1.75;margin-bottom:8px">${PS.ui.esc(p.summary)}</div>
              ${p.core && p.core.length ? `<ul class="bullets" style="margin-bottom:8px">${p.core.map((x) => `<li style="font-size:12.5px">${PS.ui.esc(x)}</li>`).join("")}</ul>` : ""}
              ${p.formulas && p.formulas.length ? `<div class="code" style="margin-bottom:8px">${p.formulas.map((f) => PS.ui.esc(f)).join("　　")}</div>` : ""}
              <div class="grid g2" style="gap:10px"><div style="font-size:11.5px;color:var(--muted)"><b style="color:var(--accent)">重点</b><br>${p.key.map((x) => PS.ui.esc(x)).join("；") || "—"}</div><div style="font-size:11.5px;color:var(--muted)"><b style="color:var(--amber)">难点</b><br>${p.hard.map((x) => PS.ui.esc(x)).join("；") || "—"}</div></div>
              ${p.misconceptions && p.misconceptions.length ? `<div style="margin-top:10px;font-size:11.5px;color:#e9c7c7"><b style="color:var(--red)">易错</b>　${p.misconceptions.map((m) => "× " + PS.ui.esc(m.replace("认为", ""))).join("　")}</div>` : ""}
              ${p.labTitles && p.labTitles.length ? `<div style="margin-top:8px;font-size:11.5px;color:var(--muted)"><b style="color:var(--accent-2)">实验</b>　${p.labTitles.map((x) => PS.ui.esc(x)).join("；")}</div>` : ""}
            </div>`
          )
          .join("")}`;
      $("tb-prev").onclick = () => nav(-1);
      $("tb-next").onclick = () => nav(1);
    }

    function nav(dir) {
      const b = curBook();
      if (!b) return;
      let bi = state.book, ci = state.chapter + dir;
      if (ci < 0) { bi--; if (bi < 0) return; ci = books()[bi].chapters.length - 1; }
      if (ci >= b.chapters.length) { bi++; if (bi >= books().length) return; ci = 0; }
      state.book = bi; state.chapter = ci; paint();
      document.getElementById("view").scrollTop = 0;
    }

    // 初始化
    try { readData = await PS.api.get("/api/textbook"); } catch (e) { readData = { stages: [] }; }
    await loadOfficial();
    paint();
  },
};